
--ADD Column For Asset Lobel Printing 

ALTER  ASSET_ACQUISITION  ADD ISLabelPrinted BIT ,  LabelPrintedBy VARCHAR(100) , LabelPrintedON DATETIME  ;

-------------------------

-- =============================================
-- Author:		Vinay kumar pandey
-- Create date: 25 SEPT 2019
-- Description:	Get All Parent of Child
-- =============================================
ALTER FUNCTION [dbo].[UDF_GetCategory]
(
	@CategoryCode VARCHAR(100) =''
)
RETURNS 
@AssetCategory Table(CategoryName VARCHAR(100))
	
AS
BEGIN

WITH X AS 
(
 SELECT T.* FROM CATEGORY_MASTER T  WHERE T.CATEGORY_CODE =@CategoryCode 
 UNION ALL 
 SELECT T.* FROM  X JOIN CATEGORY_MASTER T on t.CATEGORY_CODE =x.PARENT_CATEGORY 
)
Insert into @AssetCategory(CategoryName) SELECT X.CATEGORY_NAME FROM X Order by X.CATEGORY_LEVEL ASC  ;
	
	RETURN ;
END


---------------------------------------


-- =============================================
-- Author:		Vinay kumar pandey
-- Create date: 25 SEPT 2019
-- Description:	Get All Parent of Child
-- =============================================
CREATE FUNCTION [dbo].[UDF_GetCategoryCode]
(
	@CategoryCode VARCHAR(100) =''
)
RETURNS 
@AssetCategory Table(CategoryName VARCHAR(100) , CategoryCode Varchar(100) , CategoryLevel int )
	
AS
BEGIN

WITH X AS 
(
 SELECT T.* FROM CATEGORY_MASTER T  WHERE T.CATEGORY_CODE =@CategoryCode 
 UNION ALL 
 SELECT T.* FROM  X JOIN CATEGORY_MASTER T on t.PARENT_CATEGORY =x.CATEGORY_CODE
)
Insert into @AssetCategory(CategoryName , CategoryCode , CategoryLevel ) SELECT  X.CATEGORY_NAME ,X.CATEGORY_CODE , X.CATEGORY_LEVEL   FROM X Order by X.CATEGORY_LEVEL ASC  ;
	
	RETURN ;
END

---------------------------------------------------------


-- =============================================
-- Author:		Vinay Kumar Pandey
-- Create date:  25 SEPT 2019
-- Description:	 Get all location 
-- =============================================
CREATE FUNCTION  [dbo].[UDF_GetLocation]
(
@LocationCode VARCHAR(50)=''
)
RETURNS 
@AssetLocation Table (LocationName VARCHAR(50))
AS
BEGIN
	-- Fill the table variable with the rows for your result set
	

	WITH X AS 
(
 SELECT T.* FROM LOCATION_MASTER T  WHERE T.LOC_CODE =@LocationCode 
 UNION ALL 
 SELECT T.* FROM  X JOIN LOCATION_MASTER T on t.LOC_CODE =x.PARENT_LOC_CODE 
)
Insert into @AssetLocation(LocationName) SELECT X.LOC_NAME FROM X Order by x.LOC_LEVEL asc  ;
	
	RETURN ;


END

-----------------------------------------------


ALTER  PROC [dbo].[USP_SearchAssetForLabelPrinting]
 
  @AssetType VARCHAR(50) =''
, @AssetLocation VARCHAR(50) =''
, @AssetCategory VARCHAR(50)=''
, @AssetModel VARCHAR(50)=''
, @CategoryLevel int=0
, @PrintStatus bit =0
, @AssetApprove bit=0
, @AssetCode VARCHAR(max)=''
,@AssetMake VARCHAR(50)=''
,@CreatedFrom DateTime=NULL
,@CreatedTo DateTime =NULL

AS 
BEGIN 


SELECT  ROW_NUMBER () Over(Order by (SELECT 1))  AS [SerialNo],  T.* from ASSET_ACQUISITION  T 
 Left JOIN  CATEGORY_MASTER T1  ON T.CATEGORY_CODE =  T1.CATEGORY_CODE
 Inner JOIN( SELECT Distinct  item from   dbo.SplitString(@AssetCode ,',')) T3 on T.ASSET_CODE =ISNULL(NULLIF(RTRIM(LTRIM( T3.Item)),''),T.ASSET_CODE)  --NULLIF(RTRIM(LTRIM(T3.Item)),'')
 --ISNULL(NULLIF(RTRIM(LTRIM(T3.Item)),''),T.ASSET_CODE)

WHERE  
        (@AssetType='' OR  (T.ASSET_TYPE =@AssetType))
AND		(@AssetLocation ='' OR (T.LOCATION = @AssetLocation))
AND    (@AssetCategory=''  OR  T1.CATEGORY_CODE in ( SELECT CategoryCode FROM  dbo.UDF_GetCategoryCode(@AssetCategory))) --(COALESCE( NULLIF(T1.PARENT_CATEGORY,''),T1.CATEGORY_CODE)=@AssetCategory))
AND    (@AssetApprove =0 OR ( T.ASSET_APPROVED = @AssetApprove ))
--AND	   (@PrintStatus =0 OR (ISNULL(T.ISLabelPrinted,0) = @PrintStatus))
AND    (@AssetModel ='' OR(T.MODEL_NAME = @AssetModel))
AND    (@AssetMake ='' OR (T.ASSET_MAKE =@AssetMake))
--AND    (@CategoryLevel = 0 OR ( T1.CATEGORY_LEVEL<= @CategoryLevel)) 
AND ISNULL(T.ISLabelPrinted,0) =@PrintStatus
AND    ((@CreatedFrom IS NULL OR @CreatedTo IS NULL )  
OR  CAST(T.CREATED_ON AS DATE ) BETWEEN  CAST(@CreatedFrom AS DATE)  AND CAST(@CreatedTo AS DATE))


END 
