﻿using BCIL.User.BL.Permission;

namespace BCIL.WMS.Shell.Models
{
    public class LoginModel
    {
        public KeyValueCollection Sites { get; set; }
    }
}