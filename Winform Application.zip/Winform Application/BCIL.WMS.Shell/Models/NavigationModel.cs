﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;

namespace BCIL.WMS.Shell.Models
{
    public class MenuNode
    {
        public CustomMetroLink Contorl { get; set; }
        public string ID { get; set; }
        public string Parent { get; set; }
        public string Text { get; set; }
    }

    public class NavigationEventArg : EventArgs
    {
        public string NavigationKey { get; set; }
    }

    public class NavigationModel
    {
        public Dictionary<string, MenuNode> Nodes = new Dictionary<string, MenuNode>();
        public Dictionary<string, MenuNode> QuickNodes = new Dictionary<string, MenuNode>();
    }
    public class ScrollEventArg : EventArgs
    {
        public bool Isscrollable { get; set; }
    }
}