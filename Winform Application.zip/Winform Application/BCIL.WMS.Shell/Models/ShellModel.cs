﻿using BCIL;

namespace BCIL.WMS.Shell
{
    public class ShellModel
    {
        public ControlSliderBase ActiveView { get; set; }
        public string LoggedInUserName { get; set; }
    }
}