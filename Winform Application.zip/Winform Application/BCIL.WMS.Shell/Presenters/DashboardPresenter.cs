﻿using BCIL.WMS.Shell.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using WinFormsMvp;

namespace BCIL.WMS.Shell.Presenters
{
    public class DashboardPresenter : Presenter<IDashboardView>
    {
        public DashboardPresenter(IDashboardView view)
            : base(view)
        {
           
        }

        private void View_Load(object sender, EventArgs e)
        {
           
        }

     
    }
}