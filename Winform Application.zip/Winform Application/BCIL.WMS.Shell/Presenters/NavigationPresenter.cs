﻿using BCIL.WMS.Shell.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.Shell.Presenters
{
    public class NavigationPresenter : Presenter<INavigationView>
    {
        public NavigationPresenter(INavigationView view) : base(view)
        {
            view.Load += View_Load;
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model = new Models.NavigationModel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}