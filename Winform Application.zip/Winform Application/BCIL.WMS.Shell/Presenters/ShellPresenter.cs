﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.User.BL.Permission;
using BCIL.User.UI.Views;
using BCIL.WMS.Shell.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.Shell.Presenters
{
    public class ShellPresenter : Presenter<IShellView>
    {
        public ShellPresenter(IShellView view) : base(view)
        {
            if (View.Model == null) View.Model = new ShellModel();

            view.Load += View_Load;
            view.NavigationClicked += View_NavigationClicked;
            view.LogOut += View_LogOut;
            view.ChangePasswordRequested += View_ChangePasswordRequested;
        }

        private void ResetLoginDetails()
        {
            App.Login.Employee = null;
            App.Login.LoginSite = null;
            App.Login.User.Permissions = new Dictionary<string, UserPermission>();
        }

        private bool AuthenticateUser()
        {
            LoginView login = new LoginView();
            View.Hide();
            View.HideDashboard();
            ResetLoginDetails();

            if (login.ShowDialog() == DialogResult.OK)
            {
                View.Model.LoggedInUserName = App.Login.Employee.Name;
                return true;
            }
            else
            {
                Application.Exit();
            }
            return false;
        }

        private void BuildMenu()
        {
            NodeDvl nodes = NodeDvl.GetNodes();
            App.ApplicationActionNodes = nodes.ToDictionary(x => x.NodeCode);

            View.ResetMenu();

            var parentNodes = nodes.Where(x => string.IsNullOrWhiteSpace(x.ParentNode) && x.AppType == AppType.Desktop).OrderBy((y) => y.DisplayIndex).ToList();

            foreach (Node node in parentNodes)
            {
                View.AddMenu(node.NodeCode, node.NodeName, node.ShortName, node.ParentNode, Images.GetImage(node.ImageName));
            }

            var childNodes = nodes.Where(x => !string.IsNullOrWhiteSpace(x.ParentNode) && !string.IsNullOrWhiteSpace(x.Class)).OrderBy((y) => y.DisplayIndex).ToList();
            foreach (Node node in childNodes)
            {
                View.AddMenu(node.NodeCode, node.NodeName, node.ShortName, node.ParentNode, Images.GetImage(node.ImageName));
            }
        }

        private void NewView_Closed(object sender, EventArgs e)
        {
            try
            {
                View.Model.ActiveView = null;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ChangePasswordRequested(object sender, EventArgs e)
        {
            try
            {
                CredentialView credentialView = new CredentialView(true, false);
                credentialView.LoginId = App.Login.Employee.LoginId;
                if (credentialView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    var user = User.BL.User.GetUser(App.Login.Employee.EmployeeId);
                    user.LoginId = credentialView.LoginId;
                    user.Password = credentialView.NewPassword;
                    user.Save();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.LoggedInUserName = App.Login.Employee.Name;
                View.ShowDashboard();
                BuildMenu();
                View.Show();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_LogOut(object sender, EventArgs e)
        {
            if (View.Model.ActiveView == null || View.Model.ActiveView.swipe(false))
            {
                if (AuthenticateUser())
                {
                    BuildMenu();
                    View.ShowDashboard();
                    View.RefreshBinding();
                    View.Show();
                }
            }
        }

        private void View_NavigationClicked(object sender, string e)
        {
            try
            {
                string actionType = App.ApplicationActionNodes[e].Class;
                if (!string.IsNullOrWhiteSpace(actionType))
                {
                    Type newViewType = Type.GetType(actionType);
                    if (newViewType == null)
                    {
                        View.ShowException("\"" + actionType + "\" not found.");
                    }

                    if (View.Model.ActiveView != null && View.Model.ActiveView.GetType() == newViewType)
                    {
                        return;
                    }
                    ControlSliderBase newView = Activator.CreateInstance(newViewType, View.MainContainer) as ControlSliderBase;

                    if (View.Model.ActiveView != null)
                    {
                        pnlSlider.ActionArg closingEvent = new pnlSlider.ActionArg();
                        View.Model.ActiveView.closing(closingEvent);
                        if (closingEvent.Handled == false)
                        {
                            if (newView.swipe(true))
                            {
                                View.Model.ActiveView.SwipeOutWithoutClosingEvent();
                                newView.Closed += NewView_Closed;
                                View.Model.ActiveView = newView;
                            }
                        }
                    }
                    else
                    {
                        newView.Closed += NewView_Closed;
                        if (newView.swipe(true))
                        {
                            View.Model.ActiveView = newView;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}