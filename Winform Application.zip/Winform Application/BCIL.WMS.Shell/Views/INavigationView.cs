﻿using BCIL;
using BCIL.WMS.Shell.Models;
using System.Drawing;

namespace BCIL.WMS.Shell.Views
{
    public interface INavigationView : IBaseView<NavigationModel>
    {
        void AddMainMenu(string key, string text, string shortName, Image icon);

        void AddSubMenu(string parentKey, string key, string text, Image icon);
    }
}