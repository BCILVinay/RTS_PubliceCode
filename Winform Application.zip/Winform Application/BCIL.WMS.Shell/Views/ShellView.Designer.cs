﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;

namespace BCIL.WMS.Shell
{
    partial class ShellView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShellView));
            BCIL.WMS.Shell.Models.NavigationModel navigationModel1 = new BCIL.WMS.Shell.Models.NavigationModel();
            this.pnlDetail = new MetroFramework.Controls.MetroPanel();
            this.pnlUser = new BCIL.UIHelper.Controls.RoundedCornerPanel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lnkUser = new MetroFramework.Controls.CustomMetroLink();
            this.lblHeader = new System.Windows.Forms.Label();
            this.metroContextMenu1 = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.tsmLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.roundedCornerPanel1 = new BCIL.UIHelper.Controls.RoundedCornerPanel();
            this.pictureBox1 = new BCIL.UIHelper.PictureBox();
            this.navigationView = new BCIL.WMS.Shell.NavigationView();
            this.pnlUser.SuspendLayout();
            this.metroContextMenu1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.roundedCornerPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlDetail
            // 
            this.pnlDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDetail.BackColor = System.Drawing.Color.LightGray;
            this.pnlDetail.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.pnlDetail.HorizontalScrollbarBarColor = true;
            this.pnlDetail.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlDetail.HorizontalScrollbarSize = 10;
            this.pnlDetail.Location = new System.Drawing.Point(67, 39);
            this.pnlDetail.Name = "pnlDetail";
            this.pnlDetail.Size = new System.Drawing.Size(955, 659);
            this.pnlDetail.TabIndex = 1;
            this.pnlDetail.VerticalScrollbarBarColor = true;
            this.pnlDetail.VerticalScrollbarHighlightOnWheel = false;
            this.pnlDetail.VerticalScrollbarSize = 10;
            // 
            // pnlUser
            // 
            this.pnlUser.AutoSize = true;
            this.pnlUser.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlUser.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnlUser.BackGroundFillColor = System.Drawing.SystemColors.ControlLight;
            this.pnlUser.Controls.Add(this.lblUserName);
            this.pnlUser.Controls.Add(this.lnkUser);
            this.pnlUser.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlUser.ForeColor = System.Drawing.Color.White;
            this.pnlUser.HeightPadding = 3;
            this.pnlUser.Location = new System.Drawing.Point(752, 2);
            this.pnlUser.MinimumSize = new System.Drawing.Size(100, 32);
            this.pnlUser.Name = "pnlUser";
            this.pnlUser.Padding = new System.Windows.Forms.Padding(10, 0, 6, 3);
            this.pnlUser.Radius = 15;
            this.pnlUser.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pnlUser.RounddingStartLocation = new System.Drawing.Point(0, 0);
            this.pnlUser.Size = new System.Drawing.Size(102, 32);
            this.pnlUser.TabIndex = 2;
            this.pnlUser.WidthPadding = 1;
            this.pnlUser.Click += new System.EventHandler(this.customMetroLink1_Click);
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.DimGray;
            this.lblUserName.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserName.Location = new System.Drawing.Point(10, 0);
            this.lblUserName.MinimumSize = new System.Drawing.Size(47, 21);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblUserName.Size = new System.Drawing.Size(54, 26);
            this.lblUserName.TabIndex = 10;
            this.lblUserName.Text = "Admin";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserName.Click += new System.EventHandler(this.customMetroLink1_Click);
            // 
            // lnkUser
            // 
            this.lnkUser.BackColor = System.Drawing.Color.Transparent;
            this.lnkUser.CanNotVisible = false;
            this.lnkUser.Dock = System.Windows.Forms.DockStyle.Right;
            this.lnkUser.Enabled = false;
            this.lnkUser.Image = ((System.Drawing.Image)(resources.GetObject("lnkUser.Image")));
            this.lnkUser.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkUser.ImageSize = 35;
            this.lnkUser.Location = new System.Drawing.Point(64, 0);
            this.lnkUser.Margin = new System.Windows.Forms.Padding(0);
            this.lnkUser.MinimumSize = new System.Drawing.Size(32, 21);
            this.lnkUser.Name = "lnkUser";
            this.lnkUser.Size = new System.Drawing.Size(32, 29);
            this.lnkUser.TabIndex = 13;
            this.lnkUser.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lnkUser.UseCustomBackColor = true;
            this.lnkUser.UseSelectable = true;
            this.lnkUser.Click += new System.EventHandler(this.customMetroLink1_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(2, 2);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.lblHeader.Size = new System.Drawing.Size(61, 29);
            this.lblHeader.TabIndex = 7;
            this.lblHeader.Text = "       ";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // metroContextMenu1
            // 
            this.metroContextMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmLogout,
            this.changePasswordToolStripMenuItem});
            this.metroContextMenu1.Name = "metroContextMenu1";
            this.metroContextMenu1.Size = new System.Drawing.Size(169, 48);
            // 
            // tsmLogout
            // 
            this.tsmLogout.Image = ((System.Drawing.Image)(resources.GetObject("tsmLogout.Image")));
            this.tsmLogout.Name = "tsmLogout";
            this.tsmLogout.Size = new System.Drawing.Size(168, 22);
            this.tsmLogout.Text = "Logout";
            this.tsmLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("changePasswordToolStripMenuItem.Image")));
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.pnlUser);
            this.panel1.Controls.Add(this.lblHeader);
            this.panel1.Location = new System.Drawing.Point(72, 5);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(2);
            this.panel1.Size = new System.Drawing.Size(856, 34);
            this.panel1.TabIndex = 12;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            this.panel1.DoubleClick += new System.EventHandler(this.panel1_DoubleClick);
            this.panel1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDoubleClick);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // roundedCornerPanel1
            // 
            this.roundedCornerPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.roundedCornerPanel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.roundedCornerPanel1.BackGroundFillColor = System.Drawing.SystemColors.ControlDark;
            this.roundedCornerPanel1.Controls.Add(this.pictureBox1);
            this.roundedCornerPanel1.ForeColor = System.Drawing.Color.White;
            this.roundedCornerPanel1.HeightPadding = 3;
            this.roundedCornerPanel1.Location = new System.Drawing.Point(0, 5);
            this.roundedCornerPanel1.Name = "roundedCornerPanel1";
            this.roundedCornerPanel1.Padding = new System.Windows.Forms.Padding(3, 3, 6, 0);
            this.roundedCornerPanel1.Radius = 15;
            this.roundedCornerPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.roundedCornerPanel1.RounddingStartLocation = new System.Drawing.Point(0, 0);
            this.roundedCornerPanel1.Size = new System.Drawing.Size(72, 34);
            this.roundedCornerPanel1.TabIndex = 13;
            this.roundedCornerPanel1.WidthPadding = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.MaxImageSize = new System.Drawing.Size(0, 0);
            this.pictureBox1.MinImageSize = new System.Drawing.Size(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // navigationView
            // 
            this.navigationView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.navigationView.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.navigationView.Location = new System.Drawing.Point(0, 39);
            this.navigationView.MessageLable = null;
            this.navigationView.Model = navigationModel1;
            this.navigationView.Name = "navigationView";
            this.navigationView.Size = new System.Drawing.Size(69, 661);
            this.navigationView.TabIndex = 0;
            this.navigationView.UseSelectable = true;
            this.navigationView.NavigationClicked += new System.EventHandler<BCIL.WMS.Shell.Models.NavigationEventArg>(this.navigationView_NavigationClicked);
            // 
            // ShellView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 700);
            this.Controls.Add(this.roundedCornerPanel1);
            this.Controls.Add(this.navigationView);
            this.Controls.Add(this.pnlDetail);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ShellView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "   WMS";
            this.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShellView_FormClosing);
            this.Load += new System.EventHandler(this.ShellView_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ShellView_KeyUp);
            this.pnlUser.ResumeLayout(false);
            this.pnlUser.PerformLayout();
            this.metroContextMenu1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.roundedCornerPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private NavigationView navigationView;
        private MetroFramework.Controls.MetroPanel pnlDetail;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblUserName;
        private MetroFramework.Controls.MetroContextMenu metroContextMenu1;
        private System.Windows.Forms.ToolStripMenuItem tsmLogout;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private BCIL.UIHelper.Controls.RoundedCornerPanel pnlUser;
        private MetroFramework.Controls.CustomMetroLink lnkUser;
        private BCIL.UIHelper.Controls.RoundedCornerPanel roundedCornerPanel1;
        private BCIL.UIHelper.PictureBox pictureBox1;
    }
}

