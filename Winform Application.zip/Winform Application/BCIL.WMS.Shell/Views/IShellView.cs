﻿using BCIL;
using System;
using System.Drawing;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.Shell
{
    public interface IShellView : IBaseView<ShellModel>
    {
        event EventHandler ChangePasswordRequested;

        event EventHandler LogOut;

        event EventHandler<string> NavigationClicked;
        Control MainContainer { get; }

        void AddMenu(string menuId, string displayText, string shortName, string parentId, Image icon);

        void Hide();

        void HideDashboard();

        void RefreshBinding();

        void ResetMenu();

        void Show();
        void ShowDashboard();
    }
}