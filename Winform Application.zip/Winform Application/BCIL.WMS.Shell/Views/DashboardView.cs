﻿using BCIL;
using MetroFramework.Controls;
using BCIL.WMS.Shell.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace BCIL.WMS.Shell.Views
{
    public partial class DashboardView : ControlBase, IDashboardView
    {

        public DashboardView()
        {
            InitializeComponent();
        }
    }
}