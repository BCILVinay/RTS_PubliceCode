﻿using BCIL;
using BCIL.UIHelper;
using MetroFramework;
using MetroFramework.Controls;
using BCIL.WMS.Shell.Models;
using BCIL.WMS.Shell.Views;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.WMS.Shell
{
    public partial class NavigationView : ControlBase, INavigationView
    {
        #region Variables

        private DateTime _paneTimeStamp;

        private Color _SubMenuColor = Color.FromArgb(64, 64, 64);

        private MetroThemeStyle _Theam = MetroThemeStyle.CustomDark;

        private event EventHandler<ScrollEventArg> DetailedNavigationScrollVisible;

        private event EventHandler<ScrollEventArg> QuickNavigationScrollVisible;

        private Image TopMenuIcon = null;
        private CustomMetroLink _SelectedParent = null;
        #endregion Variables

        #region Public Properties & Events

        public event EventHandler<NavigationEventArg> NavigationClicked;

        public NavigationModel Model { get; set; }

        #endregion Public Properties & Events

        #region Constructor

        public NavigationView()
        {
            InitializeComponent();
            this.QuickNavigationScrollVisible += Navigation_QuickNavigationScrollVisible;
            this.DetailedNavigationScrollVisible += Navigation_ScrollVisible;
            navigationPanel.VisibleChanged += NavigationPanel_VisibleChanged;

            pnlQuickNavigationBar.Theme = _Theam;
            navMoveUp.Theme = _Theam;
            navMoveDown.Theme = _Theam;
            QuickNavigationPanel.Theme = _Theam;
            menu.Theme = _Theam;
            // _SubMenuColor = Color.FromArgb(200, MetroFramework.Drawing.MetroPaint.CustomDarkColor().R, MetroFramework.Drawing.MetroPaint.CustomDarkColor().G, MetroFramework.Drawing.MetroPaint.CustomDarkColor().B);
            _SubMenuColor = ControlPaint.Light(ControlPaint.Light(MetroFramework.Drawing.MetroPaint.CustomDarkColor(), .2f), .2f);
            navigationPanel.BackColor = _SubMenuColor;
            pnlDetailNavigation.BackColor = _SubMenuColor;
            ComponentResourceManager resources = new ComponentResourceManager(typeof(NavigationView));
            TopMenuIcon = ((System.Drawing.Image)(resources.GetObject("menu.Image")));
        }

        #endregion Constructor

        #region Functions

        public void AddMainMenu(string key, string text, string shortName, Image icon)
        {
            if (String.IsNullOrWhiteSpace(key) || Model.Nodes.Values.Any(x => x.ID == key)) return;

            CustomMetroLink node = new CustomMetroLink();
            node.AutoSize = true;
            node.Dock = System.Windows.Forms.DockStyle.Top;
            node.ForeColor = System.Drawing.Color.Silver;
            node.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            node.ImageSize = 32;
            node.Location = new System.Drawing.Point(0, 0);
            node.Name = key;
            node.Size = new System.Drawing.Size(196, 23);
            node.TabIndex = 2;
            node.Text = text;
            node.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            node.Theme = _Theam;
            node.Enabled = false;
            node.UseCustomForeColor = true;
            node.ForeColor = Color.White;
            if (!App.Login.User.HasPermissionOnAnyChild(key))
            {
                node.CanNotVisible = true;
                node.Visible = false;
            }
            node.BackColor = _SubMenuColor;
            node.UseCustomBackColor = true;
            node.DisplayFocus = true;
            //node.UseCustomForeColor = true;
            node.UseSelectable = true;

            navigationPanel.Controls.Add(node);
            Model.Nodes.Add(key, new MenuNode { ID = key, Text = text, Contorl = node });
            AddQuickNavigation(key, !string.IsNullOrWhiteSpace(shortName) ? shortName : text, icon);
            navigationPanel.Controls.SetChildIndex(node, 0);
        }

        public void AddSubMenu(string parentKey, string key, string text, Image icon)
        {
            if (String.IsNullOrWhiteSpace(parentKey) || !Model.Nodes.ContainsKey(parentKey)) throw new BCILException("Invalid parent key.");
            if (String.IsNullOrWhiteSpace(key)) throw new BCILException("Key can not be null.");
            if (Model.Nodes.Values.Any(x => x.ID == key)) throw new BCILException("Key already exists.");

            CustomMetroLink node = new CustomMetroLink();
            node.AutoSize = true;
            node.Dock = System.Windows.Forms.DockStyle.Top;
            node.ForeColor = System.Drawing.Color.White;
            if (icon != null) node.Image = icon;
            node.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            node.ImageSize = 32;
            node.Location = new System.Drawing.Point(0, 23);
            node.Name = key;
            node.Size = new System.Drawing.Size(196, 30);
            node.Text = "            " + text;
            node.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            node.Theme = _Theam;
            node.BackColor = _SubMenuColor;
            node.UseCustomBackColor = true;
            if (!App.Login.User.HasAnyPermission(key))
            {
                node.CanNotVisible = true;
                node.Visible = false;
            }
            node.UseSelectable = true;
            node.Click += Node_Click;

            int index = 0;
            var childNode = Model.Nodes.Values.Where(x => x.Parent == parentKey).LastOrDefault();
            if (childNode != default(MenuNode))
                index = navigationPanel.Controls.IndexOf(childNode.Contorl);
            else
                index = navigationPanel.Controls.IndexOf(Model.Nodes[parentKey].Contorl);

            Model.Nodes.Add(key, new MenuNode { ID = key, Parent = parentKey, Text = text, Contorl = node });

            navigationPanel.Controls.Add(node);
            navigationPanel.Controls.SetChildIndex(node, index);
        }

        public void Reset()
        {
            this.SuspendLayout();
            Model.QuickNodes.Clear();
            Model.Nodes.Clear();
            QuickNavigationPanel.Controls.Clear();
            navigationPanel.Controls.Clear();
           // ComponentResourceManager resources = new ComponentResourceManager(typeof(NavigationView));
            AddQuickNavigation("menu", "Menu", TopMenuIcon);
            this.ResumeLayout(true);
        }

        private void AddQuickNavigation(string key, string text, Image icon)
        {
            CustomMetroLink node = new CustomMetroLink();
            node.Dock = System.Windows.Forms.DockStyle.Top;
            node.ImageSize = 40;
            node.Location = new System.Drawing.Point(0, 0);
            node.Name = key;
            node.Size = new System.Drawing.Size(69, 69);
            node.TabIndex = 8;
            node.Text = text;
            node.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            node.Theme = _Theam;
            node.UseSelectable = true;
            if (key != "menu" && !App.Login.User.HasPermissionOnAnyChild(key))
            {
                node.CanNotVisible = true;
                node.Visible = false;
            }
            node.Image = icon;
            node.Click += ParentNode_Click;
            Model.QuickNodes.Add(key, new MenuNode { ID = key, Text = text, Contorl = node });
            QuickNavigationPanel.Controls.Add(node);
            QuickNavigationPanel.Controls.SetChildIndex(node, 0);
        }
        private void FilterMenue(string filterKey)
        {
            if (filterKey != "menu")
            {
                foreach (var ctrl in Model.Nodes)
                {
                    if (ctrl.Key != filterKey && ctrl.Value.Parent != filterKey)
                    {
                        ctrl.Value.Contorl.Visible = false;
                    }
                    else
                    {
                        ctrl.Value.Contorl.Visible = true;
                    }
                }
            }
            else
            {
                foreach (var ctrl in Model.Nodes)
                {
                    ctrl.Value.Contorl.Visible = true;
                }
            }
            if (DetailedNavigationScrollVisible != null) DetailedNavigationScrollVisible(this, new ScrollEventArg() { Isscrollable = IsScrollBarRequired(pnlDetailNavigation) });
        }

        private bool IsScrollBarRequired(ScrollableControl ctrl)
        {
            Point value = ctrl.AutoScrollPosition;
            ctrl.VerticalScroll.Value = ctrl.VerticalScroll.Maximum;
            if (ctrl.AutoScrollPosition.Y != 0)
            {
                ctrl.AutoScrollPosition = value;
                return true;
            }
            return false;
        }

        public void SetTopMenuIcone( Image icon)
        {
            if(icon != null)
            {
                TopMenuIcon = icon;
            }
        }
        #endregion Functions

        #region Events

        private void metroScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            pnlDetailNavigation.AutoScrollPosition = new Point(0, metroScrollBar.Value);
        }

        private void Navigation_Load(object sender, EventArgs e)
        {
            if (QuickNavigationScrollVisible != null) QuickNavigationScrollVisible(this, new ScrollEventArg() { Isscrollable = IsScrollBarRequired(QuickNavigationPanel) });
        }

        private void Navigation_QuickNavigationScrollVisible(object sender, ScrollEventArg e)
        {
            pnlQuickNavigationBar.Visible = e.Isscrollable;
            pnlQuickNavigationBar.BringToFront();
            navMoveUp.Enabled = e.Isscrollable;
            navMoveDown.Enabled = e.Isscrollable;
        }

        private void Navigation_ScrollVisible(object sender, ScrollEventArg e)
        {
            if (e.Isscrollable)
            {
                metroScrollBar.Value = pnlDetailNavigation.AutoScrollPosition.Y;
                this.metroScrollBar.Minimum = 0;
                this.metroScrollBar.Maximum = this.pnlDetailNavigation.DisplayRectangle.Height;
                if (metroScrollBar.Height > 0)
                    this.metroScrollBar.LargeChange = (metroScrollBar.Maximum / metroScrollBar.Height) + this.pnlDetailNavigation.Height;
                this.metroScrollBar.SmallChange = 15;
            }
            metroScrollBar.Visible = e.Isscrollable;
        }

        private void navigationPanel_Leave(object sender, EventArgs e)
        {
            navigationPanel.Visible = false;
        }

        private void NavigationPanel_VisibleChanged(object sender, EventArgs e)
        {
            try
            {
                if(navigationPanel.Visible ==false && _SelectedParent!=null)
                {
                    _SelectedParent.DisplaySelected = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void navigationPanel_VisibleChanged(object sender, EventArgs e)
        {
            _paneTimeStamp = DateTime.Now;
            if (navigationPanel.Visible)
            {
                if (!(navigationPanel.ContainsFocus))
                {
                    System.Threading.Timer t = new System.Threading.Timer(o =>
                    {
                        navigationPanel.BeginInvoke((Action)delegate ()
                        {
                            bool mousein = navigationPanel.ClientRectangle.Contains(navigationPanel.PointToClient(Cursor.Position));
                            if (!(navigationPanel.ContainsFocus || mousein) && (DateTime.Now - _paneTimeStamp).TotalSeconds > 5)
                            {
                                navigationPanel.Visible = false;
                            }
                        });
                    },
                   null, 5000, System.Threading.Timeout.Infinite);
                }
                this.Width = QuickNavigationPanel.Width + navigationPanel.Width + (navigationPanel.VerticalScroll.Visible ? 20 : 0);
            }
            else
            {
                this.Width = QuickNavigationPanel.Width;
            }
            if (DetailedNavigationScrollVisible != null) DetailedNavigationScrollVisible(this, new ScrollEventArg() { Isscrollable = IsScrollBarRequired(pnlDetailNavigation) });
        }

        private void navMoveDown_Click(object sender, EventArgs e)
        {
            QuickNavigationPanel.VerticalScroll.Value += 15;
        }

        private void navMoveUp_Click(object sender, EventArgs e)
        {
            if (QuickNavigationPanel.VerticalScroll.Value > 15)
                QuickNavigationPanel.VerticalScroll.Value -= 15;
            else
                QuickNavigationPanel.VerticalScroll.Value = 0;
        }

        private void Node_Click(object sender, EventArgs e)
        {
            navigationPanel.Visible = false;
            if (NavigationClicked != null) NavigationClicked(this, new NavigationEventArg() { NavigationKey = ((Control)sender).Name });
        }

        private void ParentNode_Click(object sender, EventArgs e)
        {
            navigationPanel.Visible = true;
            FilterMenue(((Control)sender).Name);
            if (_SelectedParent != null)
            {
                _SelectedParent.DisplaySelected = false;
                _SelectedParent.Refresh();
                QuickNavigationPanel.Refresh();
            }
            _SelectedParent = (CustomMetroLink)sender;
            _SelectedParent.DisplaySelected = true;
        }

        private void pnlDetailNavigation_SizeChanged(object sender, EventArgs e)
        {
            if (DetailedNavigationScrollVisible != null) DetailedNavigationScrollVisible(this, new ScrollEventArg() { Isscrollable = IsScrollBarRequired(pnlDetailNavigation) });
        }

        private void QuickNavigationPanel_MouseLeave(object sender, EventArgs e)
        {
            if (!this.ClientRectangle.Contains(this.PointToClient(Cursor.Position)))
                navigationPanel.Visible = false;
        }
        private void QuickNavigationPanel_SizeChanged(object sender, EventArgs e)
        {
            if (QuickNavigationScrollVisible != null) QuickNavigationScrollVisible(this, new ScrollEventArg() { Isscrollable = IsScrollBarRequired(QuickNavigationPanel) });
        }
        #endregion Events
    }
}