﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.Shell.Views;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace BCIL.WMS.Shell
{
    public partial class ShellView : FormBase, IShellView
    {
        #region Private Fields
        private DashboardView _dashboardView = null;
        #endregion

        #region Public Events
        public event EventHandler ChangePasswordRequested;

        public event EventHandler LogOut;

        public event EventHandler<string> NavigationClicked;
        #endregion

        #region Public Constructors
        public ShellView() : base()
        {
            InitializeComponent();
            this.SizeGripStyle = SizeGripStyle.Show;
            this.MaximizeBox = true;
            this.MinimizeBox = true;
            this.MaximumSize = new System.Drawing.Size(0, 0);
            this.ShowInTaskbar = true;
            App.Shell = this;
            App.MainContainer = this.MainContainer;
            App.LoginSiteChanged += Login_LoginSiteChanged;
            this.StartPosition = FormStartPosition.Manual;
            this.WindowState = FormWindowState.Normal;
            this.Height = Screen.PrimaryScreen.WorkingArea.Height;
            this.Width = Screen.PrimaryScreen.WorkingArea.Width;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        #endregion

        #region Public Properties
        public Control MainContainer => this.pnlDetail;

        public ShellModel Model { get; set; }
        #endregion

        #region Public Methods
        public void AddMenu(string menuId, string displayText, string shortName, string parentId, Image icon)
        {
            if (string.IsNullOrWhiteSpace(parentId))
            {
                navigationView.AddMainMenu(menuId, displayText, shortName, icon);
            }
            else
            {
                navigationView.AddSubMenu(parentId, menuId, displayText, icon);
            }
        }

        public void HideDashboard()
        {
            if (_dashboardView != null) pnlDetail.Controls.Remove(_dashboardView);
        }

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(lblUserName, x => x.Text, Model, y => y.LoggedInUserName);
        }

        public void ResetMenu()
        {
            SetMenuIcon();
            navigationView.Reset();
        }

        public void ShowDashboard()
        {
            _dashboardView = new DashboardView();
            _dashboardView.Dock = DockStyle.Fill;
            pnlDetail.Controls.Add(_dashboardView);
        }
        #endregion

        #region Private Methods
        private void btnLogout_Click(object sender, EventArgs e)
        {
            LogOut?.Invoke(sender, e);
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePasswordRequested?.Invoke(sender, null);
        }

        private void customMetroLink1_Click(object sender, EventArgs e)
        {
            panel1.Focus();
            metroContextMenu1.RightToLeft = RightToLeft.No;
            metroContextMenu1.Show(pnlUser.PointToScreen(new Point(20, pnlUser.Size.Height)));
        }

        private void Login_LoginLocationTypeChanged(object sender, LocationType e)
        {
            try
            {
                SetMenuIcon();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void Login_LoginSiteChanged(object sender, EventArgs e)
        {
            SetLoginLocation();
        }

        private void navigationView_NavigationClicked(object sender, Models.NavigationEventArg e)
        {
            NavigationClicked?.Invoke(sender, e.NavigationKey);
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            this.OnClick(e);
        }

        private void panel1_DoubleClick(object sender, EventArgs e)
        {
            this.OnDoubleClick(e);
        }

        private void panel1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.OnMouseDoubleClick(e);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            this.OnMouseDown(e);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            this.OnMouseMove(e);
        }

        private void SetLoginLocation()
        {
            if (App.Login.LoginSite != null)
            {
                lblHeader.Text = string.Format("{0} - {1}", App.Login.LoginSite.SiteCode, App.Login.LoginSite.SiteName);
                if (App.WorkStation.WMaterialBination.IsNotNull() && App.WorkStation.WMaterialBination.LocationId > -1)
                    lblHeader.Text = lblHeader.Text + " / " + App.WorkStation.WMaterialBination.LocationCode;

                if (App.WorkStation.WSLine.IsNotNull() && App.WorkStation.WSLine.LocationId > -1)
                    lblHeader.Text = lblHeader.Text + " / " + App.WorkStation.WSLine.Code;
            }
            else
            {
                lblHeader.Text = "";
            }
        }

        private void SetMenuIcon()
        {
            //if (App.Login.LoginedLocationType == LocationType.WareHouse)
            //    navigationView.SetTopMenuIcone(Images.GetImage("warehouse"));
            //else
            //    navigationView.SetTopMenuIcone(Images.GetImage("Store"));
        }

        private void ShellView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (pnlDetail.Controls.Contains(_dashboardView))
                {
                    if (BcilMessageBox.GetUserInput(this._dashboardView, "Do you want to close application?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        e.Cancel = false;
                    else
                        e.Cancel = true;
                }
            }
            catch (Exception ex)
            {
                BcilLogger.Error(ex, "MobiVue");
            }
        }

        private void ShellView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                e.Handled = true;
        }

        private void ShellView_Load(object sender, EventArgs e)
        {
            FocusMe();
            RefreshBinding();
            SetLoginLocation();
        }

        private void View_PerformNodeAction(object sender, string e)
        {
            NavigationClicked?.Invoke(sender, e);
        }
        #endregion
    }
}