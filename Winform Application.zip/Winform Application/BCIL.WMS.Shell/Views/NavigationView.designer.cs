﻿using MetroFramework.Controls;
using System.Windows.Forms;

namespace BCIL.WMS.Shell
{
    partial class NavigationView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NavigationView));
            this.navigationPanel = new System.Windows.Forms.Panel();
            this.QuickNavigationPanel = new MetroFramework.Controls.MetroPanel();
            this.menu = new MetroFramework.Controls.CustomMetroLink();
            this.pnlDetailNavigation = new MetroFramework.Controls.MetroPanel();
            this.metroScrollBar = new MetroFramework.Controls.MetroScrollBar();
            this.pnlQuickNavigation = new System.Windows.Forms.Panel();
            this.pnlQuickNavigationBar = new MetroFramework.Controls.MetroPanel();
            this.navMoveDown = new MetroFramework.Controls.CustomMetroLink();
            this.navMoveUp = new MetroFramework.Controls.CustomMetroLink();
            this.QuickNavigationPanel.SuspendLayout();
            this.pnlDetailNavigation.SuspendLayout();
            this.pnlQuickNavigation.SuspendLayout();
            this.pnlQuickNavigationBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // navigationPanel
            // 
            this.navigationPanel.AutoSize = true;
            this.navigationPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.navigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.navigationPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.navigationPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.navigationPanel.Location = new System.Drawing.Point(0, 0);
            this.navigationPanel.MinimumSize = new System.Drawing.Size(0, 30);
            this.navigationPanel.Name = "navigationPanel";
            this.navigationPanel.Size = new System.Drawing.Size(249, 30);
            this.navigationPanel.TabIndex = 7;
            this.navigationPanel.Visible = false;
            this.navigationPanel.VisibleChanged += new System.EventHandler(this.navigationPanel_VisibleChanged);
            this.navigationPanel.Leave += new System.EventHandler(this.navigationPanel_Leave);
            this.navigationPanel.MouseLeave += new System.EventHandler(this.QuickNavigationPanel_MouseLeave);
            // 
            // QuickNavigationPanel
            // 
            this.QuickNavigationPanel.AutoScroll = true;
            this.QuickNavigationPanel.BackColor = System.Drawing.Color.Black;
            this.QuickNavigationPanel.Controls.Add(this.menu);
            this.QuickNavigationPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QuickNavigationPanel.HorizontalScrollbar = true;
            this.QuickNavigationPanel.HorizontalScrollbarBarColor = true;
            this.QuickNavigationPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.QuickNavigationPanel.HorizontalScrollbarSize = 10;
            this.QuickNavigationPanel.Location = new System.Drawing.Point(0, 0);
            this.QuickNavigationPanel.Name = "QuickNavigationPanel";
            this.QuickNavigationPanel.Size = new System.Drawing.Size(67, 478);
            this.QuickNavigationPanel.TabIndex = 6;
            this.QuickNavigationPanel.Theme = MetroFramework.MetroThemeStyle.CustomDark;
            this.QuickNavigationPanel.VerticalScrollbar = true;
            this.QuickNavigationPanel.VerticalScrollbarBarColor = true;
            this.QuickNavigationPanel.VerticalScrollbarHighlightOnWheel = false;
            this.QuickNavigationPanel.VerticalScrollbarSize = 10;
            this.QuickNavigationPanel.SizeChanged += new System.EventHandler(this.QuickNavigationPanel_SizeChanged);
            this.QuickNavigationPanel.MouseLeave += new System.EventHandler(this.QuickNavigationPanel_MouseLeave);
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.Black;
            this.menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu.Image = ((System.Drawing.Image)(resources.GetObject("menu.Image")));
            this.menu.ImageSize = 40;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(67, 69);
            this.menu.TabIndex = 8;
            this.menu.Text = "Menu";
            this.menu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.menu.Theme = MetroFramework.MetroThemeStyle.CustomDark;
            this.menu.UseSelectable = true;
            this.menu.Click += new System.EventHandler(this.ParentNode_Click);
            // 
            // pnlDetailNavigation
            // 
            this.pnlDetailNavigation.AutoScroll = true;
            this.pnlDetailNavigation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlDetailNavigation.Controls.Add(this.navigationPanel);
            this.pnlDetailNavigation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDetailNavigation.HorizontalScrollbar = true;
            this.pnlDetailNavigation.HorizontalScrollbarBarColor = true;
            this.pnlDetailNavigation.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlDetailNavigation.HorizontalScrollbarSize = 10;
            this.pnlDetailNavigation.Location = new System.Drawing.Point(67, 0);
            this.pnlDetailNavigation.Name = "pnlDetailNavigation";
            this.pnlDetailNavigation.Size = new System.Drawing.Size(249, 541);
            this.pnlDetailNavigation.TabIndex = 8;
            this.pnlDetailNavigation.UseCustomBackColor = true;
            this.pnlDetailNavigation.VerticalScrollbar = true;
            this.pnlDetailNavigation.VerticalScrollbarBarColor = true;
            this.pnlDetailNavigation.VerticalScrollbarHighlightOnWheel = false;
            this.pnlDetailNavigation.VerticalScrollbarSize = 10;
            this.pnlDetailNavigation.SizeChanged += new System.EventHandler(this.pnlDetailNavigation_SizeChanged);
            // 
            // metroScrollBar
            // 
            this.metroScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.metroScrollBar.LargeChange = 10;
            this.metroScrollBar.Location = new System.Drawing.Point(301, 0);
            this.metroScrollBar.Maximum = 100;
            this.metroScrollBar.Minimum = 0;
            this.metroScrollBar.MouseWheelBarPartitions = 10;
            this.metroScrollBar.Name = "metroScrollBar";
            this.metroScrollBar.Orientation = MetroFramework.Controls.MetroScrollOrientation.Vertical;
            this.metroScrollBar.ScrollbarSize = 15;
            this.metroScrollBar.Size = new System.Drawing.Size(15, 541);
            this.metroScrollBar.TabIndex = 9;
            this.metroScrollBar.UseSelectable = true;
            this.metroScrollBar.Visible = false;
            this.metroScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.metroScrollBar1_Scroll);
            // 
            // pnlQuickNavigation
            // 
            this.pnlQuickNavigation.Controls.Add(this.QuickNavigationPanel);
            this.pnlQuickNavigation.Controls.Add(this.pnlQuickNavigationBar);
            this.pnlQuickNavigation.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlQuickNavigation.Location = new System.Drawing.Point(0, 0);
            this.pnlQuickNavigation.Name = "pnlQuickNavigation";
            this.pnlQuickNavigation.Size = new System.Drawing.Size(67, 541);
            this.pnlQuickNavigation.TabIndex = 10;
            // 
            // pnlQuickNavigationBar
            // 
            this.pnlQuickNavigationBar.Controls.Add(this.navMoveDown);
            this.pnlQuickNavigationBar.Controls.Add(this.navMoveUp);
            this.pnlQuickNavigationBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlQuickNavigationBar.HorizontalScrollbarBarColor = true;
            this.pnlQuickNavigationBar.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlQuickNavigationBar.HorizontalScrollbarSize = 10;
            this.pnlQuickNavigationBar.Location = new System.Drawing.Point(0, 478);
            this.pnlQuickNavigationBar.Name = "pnlQuickNavigationBar";
            this.pnlQuickNavigationBar.Size = new System.Drawing.Size(67, 63);
            this.pnlQuickNavigationBar.TabIndex = 7;
            this.pnlQuickNavigationBar.Theme = MetroFramework.MetroThemeStyle.CustomDark;
            this.pnlQuickNavigationBar.VerticalScrollbarBarColor = true;
            this.pnlQuickNavigationBar.VerticalScrollbarHighlightOnWheel = false;
            this.pnlQuickNavigationBar.VerticalScrollbarSize = 10;
            this.pnlQuickNavigationBar.Visible = false;
            // 
            // navMoveDown
            // 
            this.navMoveDown.BackColor = System.Drawing.Color.Black;
            this.navMoveDown.Dock = System.Windows.Forms.DockStyle.Top;
            this.navMoveDown.Image = ((System.Drawing.Image)(resources.GetObject("navMoveDown.Image")));
            this.navMoveDown.ImageSize = 40;
            this.navMoveDown.Location = new System.Drawing.Point(0, 29);
            this.navMoveDown.Name = "navMoveDown";
            this.navMoveDown.Size = new System.Drawing.Size(67, 32);
            this.navMoveDown.TabIndex = 9;
            this.navMoveDown.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.navMoveDown.Theme = MetroFramework.MetroThemeStyle.CustomDark;
            this.navMoveDown.UseSelectable = true;
            this.navMoveDown.Click += new System.EventHandler(this.navMoveDown_Click);
            // 
            // navMoveUp
            // 
            this.navMoveUp.BackColor = System.Drawing.Color.Black;
            this.navMoveUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.navMoveUp.Image = ((System.Drawing.Image)(resources.GetObject("navMoveUp.Image")));
            this.navMoveUp.ImageSize = 40;
            this.navMoveUp.Location = new System.Drawing.Point(0, 0);
            this.navMoveUp.Name = "navMoveUp";
            this.navMoveUp.Size = new System.Drawing.Size(67, 29);
            this.navMoveUp.TabIndex = 8;
            this.navMoveUp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.navMoveUp.Theme = MetroFramework.MetroThemeStyle.CustomDark;
            this.navMoveUp.UseSelectable = true;
            this.navMoveUp.Click += new System.EventHandler(this.navMoveUp_Click);
            // 
            // Navigation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.metroScrollBar);
            this.Controls.Add(this.pnlDetailNavigation);
            this.Controls.Add(this.pnlQuickNavigation);
            this.Name = "Navigation";
            this.Size = new System.Drawing.Size(316, 541);
            this.Load += new System.EventHandler(this.Navigation_Load);
            this.Leave += new System.EventHandler(this.navigationPanel_Leave);
            this.QuickNavigationPanel.ResumeLayout(false);
            this.pnlDetailNavigation.ResumeLayout(false);
            this.pnlDetailNavigation.PerformLayout();
            this.pnlQuickNavigation.ResumeLayout(false);
            this.pnlQuickNavigationBar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel navigationPanel;
        private MetroFramework.Controls.MetroPanel QuickNavigationPanel;
        private MetroFramework.Controls.CustomMetroLink menu;
        private MetroPanel pnlDetailNavigation;
        private MetroFramework.Controls.MetroScrollBar metroScrollBar;
        private Panel pnlQuickNavigation;
        private MetroPanel pnlQuickNavigationBar;
        private CustomMetroLink navMoveDown;
        private CustomMetroLink navMoveUp;
    }
}
