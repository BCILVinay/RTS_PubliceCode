﻿using BCIL;
using BCIL.WMS.Shell.Models;
using System;

namespace BCIL.WMS.Shell.Views
{
    public interface IDashboardView : IBaseView
    {

    }
}