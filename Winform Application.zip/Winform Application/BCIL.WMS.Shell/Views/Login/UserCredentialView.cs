﻿using System;
using System.Windows.Forms;

namespace BCIL.WMS.Shell.Views.Login
{
    public partial class UserCredentialView : pnlSlider
    {
        #region Public Delegates
        public delegate void CancelDelegate();

        public delegate void LogginDelegate(string userName, string password);
        #endregion

        #region Public Constructors
        public UserCredentialView(Control owner)
                            : base(owner)
        {
            InitializeComponent();
            this.HeaderVisible = false;
        }
        #endregion

        #region Public Properties
        public CancelDelegate OnCancel { get; set; }
        public LogginDelegate OnLogginAction { get; set; }
        #endregion

        #region Private Methods
        private void btnCancel_Click(object sender, EventArgs e)
        {
            OnCancel?.Invoke();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUserName.Text))
            {
                BcilMessageBox.ShowException(this, "User name should not blank.");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtPwd.Text))
            {
                BcilMessageBox.ShowException(this, "Password should not blank.");
                return;
            }

            OnLogginAction?.Invoke(txtUserName.Text, txtPwd.Text);
        }

        private void UserCredentialView_Load(object sender, EventArgs e)
        {
            this.FindForm().AcceptButton = this.btnLogin;
            this.FindForm().CancelButton = this.btnCancel;
            txtUserName.Focus();
        }
        #endregion
    }
}