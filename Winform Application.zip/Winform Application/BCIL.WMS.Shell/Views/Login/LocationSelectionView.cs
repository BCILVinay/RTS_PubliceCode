﻿using BCIL;
using BCIL.Administration.BL;
using BCIL.User.BL.Permission;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;


namespace MobiVUE.Shell.Views.Login
{
    public partial class LocationSelectionView : pnlSlider
    {
        private DefaultSettings _DefaultSettings = null;

        private KeyValueCollection _sites;


        public LocationSelectionView(Control owner)
            : base(owner)
        {
            InitializeComponent();
            this.HeaderVisible = false;
        }

        public delegate DefaultSettings DefaultSettingGetterDelegate();

        public delegate void OnCancelClickedDelegate();

        public delegate void OnOkClickedDelegate(KeyValuePair<int,string> value);

        public delegate KeyValueCollection AllowedSitesDelegate();


        public DefaultSettingGetterDelegate DefaultSettingGetter { get; set; }
        public AllowedSitesDelegate AllowedSitesGetter { get; set; }
        public OnCancelClickedDelegate OnCanceledClicked { get; set; }
        public OnOkClickedDelegate OnOkClicked { get; set; }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            OnCanceledClicked?.Invoke();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            var selectedSite = cboSites.SelectedItem as Csla.NameValueListBase<long, string>.NameValuePair;
            if (cboSites.SelectedItem == null || selectedSite == null)
            {
                BcilMessageBox.ShowException(this, "Please select a site");
                return;
            }

            OnOkClicked(new KeyValuePair<int, string>(Convert.ToInt32( selectedSite.Key), selectedSite.Value));
        }

       
     

        private void LocationSelectionView_Load(object sender, EventArgs e)
        {
            if (DefaultSettingGetter != null)
                _DefaultSettings = DefaultSettingGetter();
            else
                _DefaultSettings = new DefaultSettings();

            if (AllowedSitesGetter != null) _sites = AllowedSitesGetter();

            cboSites.BeginUpdate();
            cboSites.DisplayMember = "Value";
            cboSites.ValueMember = "Name";
            cboSites.DataSource = _sites;
            cboSites.EndUpdate();

            if (_DefaultSettings.SiteId > 0)
            {
                var site = _sites.FirstOrDefault(x => x.Key == _DefaultSettings.SiteId);
                if (site != null)
                {
                    cboSites.SelectedIndex = _sites.IndexOf(site);
                }
            }

            FindForm().AcceptButton = btnOK;
            FindForm().CancelButton = btnCancel;
        }

        public class DefaultSettings
        {
            public int SiteId { get; set; }
        }
    }
}