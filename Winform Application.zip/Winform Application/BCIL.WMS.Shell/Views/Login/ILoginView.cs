﻿using BCIL;
using BCIL.User.BL.Permission;
using BCIL.Utility;
using BCIL.WMS.Shell.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BCIL.WMS.Shell.Views
{
    public interface ILoginView : IBaseView<LoginModel>
    {
        event EventHandler<KeyValue<string,string>> AuthenticateCredentials;

        event EventHandler<KeyValuePair<int, string>> AuthorizeUser;

        DialogResult DialogResult { get; set; }
        void GetAuthorizationDetails(KeyValueCollection sites);

    }
}