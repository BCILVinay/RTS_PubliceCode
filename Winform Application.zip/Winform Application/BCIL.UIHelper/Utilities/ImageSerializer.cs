﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper
{
    public static class ImageSerializer
    {
        public static string SerializeImageAsString(Image imageToSerialize)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                imageToSerialize.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                return System.Convert.ToBase64String(memory.ToArray());
            }
        }

        public static Stream SerializeImageAsStram(Image imageToSerialize)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                imageToSerialize.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                return memory;
            }
        }

        public static byte[] SerializeImage(Image imageToSerialize)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                //imageToSerialize.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                //return memory.ToArray();
                ImageConverter imgCon = new ImageConverter();
                return (byte[])imgCon.ConvertTo(imageToSerialize, typeof(byte[]));
            }
        }

        public static Image DeSerializeImage(byte[] imageStringToDeSerialize)
        {
            using (MemoryStream memory = new MemoryStream(imageStringToDeSerialize))
            {
                return Image.FromStream(memory, true);
            }
        }

        public static Image DeSerializeImageFromString(string imageStringToDeSerialize)
        {
            Byte[] imageBytes = Convert.FromBase64String(imageStringToDeSerialize);

            using (MemoryStream memory = new MemoryStream(imageBytes))
            {
                return Image.FromStream(memory, true);
            }
        }

        public static byte[] ConvertStreamToArry(Stream stream)
        {
            using (MemoryStream mStream = new MemoryStream())
            {
                stream.CopyTo(mStream);
                return mStream.ToArray(); 
            }
        }

        public static bool CheckValidLogo(long fileSizeInBytes)
        {
            bool result = false;
            long limitInBytes = 20480;

            if (fileSizeInBytes > 0)
            {
                if (fileSizeInBytes > limitInBytes)
                    result = false;
                else
                    result = true;
            }

            return result;
        }

        public static bool CheckValidImage(long fileSizeInBytes)
        {
            bool result = false;
            long limitInBytes = 51200;

            if (fileSizeInBytes > 0)
            {
                if (fileSizeInBytes > limitInBytes)
                    result = false;
                else
                    result = true;
            }

            return result;
        }
    }
}
