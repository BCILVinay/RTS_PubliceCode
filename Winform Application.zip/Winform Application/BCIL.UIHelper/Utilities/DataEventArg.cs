﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper
{
    public class DataEventArg<T> : EventArgs
    {
        public DataEventArg(T data)
        {
            this.EventData = data;
        }
        public T EventData { get; set; }
    }
}
