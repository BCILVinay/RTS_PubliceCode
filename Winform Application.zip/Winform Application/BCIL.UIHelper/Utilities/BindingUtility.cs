﻿using BCIL;
using BCIL.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL
{
    public class BindingUtility
    {
        public static void CreateBinding<TControl, TDataSource>(TControl controlInstance, Expression<Func<TControl, object>> controlPropertyAccessor, TDataSource DataSource, Expression<Func<TDataSource, object>> datasourceMemberAccesor)
            where TControl : Control
        {
            CodeContract.Required<BCILException>(controlInstance != null, "Control to bind should not be null");

            var propertyName = GetPropertyName(controlPropertyAccessor);
            if (controlInstance.DataBindings.Count > 0)
            {
                var bindings = controlInstance.DataBindings.Cast<Binding>().Where(x => x.PropertyName == propertyName).ToList();
                foreach (Binding binding in bindings)
                {
                    controlInstance.DataBindings.Remove(binding);
                }
            }
            controlInstance.DataBindings.Add(GetPropertyName(controlPropertyAccessor), DataSource, GetPropertyName(datasourceMemberAccesor), true, DataSourceUpdateMode.OnValidation);
        }

        public static void CreateBinding<TControl, TDataSource>(TControl controlInstance, Expression<Func<TControl, object>> controlPropertyAccessor, TDataSource DataSource, Expression<Func<TDataSource, object>> datasourceMemberAccesor, DataSourceUpdateMode mode)
            where TControl : Control
        {
            CodeContract.Required<BCILException>(controlInstance != null, "Control to bind should not be null");

            var propertyName = GetPropertyName(controlPropertyAccessor);
            if (controlInstance.DataBindings.Count > 0)
            {
                var bindings = controlInstance.DataBindings.Cast<Binding>().Where(x => x.PropertyName == propertyName).ToList();
                foreach (Binding binding in bindings)
                {
                    controlInstance.DataBindings.Remove(binding);
                }
            }
            controlInstance.DataBindings.Add(GetPropertyName(controlPropertyAccessor), DataSource, GetPropertyName(datasourceMemberAccesor), true, mode);
        }

        public static string GetPropertyName<TItem, TResult>(Expression<Func<TItem, TResult>> expression)
        {
            if (expression.Body.NodeType == ExpressionType.MemberAccess)
            {
                return (expression.Body as MemberExpression).Member.Name;
            }
            if (expression.Body.NodeType == ExpressionType.Convert || expression.Body.NodeType == ExpressionType.ConvertChecked)
            {
                var op = ((UnaryExpression)expression.Body).Operand;
                return ((MemberExpression)op).Member.Name;
            }
            throw new NotSupportedException("This overload accepts only member access lambda expressions");
        }

        private static void abc()
        {
            CreateBinding(new Control(), x => x.Text, new Button(), y => y.ToString());
        }
    }
}
