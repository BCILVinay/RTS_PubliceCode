﻿using BCIL.UIHelper.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL
{
    public class Images
    {
        public static Image ApplicationLogo { get { return Resources.ApplicationLogo; } }

        public static Image Save { get { return UIHelper.Properties.Resources.save; } }

        public static Image Cancel { get { return UIHelper.Properties.Resources.cancel; } }

        public static Image BlankPicture { get { return UIHelper.Properties.Resources.BlankImage; } }

        public static Image BlankUser { get { return UIHelper.Properties.Resources.BlankImage; } }

        public static Bitmap GetImageLight(string imageName)
        {
            return GetImage(imageName + "_Light");
        }

        public static Bitmap GetImage(string imageName)
        {
            try
            {
                object imageObj = null;

                if (!string.IsNullOrWhiteSpace(imageName))
                {
                    imageObj = UIHelper.Properties.Resources.ResourceManager.GetObject(imageName, UIHelper.Properties.Resources.Culture);
                }

                if (imageObj != null)
                {
                    return ((Bitmap)(imageObj));
                }
                else
                {
                    return UIHelper.Properties.Resources.DefaultMenuIcon;
                }
            }
            catch
            {
                return UIHelper.Properties.Resources.DefaultMenuIcon;
            }
        }

        public static ImageList GetImageList()
        {
            ImageList imagelst = new ImageList();
            imagelst.ImageSize = new System.Drawing.Size(24, 24);
            imagelst.Images.Add("Error", Images.GetImage("Error_Red"));
            imagelst.Images.Add("Valid", Images.GetImage("Valid_Green"));
            return imagelst;
        }
    }
}
