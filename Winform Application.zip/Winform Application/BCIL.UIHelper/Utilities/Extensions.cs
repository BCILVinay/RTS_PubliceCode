﻿using MetroFramework.Controls;
using System.Windows.Forms;

namespace BCIL
{
    public static class UIExtensions
    {
        public static void AllowWholeNumberOnly(this KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)) e.Handled = true;
            if (e.KeyChar == (char)8) e.Handled = false;
        }

        public static void AllowNumbericValueOnly(this KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)) e.Handled = true;
            if (e.KeyChar == (char)8) e.Handled = false;
            if (e.KeyChar == (char)46) e.Handled = false;
        }

        public static bool AllowDecimalValueOnly(object sender, KeyPressEventArgs e)
        {
            var IsValid = false;
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                IsValid = true;
            }
            else
            {
                IsValid = false;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as MetroTextBox).Text.IndexOf(e.KeyChar) != -1)
                {
                    IsValid = true;
                }
                else
                {
                    IsValid = false;
                }
            }

            return IsValid;
        }

        public static void AllowAlphabeticalValueOnly(this KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar)) e.Handled = true;
            if (e.KeyChar == (char)8) e.Handled = false;
            if (e.KeyChar == (char)46) e.Handled = false;
        }

        public static void ResetBindingOrDefaultValueOnInvalid(this MetroFramework.Controls.MetroTextBox txtBox, string defaultVal)
        {
            if (txtBox.IsNull() || txtBox.Text.Length > 0) return;

            if (txtBox.DataBindings.Count > 0)
                txtBox.DataBindings[0].ReadValue();
            else
                txtBox.Text = defaultVal;
        }

        public static void InspectPropertiesAtRuntime(this Control ctrl)
        {
#if DEBUG
            ctrl.ContextMenuStrip = new ContextMenuStrip();
            ToolStripItem item = new ToolStripButton("Show Properties");
            item.Size = new System.Drawing.Size(70, 10);
            item.Click += (sender, arg) =>
            {
                UIHelper.Controls.PropertyView.ShowProperties(ctrl);
            };
            ctrl.ContextMenuStrip.Items.Add(item);
#endif
        }
    }
}