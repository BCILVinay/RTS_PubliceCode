﻿using BCIL.Administration.BL;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using BCIL.User.BL.Permission;
using BCIL.WMS.BL;
using Csla.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;

namespace BCIL
{
    public sealed class App
    {
        public static event EventHandler LoginSiteChanged;

        public const string Name = "WMS";

        public const string DateFormat = "dd MMMM yyyy";

        public const int InlineMessageDisaprearTime = 15000;

        public static Form Shell { get; set; }

        public static Control MainContainer { get; set; }

        public static Dictionary<string, Node> ApplicationActionNodes { get; set; }

        private static void SaveConfig(string key, string value)
        {
            Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            if (config.AppSettings.Settings.AllKeys.Any(x => x == key)) {
                config.AppSettings.Settings[key].Value = value;
            }
            else {
                config.AppSettings.Settings.Add(key, value);
            }

            // Save the changes in App.config file.
            config.Save(ConfigurationSaveMode.Modified);

            // Force a reload of a changed section.
            System.Configuration.ConfigurationManager.RefreshSection("appSettings");
        }

        public class WorkStation
        {
            private static Location _location;
            public static Location WMaterialBination
            {
                get
                {
                    return _location;
                }
                set
                {
                    if (_location != value) {
                        _location = value;
                        SaveConfig("WMaterialBination", _location.LocationId.ToString());
                        LoginSiteChanged?.Invoke(null, null);
                    }
                }
            }

            private static Line _line;
            public static Line WSLine
            {
                get
                {
                    return _line;
                }
                set
                {
                    if (_line != value) {
                        _line = value;

                        SaveConfig("WSLine", _line.LineId.ToString());

                        LoginSiteChanged?.Invoke(null, null);
                    }
                }
            }
        }

        public class Login
        {
            public static Employee Employee { get; set; }

            private static Site _Site;

            public static Site LoginSite
            {
                get
                {
                    return _Site;
                }
                set
                {
                    if (_Site != value)
                    {
                        _Site = value;
                        SaveConfig("WSSite", _Site.IsNull() ? "" : _Site.SiteId.ToString());
                        LoginSiteChanged?.Invoke(null, null);
                    }
                }
            }

            public static int ApplicationBelongsTo { get; set; }

            public class User
            {
                public static string LogInUser { get; set; }
                public static string LogInPassword { get; set; }
                public static Dictionary<string, UserPermission> Permissions { get; set; }

                public static bool IsSupperUser { get; set; }

                private static bool IsNodeBelongsToLoginedLocation(string code)
                {
                    if (App.ApplicationActionNodes[code].NodeBelongsTo == 0)
                        return true;
                    else if (App.ApplicationActionNodes[code].NodeBelongsTo == ApplicationBelongsTo)
                        return true;
                    else
                        return false;
                }

                public static bool HasPermission(string code, PermissionType permission)
                {
                    if (!IsNodeBelongsToLoginedLocation(code)) return false;

                    if (IsSupperUser)
                    {
                        if (permission == PermissionType.None)
                            return false;
                        else
                            return true;
                    }

                    if (Permissions == null || Permissions.Count == 0 || !Permissions.ContainsKey(code)) return false;


                    if (permission == PermissionType.Any)
                        return Permissions[code].Permission != PermissionType.None;
                    else
                        return Permissions[code].Permission == permission;
                }

                public static bool HasAnyPermission(string code)
                {
                    if (!IsNodeBelongsToLoginedLocation(code)) return false;

                    if (IsSupperUser) return true;

                    if (Permissions == null || Permissions.Count == 0 || !Permissions.ContainsKey(code)) return false;
                    return Permissions[code].Permission != PermissionType.None;
                }

                public static bool HasPermissionOnAnyChild(string code)
                {
                    if (!IsNodeBelongsToLoginedLocation(code)) return false;

                    if (IsSupperUser) return true;

                    if (Permissions == null || Permissions.Count == 0) return false;

                    if (Permissions.ContainsKey(code) && Permissions[code].Permission != PermissionType.None) return true;

                    return Permissions.Where(x => x.Value.ParentCode == code).Any(y => y.Value.Permission != PermissionType.None);
                }
            }
        }

        public static void SetWorkstationLocation(Int64 locationId)
        {
            if (locationId > 0)
                App.WorkStation.WMaterialBination = Location.GetLocation(locationId);
        }
        public static void SetWorkstationLine(Int32 lineId)
        {
            if (lineId > 0)
                App.WorkStation.WSLine = Line.GetLine(lineId);
        }
    }
}