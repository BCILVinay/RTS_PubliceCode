﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL
{
    public sealed class PermissionCode
    {
        #region User Management
        public const string Users = "UR002";
        public const string Roles = "UR003";
        public const string RolePermission = "UR003-1";
        public const string ChangeCredentials = "UR002-1";
        public const string AssignRoleAndPermission = "UR002-2";
        #endregion

        #region Masters
        public const string RegionAndSiteSetup = "IN002";
        public const string StoreWarehouse = "IN003";
        public const string Seasons = "IN004";
        public const string MasterDataConfiguration = "IN005";
        public const string Suppliers = "IN006";
        public const string Slot = "IN007";
        public const string ItemCategory = "IN008";
        public const string Size = "IN009";
        public const string Brand = "IN0010";
        public const string Order = "IN0011";
        public const string Items = "IN0012";
        public const string Reason = "IN0031";
        #endregion

        public const string Oprations = "IN001";
        public const string GeneralSetup = "GS001";
        public const string CompanyProfile = "GS002";
        public const string FreshItemPacking = "IN0018-1";
        public const string RequestBasedItemPacking = "IN0018-2";
        public const string RequestBasedCartonPacking = "IN0018-3";
        public const string ItemPackingStore = "IN0018-4";
        public const string ItemReceiving = "IN0024-1";
        public const string BulkReceiving = "IN0024-2";
        public const string FreshDispatch = "IN0022-1";
        public const string RequestBasedDispatch = "IN0022-2";
        public const string GOARequestApproval = "IN0025-1";

    }
}
