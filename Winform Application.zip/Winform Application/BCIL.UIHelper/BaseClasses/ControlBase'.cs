﻿using BCIL.UIHelper;
using BCIL.Utility;
using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsMvp;
using WinFormsMvp.Binder;

namespace BCIL
{
    public partial class ControlBase : MetroUserControl, IView
    {
        private readonly PresenterBinder presenterBinder = new PresenterBinder();
        public ControlBase()
        {
            ThrowExceptionIfNoPresenterBound = true;

            presenterBinder.PerformBinding(this);

            //required for menu flip
            this.Click += ControlBase_Click;
            this.ControlAdded += ControlBase_ControlAdded;
        }

        private void ControlBase_ControlAdded(object sender, ControlEventArgs e)
        {
            AttachEvents(e.Control);
        }

        void AttachEvents(Control ctrl)
        {
            ctrl.Click += ControlBase_Click;
            ctrl.ControlAdded += ControlBase_ControlAdded;

            foreach (Control control in ctrl.Controls)
            {
                AttachEvents(control);
            }
        }


        private void ControlBase_Click(object sender, EventArgs e)
        {
            this.Focus();
        }

        public bool ThrowExceptionIfNoPresenterBound { get; private set; }

        public void ShowException(Exception ex)
        {
            BcilMessageBox.ShowException(this, ex);
        }

        public void ShowException(string message)
        {
            BcilMessageBox.ShowException(this, message);
        }

        public void ShowMessage(string message)
        {
            BcilMessageBox.ShowMessage(this, message);
        }

        public DialogResult UserInput(string message, MessageBoxButtons options)
        {
            return BcilMessageBox.GetUserInput(this, message, options);
        }

        public Label MessageLable { get; set; }

        private void SetTimer()
        {
            if (_threadToProcessTag == null)
            {
                _threadToProcessTag = new System.Threading.Timer((s) =>
                {
                    if (MessageLable.InvokeRequired)
                    {
                        MessageLable.BeginInvoke((Action)(() =>
                        {
                            MessageLable.Text = "";
                            _threadToProcessTag.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                        }));
                    }

                }, null, App.InlineMessageDisaprearTime, App.InlineMessageDisaprearTime);
            }
            else
            {
                _threadToProcessTag.Change(App.InlineMessageDisaprearTime, App.InlineMessageDisaprearTime);
            }
        }

        private System.Threading.Timer _threadToProcessTag;
        public void ShowInControlException(Exception ex, string moduleName)
        {
            BcilLogger.Error(ex, moduleName);
            if (MessageLable.IsNull()) return;

            if (MessageLable.InvokeRequired)
            {
                MessageLable.Invoke((Action)(() =>
                {
                    SetTimer();
                    MessageLable.ForeColor = System.Drawing.Color.Red;
                    MessageLable.Text = ex.Message;
                }));
            }
            else
            {
                SetTimer();
                MessageLable.ForeColor = System.Drawing.Color.Red;
                MessageLable.Text = ex.Message;
            }
        }

        public void ShowInControlException(Exception ex)
        {
            ShowInControlException(ex, "");
        }

        public void ShowInControlMessage(string message)
        {
            if (MessageLable.IsNull()) return;

            if (MessageLable.InvokeRequired)
            {
                MessageLable.Invoke((Action)(() =>
                {
                    SetTimer();
                    MessageLable.ForeColor = System.Drawing.Color.Green;
                    MessageLable.Text = message;
                }));

            }
            else
            {
                SetTimer();
                MessageLable.ForeColor = System.Drawing.Color.Green;
                MessageLable.Text = message;
            }
        }
    }
}
