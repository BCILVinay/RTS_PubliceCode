﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL
{
    public interface IBaseView<TModel> : IView
    {
        TModel Model { get; set; }

        void ShowException(Exception ex);

        void ShowMessage(string message);

        void ShowException(string message);

        DialogResult UserInput(string message, MessageBoxButtons options);

        void ShowInControlException(Exception ex);

        void ShowInControlException(Exception ex, string moduleName);

        void ShowInControlMessage(string message);
       
    }

    public interface IBaseView : IView
    {
        void ShowException(Exception ex);

        void ShowMessage(string message);

        void ShowException(string message);

        DialogResult UserInput(string message, MessageBoxButtons options);
    }
}
