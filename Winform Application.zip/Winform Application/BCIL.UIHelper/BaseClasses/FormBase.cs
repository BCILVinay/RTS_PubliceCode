﻿using BCIL.Utility;
using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsMvp;
using WinFormsMvp.Binder;

namespace BCIL.UIHelper
{
    public class FormBase : MetroForm, IView
    {
        private readonly PresenterBinder presenterBinder = new PresenterBinder();
        public FormBase()
        {
            ThrowExceptionIfNoPresenterBound = true;

            presenterBinder.PerformBinding(this);
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1024, 700);
            this.ShowInTaskbar = false;
            this.Resizable = false;
            this.KeyPreview = true;
        }

        public bool ThrowExceptionIfNoPresenterBound { get; private set; }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBase));
            this.SuspendLayout();
            // 
            // FormBase
            // 
            this.ClientSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            
            this.Name = "FormBase";
            this.ResumeLayout(false);

        }

        public void ShowException(Exception ex)
        {
            BcilMessageBox.ShowException(this, ex);
        }

        public void ShowException(string message)
        {
            BcilMessageBox.ShowException(this, message);
        }

        public void ShowMessage( string message)
        {
            BcilMessageBox.ShowMessage(this, message);
        }

        public DialogResult UserInput(string message, MessageBoxButtons options)
        {
            return BcilMessageBox.GetUserInput(this, message, options);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
            if (e.KeyCode == Keys.Escape && !e.Handled)
            {
                this.Close();
            }
        }

        public Label MessageLable { get; set; }

        private void SetTimer()
        {
            if (_threadToProcessTag == null)
            {
                _threadToProcessTag = new System.Threading.Timer((s) =>
                {
                    if (MessageLable.InvokeRequired)
                    {
                        MessageLable.BeginInvoke((Action)(() =>
                        {
                            MessageLable.Text = "";
                            _threadToProcessTag.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                        }));
                    }

                }, null, App.InlineMessageDisaprearTime, App.InlineMessageDisaprearTime);
            }
            else
            {
                _threadToProcessTag.Change(App.InlineMessageDisaprearTime, App.InlineMessageDisaprearTime);
            }
        }

        private System.Threading.Timer _threadToProcessTag;
        public void ShowInControlException(Exception ex, string moduleName)
        {
            BcilLogger.Error(ex, moduleName);
            if (MessageLable.IsNull()) return;

            if (MessageLable.InvokeRequired)
            {
                MessageLable.Invoke((Action)(() =>
                {
                    SetTimer();
                    MessageLable.ForeColor = System.Drawing.Color.Red;
                    MessageLable.Text = ex.Message;
                }));
            }
            else
            {
                SetTimer();
                MessageLable.ForeColor = System.Drawing.Color.Red;
                MessageLable.Text = ex.Message;
            }
        }

        public void ShowInControlException(Exception ex)
        {
            ShowInControlException(ex, "");
        }

        public void ShowInControlMessage(string message)
        {
            if (MessageLable.IsNull()) return;

            if (MessageLable.InvokeRequired)
            {
                MessageLable.Invoke((Action)(() =>
                {
                    SetTimer();
                    MessageLable.ForeColor = System.Drawing.Color.Green;
                    MessageLable.Text = message;
                }));

            }
            else
            {
                SetTimer();
                MessageLable.ForeColor = System.Drawing.Color.Green;
                MessageLable.Text = message;
            }
        }

    }
}
