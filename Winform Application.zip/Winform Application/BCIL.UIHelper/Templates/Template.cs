﻿using System;
using System.Data;

namespace BCIL.UIHelper
{
    public class Template
    {
        #region CustomerOrder

        public DataSet GetImportCustomerOrderTemplate()
        {
            var dataSource = new DataSet();
            DataTable templateDt = new DataTable();

            templateDt.Columns.Add("CustomerOrderCode", typeof(string));
            templateDt.Columns.Add("ItemCode", typeof(string));
            templateDt.Columns.Add("Quantity", typeof(int));
            templateDt.Columns.Add("PinCode", typeof(string));
            templateDt.Columns.Add("CustomerName", typeof(string));
            templateDt.Columns.Add("ShippingAddress", typeof(string));

            templateDt.Rows.Add("ABC0002", "U61000BCMM17", 5, "110092", "Mohan", "Mohan Corp Mumbai");
            templateDt.Rows.Add("ABC0003", "ABC0001", 10, "110092", "Sohan", "Sohan Corp Gurgaon");
            templateDt.Rows.Add("ABC0004", "ABC0001", 2, "110092", "Sita Gita", "SitaGita Corp Noida");
            templateDt.Rows.Add("ABC0005", "ITEM   987ICEGRNMSRRR", 6, "110092", "Radhe Mohan", "RadheMohan Corp Delhi");

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        #endregion CustomerOrder

        #region User

        public DataSet GetImportUserTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("Name", typeof(string));
            templateDt.Columns.Add("Email", typeof(string));
            templateDt.Columns.Add("Address", typeof(string));
            templateDt.Columns.Add("Phone1", typeof(string));

            templateDt.Rows.Add("Ram", "Ram@barcodeindia.com", "Delhi", "9874563210");
            templateDt.Rows.Add("Shyam", "Shyam@barcodeindia.com", "Mumbai", "9874563212");
            templateDt.Rows.Add("Mohan", "Mohan@barcodeindia.com", "Chennai", "9874563213");
            templateDt.Rows.Add("Sohan", "Sohan@barcodeindia.com", "Noida", "9874563214");

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        public DataSet GetImportPOTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("PONo", typeof(string));
            templateDt.Columns.Add("PODate", typeof(string));
            templateDt.Columns.Add("PlantCode", typeof(string));
            templateDt.Columns.Add("MovementType", typeof(string));
            templateDt.Columns.Add("ChangeDate", typeof(string));
            templateDt.Columns.Add("PPLine", typeof(string));
            templateDt.Columns.Add("MaterialCode", typeof(string));
            templateDt.Columns.Add("BundleQty", typeof(int));
            templateDt.Columns.Add("UoM", typeof(string));
            templateDt.Columns.Add("Length", typeof(decimal));
            templateDt.Columns.Add("SLoc", typeof(string));

            templateDt.Rows.Add("11074", "03-12-2018", "FEXT", "TEST", "03-12-2018", "L1001", "M1001", 2, "ME", 23, "FKPS");
            templateDt.Rows.Add("11075", "04-12-2018", "FEXT", "TEST", "05-12-2018", "L1002", "M1002", 4, "ME", 35, "WP01");
            templateDt.Rows.Add("11076", "05-12-2018", "FEXT", "TEST", "04-12-2018", "L1001", "M1001", 5, "ME", 140, "FKPS");
            templateDt.Rows.Add("11077", "06-12-2018", "FEXT", "TEST", "06-12-2018", "L1002", "M1002", 6, "ME", 220, "WP01");

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        public DataSet GetImportMaterialBinTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("MaterialBinCode", typeof(string));
            templateDt.Columns.Add("RackNo", typeof(string));
            templateDt.Columns.Add("RowNo", typeof(string));
            templateDt.Columns.Add("ColumnNo", typeof(string));
            templateDt.Columns.Add("Height", typeof(decimal));
            templateDt.Columns.Add("Width", typeof(decimal));
            templateDt.Columns.Add("MaterialCode", typeof(string));
            templateDt.Columns.Add("LocationCode", typeof(string));
            templateDt.Columns.Add("Capacity", typeof(int));

            templateDt.Rows.Add("30238A1", "A1", "1", "A", 1.5, 20.5, "30238", "FW01", 4);
            templateDt.Rows.Add("30239B1", "B1", "2", "B", 6.5, 2.5, "30239", "FW01", 2);
            templateDt.Rows.Add("30240C1", "C1", "3", "C", 9.5, 4.5, "30240", "FW01", 3);

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        public DataSet GetImportMaterialTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("MaterialCode", typeof(string));
            templateDt.Columns.Add("MaterialDescription", typeof(string));
            templateDt.Columns.Add("ToolingCode", typeof(string));
            templateDt.Columns.Add("UOM", typeof(string));
            templateDt.Columns.Add("SectionalWeight", typeof(decimal));
            templateDt.Columns.Add("StdBarLength", typeof(decimal));
            templateDt.Columns.Add("PackSize", typeof(Int32));
            templateDt.Columns.Add("Breath", typeof(decimal));
            templateDt.Columns.Add("Height", typeof(decimal));
            templateDt.Columns.Add("Weight", typeof(decimal));
            templateDt.Columns.Add("IsBrown", typeof(bool));

            templateDt.Rows.Add("M1001", "UPVC_PROFILE PWH S56 PF1", "A65 PB1", "ME", 1.23, 6.50, 4, 65.9, 20.6, 2.5, true);
            templateDt.Rows.Add("M1002", "UPVC_PROFILE PWH S56 PT2", "A65 PB2", "ME", 1.23, 12.60, 4, 35.2, 20.4, 2.5, true);
            templateDt.Rows.Add("M1003", "UPVC_PROFILE PWH S56 PS5", "A65 PB3", "ME", 1.23, 10.80, 4, 14.8, 20.7, 2.5, true);

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        public DataSet GetImportLocationTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("LocationCode", typeof(string));
            templateDt.Columns.Add("LocationType", typeof(string));
            templateDt.Columns.Add("Mode", typeof(string));
            templateDt.Columns.Add("DimensionHeight", typeof(decimal));
            templateDt.Columns.Add("DimensionLength", typeof(decimal));
            templateDt.Columns.Add("DimensionWidth", typeof(decimal));

            templateDt.Rows.Add("Gurugram", "Interim", "Trolley", 25.00, 25.00, 150.00);
            templateDt.Rows.Add("Delhi", "Scrap", "Bin", 15.00, 15.00, 250.00);
            templateDt.Rows.Add("Mumbai", "Quality", "Grid", 5.00, 5.00, 350.00);

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        public DataSet GetImportToolingTemplate()
        {
            DataTable templateDt = new DataTable();
            var dataSource = new DataSet();
            templateDt.Columns.Add("ToolingCode", typeof(string));
            templateDt.Columns.Add("ToolingSpeed", typeof(decimal));

            templateDt.Columns.Add("LineCode", typeof(string));
            templateDt.Columns.Add("PrefencesLineCode", typeof(string));
            templateDt.Columns.Add("LocationCode", typeof(string));
            templateDt.Columns.Add("OtherInfo", typeof(string));

            templateDt.Rows.Add("S56PS2", 1.5, "L1002", "L1002", "FKPS", "WH");
            templateDt.Rows.Add("S56PS1", 1.5, "L1001", "L1001", "WP01", "BR");

            dataSource.Tables.Add(templateDt);
            return dataSource;
        }

        #endregion User
    }
}