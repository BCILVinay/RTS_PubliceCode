﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper
{
    public class ButtonSave : MyMetroButton
    {
        public ButtonSave ()
        {
            this.ButtonImage = Properties.Resources.save;
            this.Size = new System.Drawing.Size(85, 56);
            this.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ImageSize = 50;
            this.Text = "Save";
        }
    }
}
