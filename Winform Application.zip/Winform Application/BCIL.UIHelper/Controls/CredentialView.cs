﻿using BCIL.User.BL;
using BCIL.Utility;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public partial class CredentialView : MetroFramework.Forms.MetroForm 
    {
        private bool _changePassword = false;
        private bool _changePasswordByAdmin = false;
        public CredentialView(bool changePassword, bool isChangedByAdmin)
        {
            InitializeComponent();
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1024, 700);
            this.ShowInTaskbar = false;
            _changePassword = changePassword;
            _changePasswordByAdmin = isChangedByAdmin;
        }

        public string LoginId { get; set; }

        public string Password { get; set; }

        public string NewPassword { get; set; }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (!_changePassword)
                   CodeContract.Required<BCILException>(!string.IsNullOrWhiteSpace(txtLoginId.Text), "Login id should not blank");

                if (!_changePasswordByAdmin)
                {
                    if(!UserAuthenticateCommand.Authenticate(txtLoginId.Text, txtPassword.Text).IsAuthenticated )
                    {
                        throw new BCILException("Invalid existing password");
                    }
                    CodeContract.Required<BCILException>(!string.IsNullOrWhiteSpace(txtPassword.Text), "Password should not blank");
                }

                CodeContract.Required<BCILException>(!string.IsNullOrWhiteSpace(txtNewPassword.Text), "New password should not blank");
                CodeContract.Required<BCILException>(!string.IsNullOrWhiteSpace(txtConfirmPassword.Text), "Confirm password should not blank");
                CodeContract.Required<BCILException>(txtConfirmPassword.Text==txtNewPassword.Text  , "Confirm password doesn't match with new password");

                this.LoginId = txtLoginId.Text.Trim();
                this.Password = txtPassword.Text.Trim();
                this.NewPassword = txtNewPassword.Text.Trim();
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                BcilMessageBox.ShowException(this, ex);
            }
        }

        private void UserCredentialView_Load(object sender, EventArgs e)
        {
            if(_changePassword)
            {
                txtLoginId.ReadOnly = true;
                txtLoginId.Text = LoginId;
                if(_changePasswordByAdmin)
                {
                    lblPassword.Visible = false;
                    pnlPassword.Visible = false; 
                }
                else
                {
                    lblPassword.Visible = true;
                    pnlPassword.Visible = true;
                }
            }
            else
            {
                lblLoginId.Visible = true;
                pnlLoginId.Visible = true;

                lblPassword.Visible = false;
                pnlPassword.Visible = false;
                lblNewPassword.Text = "Password";
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
