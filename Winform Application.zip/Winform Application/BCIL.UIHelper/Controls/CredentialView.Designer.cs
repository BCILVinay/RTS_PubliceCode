﻿namespace BCIL.UIHelper
{
    partial class CredentialView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CredentialView));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlNewPassword = new BCIL.UIHelper.RequiredPanel();
            this.txtNewPassword = new MetroFramework.Controls.MetroTextBox();
            this.pnlPassword = new BCIL.UIHelper.RequiredPanel();
            this.txtPassword = new MetroFramework.Controls.MetroTextBox();
            this.lblPassword = new MetroFramework.Controls.MetroLabel();
            this.lblLoginId = new MetroFramework.Controls.MetroLabel();
            this.pnlLoginId = new BCIL.UIHelper.RequiredPanel();
            this.txtLoginId = new MetroFramework.Controls.MetroTextBox();
            this.lblNewPassword = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel4 = new BCIL.UIHelper.RequiredPanel();
            this.txtConfirmPassword = new MetroFramework.Controls.MetroTextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlNewPassword.SuspendLayout();
            this.pnlPassword.SuspendLayout();
            this.pnlLoginId.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.requiredPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.pnlNewPassword, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.pnlPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblPassword, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblLoginId, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlLoginId, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblNewPassword, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.metroPanel1, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.requiredPanel4, 1, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(23, 63);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(428, 205);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pnlNewPassword
            // 
            this.pnlNewPassword.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlNewPassword.BackColor = System.Drawing.Color.Transparent;
            this.pnlNewPassword.Controls.Add(this.txtNewPassword);
            this.pnlNewPassword.IsRequired = true;
            this.pnlNewPassword.Location = new System.Drawing.Point(128, 67);
            this.pnlNewPassword.Name = "pnlNewPassword";
            this.pnlNewPassword.Size = new System.Drawing.Size(297, 26);
            this.pnlNewPassword.TabIndex = 3;
            // 
            // txtNewPassword
            // 
            // 
            // 
            // 
            this.txtNewPassword.CustomButton.Image = null;
            this.txtNewPassword.CustomButton.Location = new System.Drawing.Point(253, 2);
            this.txtNewPassword.CustomButton.Name = "";
            this.txtNewPassword.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtNewPassword.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtNewPassword.CustomButton.TabIndex = 1;
            this.txtNewPassword.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtNewPassword.CustomButton.UseSelectable = true;
            this.txtNewPassword.CustomButton.Visible = false;
            this.txtNewPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNewPassword.Lines = new string[0];
            this.txtNewPassword.Location = new System.Drawing.Point(0, 0);
            this.txtNewPassword.MaxLength = 50;
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.PasswordChar = '.';
            this.txtNewPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNewPassword.SelectedText = "";
            this.txtNewPassword.SelectionLength = 0;
            this.txtNewPassword.SelectionStart = 0;
            this.txtNewPassword.ShortcutsEnabled = true;
            this.txtNewPassword.Size = new System.Drawing.Size(277, 26);
            this.txtNewPassword.TabIndex = 0;
            this.txtNewPassword.UseSelectable = true;
            this.txtNewPassword.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtNewPassword.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pnlPassword
            // 
            this.pnlPassword.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlPassword.BackColor = System.Drawing.Color.Transparent;
            this.pnlPassword.Controls.Add(this.txtPassword);
            this.pnlPassword.IsRequired = true;
            this.pnlPassword.Location = new System.Drawing.Point(128, 35);
            this.pnlPassword.Name = "pnlPassword";
            this.pnlPassword.Size = new System.Drawing.Size(297, 26);
            this.pnlPassword.TabIndex = 2;
            // 
            // txtPassword
            // 
            // 
            // 
            // 
            this.txtPassword.CustomButton.Image = null;
            this.txtPassword.CustomButton.Location = new System.Drawing.Point(253, 2);
            this.txtPassword.CustomButton.Name = "";
            this.txtPassword.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPassword.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPassword.CustomButton.TabIndex = 1;
            this.txtPassword.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPassword.CustomButton.UseSelectable = true;
            this.txtPassword.CustomButton.Visible = false;
            this.txtPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPassword.Lines = new string[0];
            this.txtPassword.Location = new System.Drawing.Point(0, 0);
            this.txtPassword.MaxLength = 50;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '.';
            this.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPassword.SelectedText = "";
            this.txtPassword.SelectionLength = 0;
            this.txtPassword.SelectionStart = 0;
            this.txtPassword.ShortcutsEnabled = true;
            this.txtPassword.Size = new System.Drawing.Size(277, 26);
            this.txtPassword.TabIndex = 0;
            this.txtPassword.UseSelectable = true;
            this.txtPassword.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPassword.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(3, 32);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(67, 19);
            this.lblPassword.TabIndex = 26;
            this.lblPassword.Text = "Password:";
            // 
            // lblLoginId
            // 
            this.lblLoginId.AutoSize = true;
            this.lblLoginId.Location = new System.Drawing.Point(3, 0);
            this.lblLoginId.Name = "lblLoginId";
            this.lblLoginId.Size = new System.Drawing.Size(59, 19);
            this.lblLoginId.TabIndex = 0;
            this.lblLoginId.Text = "Login Id:";
            // 
            // pnlLoginId
            // 
            this.pnlLoginId.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlLoginId.BackColor = System.Drawing.Color.Transparent;
            this.pnlLoginId.Controls.Add(this.txtLoginId);
            this.pnlLoginId.IsRequired = true;
            this.pnlLoginId.Location = new System.Drawing.Point(128, 3);
            this.pnlLoginId.Name = "pnlLoginId";
            this.pnlLoginId.Size = new System.Drawing.Size(297, 26);
            this.pnlLoginId.TabIndex = 1;
            // 
            // txtLoginId
            // 
            // 
            // 
            // 
            this.txtLoginId.CustomButton.Image = null;
            this.txtLoginId.CustomButton.Location = new System.Drawing.Point(253, 2);
            this.txtLoginId.CustomButton.Name = "";
            this.txtLoginId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtLoginId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLoginId.CustomButton.TabIndex = 1;
            this.txtLoginId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLoginId.CustomButton.UseSelectable = true;
            this.txtLoginId.CustomButton.Visible = false;
            this.txtLoginId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLoginId.Lines = new string[0];
            this.txtLoginId.Location = new System.Drawing.Point(0, 0);
            this.txtLoginId.MaxLength = 50;
            this.txtLoginId.Name = "txtLoginId";
            this.txtLoginId.PasswordChar = '\0';
            this.txtLoginId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLoginId.SelectedText = "";
            this.txtLoginId.SelectionLength = 0;
            this.txtLoginId.SelectionStart = 0;
            this.txtLoginId.ShortcutsEnabled = true;
            this.txtLoginId.Size = new System.Drawing.Size(277, 26);
            this.txtLoginId.TabIndex = 0;
            this.txtLoginId.UseSelectable = true;
            this.txtLoginId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLoginId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Location = new System.Drawing.Point(3, 64);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(97, 19);
            this.lblNewPassword.TabIndex = 27;
            this.lblNewPassword.Text = "New Password:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(3, 96);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(119, 19);
            this.metroLabel3.TabIndex = 31;
            this.metroLabel3.Text = "Confirm Password:";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.btnCancel);
            this.metroPanel1.Controls.Add(this.btnSave);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(128, 131);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(297, 71);
            this.metroPanel1.TabIndex = 6;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(198, 11);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(96, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel4
            // 
            this.requiredPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel4.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel4.Controls.Add(this.txtConfirmPassword);
            this.requiredPanel4.IsRequired = true;
            this.requiredPanel4.Location = new System.Drawing.Point(128, 99);
            this.requiredPanel4.Name = "requiredPanel4";
            this.requiredPanel4.Size = new System.Drawing.Size(297, 26);
            this.requiredPanel4.TabIndex = 5;
            // 
            // txtConfirmPassword
            // 
            // 
            // 
            // 
            this.txtConfirmPassword.CustomButton.Image = null;
            this.txtConfirmPassword.CustomButton.Location = new System.Drawing.Point(253, 2);
            this.txtConfirmPassword.CustomButton.Name = "";
            this.txtConfirmPassword.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtConfirmPassword.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtConfirmPassword.CustomButton.TabIndex = 1;
            this.txtConfirmPassword.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtConfirmPassword.CustomButton.UseSelectable = true;
            this.txtConfirmPassword.CustomButton.Visible = false;
            this.txtConfirmPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtConfirmPassword.Lines = new string[0];
            this.txtConfirmPassword.Location = new System.Drawing.Point(0, 0);
            this.txtConfirmPassword.MaxLength = 50;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '.';
            this.txtConfirmPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtConfirmPassword.SelectedText = "";
            this.txtConfirmPassword.SelectionLength = 0;
            this.txtConfirmPassword.SelectionStart = 0;
            this.txtConfirmPassword.ShortcutsEnabled = true;
            this.txtConfirmPassword.Size = new System.Drawing.Size(277, 26);
            this.txtConfirmPassword.TabIndex = 0;
            this.txtConfirmPassword.UseSelectable = true;
            this.txtConfirmPassword.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtConfirmPassword.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // CredentialView
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 283);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "CredentialView";
            this.Text = "Credentials";
            this.Load += new System.EventHandler(this.UserCredentialView_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.pnlNewPassword.ResumeLayout(false);
            this.pnlPassword.ResumeLayout(false);
            this.pnlLoginId.ResumeLayout(false);
            this.metroPanel1.ResumeLayout(false);
            this.requiredPanel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private RequiredPanel pnlNewPassword;
        private MetroFramework.Controls.MetroTextBox txtNewPassword;
        private RequiredPanel pnlPassword;
        private MetroFramework.Controls.MetroTextBox txtPassword;
        private MetroFramework.Controls.MetroLabel lblPassword;
        private MetroFramework.Controls.MetroLabel lblLoginId;
        private RequiredPanel pnlLoginId;
        private MetroFramework.Controls.MetroTextBox txtLoginId;
        private MetroFramework.Controls.MetroLabel lblNewPassword;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private ButtonCancel btnCancel;
        private ButtonSave btnSave;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private RequiredPanel requiredPanel4;
        private MetroFramework.Controls.MetroTextBox txtConfirmPassword;
    }
}