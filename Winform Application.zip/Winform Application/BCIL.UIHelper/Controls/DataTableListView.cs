﻿using BrightIdeasSoftware;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public class DataTableListView : BrightIdeasSoftware.DataListView
    {
        public DataTableListView()
        {
            UpdateUI();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);

            UpdateUI();
        }
        public override bool ShowGroups { get; set; }
        private void UpdateUI()
        {
            this.HeaderUsesThemes = false;
            this.IncludeColumnHeadersInCopy = true;
            Font font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.HeaderFormatStyle = new BrightIdeasSoftware.HeaderFormatStyle()
            {
                Normal = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = ControlPaint.Light(Color.WhiteSmoke, .2f), Font = font },
                Hot = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.FromArgb(235, 235, 235), Font = font },
                Pressed = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.FromArgb(235, 235, 235), Font = font }
            };
            this.Font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.ForeColor = Color.FromArgb(136, 136, 136);
            this.HeaderMinimumHeight = 30;
            this.ShowGroups = ShowGroups;
            this.FullRowSelect = true;
            this.HideSelection = false;
            if (this.RowHeight != 25) this.RowHeight = 25;
        }
    }
}
