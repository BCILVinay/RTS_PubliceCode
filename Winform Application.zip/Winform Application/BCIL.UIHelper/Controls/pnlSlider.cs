﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Controls;
using Transitions;

namespace BCIL
{
    public partial class pnlSlider : MetroUserControl
    {
#region Variables
        private Control _owner = null;
        private bool _loaded = false;
#endregion

#region Public Events
        public event EventHandler Closed;
        public event EventHandler Shown;
        public event EventHandler<ActionArg>  Showing;
        public event EventHandler<ActionArg> Closing;
        #endregion

#region Properties
        public string Title {
            get { return lnkBack.Text.Trim(); }
            set { lnkBack.Text = "        " + value; }
        }

        [Browsable(true)]
        public bool HeaderVisible
        {
            get { return pnlHeader.Visible; }
            set { pnlHeader.Visible = value; }
        }
#endregion

#region Constructor
        public pnlSlider()
        {
            InitializeComponent();
        }
        public pnlSlider(Control owner, string title = "")
           : this()
        {
            this.Visible = false;
            this.Title = title;
            if (owner != null)
            {
                _owner = owner;
                owner.Controls.Add(this);
                this.BringToFront();
                owner.Resize += owner_Resize;
                ResizeForm();
            }
        }

#endregion

#region Functions
        protected virtual void closed(EventArgs e)
        {
            Closed?.Invoke(this, e);
        }

        public virtual void closing(ActionArg e)
        {
            Closing?.Invoke(this, e);
        }

        protected virtual void shown(EventArgs e)
        {
            Shown?.Invoke(this, e);
        }

        protected virtual void showing(ActionArg e)
        {
            Showing?.Invoke(this, e);
        }

        private void ResizeForm()
        {
            this.Width = _owner.Width;
            //this.Height = _owner.Height - 77;
            this.Height = _owner.Height;
            //this.Location = new Point(_loaded ? 0 : _owner.Width, 60);
            this.Location = new Point(_loaded ? 0 : _owner.Width, 0);
        }

        public bool SwipeOutWithoutClosingEvent()
        {
            RunTransition(false);
            closed(new EventArgs());
            _owner.Resize -= owner_Resize;
            _owner.Controls.Remove(this);
            this.Dispose();
            return true;
        }

        public bool swipe(bool show = true)
        {
            if (show) ResizeForm();

            if (!show)
            {
                ActionArg closingEvent = new ActionArg();
                closing(closingEvent);
                if (closingEvent.Handled == false)
                {
                    RunTransition(show);
                     closed(new EventArgs());
                    _owner.Resize -= owner_Resize;
                    _owner.Controls.Remove(this);
                    this.Dispose();
                    return true;
                }
                return false;
            }
            else
            {
                ActionArg showingEvent = new ActionArg();
                showing(showingEvent);
                if (showingEvent.Handled == false)
                {
                    RunTransition(show);
                    _loaded = true;
                    ResizeForm();
                    shown(new EventArgs());
                    return true;
                }
                return false;
            }
        }

        private void RunTransition(bool show)
        {
            this.Visible = true;
            Transition _transasition = new Transitions.Transition(new TransitionType_EaseInEaseOut(500));
            _transasition.add(this, "Left", show ? 0 : this.Width);
            _transasition.run();
            while (this.Left != (show ? 0 : this.Width))
            {
                System.Windows.Forms.Application.DoEvents();
            }
        }
#endregion

#region Events
        void owner_Resize(object sender, EventArgs e)
        {
            ResizeForm();
        }

        private void lnkBack_Click(object sender, EventArgs e)
        {
            swipe(false);
        }
#endregion

#region Internal Classes
        public class ActionArg
        {
            public bool Handled { get; set; }
        }
#endregion
    }
}
