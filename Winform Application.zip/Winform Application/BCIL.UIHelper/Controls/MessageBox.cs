﻿using BCIL;
using BCIL.UIHelper;
using BCIL.Utility;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL
{
    public static class BcilMessageBox
    {
        public static void ShowException(IWin32Window owner, Exception ex)
        {
            CodeContract.Required<BCILException>(owner != null, "Owner can not be null");
            CodeContract.Required<BCILException>(ex != null, "There is no exception to show");

            //Form _owner = (owner as Form == null) ? ((Control)owner).FindForm() : (Form)owner;
            Control control = owner as Control;
            Form _ownerForm = ((Control)owner).FindForm();

            if (_ownerForm == App.Shell && (control.Visible == false || isPointVisibleOnAScreen(control.Location) == false))
            {
                owner = App.MainContainer;
            }
            MetroMessageBox.Show(owner, ex is Csla.DataPortalException ? ex.GetBaseException().Message : ex.Message, App.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, _ownerForm != App.Shell);
            BcilLogger.Error(ex, "");
        }

        public static void ShowException(IWin32Window owner, string message)
        {
            CodeContract.Required<BCILException>(owner != null, "Owner can not be null");
            CodeContract.Required<BCILException>(!string.IsNullOrWhiteSpace(message), "There is no exception to show");

            Form _owner = (owner as Form == null) ? ((UserControl)owner).ParentForm : (Form)owner;
            MetroMessageBox.Show(owner, message, App.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, _owner != App.Shell);
        }

        public static void ShowMessage(IWin32Window owner, string message)
        {
            CodeContract.Required<BCILException>(owner != null, "Owner can not be null");
            Form _owner = (owner as Form == null) ? ((UserControl)owner).ParentForm : (Form)owner;
            MetroMessageBox.Show(owner, message, App.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, _owner != App.Shell);
        }

        public static DialogResult GetUserInput(IWin32Window owner, string message, MessageBoxButtons options)
        {
            CodeContract.Required<BCILException>(owner != null, "Owner can not be null");
            Form _owner = (owner as Form == null) ? ((UserControl)owner).ParentForm : (Form)owner;
            return MetroMessageBox.Show(owner, message, App.Name, options, MessageBoxIcon.Question, _owner != App.Shell);
        }

        private static bool isPointVisibleOnAScreen(Point p)
        {
            foreach (Screen s in Screen.AllScreens)
            {
                if (p.X < s.Bounds.Right && p.X > s.Bounds.Left && p.Y > s.Bounds.Top && p.Y < s.Bounds.Bottom)
                    return true;
            }
            return false;
        }

        private static bool isFormFullyVisible(Form f)
        {
            return isPointVisibleOnAScreen(new Point(f.Left, f.Top)) && isPointVisibleOnAScreen(new Point(f.Right, f.Top)) && isPointVisibleOnAScreen(new Point(f.Left, f.Bottom)) && isPointVisibleOnAScreen(new Point(f.Right, f.Bottom));
        }
    }
}
