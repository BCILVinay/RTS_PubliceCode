﻿using BrightIdeasSoftware;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public partial class DataTreeListView : TreeListView
    {
        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);

            UpdateUI();
        }

        /// <summary>
        ///  Normal = new HeaderStateStyle() { BackColor = Color.LightBlue, Font = headerFont },
        /// </summary>
        public DataTreeListView()
        {
            UpdateUI();

        }

        void UpdateUI()
        {
            this.HeaderUsesThemes = false;
            this.IncludeColumnHeadersInCopy = true;
            Font headerFont = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.HeaderFormatStyle = new HeaderFormatStyle()
            {
                Normal = new HeaderStateStyle() { BackColor = ControlPaint.Light(Color.WhiteSmoke, .2f), Font = headerFont },
                Hot = new HeaderStateStyle() { BackColor = Color.FromArgb(235, 235, 235), Font = headerFont },
                Pressed = new HeaderStateStyle() { BackColor = Color.FromArgb(235, 235, 235), Font = headerFont }
            };
            this.Font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.HeaderMinimumHeight = 30;
            this.ForeColor = Color.FromArgb(136, 136, 136);
            this.ShowGroups = false;
            this.FullRowSelect = true;
            if (this.RowHeight != 25) this.RowHeight = 25;
            //this.GridLines = true;
            this.TreeColumnRenderer.IsShowLines = false;
            this.TreeColumnRenderer.UseTriangles = true;
        }
    }
}
