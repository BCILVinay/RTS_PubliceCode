﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper.Controls
{
    public partial class PropertyView : Form
    {
        public PropertyView()
        {
            InitializeComponent();
        }

        private  void SetObject(object obj)
        {
            this.propertyGrid1.SelectedObject = obj;
        }

        private static PropertyView _view;
        public static void ShowProperties(object obj)
        {
            if (_view == null)
            {
                _view = new PropertyView();
            }

            _view.SetObject(obj);
            _view.ShowDialog(App.Shell);
            _view = null;
        }
    }
}
