﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper.Controls
{
    public class MetroValueLable : MetroFramework.Controls.MetroLabel
    {
        public MetroValueLable()
        {
            UpdateUI();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);

            UpdateUI();
        }

        private void UpdateUI()
        {
            this.UseCustomForeColor = true;
            this.ForeColor = Color.FromArgb(136, 136, 136);
        }
    }
}
