﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper.Controls
{
    public sealed class ListViewSettings
    {
        public static Color HeaderColor = ControlPaint.Light(Color.WhiteSmoke, .2f);
    }
}
