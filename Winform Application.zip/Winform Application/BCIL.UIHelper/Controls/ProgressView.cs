﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace BCIL.UIHelper
{
    public partial class ProgressView : MetroForm
    {
        private IWin32Window prentScreen;
        public ProgressView(IWin32Window owner)
        {
            InitializeComponent();
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.MaximumSize = new System.Drawing.Size(1024, 700);
            this.ShowInTaskbar = false;
            this.Resizable = false;
            prentScreen = owner;
        }

        public delegate void DoWorkDelegate(DoEventArgs e);
        public delegate void OnWorkerCompletedDelegate(RunWorkerCompletedEventArgs e);
        public delegate string OnProgressChangedDelegate(ProgressChangedEventArgs e);

        public DoWorkDelegate DoWork { get; set; }

        public OnWorkerCompletedDelegate RunWorkerCompleted { get; set; }

        public OnProgressChangedDelegate OnProgressChanged { get; set; }

        public int TotalRecords { get; set; }

        public string Message
        {
            get
            {
                return lblMessage.Text;
            }
            set
            {
                lblMessage.Text = value;
            }
        }

        public void Run(object argument)
        {
            if (TotalRecords > 0)
                pnlSpinner.Visible = false;
            else
                pnlProgressBar.Visible = false;

            if (argument != null)
                backgroundWorker.RunWorkerAsync(argument);
            else
                backgroundWorker.RunWorkerAsync();

            this.ShowDialog(prentScreen);
        }

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var eventArg = new DoEventArgs() { DoWorkEventArgs = e };
            eventArg._ReportProgress += EventArg__ReportProgress;
            DoWork?.Invoke(eventArg);
        }

        private void EventArg__ReportProgress(object sender, int e)
        {
            if (sender != null)
                backgroundWorker.ReportProgress(e, ((DoEventArgs)sender).DoWorkEventArgs);
            else
                backgroundWorker.ReportProgress(e);
        }

        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
 
            lblMessage.Text = OnProgressChanged?.Invoke(e);
            if (pnlProgressBar.Visible == true)
                progressBar.Value = e.ProgressPercentage;
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                RunWorkerCompleted?.Invoke(e);
            }
            finally
            {
                this.Close();
            }
        }
    }

    public class DoEventArgs 
    {
        public event EventHandler<Int32> _ReportProgress;

        public DoWorkEventArgs DoWorkEventArgs { get; set; }

        public void ReportProgress(int progress)
        {
            _ReportProgress?.Invoke(this, progress);
        }
    }
}
