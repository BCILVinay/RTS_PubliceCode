﻿using MetroFramework.Controls;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace BCIL.UIHelper.Controls
{
    public class ButtonHelp: MyMetroButton
    {
        public Image image { get; set; }

        public ButtonHelp()
        {
            this.ButtonImage = ((System.Drawing.Image)(Properties.Resources.Error));
            this.Size = new System.Drawing.Size(Width / 2, Height / 2);
            this.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);
            this.Region = new Region(path);
            // this.ImageSize = ButtonImage.Width / 2; 
            this.Text = "help";
        }
    }
}