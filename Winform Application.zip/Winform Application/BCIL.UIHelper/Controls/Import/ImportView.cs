﻿using BCIL;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.UIHelper.Controls
{
    public partial class ImportView : MetroForm
    {
        #region Variables

        public delegate void DoWorkDelegate(DoEventArgs e);

        public delegate void OnWorkerCompletedDelegate(RunWorkerCompletedEventArgs e);

        public delegate void OnImportRequestedDelegate(string fileName);

        private DataSet m_errorDataSet = null;

        private DataSet _templateData;

        #endregion Variables

        #region Constructor

        public ImportView()
        {
            InitializeComponent();
        }

        #endregion Constructor

        #region Properties

        public DoWorkDelegate DoWork { get; set; }

        public OnWorkerCompletedDelegate RunWorkerCompleted { get; set; }

        public OnImportRequestedDelegate OnImportRequested { get; set; }

        public int TotalRecords
        {
            set { lblTotal.Text = "Total records: " + value.ToString(); }
        }

        public DataSet TemplateDataSet
        {
            get { return _templateData; }
            set
            {
                if (value != null && value.Tables.Count > 0)
                {
                    _templateData = value;
                }
            }
        }

        public DataSet ErrorDataSet
        {
            get
            {
                return m_errorDataSet;
            }
            set
            {
                if (value != null && value.Tables.Count > 0)
                {
                    m_errorDataSet = value;
                    if (lnkDownloadException.InvokeRequired)
                    {
                        lnkDownloadException.BeginInvoke((Action)(() =>
                        {
                            lnkDownloadException.Visible = true;
                        }));
                    }
                    else
                    {
                        lnkDownloadException.Visible = true;
                    }
                }
            }
        }

        #endregion Properties

        #region Events

        private void ImportView_Load(object sender, EventArgs e)
        {
            pnlProgress.Visible = false;
            lblFailed.Visible = false;
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.AddExtension = true;
                fileDialog.Filter = "CSV|*.csv";
                if (fileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtDataFile.Text = fileDialog.FileName;
                    btnImport.Enabled = true;
                    pnlProgress.Visible = false;
                    lblFailed.Visible = false;
                    lnkDownloadException.Visible = false;
                }
            }
            catch (Exception ex)
            {
                BcilMessageBox.ShowException(this, ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<BCILException>(txtDataFile.Text.Trim().Length > 0, "Please select file to import");
                OnImportRequested?.Invoke(txtDataFile.Text);
            }
            catch (Exception ex)
            {
                BcilMessageBox.ShowException(this, ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lnkDownloadException_Click(object sender, EventArgs e)
        {
            try
            {
                ExportErrorToExcel();
            }
            catch (Exception ex)
            {
                BcilMessageBox.ShowException(this, ex);
            }
        }

        private void ExportErrorToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.AddExtension = true;
            fileDialog.Filter = "csv|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                FileWriter writer = new FileWriter();
                writer.WriteFile(fileDialog.FileName, ErrorDataSet.Tables.Cast<DataTable>().ToList());
            }
        }

        private void lnkTemplate_Click(object sender, EventArgs e)
        {
            try
            {
                ExportTemplateToExcel();
            }
            catch (Exception ex)
            {
                BcilMessageBox.ShowException(this, ex);
            }
        }

        private void ExportTemplateToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            fileDialog.AddExtension = true;
            fileDialog.Filter = "csv|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                FileWriter writer = new FileWriter();
                writer.WriteFile(fileDialog.FileName, TemplateDataSet.Tables.Cast<DataTable>().ToList());
            }
        }

        #endregion Events

        #region Background Events

        public void Run(object argument)
        {
            pnlProgress.Visible = true;
            btnImport.Enabled = false;
            btnCancel.Enabled = false;
            if (argument != null)
                backgroundWorker.RunWorkerAsync(argument);
            else
                backgroundWorker.RunWorkerAsync();
        }

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var eventArg = new DoEventArgs() { DoWorkEventArgs = e };
            eventArg._ReportProgress += EventArg__ReportProgress;
            DoWork?.Invoke(eventArg);
        }

        private void EventArg__ReportProgress(object sender, int e)
        {
            if (sender != null)
                backgroundWorker.ReportProgress(e, ((DoEventArgs)sender).DoWorkEventArgs);
            else
                backgroundWorker.ReportProgress(e);
        }

        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            var result = ((System.ComponentModel.DoWorkEventArgs)e.UserState).Result;
            if (result != null && !string.IsNullOrWhiteSpace(result.ToString()))
            {
                lblFailed.Text = result.ToString();
                if (!lblFailed.Visible) lblFailed.Visible = true;
            }
            progressBar.Value = e.ProgressPercentage;
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                RunWorkerCompleted?.Invoke(e);
                progressBar.Value = 100;
            }
            finally
            {
                btnCancel.Enabled = true;
                //this.Close();
            }
        }

        #endregion Background Events
    }
}