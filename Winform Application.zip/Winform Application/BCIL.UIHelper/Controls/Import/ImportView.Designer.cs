﻿namespace BCIL.UIHelper.Controls
{
    partial class ImportView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportView));
            this.lblFile = new MetroFramework.Controls.MetroLabel();
            this.txtDataFile = new MetroFramework.Controls.MetroTextBox();
            this.lnkTemplate = new MetroFramework.Controls.MetroLink();
            this.btnSelectFile = new MetroFramework.Controls.MetroButton();
            this.lblTotal = new MetroFramework.Controls.MetroLabel();
            this.progressBar = new MetroFramework.Controls.MetroProgressBar();
            this.lblFailed = new MetroFramework.Controls.MetroLink();
            this.pnlProgress = new MetroFramework.Controls.MetroPanel();
            this.pnlFile = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.lnkDownloadException = new MetroFramework.Controls.MetroLink();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnImport = new BCIL.UIHelper.ButtonSave();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.pnlProgress.SuspendLayout();
            this.pnlFile.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFile
            // 
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(4, 8);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(60, 19);
            this.lblFile.TabIndex = 1;
            this.lblFile.Text = "Data file:";
            // 
            // txtDataFile
            // 
            // 
            // 
            // 
            this.txtDataFile.CustomButton.Image = null;
            this.txtDataFile.CustomButton.Location = new System.Drawing.Point(474, 1);
            this.txtDataFile.CustomButton.Name = "";
            this.txtDataFile.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtDataFile.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtDataFile.CustomButton.TabIndex = 1;
            this.txtDataFile.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtDataFile.CustomButton.UseSelectable = true;
            this.txtDataFile.CustomButton.Visible = false;
            this.txtDataFile.Lines = new string[0];
            this.txtDataFile.Location = new System.Drawing.Point(64, 8);
            this.txtDataFile.MaxLength = 32767;
            this.txtDataFile.Name = "txtDataFile";
            this.txtDataFile.PasswordChar = '\0';
            this.txtDataFile.ReadOnly = true;
            this.txtDataFile.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDataFile.SelectedText = "";
            this.txtDataFile.SelectionLength = 0;
            this.txtDataFile.SelectionStart = 0;
            this.txtDataFile.ShortcutsEnabled = true;
            this.txtDataFile.Size = new System.Drawing.Size(496, 23);
            this.txtDataFile.TabIndex = 2;
            this.txtDataFile.UseSelectable = true;
            this.txtDataFile.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtDataFile.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lnkTemplate
            // 
            this.lnkTemplate.Image = ((System.Drawing.Image)(resources.GetObject("lnkTemplate.Image")));
            this.lnkTemplate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkTemplate.ImageSize = 32;
            this.lnkTemplate.Location = new System.Drawing.Point(492, 32);
            this.lnkTemplate.Name = "lnkTemplate";
            this.lnkTemplate.Size = new System.Drawing.Size(140, 36);
            this.lnkTemplate.Style = MetroFramework.MetroColorStyle.Blue;
            this.lnkTemplate.TabIndex = 5;
            this.lnkTemplate.Text = "Download template";
            this.lnkTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkTemplate.UseSelectable = true;
            this.lnkTemplate.UseStyleColors = true;
            this.lnkTemplate.Click += new System.EventHandler(this.lnkTemplate_Click);
            // 
            // btnSelectFile
            // 
            this.btnSelectFile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSelectFile.BackgroundImage")));
            this.btnSelectFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelectFile.Location = new System.Drawing.Point(560, 8);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Size = new System.Drawing.Size(40, 23);
            this.btnSelectFile.TabIndex = 3;
            this.btnSelectFile.Text = "...";
            this.btnSelectFile.UseSelectable = true;
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(60, 24);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(114, 19);
            this.lblTotal.TabIndex = 11;
            this.lblTotal.Text = "Total records: 100";
            this.lblTotal.UseCustomForeColor = true;
            // 
            // progressBar
            // 
            this.progressBar.HideProgressText = false;
            this.progressBar.Location = new System.Drawing.Point(64, 0);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(537, 23);
            this.progressBar.TabIndex = 12;
            this.progressBar.Value = 50;
            // 
            // lblFailed
            // 
            this.lblFailed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFailed.ImageSize = 32;
            this.lblFailed.Location = new System.Drawing.Point(60, 8);
            this.lblFailed.Name = "lblFailed";
            this.lblFailed.Size = new System.Drawing.Size(160, 23);
            this.lblFailed.Style = MetroFramework.MetroColorStyle.Red;
            this.lblFailed.TabIndex = 15;
            this.lblFailed.Text = "Failed to import: 10";
            this.lblFailed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFailed.UseSelectable = true;
            this.lblFailed.UseStyleColors = true;
            this.lblFailed.Visible = false;
            // 
            // pnlProgress
            // 
            this.pnlProgress.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.pnlProgress.Controls.Add(this.lblTotal);
            this.pnlProgress.Controls.Add(this.progressBar);
            this.pnlProgress.HorizontalScrollbarBarColor = true;
            this.pnlProgress.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlProgress.HorizontalScrollbarSize = 10;
            this.pnlProgress.Location = new System.Drawing.Point(3, 49);
            this.pnlProgress.Name = "pnlProgress";
            this.pnlProgress.Size = new System.Drawing.Size(601, 47);
            this.pnlProgress.TabIndex = 16;
            this.pnlProgress.VerticalScrollbarBarColor = true;
            this.pnlProgress.VerticalScrollbarHighlightOnWheel = false;
            this.pnlProgress.VerticalScrollbarSize = 10;
            this.pnlProgress.Visible = false;
            // 
            // pnlFile
            // 
            this.pnlFile.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.pnlFile.Controls.Add(this.txtDataFile);
            this.pnlFile.Controls.Add(this.lblFile);
            this.pnlFile.Controls.Add(this.btnSelectFile);
            this.pnlFile.HorizontalScrollbarBarColor = true;
            this.pnlFile.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlFile.HorizontalScrollbarSize = 10;
            this.pnlFile.Location = new System.Drawing.Point(3, 3);
            this.pnlFile.Name = "pnlFile";
            this.pnlFile.Size = new System.Drawing.Size(604, 40);
            this.pnlFile.TabIndex = 17;
            this.pnlFile.VerticalScrollbarBarColor = true;
            this.pnlFile.VerticalScrollbarHighlightOnWheel = false;
            this.pnlFile.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.metroPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pnlFile, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlProgress, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 72);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(610, 174);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel3.Controls.Add(this.lnkDownloadException);
            this.metroPanel3.Controls.Add(this.lblFailed);
            this.metroPanel3.Controls.Add(this.btnCancel);
            this.metroPanel3.Controls.Add(this.btnImport);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(3, 102);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(601, 69);
            this.metroPanel3.TabIndex = 19;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // lnkDownloadException
            // 
            this.lnkDownloadException.Image = ((System.Drawing.Image)(resources.GetObject("lnkDownloadException.Image")));
            this.lnkDownloadException.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkDownloadException.ImageSize = 32;
            this.lnkDownloadException.Location = new System.Drawing.Point(60, 32);
            this.lnkDownloadException.Name = "lnkDownloadException";
            this.lnkDownloadException.Size = new System.Drawing.Size(148, 23);
            this.lnkDownloadException.Style = MetroFramework.MetroColorStyle.Blue;
            this.lnkDownloadException.TabIndex = 16;
            this.lnkDownloadException.Text = "Download exceptions";
            this.lnkDownloadException.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkDownloadException.UseSelectable = true;
            this.lnkDownloadException.UseStyleColors = true;
            this.lnkDownloadException.Visible = false;
            this.lnkDownloadException.Click += new System.EventHandler(this.lnkDownloadException_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(512, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Close";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnImport
            // 
            this.btnImport.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnImport.ButtonImage")));
            this.btnImport.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnImport.Enabled = false;
            this.btnImport.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnImport.ImageSize = 50;
            this.btnImport.Location = new System.Drawing.Point(420, 4);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(85, 56);
            this.btnImport.TabIndex = 6;
            this.btnImport.Text = "Import";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnImport.UseSelectable = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.WorkerSupportsCancellation = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // ImportView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(650, 260);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lnkTemplate);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ImportView";
            this.Text = "Import ---";
            this.Load += new System.EventHandler(this.ImportView_Load);
            this.pnlProgress.ResumeLayout(false);
            this.pnlProgress.PerformLayout();
            this.pnlFile.ResumeLayout(false);
            this.pnlFile.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblFile;
        private MetroFramework.Controls.MetroTextBox txtDataFile;
        private MetroFramework.Controls.MetroButton btnSelectFile;
        private MetroFramework.Controls.MetroLink lnkTemplate;
        private ButtonSave btnImport;
        private ButtonCancel btnCancel;
        private MetroFramework.Controls.MetroLabel lblTotal;
        private MetroFramework.Controls.MetroProgressBar progressBar;
        private MetroFramework.Controls.MetroLink lblFailed;
        private MetroFramework.Controls.MetroPanel pnlProgress;
        private MetroFramework.Controls.MetroPanel pnlFile;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private MetroFramework.Controls.MetroLink lnkDownloadException;
    }
}
