﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace BCIL.UIHelper
{
    public class RequiredPanel : Panel
    {
        private bool _handelToAdd = false;
        private Label _lblError;
        public RequiredPanel ()
        {
            _handelToAdd = true;
            _lblError = new Label();
            this.BackColor = Color.Transparent;
            _lblError.EnabledChanged += _lblError_EnabledChanged;
            _lblError.Text = "٭";
            _lblError.ForeColor = System.Drawing.Color.Red;
            _lblError.Dock = DockStyle.Right;
            _lblError.Width = 20;
            _lblError.Font = new System.Drawing.Font("Dubai Light", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _lblError.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Controls.Add(_lblError);
            _handelToAdd = false;
            this.VisibleChanged += RequiredPanel_VisibleChanged;
        }

        private void RequiredPanel_VisibleChanged(object sender, EventArgs e)
        {
            _lblError.ForeColor = System.Drawing.Color.Red;
        }

        private void _lblError_EnabledChanged(object sender, EventArgs e)
        {
            _lblError.Text = _lblError.Enabled ? "٭" : "";
        }

        public bool IsRequired
        {
            get { return _lblError.Enabled; }
            set { _lblError.Enabled = value; }
        }
        protected override void OnControlAdded(ControlEventArgs e)
        {
            if (_handelToAdd) return;

            if(Controls.Count >2)
            {
                Controls.RemoveAt(2);
                return;
            }

            base.OnControlAdded(e);
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.Location = e.Control.Location;
            this.Size = e.Control.Size;
            e.Control.Dock = DockStyle.Fill;
           _lblError.SendToBack();
            e.Control.BringToFront();
        }

    }
}
