﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public class GridView : DataGridView
    {
        public GridView()
        {
            UpdateUI();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);

            UpdateUI();
        }

        private void UpdateUI()
        {
            DataGridViewCellStyle headerCellStyle = new DataGridViewCellStyle();

            headerCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            headerCellStyle.BackColor = ControlPaint.Light(Color.WhiteSmoke, .2f);
            headerCellStyle.Font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            headerCellStyle.ForeColor = Color.Black;
            headerCellStyle.SelectionBackColor = Color.FromArgb(235, 235, 235);
            headerCellStyle.WrapMode = DataGridViewTriState.True;
            this.ColumnHeadersDefaultCellStyle = headerCellStyle;

            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            cellStyle.Font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            
            cellStyle.WrapMode = DataGridViewTriState.False;
            this.DefaultCellStyle = cellStyle;

            this.EnableHeadersVisualStyles = false;
            this.RowHeadersVisible = false;
            this.RowTemplate.Height = 25;
            this.SelectionMode = DataGridViewSelectionMode.CellSelect;

            this.Font = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.ForeColor = Color.FromArgb(136, 136, 136);
            this.AllowUserToAddRows = false;
            this.AllowUserToDeleteRows = false;
            this.AllowUserToResizeColumns = true;
            this.AllowUserToResizeRows = true;
            this.BackgroundColor = Color.White; 
            this.ColumnHeadersHeight = 30;
            this.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            this.CellBorderStyle = DataGridViewCellBorderStyle.None;
            this.BorderStyle = BorderStyle.Fixed3D;
        }
    }
}
