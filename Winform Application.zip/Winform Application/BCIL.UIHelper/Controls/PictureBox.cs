﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Http;

namespace BCIL.UIHelper
{
    public partial class PictureBox : System.Windows.Forms.PictureBox
    {
        public event EventHandler<SelectedImage> ImageChanged;
        public PictureBox()
        {
            InitializeComponent();
            this.Image = Images.BlankPicture;
            this.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        public Size MaxImageSize { get; set; }

        public Size MinImageSize { get; set; }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);

            OpenFileDialog fileBrowser = new OpenFileDialog();
            fileBrowser.Filter = "Image Files|*.jpg;*.jpeg;*.png;";
            if (fileBrowser.ShowDialog() == DialogResult.OK)
            {
                Image = Image.FromFile(fileBrowser.FileName);
                if (ImageChanged != null) ImageChanged(this, new SelectedImage() { ImageExtension = Path.GetExtension(fileBrowser.FileName), UserImage = Image });
            }
        }

        private bool  ValidateImageSize(Image image)
        {
            if (MaxImageSize != default (Size) && MinImageSize !=default (Size))
            {
                if (image.Size.Height > MaxImageSize.Height || image.Size.Height < MinImageSize.Height || image.Size.Width > MaxImageSize.Width || image.Size.Width < MinImageSize.Width)
                {
                    BcilMessageBox.ShowException(this, String.Format("Image size should be between ({0}X{1}) and ({2}X{3})", MinImageSize.Height, MinImageSize.Width, MaxImageSize.Height, MaxImageSize.Width));
                    return false;
                }
            }
            else if(MaxImageSize != default(Size))
            {
                if (image.Size.Height > MaxImageSize.Height || image.Size.Width > MaxImageSize.Width )
                {
                    BcilMessageBox.ShowException(this, String.Format("Image size should not be greater than ({0}X{1}))", MaxImageSize.Height, MaxImageSize.Width));
                    return false;
                }
            }
            else if (MinImageSize != default(Size))
            {
                if (image.Size.Height < MinImageSize.Height || image.Size.Width < MinImageSize.Width)
                {
                    BcilMessageBox.ShowException(this, String.Format("Image size should not be less than ({0}X{1}))", MinImageSize.Height, MinImageSize.Width));
                    return false;
                }
            }
            return true;
        }
       // private void ImageSize(Image image)
       // {
       //     using (var request = new StreamContent(stream)) {

       //         request.ReadAsByteArrayAsync ().Result.Length  
       //             }
       //}
        public class SelectedImage
        {
            public string  ImageExtension { get; set; }

            public Image UserImage { get; set; }
        }
    }
}
