﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public partial class ButtonSearch : MyMetroButton
    {
        public ButtonSearch()
        {
            InitializeComponent();

            this.ButtonImage = Properties.Resources.Search;
            this.Size = new System.Drawing.Size(85, 56);
            this.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ImageSize = 50;
            this.Text = "Save";
        }
    }
}
