﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper.Controls
{
    public class RoundedCornerPanel : Panel
    {
        private Color _BackGroundFillColor= Color.White;
        public Color BackGroundFillColor
        {
            get { return _BackGroundFillColor; }
            set { _BackGroundFillColor = value; Refresh(); }
        }

        private int _radius = 15;

        public int Radius
        {
            get { return _radius; }
            set { _radius = value; }
        }

        private int _widthPadding=1;

        public int WidthPadding
        {
            get { return _widthPadding; }
            set { _widthPadding = value; }
        }

        private int _heightPadding=3;

        public int HeightPadding
        {
            get { return _heightPadding; }
            set { _heightPadding = value; }
        }

        private Point _roundPoint = new Point(0, 0);

        public Point RounddingStartLocation
        {
            get { return _roundPoint; }
            set { _roundPoint = value; }
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.FillRoundedRectangle(new SolidBrush(BackGroundFillColor), _roundPoint.X, _roundPoint.Y, this.Width - WidthPadding, this.Height - HeightPadding, Radius);
            g.FillRoundedRectangle(new SolidBrush(BackGroundFillColor), _roundPoint.X + 2, _roundPoint.Y + 2, this.Width - WidthPadding - 4, this.Height - HeightPadding - 4, Radius);
            g.DrawRoundedRectangle(new Pen(ControlPaint.Light(BackGroundFillColor, 0.00f)), _roundPoint.X + 2, _roundPoint.Y + 2, this.Width - WidthPadding - 4, this.Height - HeightPadding - 4, Radius);
            g.FillRoundedRectangle(new SolidBrush(BackGroundFillColor), _roundPoint.X + 2, _roundPoint.Y + 2 + ((this.Height - HeightPadding - 4) / 2), this.Width - WidthPadding - 4, (this.Height - HeightPadding - 4) / 2, Radius);
        }
    }
}
