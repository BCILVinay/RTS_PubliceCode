﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper
{
    public class YesNoComboBox : MetroComboBox
    {
        private List<KeyValuePair<bool, string>> _YesNoList = new List<KeyValuePair<bool, string>>() {
             new KeyValuePair<bool, string>(true, "Yes"),
            new KeyValuePair<bool, string> (false,"No" )
            };

        public YesNoComboBox()
        {
            if (!this.DesignMode)
            {
                this.DataSource = _YesNoList;
                this.DisplayMember = "Value";
                this.ValueMember = "Key";
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public new ObjectCollection Items
        {
            get { return base.Items; }
        }
    }
}
