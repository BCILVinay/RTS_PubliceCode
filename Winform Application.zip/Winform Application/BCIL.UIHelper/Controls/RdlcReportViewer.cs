﻿using MetroFramework.Forms;
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.UIHelper
{
    public partial class RdlcReportViewer : MetroForm
    {
        public RdlcReportViewer()
        {
            InitializeComponent();
        }

        public void SetEmbededResource(string report)
        {
            this.reportViewer1.LocalReport.ReportEmbeddedResource = report;
        }

        public void SetReportPath(string report)
        {
            this.reportViewer1.LocalReport.ReportPath = report;
        }

        public void SetDataSource(string name, object data)
        {
            ReportDataSource datasource = new ReportDataSource(name, data);
            reportViewer1.LocalReport.DataSources.Add(datasource);
        }

        public void SetParameters(ReportParameter[] parameters)
        {
            reportViewer1.LocalReport.SetParameters(parameters);
        }

        private void RdlcReportViewer_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }
    }
}
