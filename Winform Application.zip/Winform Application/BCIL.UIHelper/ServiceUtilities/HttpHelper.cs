﻿using BCIL;
using BCIL.Utility;
using BCIL.UIHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Xml.Linq;

namespace BCIL.Common.Utility.ServiceUtilities
{
    //public class HttpHelper: HttpClient
    //{
    //    #region Private Fields
    //    private static string _ApplicationToken = "91aaa5096e54ab1d29459daa61e69bec5836b40a60d79a51251d886cbad9be4c";
    //    private static string _AuthenticationUrl; // = "http://localhost:8888/Authentication/";
    //    private static string _ApplicationURL; // = "http://localhost:8888/MobiVUE/";
    //    private static string _ApplicationName = "WinApp";
    //    private static string _Domain = "";
    //    #endregion

    //    #region Constructors
    //    public HttpHelper() : base()
    //    {

    //    }
    //    public HttpHelper(HttpMessageHandler handler) : base(handler)
    //    {

    //    }
    //    public HttpHelper(HttpMessageHandler handler,bool disposeHandler) : base(handler, disposeHandler)
    //    {

    //    }
    //    #endregion

    //    #region Public Enums
    //    public enum BusinessOnject
    //    {
    //        No = 0,
    //        BusinessBase = 1,
    //        BusinessBaseCollection = 2
    //    }

    //    private enum AuthenticationType
    //    {
    //        Authentication=0,
    //        Token=1
    //    }

    //    #endregion Public Enums

    //    #region Properties
    //    public static string ApplicationToken
    //    {
    //        get { return _ApplicationToken; }
    //        set { _ApplicationToken = value; }
    //    }

    //    public static string ApplicationName
    //    {
    //        get { return _ApplicationName; }
    //        set { _ApplicationName = value; }
    //    }

    //    public static string AuthenticationUrl
    //    {
    //        get { return _AuthenticationUrl; }
    //        set { _AuthenticationUrl = value; }
    //    }

    //    public static string ApplicationUrl
    //    {
    //        get { return _ApplicationURL; }
    //        set { _ApplicationURL = value; }
    //    }

    //    public static string Domain
    //    {
    //        get { return _Domain; }
    //        set { _Domain = value; }
    //    }

    //    public static string UserToken { get; set; }

    //    public static X509Certificate Certificate { get; set; }
    //    #endregion

    //    #region Private Methods
    //    private static HttpHelper GetHttpClient(AuthenticationType authenticationType)
    //    {
    //        HttpHelper httpClient=null;

    //        if (Certificate != null)
    //        {
    //            WebRequestHandler handler = new WebRequestHandler();
    //            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
    //            handler.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    //            {
    //                return true;
    //            };
    //            handler.ClientCertificates.Add(Certificate);
    //            httpClient = new HttpHelper(handler);
    //        }
    //        else
    //            httpClient = new HttpHelper();

    //        CodeContract.Required<BCILException>(ApplicationToken.IsNotNullOrWhiteSpace(), "Please provide application token");
    //        CodeContract.Required<BCILException>(ApplicationName.IsNotNullOrWhiteSpace(), "Please provide application name");

    //        httpClient.DefaultRequestHeaders.Add("ClientToken", ApplicationToken);
    //        httpClient.DefaultRequestHeaders.Add("ClientName", ApplicationName);
    //        httpClient.DefaultRequestHeaders.Add("Domain", Domain);

    //        if (authenticationType== AuthenticationType.Token)
    //        {
    //            CodeContract.Required<BCILException>(ApplicationUrl.IsNotNullOrWhiteSpace(), "Please provide application url");
    //            CodeContract.Required<BCILException>(UserToken.IsNotNullOrWhiteSpace(), "Please provide user token");

    //            httpClient.BaseAddress = new Uri(HttpHelper.ApplicationUrl);
    //            httpClient.DefaultRequestHeaders.Add("UserToken", UserToken);
    //        }
    //        else
    //        {
    //            CodeContract.Required<BCILException>(AuthenticationUrl.IsNotNullOrWhiteSpace(), "Please provide authentication url");
    //            httpClient.BaseAddress = new Uri(AuthenticationUrl);
    //        }
    //        // Add an Accept header for JSON format.
    //        httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    //        return httpClient;
    //    }

    //    private static BCILException ExceptionHandling(HttpResponseMessage response)
    //    {
    //        if (response.StatusCode == HttpStatusCode.InternalServerError)
    //        {
    //            try
    //            {
    //                XDocument xdoc = XDocument.Load(response.Content.ReadAsStreamAsync().Result);
    //                var detailElement = xdoc.Descendants().FirstOrDefault(x => x.Name.LocalName == "Detail");
    //                if (detailElement != default(XElement))
    //                {
    //                    List<string> exceptions = xdoc.Descendants().Where(x => x.Name.LocalName == "Message").Select(y => y.Value).ToList();

    //                    if (exceptions != null && exceptions.Count > 0)
    //                    {
    //                        return new BCILException(string.Join("\n", exceptions));
    //                    }

    //                    if (detailElement.Elements().Any(y => y.Name.LocalName == "string"))
    //                    {
    //                        return new BCILException(string.Join("\n", detailElement.Elements().First(x => x.Name.LocalName == "string").Value));
    //                    }
    //                }
    //            }
    //            catch
    //            {
    //            }
    //        }

    //        string message = response.Content.ReadAsStringAsync().Result;
    //        if (!string.IsNullOrWhiteSpace(message))
    //            if (message.Contains("Endpoint not found"))
    //                return new BCILException("Endpoint not found");
    //            else
    //                return new BCILException(message);
    //        else
    //            return new BCILException(response.StatusCode + " - " + response.ReasonPhrase);
    //    }

    //    //private static BusinessOnject IsBusinessBaseType(Type objectType)
    //    //{
    //    //    if (objectType.IsSubclassOf(typeof(BusinessBase)))
    //    //    {
    //    //        return BusinessOnject.BusinessBase;
    //    //    }
    //    //    if (objectType.IsGenericType && objectType.GenericTypeArguments.Length == 1 && objectType.GenericTypeArguments[0].IsSubclassOf(typeof(BusinessBase)))
    //    //    {
    //    //        return BusinessOnject.BusinessBaseCollection;
    //    //    }
    //    //    return BusinessOnject.No;
    //    //}

    //    private static string SerializeObject<T>(T dataObject)
    //    {
    //        return new JavaScriptSerializer().Serialize(dataObject);
    //    }

    //    //private static TReturn UpdateDirtyStatus<TReturn>(TReturn result)
    //    //{
    //    //    if (result == null) return result;
    //    //    if (IsBusinessBaseType(typeof(TReturn)) == BusinessOnject.BusinessBase)
    //    //    {
    //    //        dynamic d = result;
    //    //        d.MarkAsOld();
    //    //    }
    //    //    else if (IsBusinessBaseType(typeof(TReturn)) == BusinessOnject.BusinessBaseCollection)
    //    //    {
    //    //        dynamic d = result;
    //    //        foreach (var item in d)
    //    //        {
    //    //            item.MarkAsOld();
    //    //        }
    //    //    }
    //    //    return result;
    //    //}
    //    #endregion

    //    #region Authentication Methods

    //    public static TReturn AuthenticateUser_Mobile<TReturn>(string userName, string password)
    //    {
    //        try
    //        {
    //            HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Authentication);
    //            var credentials = Encoding.ASCII.GetBytes(string.Format("{0}:{1}", userName, password));
    //            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync("V1/MobileUserAuthenticate",null).Result;  // Blocking call!
    //            if (response.IsSuccessStatusCode)
    //            {
    //                // Parse the response body. Blocking!
    //                TReturn result = response.Content.ReadAsAsync<TReturn>().Result;
    //                return UpdateDirtyStatus(result);
    //            }
    //            else
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //        catch (AggregateException ae)
    //        {
    //            foreach (var e in ae.Flatten().InnerExceptions)
    //            {
    //                if (e.InnerException != null && e.InnerException is System.Net.WebException && ((WebException)e.InnerException).Status == WebExceptionStatus.ConnectFailure)
    //                    throw new BCILException("Service is not running.");
    //                else
    //                    throw new BCILException(ae.Message);
    //            }
    //            throw new BCILException(ae.Message);
    //        }
    //    }

    //    public static TReturn AuthenticateUser<TReturn>(string userName, string password)
    //    {
    //        try
    //        {
    //            HttpHelper client = HttpHelper.GetHttpClient( AuthenticationType.Authentication);
    //            var credentials = Encoding.ASCII.GetBytes(string.Format("{0}:{1}", userName, password));
    //            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));

    //            // List data response.
    //            HttpResponseMessage response = client.GetAsync("V1/AuthenticateUser").Result;  // Blocking call!
    //            if (response.IsSuccessStatusCode)
    //            {
    //                // Parse the response body. Blocking!
    //                TReturn result = response.Content.ReadAsAsync<TReturn>().Result;
    //                return UpdateDirtyStatus(result);
    //            }
    //            else
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //        catch (AggregateException ae)
    //        {
    //            foreach (var e in ae.Flatten().InnerExceptions)
    //            {
    //                if (e.InnerException != null && e.InnerException is System.Net.WebException && ((WebException)e.InnerException).Status == WebExceptionStatus.ConnectFailure)
    //                    throw new BCILException("Service is not running.");
    //                else
    //                    throw new BCILException(ae.Message);
    //            }
    //            throw new BCILException(ae.Message);
    //        }
    //    }

    //    public static void PostAuth<TParameter>(string urlParameters, TParameter dataObject, string UserId, string Password)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient( AuthenticationType.Authentication);

    //        var credentials = Encoding.ASCII.GetBytes(string.Format("{0}:{1}", UserId, Password));
    //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));

    //        using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
    //        {
    //            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

    //            if (!response.IsSuccessStatusCode)
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //    }

    //    public static TReturn PostAuth<TReturn, TParameter>(string urlParameters, TParameter dataObject)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Authentication);

    //        client.DefaultRequestHeaders.Add("UserToken", UserToken);

    //        using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
    //        {
    //            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

    //            if (response.IsSuccessStatusCode)
    //            {
    //                // Parse the response body. Blocking!
    //                TReturn result = response.Content.ReadAsAsync<TReturn>().Result;
    //                return UpdateDirtyStatus(result);
    //            }
    //            else
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //    }

    //    public static void PostAuth<TParameter>(string urlParameters, TParameter dataObject)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Authentication);

    //        client.DefaultRequestHeaders.Add("UserToken", UserToken);

    //        using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
    //        {
    //            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

    //            if (!response.IsSuccessStatusCode)
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //    }
    //    #endregion

    //    #region Http Methods

    //    public static Task<T> GetAsync<T>(string urlParameters)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);

    //        HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call!
    //        if (response.IsSuccessStatusCode)
    //        {
    //            // Parse the response body. Blocking!
    //            return response.Content.ReadAsAsync<T>();
    //        }
    //        else
    //        {
    //            throw ExceptionHandling(response);
    //        }
    //    }

    //    public static TReturn Get<TReturn>(string urlParameters)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);
    //        // List data response.
    //        HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call!
    //        if (response.IsSuccessStatusCode)
    //        {
    //            // Parse the response body. Blocking!
    //            TReturn result = response.Content.ReadAsAsync<TReturn>().Result;
    //            return UpdateDirtyStatus(result);
    //        }
    //        else
    //        {
    //            throw ExceptionHandling(response);
    //        }
    //    }

    //    public static void Post<TParameter>(string urlParameters, TParameter dataObject)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);

    //        using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
    //        {
    //            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

    //            if (!response.IsSuccessStatusCode)
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //    }

    //    public static TReturn Post<TReturn, TParameter>(string urlParameters, TParameter dataObject)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);

    //        using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
    //        {
    //            request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //            // List data response.
    //            HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

    //            if (response.IsSuccessStatusCode)
    //            {
    //                // Parse the response body. Blocking!
    //                TReturn result = response.Content.ReadAsAsync<TReturn>().Result;
    //                return UpdateDirtyStatus(result);
    //            }
    //            else
    //            {
    //                throw ExceptionHandling(response);
    //            }
    //        }
    //    }

    //    public static void Delete(string urlParameters)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);
    //        // List data response.
    //        HttpResponseMessage response = client.DeleteAsync(urlParameters).Result;

    //        if (!response.IsSuccessStatusCode)
    //        {
    //            throw ExceptionHandling(response);
    //        }
    //    }

    //    public static Stream GetFile(string fileName)
    //    {
    //        HttpHelper client = HttpHelper.GetHttpClient(AuthenticationType.Token);
    //        // List data response.
    //        HttpResponseMessage response = client.GetAsync(String.Format(ServiceUriHelper.Administration.GetImage, fileName)).Result;  // Blocking call!
    //        if (response.IsSuccessStatusCode)
    //        {
    //            // Parse the response body. Blocking!
    //            return response.Content.ReadAsStreamAsync().Result;
    //        }
    //        else
    //        {
    //            throw ExceptionHandling(response);
    //        }
    //    }

    //    public static void PostFile(string filePath)
    //    {
    //        CodeContract.Required<ArgumentNullException>(!string.IsNullOrWhiteSpace(filePath), "File should not be blank.");
    //        CodeContract.Required<ArgumentNullException>(File.Exists(filePath), "File doesn't exists.");

    //        SaveFile(Path.GetFileName(filePath), File.OpenRead(filePath));
    //    }

    //    //public static void SaveFile(string fileName, Stream stream)
    //    //{
    //    //    CodeContract.Required<ArgumentNullException>(!String.IsNullOrWhiteSpace(fileName), "File name should not be blank.");
    //    //    CodeContract.Required<ArgumentNullException>(stream != null, "File data should not be null.");

    //    //    FileDTO file = new FileDTO();
    //    //    file.FileName = fileName;
    //    //    file.FileByte = ImageSerializer.ConvertStreamToArry(stream);
    //    //    Post<FileDTO>("V1/File", file);
    //    //}

    //    //public static void PostFile(string fileName, Stream stream)
    //    //{

    //    //    CodeContract.Required<ArgumentNullException>(!String.IsNullOrWhiteSpace(fileName), "File name should not be blank.");
    //    //    CodeContract.Required<ArgumentNullException>(stream != null, "File data should not be null.");

    //    //    HttpHandler client = HttpHandler.GetHttpClient(AuthenticationType.Token);

    //    //    using (var request = new StreamContent(stream))
    //    //    {
    //    //        request.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

    //    //        // List data response.
    //    //        HttpResponseMessage response = client.PostAsync(String.Format(ServiceUriHelper.Administration.UploadImage, fileName), request).Result;

    //    //        if (!response.IsSuccessStatusCode)
    //    //        {
    //    //            throw ExceptionHandling(response);
    //    //        }
    //    //    }
    //    //}
    //    #endregion
    //}
}