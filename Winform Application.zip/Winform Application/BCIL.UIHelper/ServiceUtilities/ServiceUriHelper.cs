﻿namespace BCIL.UIHelper
{
    public sealed class ServiceUriHelper
    {
        public class Reports
        {
            public const string GetTagLostData = "Reports/V1/GetTagLostData";
            public const string GetLocationWiseItemAvailability = "Reports/V1/GetLocationWiseItemAvailability";
        }
        
        public class InventoryManagement
        {
            // public const string SaveCompanyWithImage = "V1/Company/Image";

            public const string SaveCompany = "V1/Company";
            public const string GetRegions = "V1/Regions";
            public const string GetRegionById = "V1/Regions/{0}";
            public const string SavRegion = "V1/Region";
            public const string DeleteRegion = "V1/DeleteRegion/{0}";

            public const string GetSites = "V1/Sites";
            public const string GetSiteById = "V1/Sites/{0}";
            public const string SavSite = "V1/Site";
            public const string DeleteSite = "V1/DeleteSite/{0}";

            public const string GetLocations = "V1/Location?companyId={0}&pageSize={1}";
            public const string GetLocationsBySite = "V1/LocationsBySite/{0}";
            public const string GetLocationById = "V1/Locations/{0}";
            public const string SaveLocation = "V1/Location";
            public const string DeleteLocation = "V1/DeleteLocation/{0}";
            public const string LocationKeyValuePairs = "V1/LocationKeyValuePairs";
            public const string GetStoresFromOrder = "V1/Stores/{0}";
            public const string LocationKeyValuePairsForItemTag = "V1/FetchLocationsHavingTag";
            public const string GetLocationForPackingDone = "V1/GetLocationForPackingDone/{0}";

            public const string GetSeasonBySeasonId = "V1/Season/{0}";
            public const string GetSeasonsByCompanyId = "V1/Seasons";
            public const string DeleteSeason = "V1/DeleteSeason/{0}";
            public const string SaveSeason = "V1/Season";

            public const string GetSupplierById = "V1/Supplier/{0}";
            public const string GetSuppliers = "V1/Suppliers";
            public const string DeleteSupplier = "V1/DeleteSupplier/{0}";
            public const string SaveSupplier = "V1/Supplier";

            public const string GetSlotByCode = "V1/GetSlotByCode?SlotCode={0}&LocationId={1}";
            public const string GetSlot = "V1/Slots/{0}";
            public const string GetSlotsByLocation = "V1/Slots?locationId={0}";
            public const string SaveSlot = "V1/Slot";
            public const string GetSlotTypes = "V1/SlotTypes";
            public const string CreateSlotInBulk = "V1/BulkSlot";
            public const string GetSlotsByType = "V1/SlotsByType?TypeCode={0}&LocationId={1}";

            public const string GetBrands = "V1/Brands";
            public const string SaveBrand = "V1/Brand";

            public const string GetItemCategoryById = "V1/ItemCategory/{0}";
            public const string GetItemCategories = "V1/ItemCategories";
            public const string DeleteItemCategory = "V1/DeleteItemCategory/{0}";
            public const string SaveItemCategory = "V1/ItemCategory";

            public const string GetItemSubCategoryById = "V1/ItemSubCategory/{0}";
            public const string DeleteItemSubCategory = "V1/DeleteItemSubCategory/{0}";
            public const string SaveItemSubCategory = "V1/ItemSubCategory";

            public const string GetManufacturers = "V1/Manufacturers";
            public const string SaveManufacturer = "V1/Manufacturer";
            public const string GetManufacturer = "V1/Manufacturer/{0}";

            public const string GetCodeSetups = "V1/CodeSetups/{0}";
            public const string SaveCodeSetup = "V1/CodeSetup";
            public const string GetNewCode = "V1/GetNextCode?objectType={0}";
            public const string GetNewCodeByLocation = "V1/GetNextCode?objectType={0}&locationId={1}";

            public const string GetOrder = "V1/Order/{0}";
            public const string GetOrders = "V1/Orders?pageNumber={0}&pageSize={1}";
            public const string SaveOrder = "V1/Order";
            public const string CancelOrder = "V1/Orders/{0}";
            public const string GetOrderChunk = "V1/OrderChunk";

            public const string GetItem = "V1/Item/{0}";
            public const string GetItems = "V1/Items";
            public const string SaveItem = "V1/Item";
            public const string DeleteItem = "V1/DeleteItem/{0}";
            public const string GetItemStyles = "V1/ItemStyles";
            public const string GetItemStylesByLocation = "V1/ItemStyles?locationId={0}&status={1}";
            public const string GetItemsByCriteria = "V1/Items?pageNumber={0}&pageSize={1}";
            public const string GetItemsToPrint = "V1/ItemsToPrint?pageNumber={0}&pageSize={1}";
            public const string GetItemDetails = "V1/ItemsDetail";
            public const string GetRequestItems = "V1/GetRequestItems";
            public const string GetItemsWithAvailability = "V1/GetItemsWithAvailability";
            public const string GetInventoryLookupItems = "V1/GetInventoryLookupItems";
            public const string GetAllInventoryLookupItems = "V1/GetAllInventoryLookupItems?pageNumber={0}&pageSize={1}";

            public const string GetBOKeyValues = "V1/BOKeyValuePairs?BoType={0}&onlyActive={1}";
            public const string GetBOKeyValuesByLocation = "V1/BOKeyValuePairs?BoType={0}&onlyActive={1}&locationID={2}&status={3}";

            public const string GetItemSetup = "V1/ItemSetup";
            public const string SaveItemSetup = "V1/ItemSetup";
            public const string DeleteItemSetup = "V1/DeleteItemSetup/{0}";

            public const string GetPrintReceiptByType = "V1/Prn/receiptType={0}";
            public const string SaveItemTag = "V1/ItemTag";
            public const string GetItemTagBySGTIN = "V1/ItemTag/{0}";
            public const string GetItemTagBySGTINs = "V1/ItemTagsBySGTINS";
            public const string GetItemTagsByCriteria = "V1/ItemTagsByCriteria";
            public const string UpdateTags = "V1/UpdateTags";
            public const string GetTags = "V1/ItemTags";
            public const string GetTagsForPaging = "V1/GetItemTags?pageNumber={pageNumber}&pageSize={pageSize}";

            public const string GetPrintingSetup = "V1/PrintingSetup";
            public const string SavePrintingSetup = "V1/PrintingSetup";

            public const string GetInwardSetup = "V1/InwardSetup";
            public const string SaveInwardSetup = "V1/InwardSetup";
            public const string GetInwardProcess = "V1/InwardProcess";

            public const string GetOutwardSetup = "V1/OutwardSetup";
            public const string SaveOutwardSetup = "V1/OutwardSetup";

            public const string GetReceivedItem = "V1/ReceivedItem/{0}";
            public const string GetReceivedItems = "V1/ReceivedItems";
            public const string SaveReceivedItems = "V1/ReceivedItems";
            public const string DeleteReceivedItem = "V1/DeleteReceivedItem/{0}";
            public const string GetTransferReadOnlyDataByTransferId = "V1/TransferReadOnlyDataByTransferId/{0}";

            public const string GetCartonLabelPrint = "V1/CartonLabelPrintRequest/{0}";
            public const string SaveCartonLabelPrint = "V1/CartonLabelPrintRequest";
            public const string GetCartonLabelPrintListRequests = "V1/CartonLabelPrintRequest?pageNumber={0}&pageSize={1}";
            public const string CancelCartonLabelPrint = "V1/CancelCartonLabelPrintRequest/{0}";

            public const string GetTagReprintRequest = "V1/TagReprintRequests/{0}";
            public const string GetTagReprintRequests = "V1/TagReprintRequests?pageNumber={0}&pageSize={1}";
            public const string SaveTagReprintRequest = "V1/TagReprintRequest";
            public const string CancelTagReprintRequest = "V1/CancelTagReprintRequest/{0}";

            public const string GetItemsTag = "V1/ItemsKeyValue";
            public const string GetTotalQuantity = "V1/TagReprintRequests/{0}";
            public const string SaveItemTagChangeRequest = "V1/ItemTagChangeRequest";
            public const string SaveReprintedTag = "V1/ReprintedTag";
            public const string GetReprintedTags = "V1/ReprintedTags?tagReprintRequestId={0}";
            public const string GetReprintedTagsViewData = "V1/ReprintedTagsViewData?tagReprintRequestId={0}";
            public const string DispatchTags = "V1/DispatchTags";

            public const string GetPacking = "V1/Packing/{0}";
            public const string SavePacking = "V1/Packing";
            public const string GetPackingList = "V1/PackingList?pageNumber={0}&pageSize={1}";
            public const string GetPackingByRequest = "V1/GetPackingByRequest/{0}";

            public const string GetItemRequest = "V1/ItemRequest/{0}";
            public const string SaveItemRequest = "V1/ItemRequest";
            public const string SaveItemRequests = "V1/ItemRequests";
            public const string GetItemRequestList = "V1/ItemRequestList?pageNumber={0}&pageSize={1}";
            public const string PackedItemsAgainstRequest = "V1/PackedItemsAgainstRequest/{0}";

            public const string GetFreshRequestItems = "V1/GetFreshRequestItems";
            public const string GetPastSeasonRequestItems = "V1/GetPastSeasonRequestItems";
            public const string GetRequestChunk = "V1/GetRequestChunk";
            public const string GetRequestLineItem = "V1/GetRequestLineItem/{0}";
            public const string GetBackupRequestItems = "V1/GetBackupRequestItems";
            public const string GetPendingRequestsByStore = "V1/GetPendingRequestsByStore";
            public const string EndSaleRequest = "V1/EndSaleRequest";

            public const string GetCarton = "V1/Carton/{0}";
            public const string GetCartons = "V1/GetCartons";
            public const string GetCartonsbyCodes = "V1/GetCartonsbyCodes";
            public const string GetCartonsInfo = "V1/GetCartonsInfo";
            public const string SaveCarton = "V1/Carton";
            public const string PutAwayCartons = "V1/CartonsPutAway?slotId={0}";
            public const string PutAwayCarton = "V1/CartonPutAway?slotId={0}";
            public const string GetPackedCartonsForLocationWithoutRequest = "V1/PackedCartons?packedAt={0}&packedFor={1}";
            public const string ItemPutAway = "V1/ItemPutAwayValidateAndSave";
            public const string GetCartonBySlotCode = "V1/GetCartonBySlotCode?SlotCode={0}&LocationId={1}";

            public const string SaveTransfer = "V1/Transfer";
            public const string GetTransfer = "V1/Transfer/{0}";
            public const string GetTransfers = "V1/Transfers";
            public const string GetTransfersInfo = "V1/TransfersInfo";
            public const string GetReceivings = "V1/GetReceivings?pageNumber={0}&pageSize={1}";
            public const string SaveReceivings = "V1/IOReceiving";
            public const string SaveBulkIOReceiving = "V1/BulkIOReceiving";
            public const string GetASNs = "V1/GetASNs";
            public const string GetAllTransfers = "V1/GetAllTransfers?pageNumber={0}&pageSize={1}";
            public const string SaveCartonTransfer = "V1/CartonTransfer";

            public const string SaveStockReserve = "V1/StockReserve";
            public const string SaveStockReserveReturn = "V1/StockReserveReturn";
            public const string GetStockReserve = "V1/StockReserve/{0}";
            public const string GetStockReserveWithCriteria = "V1/GetStockReserveCriteria?pageNumber={0}&pageSize={1}";
            public const string DeleteStockReserve = "V1/DeleteStockReserve/{0}";
            public const string GetGOARequestReasonNotReturnable = "V1/GetGOAReasonNotReturnable/{0}";
            public const string GetGOAReturnViewData = "V1/GetGOAReturn/{0}";
            public const string GetStockReserveToApprove = "V1/GetStockReserveToApprove";

            public const string SaveTagCommissioning = "V1/TagCommissioning";

            public const string GetCycleCountAdvice = "V1/CycleCountAdvice/{0}";
            public const string GetCycleCountAdvices = "V1/CycleCountAdvices";
            public const string GetActiveCycleCountAdvice = "V1/ActiveCycleCountAdvice?locationId={0}";
            public const string SaveCycleCountAdvice = "V1/CycleCountAdvice";
            public const string SaveCountTag = "V1/CountTag";
            public const string SaveCountTagList = "V1/CountTagList";
            public const string HasRunningCycleCount = "V1/HasRunningCycleCount?locationId={0}";
            public const string CycleCountAudit = "V1/AditCycleCount?cycleCountAdviceId={0}";
            public const string CloseCountAudit = "V1/CloseCycleCountAdvice";
            public const string GetActiveCycleCountTagsDetail = "V1/ActiveCycleCountTagsDetail?itemId={0}&locationId={1}";
            public const string GetClosedCycleCountDetail = "V1/ClosedCycleCountDetail?adviceId={0}";
            public const string GetItemsToRecocile="V1/ItemsToRecocile";
            public const string DeleteCycleCountException = "V1/CycleCount/Exceptions";

            public const string GetSaleReconcile = "V1/GetSaleReconcile";
            public const string SaveSaleReconcile = "V1/SaveSaleReconcile";
            public const string SaveSaleClearance = "V1/SaveSaleClearance";

            public const string SaveSize = "V1/Size";
            public const string DeleteSize = "V1/DeleteSize/{0}";
            public const string GetSizebyId = "V1/Size/{0}";
            public const string GetAllSizes = "V1/Sizes";
            public const string GetSizes = "V1/GetSizes";

            public const string GetReasons = "V1/Reasons/{0}";
            public const string GetReasonByReasonType = "V1/ReasonsByType/{0}";
            public const string SaveReason = "V1/Reason";
            public const string DeleteReason = "V1/DeleteReason/{0}";
            public const string GetReasonbyId = "V1/GetReason/{0}";

            public const string CancelScannedTags = "V1/CancelScannedTags";
            public const string CancelUnscannedTags = "V1/CancelUnscannedTags";

            public const string GetPicklistByRequestId = "V1/GetPicklistByRequestId?requestId={0}";
            public const string SavePicklist = "V1/SavePicklist";
        }

        public class ARManagement
        {
            public const string GetTaxes = "ARTransactions/V1/GetTaxes";
            public const string GetTaxesByCategory = "ARTransactions/V1/GetTaxes?categoryId={0}";
            public const string GetTax = "ARTransactions/V1/GetTax?taxId={0}";
            public const string SaveTax = "ARTransactions/V1/SaveTax";
            public const string KeyValuesTaxes = "ARTransactions/V1/KeyValuesTaxes";

            public const string SaveCategoryTax = "ARTransactions/V1/SaveCategoryTax";


            public const string SaveARTransaction = "ARTransactions/V1/SaveARTransaction";
            public const string GetARTransactionById = "ARTransactions/V1/GetARTransactionById?transactionId={0}";
            public const string GetInvoiceDataForReturn = "ARTransactions/V1/GetInvoiceDataForReturn?invoiceNo={0}";
            public const string GetReturnedDataByInvoiceNo = "ARTransactions/V1/InvoiceReturnedData?invoiceNo={0}";
            public const string GetArTransactionViewData = "ARTransactions/V1/ArTransactionViewData?pageNumber={0}&pageSize={1}";
        }

        public class UserManagerment
        {
            public const string GetEmployeeById = "Users/V1/Employees/{0}";
            public const string SaveEmployee = "Users/V1/Employee";
            public const string GetAllEmployees = "Users/V1/Employees?pageNumber={0}&pageSize={1}";
            public const string DeleteEmployee = "Users/V1/DeleteEmployee/{0}";
            public const string GetEmployeePermissions = "Users/V1/EmployeePermissions?employeeId={0}&siteid={1}";
            public const string SaveEmployeePermissions = "Users/V1/EmployeePermissions";
            public const string GetAllRoles = "Users/V1/Roles";
            public const string GetRoleById = "Users/V1/Roles/{0}";
            public const string SaveRole = "Users/V1/Role";
            public const string GetRolePermissions = "Users/V1/RolePermissions?roleId={0}&siteID={1}";
            public const string GetRolesPermissions = "Users/V1/RolesPermissions?siteID={0}";
            public const string SaveRolePermissions = "Users/V1/RolePermissions";
            public const string GetEmployeeRoles = "Users/V1/EmployeeRoles?employeeId={0}&siteid={1}";
            public const string SaveEmployeeRoles = "Users/V1/EmployeeRoles";
            public const string GetEmployeePreference = "Users/V1/EmployeePreferances?employeeId={0}&siteId={1}";
            public const string SaveEmployeePreference = "Users/V1/EmployeePreferance";
            public const string GetLoggedInUserRights = "Users/V1/UserRights?siteid={0}&locationId={1}";
            public const string GetUserAtSiteRights = "Users/V1/UserRightsAtSite?siteid={0}&employeeId={1}";
            public const string GetEmployeePermissionsByLocation = "Users/V1/EmployeePermissionsByLocation?employeeId={0}&locationId={1}";
            public const string SaveEmployeePermissionsByLocation = "Users/V1/EmployeePermissionsByLocation";
        }

        public class Administration
        {
            public const string GetApplicationNodes = "V1/Nodes";
            public const string GetImage = "V1/File?fileName={0}";
            //public const string UploadImage = "V1/File/{0}";
            public const string SaveFile = "/V1/File";
            public const string CreateCredentials = "V1/UserCredentials";
            public const string ChangePassword = "V1/ChangeUserCredentials";
            public const string GetManagerID = "V1/GetManagerId?siteId={0}";
            public const string GetKeyCodeList = "V1/GetKeyCodeList";
        }
    }
}