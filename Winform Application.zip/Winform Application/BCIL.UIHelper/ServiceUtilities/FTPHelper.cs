﻿using BCIL;
using BCIL.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.UIHelper.ServiceUtilities
{
    public class FTPHelper
    {
        private string _userId;
        private string _password;
        private string _ftpServer;

        public FTPHelper (string server,string userId, string password)
        {
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(server), "Server IP/Name should not be blank");
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(userId), "FTP user id should not be blank");
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(password), "FTP password should not be blank");

            if (!server.StartsWith("FTP://", StringComparison.InvariantCultureIgnoreCase))
            {
                _ftpServer = string.Format("FTP://{0}/", server.TrimStart('/'));
            }
            else
            {
                _ftpServer = server;
            }
            _userId = userId;
            _password = password;
        }

        private bool IsPinging(string ftpUrl)
        {
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(ftpUrl), "FTP URL should not be blank");
            FtpWebRequest request = (FtpWebRequest)FtpWebRequest.Create(_ftpServer);
            request.Credentials = new NetworkCredential(_userId, _password);
            request.UsePassive = false;
            request.UseBinary = false;
            request.KeepAlive = false;
            request.Method = System.Net.WebRequestMethods.Ftp.ListDirectoryDetails;
            //if got any response then site is up
            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            {
                return true;
            }
        }

        private string GetResponse(FtpWebRequest ftp)
        {
            //Get the result, streaming to a string                   
            string result = "";
            using (FtpWebResponse response = (FtpWebResponse)ftp.GetResponse())
            {
                long size = response.ContentLength;
                using (Stream datastream = response.GetResponseStream())
                {
                    using (StreamReader sr = new StreamReader(datastream))
                    {
                        result = sr.ReadToEnd();
                        sr.Close();
                    }
                    datastream.Close();
                }
                response.Close();
            }
            return result;
        }

        public bool UploadFile(string fileToUpload, string serverFile)
        {
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(fileToUpload), "File to upload should not be blank");
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(serverFile), "Server file name should not be blank");

            if (!serverFile.StartsWith("FTP://", StringComparison.InvariantCultureIgnoreCase))
            {
                serverFile = string.Format("{0}{1}",_ftpServer, serverFile.TrimStart('/'));
            }

            FtpWebRequest request = FtpWebRequest.Create(serverFile) as FtpWebRequest;

            if (!IsPinging(request.RequestUri.Host)) throw new BCILException("FTP site is down");


            if (FileAlreadyExists(request.RequestUri.AbsoluteUri))
            {
                request.Method = WebRequestMethods.Ftp.AppendFile;
            }
            else
            {
                request.Method = WebRequestMethods.Ftp.UploadFile;
            }

            request.EnableSsl = false;
            request.Credentials = new NetworkCredential(_userId, _password);
            request.UsePassive = true;
            request.UseBinary = false;
            request.KeepAlive = false;
            using (Stream reqStream = request.GetRequestStream())
            {
                using (FileStream stream = File.OpenRead(fileToUpload))
                {
                    long Len = stream.Length;
                    byte[] buffer = new byte[stream.Length];
                    stream.Read(buffer, 0, buffer.Length);
                    reqStream.Write(buffer, 0, buffer.Length);
                }
            }
            request.GetResponse();
            return true;
        }

        public void DownloadFile(string serverFile, string downloadedFileName)
        {
            CodeContract.Required<ArgumentException>(!string.IsNullOrWhiteSpace(serverFile), "Server file name should not be blank");

            if (!serverFile.StartsWith("FTP://", StringComparison.InvariantCultureIgnoreCase))
            {
                serverFile = string.Format("{0}{1}", _ftpServer, serverFile.TrimStart('/'));
            }

            FtpWebRequest request = FtpWebRequest.Create(serverFile) as FtpWebRequest;

            if (!IsPinging(request.RequestUri.Host)) throw new BCILException("FTP site is down");

            request.Method = WebRequestMethods.Ftp.DownloadFile;
            request.EnableSsl = false;
            request.Credentials = new NetworkCredential(_userId, _password);
            request.UsePassive = false;
            request.UseBinary = true;
            request.KeepAlive = false;

            using (var reqStream = request.GetResponse())
            {
                using (Stream responseStream = reqStream.GetResponseStream())
                {
                    using (FileStream stream = new FileStream(downloadedFileName, FileMode.Create))
                    {
                        int Length = 2048;
                        Byte[] buffer = new Byte[Length];
                        int bytesRead = responseStream.Read(buffer, 0, Length);
                        while (bytesRead > 0)
                        {
                            stream.Write(buffer, 0, bytesRead);
                            bytesRead = responseStream.Read(buffer, 0, Length);
                        }
                    }
                }
            }
        }

        private bool FileAlreadyExists(string serverFile)
        {
            FtpWebRequest request = FtpWebRequest.Create(serverFile) as FtpWebRequest;
            request.Method = WebRequestMethods.Ftp.GetFileSize;
            request.Credentials = new NetworkCredential(_userId, _password );
            request.UsePassive = true;
            request.UseBinary = false;
            request.KeepAlive = false; //close the connection when done
            try
            {
                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
