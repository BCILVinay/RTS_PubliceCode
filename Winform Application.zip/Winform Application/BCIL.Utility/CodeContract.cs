﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL
{
    public class CodeContract
    {
        public static void Required<TException>(bool Predicate, string Message)
            where TException : Exception, new()
        {
            if (!Predicate)
            {
                Debug.WriteLine(Message);
                throw (TException)Activator.CreateInstance(typeof(TException), Message);
            }
        }
    }
}
