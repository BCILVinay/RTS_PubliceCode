﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Xml.Linq;

namespace BCIL.Utility
{
    public class HttpHelper : HttpClient
    {
        #region Constructors
        public HttpHelper() : base()
        {

        }
        public HttpHelper(HttpMessageHandler handler) : base(handler)
        {

        }
        public HttpHelper(HttpMessageHandler handler, bool disposeHandler) : base(handler, disposeHandler)
        {

        }
        #endregion

        #region Public Enums

        private enum AuthenticationType
        {
            Authentication = 0,
            Token = 1
        }

        #endregion Public Enums

        #region Properties
        public static string Url { get; set; } = ConfigurationManager.AppSettings["BCILComServerUrl"];

       
        public static List<KeyValue<string, string>> Headers { get; } = new List<KeyValue<string, string>>();

        public static X509Certificate Certificate { get; set; }
        #endregion

        #region Private Methods
        private static HttpHelper GetHttpClient(string userName, string password)
        {
            HttpHelper client = HttpHelper.GetHttpClient();

            var credentials = Encoding.ASCII.GetBytes(string.Format("{0}:{1}", userName, password));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));

            return client;
        }

        private static HttpHelper GetHttpClient()
        {
            HttpHelper httpClient = null;

            if (Certificate != null)
            {
                WebRequestHandler handler = new WebRequestHandler();
                handler.ClientCertificateOptions = ClientCertificateOption.Manual;
                handler.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                {
                    return true;
                };
                handler.ClientCertificates.Add(Certificate);
                httpClient = new HttpHelper(handler);
            }
            else
                httpClient = new HttpHelper();

            Headers.ForEach(x => httpClient.DefaultRequestHeaders.Add(x.Key, x.Value));

            httpClient.BaseAddress = new Uri(Url);

            // Add an Accept header for JSON format.
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return httpClient;
        }

        private static BCILException ExceptionHandling(HttpResponseMessage response)
        {
            if (response.StatusCode == HttpStatusCode.InternalServerError)
            {
                try
                {
                    XDocument xdoc = XDocument.Load(response.Content.ReadAsStreamAsync().Result);
                    var detailElement = xdoc.Descendants().FirstOrDefault(x => x.Name.LocalName == "Detail");
                    if (detailElement != default(XElement))
                    {
                        List<string> exceptions = xdoc.Descendants().Where(x => x.Name.LocalName == "Message").Select(y => y.Value).ToList();

                        if (exceptions != null && exceptions.Count > 0)
                        {
                            return new BCILException(string.Join("\n", exceptions));
                        }

                        if (detailElement.Elements().Any(y => y.Name.LocalName == "string"))
                        {
                            return new BCILException(string.Join("\n", detailElement.Elements().First(x => x.Name.LocalName == "string").Value));
                        }
                    }
                }
                catch
                {
                }
            }

            string message = response.Content.ReadAsStringAsync().Result;
            if (!string.IsNullOrWhiteSpace(message))
                if (message.Contains("Endpoint not found"))
                    return new BCILException("Endpoint not found");
                else
                    return new BCILException(message);
            else
                return new BCILException(response.StatusCode + " - " + response.ReasonPhrase);
        }

        private static string SerializeObject<T>(T dataObject) => new JavaScriptSerializer().Serialize(dataObject);

        #endregion


        #region Http Methods

        public static Task<T> GetAsync<T>(string urlParameters)
        {
            HttpHelper client = HttpHelper.GetHttpClient();

            HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call!
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body. Blocking!
                return response.Content.ReadAsAsync<T>();
            }
            else
            {
                throw ExceptionHandling(response);
            }
        }

        public static TReturn Get<TReturn>(string urlParameters)
        {
            HttpHelper client = HttpHelper.GetHttpClient();
            // List data response.
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call!
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body. Blocking!
                return response.Content.ReadAsAsync<TReturn>().Result;
            }
            else
            {
                throw ExceptionHandling(response);
            }
        }

        public static TReturn Get<TReturn>(string urlParameters, string userName, string password)
        {
            HttpHelper client = HttpHelper.GetHttpClient(userName, password);
            // List data response.
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;  // Blocking call!
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body. Blocking!
                return response.Content.ReadAsAsync<TReturn>().Result;
            }
            else
            {
                throw ExceptionHandling(response);
            }
        }

        public static void Post<TParameter>(string urlParameters, TParameter dataObject)
        {
            HttpHelper client = HttpHelper.GetHttpClient();

            using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
            {
                request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // List data response.
                HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

                if (!response.IsSuccessStatusCode)
                {
                    throw ExceptionHandling(response);
                }
            }
        }

        public static void Post<TParameter>(string urlParameters, TParameter dataObject, string userName, string password)
        {
            HttpHelper client = GetHttpClient(userName, password);

            using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
            {
                request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // List data response.
                HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

                if (!response.IsSuccessStatusCode)
                {
                    throw ExceptionHandling(response);
                }
            }
        }

        public static TReturn Post<TReturn, TParameter>(string urlParameters, TParameter dataObject)
        {
            HttpHelper client = HttpHelper.GetHttpClient();

            using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
            {
                request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // List data response.
                HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

                if (response.IsSuccessStatusCode)
                {
                    // Parse the response body. Blocking!
                    return response.Content.ReadAsAsync<TReturn>().Result;
                }
                else
                {
                    throw ExceptionHandling(response);
                }
            }
        }

        public static TReturn Post<TReturn, TParameter>(string urlParameters, TParameter dataObject, string userName, string password)
        {
            HttpHelper client = HttpHelper.GetHttpClient(userName, password);

            using (var request = new StringContent(SerializeObject<TParameter>(dataObject), Encoding.UTF8))
            {
                request.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                // List data response.
                HttpResponseMessage response = client.PostAsync(urlParameters, request).Result;

                if (response.IsSuccessStatusCode)
                {
                    // Parse the response body. Blocking!
                    return response.Content.ReadAsAsync<TReturn>().Result;
                }
                else
                {
                    throw ExceptionHandling(response);
                }
            }
        }

        public static void Delete(string urlParameters)
        {
            HttpHelper client = HttpHelper.GetHttpClient();
            // List data response.
            HttpResponseMessage response = client.DeleteAsync(urlParameters).Result;

            if (!response.IsSuccessStatusCode)
            {
                throw ExceptionHandling(response);
            }
        }

        #endregion
    }
}
