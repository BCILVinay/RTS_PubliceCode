﻿using NLog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility
{
    public static class BcilLogger
    {
        #region Private Fields

        private static Logger logger = LogManager.GetCurrentClassLogger();

        #endregion Private Fields
        public static void Error(string message, string module)
        {
            WriteEntry(message, "error", module);
            WriteMessage(LogLevel.Error, module + " : " + message);
        }

        public static void Error(Exception ex, string module)
        {
            WriteEntry(ex.ToString(), "error", module);
            WriteException(ex);
        }

        public static void Warning(string message, string module)
        {
            WriteEntry(message, "warning", module);
            WriteMessage(LogLevel.Warn, module + " : " + message);
        }

        public static void Info(string message, string module)
        {
            WriteEntry(message, "info", module);
            WriteMessage(LogLevel.Info, module + " : " + message);
        }

        private static void WriteEntry(string message, string type, string module)
        {
            Trace.WriteLine(
                    string.Format("{0},{1},{2},{3}",
                                  DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                                  type,
                                  module,
                                  message));
        }
        public static void WriteMessage(LogLevel level, string message)
        {
            logger.Log(level, message);
        }

        public static void WriteException(Exception exception)
        {
            logger.Log(LogLevel.Error, exception);
        }
    }
}
