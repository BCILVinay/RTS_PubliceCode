﻿using Csla.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility
{
    public sealed class AppData
    {
        private static Dictionary<string, object> _dataCatch = new Dictionary<string, object>();
        public object Get(string key)
        {
            CodeContract.Required<BCILException>(_dataCatch.ContainsKey(key), key+" doesn't exists");
            return _dataCatch[key];
        }

        public void Set(string key, object value)
        {
            CodeContract.Required<BCILException>(!_dataCatch.ContainsKey(key), key + " already exists");
            _dataCatch.Add(key, value);
        }

        //public static string SQLConnectionString { get; set ; } = "data source=192.168.1.7; Database=WMS_Fenesta; UID=sa;PWD=Passw0rd";
        public static string SQLConnectionString { get; set; } = ConfigurationManager.AppSettings["DBString"].ToString();
    }
}
