﻿using Csla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Csla.Rules;
using Csla.Core.FieldManager;
using Csla.Core;

namespace BCIL.Utility
{
    [Serializable]
    public class MyBusinessBase<T> : BusinessBase<T> where T : MyBusinessBase<T>
    {
        public new int EditLevel => base.EditLevel;

        public void ApplyEdits()
        {
            while (EditLevel > 0)
                ApplyEdit();
        }

        public override BrokenRulesCollection BrokenRulesCollection
        {
            get
            {
                BrokenRulesCollection cl = new BrokenRulesCollection();
                cl.AddRange(base.BrokenRulesCollection);

                foreach (var aa in this.FieldManager.GetChildren())
                {
                    if (aa is BusinessBase) cl.AddRange(((BusinessBase)aa).BrokenRulesCollection);
                }

                return cl;
            }
        }
    }
}
