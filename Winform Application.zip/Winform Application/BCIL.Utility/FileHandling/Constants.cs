﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility.FileHandling
{
    public sealed class Constants
    {
        public static List<string> ValidExtensions = new List<string>() { ".XLS", ".XLSX", ".CSV", ".TXT" };
    }
}
