﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility.FileHandling
{
    public class XFile
    {
        public XFile(string fileName)
        {
            CodeContract.Required<BCILException>(fileName.IsNotNullOrWhiteSpace(), "File is required");
            CodeContract.Required<BCILException>(Path.GetExtension(fileName).IsNotNullOrWhiteSpace(), "Invalid file name");
            CodeContract.Required<BCILException>(Constants.ValidExtensions.Contains(Path.GetExtension(fileName).ToUpperInvariant()), "Invalid file name");
            CodeContract.Required<BCILException>(Path.GetExtension(fileName) != ".TXT", "Invalid constructor call");
            FullFileName = fileName;
            this.FileType = GetFileType(Path.GetExtension(fileName));
        }

        public XFile(string fileName, Delimitation delimitation, char delemationChar = ',')
        {
            CodeContract.Required<BCILException>(fileName.IsNotNullOrWhiteSpace(), "File is required");
            CodeContract.Required<BCILException>(Path.GetExtension(fileName).IsNotNullOrWhiteSpace(), "Invalid file name");
            CodeContract.Required<BCILException>(Constants.ValidExtensions.Contains(Path.GetExtension(fileName).ToUpperInvariant()), "Invalid file name");

            if (Path.GetExtension(fileName) == ".TXT")
            {
                CodeContract.Required<BCILException>(delimitation == Delimitation.Char && delemationChar != default(char), "Specify delimitation char");
            }

            if (delimitation == Delimitation.TabDelimited)
                DelimitionChar = '\t';
            else
                DelimitionChar = delemationChar;

            FullFileName = fileName;
            this.FileType = GetFileType(Path.GetExtension(fileName));
            Delimited = delimitation;
        }

        public string FullFileName { get; set; }

        public FileType FileType { get; set; }

        public Delimitation Delimited { get; set; }

        public char DelimitionChar { get; set; }

        private FileType GetFileType(string extn)
        {
            switch (extn.Trim().TrimStart('.').ToUpperInvariant())
            {
                case "XLS":
                case "XLSX":
                    return FileType.Excel;
                case "CSV":
                    return FileType.CSV;
                case "TXT":
                    return FileType.Txt;
                default:
                    return FileType.Invalid;
            }
        }
    }

    public enum FileType
    {
        Invalid = 0,
        Excel = 1,
        CSV = 2,
        Txt = 3
    }

    public enum Delimitation
    {
        NoteSpecified = 0,
        Comma = 1,
        Char = 2,
        TabDelimited = 3,
    }
}
