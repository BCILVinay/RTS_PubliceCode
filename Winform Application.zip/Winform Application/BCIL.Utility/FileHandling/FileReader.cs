﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility.FileHandling
{
    public class FileReader
    {
        private XFile _file = null;
        public FileReader(string fileName)
        {
            _file = new XFile(fileName);
        }

        public FileReader(XFile file)
        {
            _file = file;
        }

        public DataSet Read()
        {
            DataSet excelDataSet = new DataSet();
            CodeContract.Required<BCILException>(File.Exists(_file.FullFileName), "File doesn't exits");
            using (var connection = OleDbProvider.GetConnection(_file))
            {
                connection.Open();
                var dtExcelSchema = GetSchemaTable(connection);
                string table = "";

                if (_file.FileType == FileType.Excel)
                {
                    table = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                }
                else
                {
                    foreach (DataRow dr in dtExcelSchema.Rows)
                    {
                        if (dr["TABLE_NAME"].ToString().StartsWith(Path.GetFileNameWithoutExtension(_file.FullFileName)))
                        {
                            table = dr["TABLE_NAME"].ToString();
                            break;
                        }
                    }
                }

                OleDbDataAdapter cmd = new OleDbDataAdapter(string.Format("select * from [{0}]", table), connection);
                cmd.Fill(excelDataSet, table.TrimEnd('$'));
            }
            return excelDataSet;
        }

        public DataSet Read(List<string> sheets)
        {
            DataSet excelDataSet = new DataSet();
            CodeContract.Required<BCILException>(File.Exists(_file.FullFileName), "File doesn't exits");
            using (var connection = OleDbProvider.GetConnection(_file))
            {
                connection.Open();
                foreach (var sheet in sheets)
                {
                    OleDbDataAdapter cmd = new OleDbDataAdapter(string.Format("select * from [{0}$]", sheet), connection);
                    cmd.Fill(excelDataSet, sheet);
                }
            }
            return excelDataSet;
        }

        public DataTable GetSchemaTable()
        {
            using (OleDbConnection connection = OleDbProvider.GetConnection(_file))
            {
                connection.Open();
                DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                return schemaTable;
            }
        }

        private DataTable GetSchemaTable(OleDbConnection connection)
        {
            DataTable schemaTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            return schemaTable;
        }
    }
}
