﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility.FileHandling
{
    public sealed class OleDbProvider
    {
        public static OleDbConnection GetConnection(XFile file, bool writeMode = false)
        {
            switch (file.FileType)
            {
                case FileType.Excel:
                    if (writeMode)
                        return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='Excel 12.0 Xml;HDR=Yes;READONLY=FALSE'");
                    else
                        return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='Excel 12.0 Xml;HDR=Yes;IMEX=1';");
                case FileType.CSV:
                    if (writeMode)
                        return new OleDbConnection(@"Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + Path.GetDirectoryName(file.FullFileName) + ";Mode=ReadWrite;Extended Properties='text;HDR=Yes;FMT=Delimited;READONLY=FALSE';");
                    else
                        return new OleDbConnection(@"Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + Path.GetDirectoryName(file.FullFileName) + ";Extended Properties='text;HDR=Yes;FMT=Delimited';");
                case FileType.Txt:
                    if (writeMode)
                    {
                        if (file.Delimited == Delimitation.Comma)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=Yes;FMT=Delimited(,)';");
                        else if (file.Delimited == Delimitation.TabDelimited)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=Yes;FMT=Delimited';");
                        else if (file.Delimited == Delimitation.Char)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=Yes;FMT=Delimited(" + file.DelimitionChar + ")';");
                        else throw new BCILException("Specify delimitation");
                    }
                    else
                    {
                        if (file.Delimited == Delimitation.Comma)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=NO;FMT=Delimited(,);READONLY=FALSE'");
                        else if (file.Delimited == Delimitation.TabDelimited)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=NO;FMT=Delimited;READONLY=FALSE'");
                        else if (file.Delimited == Delimitation.Char)
                            return new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + file.FullFileName + ";Extended Properties='text;HDR=NO;FMT=Delimited(" + file.DelimitionChar + ");READONLY=FALSE'");
                        else throw new BCILException("Specify delimitation");
                    }
                default:
                    throw new BCILException("Invalid file");
            }
        }

    }
}
