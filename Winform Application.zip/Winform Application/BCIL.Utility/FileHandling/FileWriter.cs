﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace BCIL.Utility.FileHandling
{
    public class FileWriter
    {
        private XFile _file = null;

        private void WriteDelimatedFile(DataTable dt)
        {
            StringBuilder sb = new StringBuilder();
            bool isFirstCol = true;

            string delimate = _file.FileType == FileType.CSV ? "," : _file.DelimitionChar.ToString();

            foreach (DataColumn col in dt.Columns)
            {
                if (isFirstCol)
                {
                    isFirstCol = false;
                    sb.AppendFormat("\"{0}\"", col.ColumnName);
                }
                else
                {
                    sb.AppendFormat("{1}\"{0}\"", col.ColumnName, delimate);
                }
            }

            foreach (DataRow dr in dt.Rows)
            {
                sb.Append(Environment.NewLine);
                isFirstCol = true;
                foreach (DataColumn col in dt.Columns)
                {
                    if (isFirstCol)
                    {
                        isFirstCol = false;
                        if (col.DataType.IsValueType)
                            sb.Append(dr[col.ColumnName]);
                        else
                            sb.AppendFormat("\"{0}\"", dr[col.ColumnName]);
                    }
                    else
                    {
                        if (col.DataType.IsValueType)
                            sb.AppendFormat("{1}{0}", dr[col.ColumnName], delimate);
                        else
                            sb.AppendFormat("{1}\"{0}\"", dr[col.ColumnName], delimate);
                    }
                }
            }

            File.WriteAllText(_file.FullFileName, sb.ToString());
        }

        private void WriteExcelFile(List<DataTable> tables)
        {
            using (var connection = OleDbProvider.GetConnection(_file, true))
            {
                connection.Open();

                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = connection;

                foreach (DataTable dt in tables)
                {
                    StringBuilder CreateTableBuilder = new StringBuilder();
                    StringBuilder InsertTableBuilder = new StringBuilder();

                    CreateTableBuilder.AppendFormat("CREATE TABLE {0} (", dt.TableName);
                    InsertTableBuilder.AppendFormat("INSERT INTO [{0}](", dt.TableName);
                    bool isFirstCol = true;
                    foreach (DataColumn col in dt.Columns)
                    {
                        if (isFirstCol == true)
                        {
                            isFirstCol = false;
                            CreateTableBuilder.AppendFormat("[{0}] {1}", col.ColumnName, col.DataType.Name);
                            InsertTableBuilder.AppendFormat("[{0}]", col.ColumnName);
                        }
                        else
                        {
                            CreateTableBuilder.AppendFormat(",[{0}] {1}", col.ColumnName, col.DataType.Name);
                            InsertTableBuilder.AppendFormat(",[{0}]", col.ColumnName);
                        }
                    }
                    CreateTableBuilder.Append(")");
                    InsertTableBuilder.Append(") VALUES ");

                    cmd.CommandText = CreateTableBuilder.ToString();
                    cmd.ExecuteNonQuery();

                    foreach (DataRow dr in dt.Rows)
                    {
                        StringBuilder InsertrowBuilder = new StringBuilder();

                        InsertrowBuilder.Append("( ");

                        isFirstCol = true;
                        foreach (DataColumn col in dt.Columns)
                        {
                            if (isFirstCol)
                            {
                                isFirstCol = false;
                                if (col.DataType.IsValueType)
                                    InsertrowBuilder.AppendFormat("{0}", dr[col.ColumnName].ToString());
                                else
                                    InsertrowBuilder.AppendFormat("\"{0}\"", dr[col.ColumnName].ToString());
                            }
                            else
                            {
                                if (col.DataType.IsValueType)
                                    InsertrowBuilder.AppendFormat(",{0}", dr[col.ColumnName].ToString());
                                else
                                    InsertrowBuilder.AppendFormat(",\"{0}\"", dr[col.ColumnName].ToString());
                            }
                        }
                        InsertrowBuilder.Append(")");
                        cmd.CommandText = InsertTableBuilder.ToString() + InsertrowBuilder.ToString();
                        cmd.ExecuteNonQuery();
                    }
                }
                connection.Close();
            }
        }

        private void WriteFile<T>(List<T> objects)
        {
            var properties = typeof(T).GetProperties();

            bool isFirstCol = true;
            string delimate = _file.FileType == FileType.CSV ? "," : _file.DelimitionChar.ToString();

            StringBuilder sb = new StringBuilder();

            foreach (PropertyInfo property in properties)
            {
                var displayNameAttribute = property.CustomAttributes.FirstOrDefault(x => x.AttributeType == typeof(DisplayNameAttribute));
                string name = property.Name;
                if (displayNameAttribute != null && displayNameAttribute.ConstructorArguments.Count > 0)
                {
                    name = displayNameAttribute.ConstructorArguments[0].Value.ToString();
                }

                if (isFirstCol)
                {
                    isFirstCol = false;
                    sb.AppendFormat("\"{0}\"", name);
                }
                else
                {
                    sb.AppendFormat("{1}\"{0}\"", name, delimate);
                }
            }

            foreach (T obj in objects)
            {
                sb.Append(Environment.NewLine);
                isFirstCol = true;

                foreach (PropertyInfo propertyInfo in properties)
                {
                    if (isFirstCol)
                    {
                        isFirstCol = false;
                        if (propertyInfo.PropertyType.IsValueType)
                            sb.Append(propertyInfo.GetValue(obj));
                        else
                            sb.AppendFormat("\"{0}\"", propertyInfo.GetValue(obj));
                    }
                    else
                    {
                        if (propertyInfo.PropertyType.IsValueType)
                            sb.AppendFormat("{1}{0}", propertyInfo.GetValue(obj), delimate);
                        else
                            sb.AppendFormat("{1}\"{0}\"", propertyInfo.GetValue(obj), delimate);
                    }
                }
            }
            File.WriteAllText(_file.FullFileName, sb.ToString());
        }

        public void WriteFile<T>(string fileName, List<T> source)
        {
            _file = new XFile(fileName);

            var path = Path.GetDirectoryName(_file.FullFileName);
            CodeContract.Required<BCILException>(path.IsNullOrWhiteSpace() || Directory.Exists(path), "Path doesn't exits");
            CodeContract.Required<BCILException>(source != null || source.Count != 0, "Source is null");

            if (_file.FileType == FileType.Excel && typeof(T) != typeof(DataTable))
            {
                throw new BCILException("Source source can not ne written in EXCEL. Try CSV file.");
            }

            if (_file.FileType == FileType.CSV || _file.FileType == FileType.Txt)
            {
                if (typeof(T) == typeof(DataTable))
                {
                    WriteDelimatedFile(source.Cast<DataTable>().First());
                }
                else
                {
                    WriteFile(source);
                }
            }
            else
            {
                WriteExcelFile(source.Cast<DataTable>().ToList());
            }
        }
    }
}