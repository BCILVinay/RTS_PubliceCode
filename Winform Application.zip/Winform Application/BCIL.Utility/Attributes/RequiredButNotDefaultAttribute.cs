﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class RequiredButNotDefaultAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null || (value.GetType().IsValueType && value.Equals(Activator.CreateInstance(value.GetType()))))
            {
                return new System.ComponentModel.DataAnnotations.ValidationResult(ErrorMessage ?? "Invalid value.");
            }
            return ValidationResult.Success;
        }
    }
}
