﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class CollectionValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var collection = (ICollection)value;
            if (value == null || collection == null) return new ValidationResult(ErrorMessage ?? "Invalid use of attribute");
            if (collection.Count == 0) return new ValidationResult(ErrorMessage ?? "Collection must have items");

            return ValidationResult.Success;
        }
    }
}
