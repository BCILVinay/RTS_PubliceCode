﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Utility
{
    public static class Data
    {
        public static string GetPagingSQL(string query, int pageNumber, int pageSize, string orderByColumn )
        {
            query = query.Trim();
            if (query.StartsWith("Select", StringComparison.OrdinalIgnoreCase))
                query = query.Substring(6);

            StringBuilder sb = new StringBuilder();
            sb.Append("WITH RowConstrainedResult \n");
            sb.AppendFormat("     AS (SELECT Row_number() OVER(  ORDER BY {0} DESC) AS RowNum, \n", orderByColumn );
            sb.Append("	  \n");
            sb.AppendFormat("  {0}	\n", query);
            sb.Append(" ) \n");
            sb.Append("SELECT *, (SELECT Max(RowNum) FROM   RowConstrainedResult) AS 'TotalRows' \n");
            sb.Append("FROM   RowConstrainedResult \n");
            sb.AppendFormat("WHERE  RowNum > ( {0} - 1 ) *{1} AND RowNum <= ( {0} - 1 ) *{1} + {1} \n", pageNumber, pageSize);
            sb.Append("ORDER  BY RowNum");
            return sb.ToString();
        }

        public static string GetPagingSQL_Parameterized(string query, string orderByColumn)
        {
            query = query.Trim();
            if (query.StartsWith("Select", StringComparison.OrdinalIgnoreCase))
                query = query.Substring(6);

            StringBuilder sb = new StringBuilder();
            sb.Append("WITH RowConstrainedResult \n");
            sb.AppendFormat("     AS (SELECT Row_number() OVER(  ORDER BY {0} DESC) AS RowNum, \n", orderByColumn );
            sb.Append("	  \n");
            sb.AppendFormat("  {0}	\n", query);
            sb.Append(" ) \n");
            sb.Append("SELECT *, (SELECT Max(RowNum) FROM   RowConstrainedResult) AS 'TotalRows' \n");
            sb.Append("FROM   RowConstrainedResult \n");
            sb.Append("WHERE  RowNum > ( @page - 1 ) * @pageSize AND RowNum <= ( @page - 1 ) * @pageSize + @pageSize \n");
            sb.Append("ORDER  BY RowNum");
            return sb.ToString();
        }
    }
}
