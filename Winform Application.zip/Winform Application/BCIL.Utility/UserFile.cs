﻿using Csla;
using System;
using System.IO;


namespace BCIL.Utility
{
    public class UserFile : MyBusinessBase<UserFile>
    {
        public static readonly PropertyInfo<string> FileNameProperty = RegisterProperty<string>(c => c.FileName);

        public string FileName
        {
            get { return GetProperty(FileNameProperty); }
            set { SetProperty(FileNameProperty, value); }
        }

        public string FileNameWithoutExt
        {
            get
            {
                if (string.IsNullOrWhiteSpace(FileName)) return "";
                return Path.GetFileNameWithoutExtension(FileName);
            }
        }

        public static readonly PropertyInfo<byte[]> FileDataProperty = RegisterProperty<byte[]>(c => c.FileData);

        public byte[] FileData
        {
            get { return GetProperty(FileDataProperty); }
            set { SetProperty(FileDataProperty, value); }
        }
    }

   
}