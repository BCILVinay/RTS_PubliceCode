﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BCIL
{
    public delegate TReturn EventHandler<TEventArgs, TReturn>(object sender, TEventArgs argument);
    public static class Extensions
    {
        public static Int32 ToInt32<TException>(this string toConvertInInteger, string errMessage)
            where TException : Exception, new()
        {
            int value;
            if (Int32.TryParse(toConvertInInteger, out value))
            {
                return value;
            }
            throw (TException)Activator.CreateInstance(typeof(TException), errMessage);
        }

        public static Int64 ToInt64<TException>(this string toConvertInInteger, string errMessage)
          where TException : Exception, new()
        {
            Int64 value;
            if (Int64.TryParse(toConvertInInteger, out value))
            {
                return value;
            }
            throw (TException)Activator.CreateInstance(typeof(TException), errMessage);
        }

        public static int GetPercentValue(this int value, decimal percentage)
        {
            return (int)(value * percentage / 100);
        }

        public static long GetPercentValue(this long value, decimal percentage)
        {
            return (long)(value * percentage / 100);
        }

        public static decimal GetPercentValue(this decimal value, decimal percentage)
        {
            return value * percentage / 100;
        }

        public static string Ordinal(this int number)
        {
            string suffix = String.Empty;

            int ones = number % 10;
            int tens = (int)Math.Floor(number / 10M) % 10;

            if (tens == 1)
            {
                suffix = "th";
            }
            else
            {
                switch (ones)
                {
                    case 1:
                        suffix = "st";
                        break;

                    case 2:
                        suffix = "nd";
                        break;

                    case 3:
                        suffix = "rd";
                        break;

                    default:
                        suffix = "th";
                        break;
                }
            }
            return String.Format("{0}{1}", number, suffix);
        }

        public static string Join<TSource>(this IEnumerable<TSource> source, string separator, Expression<Func<TSource, object>> dataSourceMemberAccess)
        {
            StringBuilder sb = new StringBuilder();

            foreach (TSource item in source)
            {
                var val = dataSourceMemberAccess.Compile()(item);
                if (val != null)
                {
                    if (sb.Length > 0)
                        sb.AppendFormat("{0}{1}", separator, val);
                    else
                        sb.Append(val);
                }
            }
            return sb.ToString();
        }

        public static bool HaveItems<TSource>(this ICollection<TSource> source)
        {
            return source != null && source.Count > 0;
        }

        public static bool IsNull(this object obj)
        {
            return obj == null;
        }

        public static bool IsNotNull(this object obj)
        {
            return obj != null;
        }

        public static bool IsNullOrWhiteSpace(this string obj)
        {
            return string.IsNullOrWhiteSpace(obj);
        }

        public static bool IsNotNullOrWhiteSpace(this string obj)
        {
            return !string.IsNullOrWhiteSpace(obj);
        }

        public static Dictionary<string, string> EnumToDictionary(this Enum @enum)
        {
            var type = @enum.GetType();
            return Enum.GetValues(type).Cast<string>().ToDictionary(e => e, e => Enum.GetName(type, e));
        }

        public static string DisplayName(this Enum @enum)
        {
            Type mytype = @enum.GetType();
            var field = mytype.GetField(@enum.ToString());
            var valueAttribute = field.GetCustomAttribute(typeof(DescriptionAttribute));
            if (valueAttribute != null)
                return ((DescriptionAttribute)valueAttribute).Description;
            else
                return @enum.ToString();
        }

        public static string GetAttributeValue<TAttribute>(this Enum @enum, Expression<Func<TAttribute, string>> controlPropertyAccessor) where TAttribute : Attribute
        {
            Type mytype = @enum.GetType();
            var field = mytype.GetField(@enum.ToString());
            var valueAttribute = field.GetCustomAttribute(typeof(TAttribute));

            if (valueAttribute != null)
            {
                TAttribute attrObj = (TAttribute)valueAttribute;

                var a = controlPropertyAccessor.Compile();
                return a((TAttribute)valueAttribute);
            }

            throw new Exception("Attribute not found");
        }
    }
}
