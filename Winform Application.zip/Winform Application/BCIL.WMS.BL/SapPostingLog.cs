﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class SapPostingLog : MyBusinessBase<SapPostingLog>
    {
        #region Properties

        public static readonly PropertyInfo<long> LogIdProperty = RegisterProperty<long>(c => c.LogId);
        public long LogId
        {
            get { return GetProperty(LogIdProperty); }
            set { SetProperty(LogIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> SiteProperty = RegisterProperty<KeyValue<int, string>>(c => c.Site);
        public KeyValue<int,string> Site
        {
            get { return GetProperty(SiteProperty); }
            set { SetProperty(SiteProperty, value); }
        }

        public static readonly PropertyInfo<string> PostingDataProperty = RegisterProperty<string>(c => c.PostingData);
        public string PostingData
        {
            get { return GetProperty(PostingDataProperty); }
            set { SetProperty(PostingDataProperty, value); }
        }

        public static readonly PropertyInfo<string> SapResponseProperty = RegisterProperty<string>(c => c.SapResponse);
        public string SapResponse
        {
            get { return GetProperty(SapResponseProperty); }
            set { SetProperty(SapResponseProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsSuccessProperty = RegisterProperty<bool>(c => c.IsSuccess);
        public bool IsSuccess
        {
            get { return GetProperty(IsSuccessProperty); }
            set { SetProperty(IsSuccessProperty, value); }
        }

        public static readonly PropertyInfo<SapProcess> ProcessProperty = RegisterProperty<SapProcess>(c => c.Process);
        public SapProcess Process
        {
            get { return GetProperty(ProcessProperty); }
            set { SetProperty(ProcessProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedonProperty = RegisterProperty<DateTime>(c => c.CreatedOn);
        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedonProperty); }
            set { SetProperty(CreatedonProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> CreatedByProperty = RegisterProperty<KeyValue<int, string>>(c => c.CreatedBy);
        public KeyValue<int, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);
        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> UpdatedByProperty = RegisterProperty<KeyValue<int, string>>(c => c.UpdatedBy);
        public KeyValue<int, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<int> NumberOfRetriesProperty = RegisterProperty<int>(c => c.NumberOfRetries);
        public int NumberOfRetries
        {
            get { return GetProperty(NumberOfRetriesProperty); }
            set { SetProperty(NumberOfRetriesProperty, value); }
        }

        public static readonly PropertyInfo<bool> HandledManuallyProperty = RegisterProperty<bool>(c => c.HandledManually);
        public bool HandledManually
        {
            get { return GetProperty(HandledManuallyProperty); }
            set { SetProperty(HandledManuallyProperty, value); }
        }
        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
        }

        #endregion Custom Validations

        #region Factory Methods

        public static SapPostingLog NewSapPostingLog()
        {
            return DataPortal.Create<SapPostingLog>();
        }

        public static SapPostingLog GetSapPostingLog(long id)
        {
            return DataPortal.Fetch<SapPostingLog>(id);
        }

        public static SapPostingLog GetSapPostingLog(SafeDataReader dr)
        {
            return DataPortal.Fetch<SapPostingLog>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            LogId = dr.GetInt64("LogId");
            Site = new KeyValue<Int32, string>(dr.GetInt32("SiteId"), dr.GetString("SiteCode"));
            PostingData = dr.GetString("PostingData");
            SapResponse = dr.GetString("SapResponse");
            IsSuccess = dr.GetBoolean("IsSuccess");
            Process = (SapProcess)dr.GetInt32("Process");
            CreatedOn = dr.GetDateTime("Createdon");
            CreatedBy = new KeyValue<int, string>(dr.GetInt32("CreatedBy"), dr.GetString("Name"));
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = new KeyValue<int, string>(dr.GetInt32("UpdatedBy"), dr.GetString("UpdatedByName"));
            NumberOfRetries= dr.GetInt32("NumberOfRetries");
            HandledManually = dr.GetBoolean("HandledManually");
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LogId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,T2.Name,T3.NAME AS UpdatedByName \n");
            sb.Append("FROM   [PostingLog] T \n");
            sb.Append("       INNER JOIN [Site] T1 ON T.SiteId = T1.SiteId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.CreatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T3 ON T.UpdatedBy = T3.EmployeeId \n");
            sb.Append("WHERE  T.LogId = @LogId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert
        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();

                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                    cmd.Parameters.AddWithValue("@PostingData", PostingData);
                    cmd.Parameters.AddWithValue("@SapResponse", SapResponse);
                    cmd.Parameters.AddWithValue("@IsSuccess", IsSuccess);
                    cmd.Parameters.AddWithValue("@Process", Process);
                    cmd.Parameters.AddWithValue("@Createdon", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@NumberOfRetries", NumberOfRetries);
                    cmd.Parameters.AddWithValue("@HandledManually", HandledManually);
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    LogId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [PostingLog] \n");
            sb.Append("            ([SiteId],[PostingData],[SapResponse],[IsSuccess],[Process],[Createdon],[CreatedBy],[UpdatedOn],[UpdatedBy],[NumberOfRetries],[HandledManually]) \n");
            sb.Append("VALUES      (@SiteId,@PostingData,@SapResponse,@IsSuccess,@Process,@Createdon,@CreatedBy,@UpdatedOn,@UpdatedBy,@NumberOfRetries,@HandledManually)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();

                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@Logid", LogId);
                    cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                    cmd.Parameters.AddWithValue("@PostingData", PostingData);
                    cmd.Parameters.AddWithValue("@SapResponse", SapResponse);
                    cmd.Parameters.AddWithValue("@IsSuccess", IsSuccess);
                    cmd.Parameters.AddWithValue("@Process", Process);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@HandledManually", HandledManually);
                    cmd.Parameters.AddWithValue("@NumberOfRetries", NumberOfRetries);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [PostingLog] \n");
            sb.Append("SET    [SiteId] = @SiteId, \n");
            sb.Append("       [PostingData] = @PostingData, \n");
            sb.Append("       [SapResponse] = @SapResponse, \n");
            sb.Append("       [IsSuccess] = @IsSuccess, \n");
            sb.Append("       [Process] = @Process, \n");
            sb.Append("       [UpdatedOn] = @UpdatedOn, \n");
            sb.Append("       [UpdatedBy] = @UpdatedBy, \n");
            sb.Append("       [NumberOfRetries] = @NumberOfRetries, \n");
            sb.Append("       [HandledManually] = @HandledManually \n");
            sb.Append("WHERE  Logid = @Logid");
            return sb.ToString();
        }

        #endregion Update


        #endregion Data Functions
    }

    public enum SapProcess
    {
        [Description("PO Confirmation")]
        POConfirmation =0,

        [Description("SLoc to SLoc Transfer")]
        SLocToSLocTransfer =1,

        [Description("Put-Away")]
        PutAway =2,

        [Description("Picking")]
        Picking =3,

        [Description("Dispatch")]
        Dispatch =4,

        [Description("GRN")]
        Receiving =5
    }
}
