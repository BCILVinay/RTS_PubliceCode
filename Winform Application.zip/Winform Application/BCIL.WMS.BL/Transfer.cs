﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Transfer : MyBusinessBase<Transfer>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> TransferIdProperty = RegisterProperty<Int64>(c => c.TransferId);

        public Int64 TransferId
        {
            get { return GetProperty(TransferIdProperty); }
            set { SetProperty(TransferIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> PickListIdProperty = RegisterProperty<Int64>(c => c.PickListId);

        public Int64 PickListId
        {
            get { return GetProperty(PickListIdProperty); }
            set { SetProperty(PickListIdProperty, value); }
        }

        public static readonly PropertyInfo<string> STONoProperty = RegisterProperty<string>(c => c.STONo);

        public string STONo
        {
            get { return GetProperty(STONoProperty); }
            set { SetProperty(STONoProperty, value); }
        }

        public static readonly PropertyInfo<string> DeliveryNoProperty = RegisterProperty<string>(c => c.DeliveryNo);

        public string DeliveryNo
        {
            get { return GetProperty(DeliveryNoProperty); }
            set { SetProperty(DeliveryNoProperty, value); }
        }

        public static readonly PropertyInfo<TransferStatus> StatusProperty = RegisterProperty<TransferStatus>(c => c.Status);

        public TransferStatus Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> SiteFromProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.SiteFrom);

        public KeyValue<Int64, string> SiteFrom
        {
            get { return GetProperty(SiteFromProperty); }
            set { SetProperty(SiteFromProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> SiteToProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.SiteTo);

        public KeyValue<Int64, string> SiteTo
        {
            get { return GetProperty(SiteToProperty); }
            set { SetProperty(SiteToProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> DeliveryDateProperty = RegisterProperty<DateTime>(c => c.DeliveryDate);

        public DateTime DeliveryDate
        {
            get { return GetProperty(DeliveryDateProperty); }
            set { SetProperty(DeliveryDateProperty, value); }
        }

        public static readonly PropertyInfo<TransferItems> ItemsProperty = RegisterProperty<TransferItems>(c => c.Items);

        public TransferItems Items
        {
            get { return GetProperty(ItemsProperty); }
            set { SetProperty(ItemsProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Transfer()
        {
        }

        public static Transfer NewTransfer()
        {
            return DataPortal.Create<Transfer>();
        }

        public static Transfer GetTransfer(int id)
        {
            return DataPortal.Fetch<Transfer>(id);
        }

        public static Transfer GetTransfer(string deliveryNo)
        {
            return DataPortal.Fetch<Transfer>(deliveryNo);
        }

        public static void DeleteTransfer(int id)
        {
            DataPortal.Delete<Transfer>(id);
        }

        public static Transfer GetTransfer(SafeDataReader dr)
        {
            return DataPortal.Fetch<Transfer>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            TransferId = dr.GetInt64("TransferId");
            STONo = dr.GetString("STONo");
            DeliveryNo = dr.GetString("DeliveryNo");
            Status = (TransferStatus)dr.GetInt32("Status");
            SiteFrom = new KeyValue<Int64, string>(dr.GetInt64("SiteFrom"), dr.GetString("SiteFromCode"));
            SiteTo = new KeyValue<Int64, string>(dr.GetInt64("SiteTo"), dr.GetString("SiteToCode"));
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            DeliveryDate = dr.GetDateTime("DeliveryDate");
            Items = TransferItems.GetTransferItems(dr.GetInt64("TransferId"));
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@TransferId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T2.SiteId = T.SiteTo \n");
            sb.Append("WHERE  T.TransferId = @TransferId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string deliveryNo)
        {
            CodeContract.Required<ArgumentException>(deliveryNo.IsNotNullOrWhiteSpace(), "Delivery no is required to fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@DeliveryNo", deliveryNo);
                    cmd.CommandText = FetchSQLByDeliveryNo();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQLByDeliveryNo()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T2.SiteId = T.SiteTo \n");
            sb.Append("WHERE  T.DeliveryNo = @DeliveryNo");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.Parameters.AddWithValue("@STONo", STONo);
                        cmd.Parameters.AddWithValue("@PickListId", PickListId);

                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom.Key);
                        cmd.Parameters.AddWithValue("@SiteTo", SiteTo.Key);
                        cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
                        cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                        cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.Parameters.AddWithValue("@DeliveryDate", DeliveryDate);
                        cmd.CommandText = InsertSQL();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                        TransferId = Convert.ToInt64(cmd.ExecuteScalar());
                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.TransferId = TransferId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Transfer] \n");
            sb.Append("            ([STONo],[PickListId],[DeliveryNo],[Status],[SiteFrom],[SiteTo],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[DeliveryDate]) \n");
            sb.Append("VALUES      (@STONo,@PickListId,@DeliveryNo,@Status,@SiteFrom,@SiteTo,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@DeliveryDate)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = UpdateSQL();
                        cmd.Parameters.AddWithValue("@TransferId", TransferId);
                        cmd.Parameters.AddWithValue("@STONo", STONo);
                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom.Key);
                        cmd.Parameters.AddWithValue("@SiteTo", SiteTo.Key);
                        cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.Parameters.AddWithValue("@DeliveryDate", DeliveryDate);
                        cmd.ExecuteNonQuery();
                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.TransferId = TransferId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Transfer] \n");
            sb.Append("SET    [STONo] = @STONo,[DeliveryNo] = @DeliveryNo,[Status] = @Status,[SiteFrom] = @SiteFrom,[SiteTo] = @SiteTo,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[DeliveryDate] = @DeliveryDate\n");
            sb.Append("WHERE \n");
            sb.Append("  TransferId = @TransferId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}