﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Curings : BusinessBindingListBase<Curings, Curing>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static Curings GetCurings(CuringSearchCriteria criteria)
        {
            return DataPortal.Fetch<Curings>(criteria);
        }

        public static Curings GetNewCurings()
        {
            return DataPortal.Create<Curings>();
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(CuringSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand())) {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        TotalRowCount = 0;
                        while (dr.Read()) {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Curing.GetCuring(dr));
                        }
                    }
                }
            }
        }

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Update()
        {
            foreach (var curing in this) {
                var lbl = curing.Save();
            }
        }

        #endregion Data Functions

        public class CuringSearchCriteria
        {
            public int SiteId { get; set; }
            public int PageNumber { get; set; } = 1;
            public int PageSize { get; set; } = 100;

            public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("SELECT T.*,T2.MaterialId,T2.MaterialCode \n");
                sb.Append("FROM   Curing T \n");
                sb.Append("       INNER JOIN Item T1 ON T.ItemId = T1.ItemId \n");
                sb.Append("       INNER JOIN Material T2 ON T1.MaterialId = T2.MaterialId \n");
                sb.Append("WHERE  T.SiteId = @SiteId");

                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
                return cmd;
            }
        }

        public class CuringSearchByBundlesCriteria : CuringSearchCriteria
        {
            public List<long> ItemIds { get; set; }

            public override SqlCommand GetSqlCommand(SqlCommand cmd)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT T.*,T2.MaterialId,T2.MaterialCode \n");
                sb.Append("FROM   Curing T \n");
                sb.Append("       INNER JOIN Item T1 ON T.ItemId = T1.ItemId \n");
                sb.Append("       INNER JOIN Material T2 ON T1.MaterialId = T2.MaterialId \n");
                sb.AppendFormat("WHERE  ( @SiteId = 0  OR T.SiteId = @SiteId ) AND ( T.ItemId IN ( {0}) )", string.Join(",", ItemIds));
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@SiteId", SiteId);
                cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
                return cmd;
            }
        }
    }
}
