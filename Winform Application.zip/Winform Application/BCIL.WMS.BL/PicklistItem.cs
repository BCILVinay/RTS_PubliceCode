﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class PicklistItem : MyBusinessBase<PicklistItem>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> PickListLineIdProperty = RegisterProperty<Int64>(c => c.PickListLineId);

        public Int64 PickListLineId
        {
            get { return GetProperty(PickListLineIdProperty); }
            set { SetProperty(PickListLineIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> PickListIdProperty = RegisterProperty<Int64>(c => c.PickListId);

        public Int64 PickListId
        {
            get { return GetProperty(PickListIdProperty); }
            set { SetProperty(PickListIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<decimal> LengthProperty = RegisterProperty<decimal>(c => c.Length);

        public decimal Length
        {
            get { return GetProperty(LengthProperty); }
            set { SetProperty(LengthProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<int> BundelQtyProperty = RegisterProperty<int>(c => c.BundelQty);

        public int BundelQty
        {
            get { return GetProperty(BundelQtyProperty); }
            set { SetProperty(BundelQtyProperty, value); }
        }

        public static readonly PropertyInfo<PickListItemStatus> ItemStatusProperty = RegisterProperty<PickListItemStatus>(c => c.ItemStatus);

        public PickListItemStatus ItemStatus
        {
            get { return GetProperty(ItemStatusProperty); }
            set { SetProperty(ItemStatusProperty, value); }
        }

        public static readonly PropertyInfo<string> STONoProperty = RegisterProperty<string>(c => c.STONo);
        public string STONo
        {
            get { return GetProperty(STONoProperty); }
            set { SetProperty(STONoProperty, value); }
        }

        public static readonly PropertyInfo<string> STOLineNoProperty = RegisterProperty<string>(c => c.STOLineNo);
        public string STOLineNo
        {
            get { return GetProperty(STOLineNoProperty); }
            set { SetProperty(STOLineNoProperty, value); }
        }

        public static readonly PropertyInfo<string> DLineItemNoProperty = RegisterProperty<string>(c => c.DLineItemNo);
        public string DLineItemNo
        {
            get { return GetProperty(DLineItemNoProperty); }
            set { SetProperty(DLineItemNoProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
        }

        #endregion Custom Validations

        #region Factory Methods

        private PicklistItem()
        {
        }

        public static PicklistItem NewPicklistItem()
        {
            return DataPortal.CreateChild<PicklistItem>();
        }

        public static PicklistItem GetPicklistItem(Int64 id)
        {
            return DataPortal.FetchChild<PicklistItem>(id);
        }

        public static void DeletePicklistItem(Int64 id)
        {
            DataPortal.Delete<PicklistItem>(id);
        }

        public static PicklistItem GetPicklistItem(SafeDataReader dr)
        {
            return DataPortal.FetchChild<PicklistItem>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void Child_Fetch(SafeDataReader dr)
        {
            PickListLineId = dr.GetInt64("PickListLineId");
            PickListId = dr.GetInt64("PickListId");
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            Length = dr.GetDecimal("Length");
            Location = new KeyValue<Int64, string>(dr.GetInt64("LocationId"), dr.GetString("LocationCode"));
            BundelQty = dr.GetInt32("BundelQty");
            ItemStatus = (PickListItemStatus)dr.GetInt32("ItemStatus");
            STONo = dr.GetString("STONo");
            STOLineNo = dr.GetString("STOLineNo");
            DLineItemNo = dr.GetString("DLineItemNo");
        }

        private void Child_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@PickListLineId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            Child_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T2.MaterialCode,T3.LocationCode \n");
            sb.Append("FROM   PickListLineItem T \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Location T3 ON T3.LocationId = T.LocationId ");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected void Child_Insert(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@PickListId", PickListId);
                cmd.Parameters.AddWithValue("@STONo", STONo);
                cmd.Parameters.AddWithValue("@STOLineNo", STOLineNo);
                cmd.Parameters.AddWithValue("@DLineItemNo", DLineItemNo);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@Length", Length);
                cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                cmd.Parameters.AddWithValue("@BundelQty", BundelQty);
                cmd.Parameters.AddWithValue("@ItemStatus", ItemStatus);
                cmd.CommandText = InsertSQL();
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                PickListLineId = Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [PickListLineItem] \n");
            sb.Append("            ([PickListId],[STONo],[STOLineNo],[DLineItemNo],[MaterialId],[Length],[LocationId],[BundelQty],[ItemStatus]) \n");
            sb.Append("VALUES      (@PickListId,@STONo,@STOLineNo,@DLineItemNo,@MaterialId,@Length,@LocationId,@BundelQty,@ItemStatus )");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected void Child_Update(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = UpdateSQL();
                cmd.Parameters.AddWithValue("@PickListLineId", PickListLineId);
                cmd.Parameters.AddWithValue("@PickListId", PickListId);
                cmd.Parameters.AddWithValue("@STONo", STONo);
                cmd.Parameters.AddWithValue("@STOLineNo", STOLineNo);
                cmd.Parameters.AddWithValue("@DLineItemNo", DLineItemNo);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@Length", Length);
                cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                cmd.Parameters.AddWithValue("@BundelQty", BundelQty);
                cmd.Parameters.AddWithValue("@ItemStatus", ItemStatus);
                cmd.ExecuteNonQuery();
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [PickListLineItem] \n");
            sb.Append("   SET [PickListId] = @PickListId \n");
            sb.Append("      ,[STONo] = @STONo \n");
            sb.Append("      ,[STOLineNo] = @STOLineNo \n");
            sb.Append("      ,[DLineItemNo] = @DLineItemNo \n");
            sb.Append("      ,[MaterialId] = @MaterialId \n");
            sb.Append("      ,[Length] = @Length \n");
            sb.Append("      ,[LocationId] = @LocationId \n");
            sb.Append("      ,[BundelQty] = @BundelQty \n");
            sb.Append("      ,[ItemStatus] = @ItemStatus \n");
            sb.Append(" WHERE PickListLineId = @PickListLineId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void Child_Delete(Int64 Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@PickListLineId", Id);
                    cmd.CommandText = "DELETE FROM [PickListLineItem] WHERE  PickListLineId = @PickListLineId";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        #endregion Delete

        #endregion Data Functions
    }
}