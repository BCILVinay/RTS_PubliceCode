﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    //[Serializable]
    //public class Delivery : MyBusinessBase<Delivery>
    //{
    //    #region Properties

    //    public static readonly PropertyInfo<Int64> DeliveryIdProperty = RegisterProperty<Int64>(c => c.DeliveryId);

    //    public Int64 DeliveryId
    //    {
    //        get { return GetProperty(DeliveryIdProperty); }
    //        set { SetProperty(DeliveryIdProperty, value); }
    //    }

    //    public static readonly PropertyInfo<string> STONoProperty = RegisterProperty<string>(c => c.STONo);

    //    public string STONo
    //    {
    //        get { return GetProperty(STONoProperty); }
    //        set { SetProperty(STONoProperty, value); }
    //    }

    //    public static readonly PropertyInfo<string> DeliveryNoProperty = RegisterProperty<string>(c => c.DeliveryNo);

    //    public string DeliveryNo
    //    {
    //        get { return GetProperty(DeliveryNoProperty); }
    //        set { SetProperty(DeliveryNoProperty, value); }
    //    }

    //    public static readonly PropertyInfo<DateTime> DeliveryDateProperty = RegisterProperty<DateTime>(c => c.DeliveryDate);

    //    public DateTime DeliveryDate
    //    {
    //        get { return GetProperty(DeliveryDateProperty); }
    //        set { SetProperty(DeliveryDateProperty, value); }
    //    }

    //    public static readonly PropertyInfo<Int64> MaterialIdProperty = RegisterProperty<Int64>(c => c.MaterialId);

    //    public Int64 MaterialId
    //    {
    //        get { return GetProperty(MaterialIdProperty); }
    //        set { SetProperty(MaterialIdProperty, value); }
    //    }

    //    public static readonly PropertyInfo<int> QuantityProperty = RegisterProperty<int>(c => c.Quantity);

    //    public int Quantity
    //    {
    //        get { return GetProperty(QuantityProperty); }
    //        set { SetProperty(QuantityProperty, value); }
    //    }

    //    public static readonly PropertyInfo<int> SiteFromProperty = RegisterProperty<int>(c => c.SiteFrom);

    //    public int SiteFrom
    //    {
    //        get { return GetProperty(SiteFromProperty); }
    //        set { SetProperty(SiteFromProperty, value); }
    //    }

    //    public static readonly PropertyInfo<int> SiteToProperty = RegisterProperty<int>(c => c.SiteTo);

    //    public int SiteTo
    //    {
    //        get { return GetProperty(SiteToProperty); }
    //        set { SetProperty(SiteToProperty, value); }
    //    }

    //    public static readonly PropertyInfo<string> TruckNoProperty = RegisterProperty<string>(c => c.TruckNo);

    //    public string TruckNo
    //    {
    //        get { return GetProperty(TruckNoProperty); }
    //        set { SetProperty(TruckNoProperty, value); }
    //    }

    //    public static readonly PropertyInfo<string> TransporterProperty = RegisterProperty<string>(c => c.Transporter);

    //    public string Transporter
    //    {
    //        get { return GetProperty(TransporterProperty); }
    //        set { SetProperty(TransporterProperty, value); }
    //    }

    //    public static readonly PropertyInfo<string> LRNoProperty = RegisterProperty<string>(c => c.LRNo);

    //    public string LRNo
    //    {
    //        get { return GetProperty(LRNoProperty); }
    //        set { SetProperty(LRNoProperty, value); }
    //    }

    //    public static readonly PropertyInfo<DeliveryStatus> StatusProperty = RegisterProperty<DeliveryStatus>(c => c.Status);

    //    public DeliveryStatus Status
    //    {
    //        get { return GetProperty(StatusProperty); }
    //        set { SetProperty(StatusProperty, value); }
    //    }

    //    public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

    //    public DateTime CreatedOn
    //    {
    //        get { return GetProperty(CreatedOnProperty); }
    //        set { SetProperty(CreatedOnProperty, value); }
    //    }

    //    public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

    //    public int CreatedBy
    //    {
    //        get { return GetProperty(CreatedByProperty); }
    //        set { SetProperty(CreatedByProperty, value); }
    //    }

    //    public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

    //    public DateTime UpdatedOn
    //    {
    //        get { return GetProperty(UpdatedOnProperty); }
    //        set { SetProperty(UpdatedOnProperty, value); }
    //    }

    //    public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

    //    public int UpdatedBy
    //    {
    //        get { return GetProperty(UpdatedByProperty); }
    //        set { SetProperty(UpdatedByProperty, value); }
    //    }

    //    #endregion Properties

    //    #region Custom Validations

    //    protected override void AddBusinessRules()
    //    {
    //        base.AddBusinessRules();
    //        //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
    //    }

    //    #endregion Custom Validations

    //    #region Factory Methods

    //    private Delivery()
    //    {
    //    }

    //    public static Delivery NewDelivery()
    //    {
    //        return DataPortal.Create<Delivery>();
    //    }

    //    public static Delivery GetDelivery(Int64 id)
    //    {
    //        return DataPortal.Fetch<Delivery>(id);
    //    }

    //    public static Delivery GetDelivery(string deliveryNo)
    //    {
    //        return DataPortal.Fetch<Delivery>(deliveryNo);
    //    }

    //    public static Delivery GetDelivery(SafeDataReader dr)
    //    {
    //        return DataPortal.Fetch<Delivery>(dr);
    //    }

    //    public static void DeleteDelivery(Int64 id)
    //    {
    //        DataPortal.Delete<Delivery>(id);
    //    }

    //    #endregion Factory Methods

    //    #region Data Functions

    //    #region Fetch

    //    private void DataPortalFetch(SafeDataReader dr)
    //    {
    //        DeliveryId = dr.GetInt64("DeliveryId");
    //        STONo = dr.GetString("STONo");
    //        DeliveryNo = dr.GetString("DeliveryNo");
    //        DeliveryDate = dr.GetDateTime("DeliveryDate");
    //        MaterialId = dr.GetInt64("MaterialId");
    //        Quantity = dr.GetInt32("Quantity");
    //        SiteFrom = dr.GetInt32("SiteFrom");
    //        SiteTo = dr.GetInt32("SiteTo");
    //        TruckNo = dr.GetString("TruckNo");
    //        Transporter = dr.GetString("Transporter");
    //        LRNo = dr.GetString("LRNo");
    //        Status = (DeliveryStatus)dr.GetInt32("Status");
    //        CreatedOn = dr.GetDateTime("CreatedOn");
    //        CreatedBy = dr.GetInt32("CreatedBy");
    //        UpdatedOn = dr.GetDateTime("UpdatedOn");
    //        UpdatedBy = dr.GetInt32("UpdatedBy");
    //    }

    //    private void DataPortal_Fetch(int Id)
    //    {
    //        CodeContract.Required<ArgumentException>(Id > 0, "Delivery Id is required for fetch.");
    //        using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
    //        {
    //            con.Open();
    //            using (var cmd = con.CreateCommand())
    //            {
    //                cmd.CommandType = System.Data.CommandType.Text;
    //                cmd.Parameters.AddWithValue("@DeliveryId", Id);
    //                cmd.CommandText = FetchSQL();
    //                using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
    //                {
    //                    if (dr.Read())
    //                    {
    //                        DataPortalFetch(dr);
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    private string FetchSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("SELECT * \n");
    //        sb.Append("FROM   Delivery \n");
    //        sb.Append("WHERE  DeliveryId = @DeliveryId");
    //        return sb.ToString();
    //    }

    //    private void DataPortal_Fetch(string deliveryNo)
    //    {
    //        CodeContract.Required<ArgumentException>(deliveryNo.IsNotNullOrWhiteSpace(), "Delivery number is required");
    //        using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
    //        {
    //            con.Open();
    //            using (var cmd = con.CreateCommand())
    //            {
    //                cmd.CommandType = System.Data.CommandType.Text;
    //                cmd.Parameters.AddWithValue("@DeliveryNo", deliveryNo);
    //                cmd.CommandText = FetchByCodeSQL();
    //                using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
    //                {
    //                    if (dr.Read())
    //                    {
    //                        DataPortalFetch(dr);
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    private string FetchByCodeSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("SELECT * \n");
    //        sb.Append("FROM   Delivery \n");
    //        sb.Append("WHERE  DeliveryNo = @DeliveryNo");
    //        return sb.ToString();
    //    }

    //    #endregion Fetch

    //    #region Insert

    //    private bool IsExists(SqlConnection con)
    //    {
    //        using (SqlCommand cmd = con.CreateCommand())
    //        {
    //            cmd.CommandType = System.Data.CommandType.Text;
    //            cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
    //            cmd.Parameters.AddWithValue("@DeliveryId", DeliveryId);
    //            cmd.CommandText = ExistSQL();
    //            return (int)cmd.ExecuteScalar() > 0;
    //        }
    //    }

    //    private string ExistSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("SELECT Count(1) \n");
    //        sb.Append("FROM   Delivery \n");
    //        sb.Append("WHERE  DeliveryNo = @DeliveryNo \n");
    //        sb.Append("       AND ( @DeliveryId = 0 OR DeliveryId <> @DeliveryId )");
    //        return sb.ToString();
    //    }

    //    protected override void DataPortal_Insert()
    //    {
    //        using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
    //        {
    //            con.Open();

    //            if (IsExists(con)) throw new Exception("Delivery No already exists.");

    //            using (var cmd = con.CreateCommand())
    //            {
    //                cmd.CommandType = System.Data.CommandType.Text;
    //                cmd.Parameters.AddWithValue("@STONo", STONo);
    //                cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
    //                cmd.Parameters.AddWithValue("@DeliveryDate", DeliveryDate);
    //                cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
    //                cmd.Parameters.AddWithValue("@Quantity", Quantity);
    //                cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom);
    //                cmd.Parameters.AddWithValue("@SiteTo", SiteTo);
    //                cmd.Parameters.AddWithValue("@TruckNo", TruckNo);
    //                cmd.Parameters.AddWithValue("@Transporter", Transporter);
    //                cmd.Parameters.AddWithValue("@LRNo", LRNo);
    //                cmd.Parameters.AddWithValue("@Status", Status);
    //                cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
    //                cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
    //                cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
    //                cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
    //                cmd.CommandText = InsertSQL();
    //                cmd.ExecuteNonQuery();
    //                cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
    //                DeliveryId = Convert.ToInt64(cmd.ExecuteScalar());
    //            }
    //        }
    //    }

    //    private string InsertSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("INSERT INTO [dbo].[Delivery] \n");
    //        sb.Append("            ([STONo],[DeliveryNo],[DeliveryDate],[MaterialId],[Quantity],[SiteFrom],[SiteTo],[TruckNo],[Transporter],[LRNo],[Status],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy]) \n");
    //        sb.Append("VALUES      (@STONo,@DeliveryNo,@DeliveryDate,@MaterialId,@Quantity,@SiteFrom,@SiteTo,@TruckNo,@Transporter,@LRNo,@Status,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy)");
    //        return sb.ToString();
    //    }

    //    #endregion Insert

    //    #region Update

    //    protected override void DataPortal_Update()
    //    {
    //        using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
    //        {
    //            con.Open();

    //            if (IsExists(con)) throw new Exception("Delivery No already exists.");

    //            using (var cmd = con.CreateCommand())
    //            {
    //                cmd.CommandType = System.Data.CommandType.Text;
    //                cmd.CommandText = UpdateSQL();
    //                cmd.Parameters.AddWithValue("@DeliveryId", DeliveryId);
    //                cmd.Parameters.AddWithValue("@STONo", STONo);
    //                cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
    //                cmd.Parameters.AddWithValue("@DeliveryDate", DeliveryDate);
    //                cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
    //                cmd.Parameters.AddWithValue("@Quantity", Quantity);
    //                cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom);
    //                cmd.Parameters.AddWithValue("@SiteTo", SiteTo);
    //                cmd.Parameters.AddWithValue("@TruckNo", TruckNo);
    //                cmd.Parameters.AddWithValue("@Transporter", Transporter);
    //                cmd.Parameters.AddWithValue("@LRNo", LRNo);
    //                cmd.Parameters.AddWithValue("@Status", Status);
    //                cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
    //                cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
    //                cmd.ExecuteNonQuery();
    //            }
    //        }
    //    }

    //    private string UpdateSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("UPDATE [dbo].[Delivery] \n");
    //        sb.Append("SET    [STONo] = @STONo,[DeliveryNo] = @DeliveryNo,[DeliveryDate] = @DeliveryDate,[MaterialId] = @MaterialId,[Quantity] = @Quantity,[SiteFrom] = @SiteFrom,[SiteTo] = @SiteTo,[TruckNo] = @TruckNo,[Transporter] = @Transporter,[LRNo] = @LRNo,[Status] = @Status,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy \n");
    //        sb.Append("WHERE \n");
    //        sb.Append("  DeliveryId = @DeliveryId");
    //        return sb.ToString();
    //    }

    //    #endregion Update

    //    #region Delete

    //    private void DataPortal_Delete(int Id)
    //    {
    //        using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
    //        {
    //            con.Open();
    //            using (var cmd = con.CreateCommand())
    //            {
    //                cmd.CommandType = System.Data.CommandType.Text;
    //                cmd.Parameters.AddWithValue("@Id", Id);
    //                cmd.CommandText = DeleteSQL();
    //                cmd.ExecuteNonQuery();
    //            }
    //        }
    //    }

    //    private string DeleteSQL()
    //    {
    //        StringBuilder sb = new StringBuilder();
    //        return sb.ToString();
    //    }

    //    #endregion Delete

    //    #endregion Data Functions
    //}

    public enum DeliveryStatus
    {
        Pending = 0,
        Picked = 1,
        InTransit = 2,
        Delivered = 3,
    }
}