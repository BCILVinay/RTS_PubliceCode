﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class Invoices : ReadOnlyListBase<Invoices, Invoice>
    {
        public long TotalRowCount { get; set; }

        public static Invoices GetInvoices(InvoiceSearchCriteria criteria)
        {
            return DataPortal.Fetch<Invoices>(criteria);
        }

       

        private void DataPortal_Fetch(InvoiceSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Invoice.GetInvoice(Convert.ToInt64(dr["InvoiceId"])));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
    }
}

public class InvoiceSearchCriteria
{
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 100;

    public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("SELECT T.*,T1.STONo \n");
        sb.Append("FROM   Invoice T \n");
        sb.Append("       inner JOIN [Transfer] T1 ON T1.DeliveryNo = T.DeliveryNo \n");
        sb.Append("WHERE  1 = 1 \n");
        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.InvoiceId");
        return cmd;
    }
}

public class InvoiceGenericSearchCriteria : InvoiceSearchCriteria
{
    public DateTime DateFrom { get; set; }
    public DateTime DateTo { get; set; }
    public string InvoiceNo { get; set; } = "";

    public override SqlCommand GetSqlCommand(SqlCommand cmd)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("SELECT T.*,T1.STONo \n");
        sb.Append("FROM   Invoice T \n");
        sb.Append("       inner JOIN [Transfer] T1 ON T1.DeliveryNo = T.DeliveryNo \n");
        sb.Append("WHERE  1 = 1 \n");
        sb.Append(" AND (@InvoiceNo='' or T.InvoiceNo=@InvoiceNo) ");
        sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.InvoiceId");
        cmd.Parameters.AddWithValue("@FromDate", DateFrom);
        cmd.Parameters.AddWithValue("@ToDate", DateTo);
        cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
        return cmd;
    }
}



