﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class POPrintings: ReadOnlyListBase<POPrintings, POPrinting>
    {
        public static POPrintings GetPOPrintings(Int64 poId)
        {
            return DataPortal.Fetch<POPrintings>(poId);
        }

        private void DataPortal_Fetch(Int64 poId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString)) {
                cn.Open();
                using (var cm = cn.CreateCommand()) {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = GetSQL();
                    cm.Parameters.AddWithValue("@POId", poId);

                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader())) {
                        while (dr.Read()) {
                            this.IsReadOnly = false;
                            POPrinting printing = new POPrinting();
                            printing.MaterialId = dr.GetInt64("MaterialId");
                            printing.MaterialCode = dr.GetString("MaterialCode");
                            printing.Items = dr.GetInt32("Items");
                            printing.Bundles = dr.GetInt32("Bundles");
                            printing.PackSize = dr.GetInt32("PackSize");
                            this.Add(printing);
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }

        private string GetSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.MaterialId,T2.MaterialCode,T2.BundleQty PackSize,(SELECT Count(1) \n");
            sb.Append("                                     FROM   Item T11 \n");
            sb.Append("                                     WHERE  T11.MaterialId = T.MaterialId AND T11.POrderId = T.POId AND T11.BundleId =0) AS Items, \n");
            sb.Append("									   (SELECT Count(1) \n");
            sb.Append("									    FROM   Bundle T12 \n");
            sb.Append("                                     WHERE  T12.MaterialId = T.MaterialId AND T12.POrderId = T.POId) AS Bundles \n");
            sb.Append("FROM   ProductionOrderLineItem T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T.POId = T1.POrderId \n");
            sb.Append("       INNER JOIN Material T2 ON T.MaterialId = T2.MaterialId \n");
            sb.Append("WHERE  T.POId = @POId \n");
            sb.Append("GROUP  BY T.MaterialId,T2.MaterialCode,T2.BundleQty,T.POId");
            return sb.ToString();
        }
    }

    [Serializable]
    public class POPrinting
    {
        public Int64 MaterialId { get; set; }
        public string MaterialCode { get; set; }
        public int Items { get; set; }
        public int Bundles { get; set; }
        public int PackSize { get; set; }
    }
}
