﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class CodeByKeyCommand : CommandBase<CodeByKeyCommand>
    {
        private ObjectType _type;
        private long _key;
        private object[] _parameters;

        public CodeByKeyCommand(ObjectType type,long key, params object[] parameters)
        {
            _key = key;
            _type = type;
            _parameters = parameters;
        }

        private string Value { get; set; }

        public static string GetValue(ObjectType type, long key, params object[] parameters)
        {
            CodeByKeyCommand entity = new CodeByKeyCommand(type, key, parameters);
            return DataPortal.Execute(entity).Value;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();

                using (var cmd = GetCommand(con.CreateCommand())) {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            Value = dr.GetString("Value");
                        }
                    }
                }
            }
        }

        private SqlCommand GetCommand(SqlCommand cmd)
        {
            switch (_type) {
                case ObjectType.Location:
                    return GetLocationCommand(cmd);
                default:
                    throw new Exception("Invalid object type");
            }
        }

        private SqlCommand GetLocationCommand(SqlCommand cmd)
        {
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT LocationCode AS Value FROM Location WHERE LocationId = @LocationId";
            cmd.Parameters.AddWithValue("@LocationId", _key);
            return cmd;
        }

        public enum ObjectType
        {
            Location
        }
    }
}
