﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Prn : BusinessBase<Prn>
    {
        #region Properties
        public static readonly PropertyInfo<string> PrnTemplateProperty = RegisterProperty<string>(c => c.PrnTemplate);
        public string PrnTemplate
        {
            get { return GetProperty(PrnTemplateProperty); }
            set { SetProperty(PrnTemplateProperty, value); }
        }

        public static readonly PropertyInfo<PrnType> TypeProperty = RegisterProperty<PrnType>(c => c.Type);
        public PrnType Type
        {
            get { return GetProperty(TypeProperty); }
            set { SetProperty(TypeProperty, value); }
        }
        #endregion

        #region Factory Methods
        public static Prn GetPrn(PrnType prnType)
        {
            return DataPortal.Fetch<Prn>(prnType);
        }
        #endregion

        #region Data Methods
        private void DataPortal_Fetch(PrnType prnType)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = "Select * from prn where PrnType=@PrnType";
                    cm.Parameters.AddWithValue("@PrnType", prnType);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            PrnTemplate = dr.GetString("PrnTemplate");
                            this.Type = (PrnType)dr.GetInt32("PrnType");
                        }
                    }
                }
            }
        }
        #endregion
    }

    [Serializable]
    public enum PrnType
    {
        Location = 0,

        Material = 1,

        Bundle = 2,

        Item = 3,

        Invoice = 4
    }
}
