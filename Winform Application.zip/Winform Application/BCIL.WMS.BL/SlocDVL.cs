﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class MaterialBinDVL : ReadOnlyListBase<MaterialBinDVL, MaterialBin>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static MaterialBinDVL GetMaterialBinDVL(MaterialBinDVLSearchCriteria criteria)
        {
            return DataPortal.Fetch<MaterialBinDVL>(criteria);
        }

        #endregion Factory Method

        #region Data Method

        private void DataPortal_Fetch(MaterialBinDVLSearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = Data.GetPagingSQL(FetchAllSQL(), criteria.PageNumber, criteria.PageSize, "T.MaterialBinCode");
                    cm.Parameters.AddWithValue("@MaterialBinCode", criteria.MaterialBinName ?? "");
                    cm.Parameters.AddWithValue("@LocationCode", criteria.LocationCode ?? "");
                    cm.Parameters.AddWithValue("@MaterialCode", criteria.MaterialCode ?? "");

                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(MaterialBin.GetMaterialBin(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        private string FetchAllSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName ,T3.MaterialCode,T3.MaterialDesc,T4.LocationCode \n");
            sb.Append("FROM   MaterialBin T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("	      INNER JOIN Material T3 ON T.MaterialId = T3.MaterialId \n");
            sb.Append("	      INNER JOIN Location T4 ON T.LocationId = T4.LocationId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @MaterialBinCode = '' OR T.MaterialBinCode = @MaterialBinCode) \n");
            sb.Append("       AND ( @LocationCode = '' OR T4.LocationCode LIKE '%' + @LocationCode + '%' ) \n");
            sb.Append("       AND ( @MaterialCode = '' OR T3.MaterialCode LIKE '%' + @MaterialCode + '%' ) \n");
            return sb.ToString();
        }

        #endregion Data Method
    }

    [Serializable]
    public class MaterialBinDVLSearchCriteria : CriteriaBase<MaterialBinDVLSearchCriteria>
    {
        public string MaterialCode { get; set; }
        public string MaterialBinName { get; set; }
        public string LocationCode { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}