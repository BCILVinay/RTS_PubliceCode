﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class TransferItem : MyBusinessBase<TransferItem>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> TransferItemIdProperty = RegisterProperty<Int64>(c => c.TransferItemId);

        public Int64 TransferItemId
        {
            get { return GetProperty(TransferItemIdProperty); }
            set { SetProperty(TransferItemIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> TransferIdProperty = RegisterProperty<Int64>(c => c.TransferId);

        public Int64 TransferId
        {
            get { return GetProperty(TransferIdProperty); }
            set { SetProperty(TransferIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);
        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }


        public static readonly PropertyInfo<long> BundleIdProperty = RegisterProperty<long>(c => c.BundleId);
        public long BundleId
        {
            get { return GetProperty(BundleIdProperty); }
            set { SetProperty(BundleIdProperty, value); }
        }

        public static readonly PropertyInfo<string> BundleCodeProperty = RegisterProperty<string>(c => c.BundleCode);
        public string BundleCode
        {
            get { return GetProperty(BundleCodeProperty); }
            set { SetProperty(BundleCodeProperty, value); }
        }
            
        public static readonly PropertyInfo<int> QuantityProperty = RegisterProperty<int>(c => c.Quantity);

        public int Quantity
        {
            get { return GetProperty(QuantityProperty); }
            set { SetProperty(QuantityProperty, value); }
        }

        public static readonly PropertyInfo<TransferItemStatus> StatusProperty = RegisterProperty<TransferItemStatus>(c => c.Status);

        public TransferItemStatus Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> RecievedOnProperty = RegisterProperty<DateTime>(c => c.RecievedOn);

        public DateTime RecievedOn
        {
            get { return GetProperty(RecievedOnProperty); }
            set { SetProperty(RecievedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> RecievedByProperty = RegisterProperty<int>(c => c.RecievedBy);

        public int RecievedBy
        {
            get { return GetProperty(RecievedByProperty); }
            set { SetProperty(RecievedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> DispatchedOnProperty = RegisterProperty<DateTime>(c => c.DispatchedOn);

        public DateTime DispatchedOn
        {
            get { return GetProperty(DispatchedOnProperty); }
            set { SetProperty(DispatchedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> DispatchedByProperty = RegisterProperty<int>(c => c.DispatchedBy);

        public int DispatchedBy
        {
            get { return GetProperty(DispatchedByProperty); }
            set { SetProperty(DispatchedByProperty, value); }
        }
        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private TransferItem()
        {
        }

        public static TransferItem NewTransferItem()
        {
            return DataPortal.CreateChild<TransferItem>();
        }

        public static TransferItem GetTransferItem(Int64 id)
        {
            return DataPortal.FetchChild<TransferItem>(id);
        }
        public static TransferItem GetTransferItem(SafeDataReader dr)
        {
            return DataPortal.FetchChild<TransferItem>(dr);
        }
        public static void DeleteTransferItem(Int64 id)
        {
            DataPortal.Delete<TransferItem>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void Child_Fetch(SafeDataReader dr)
        {
            TransferItemId = dr.GetInt64("TransferItemId");
            TransferId = dr.GetInt64("TransferId");
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            Status = (TransferItemStatus)dr.GetInt32("Status");
            RecievedOn = dr.GetDateTime("RecievedOn");
            RecievedBy = dr.GetInt32("RecievedBy");
            DispatchedOn = dr.GetDateTime("DispatchedOn");
            DispatchedBy = dr.GetInt32("DispatchedBy");
            BundleId = dr.GetInt64("BundleId");
            BundleCode = dr.GetString("BundleCode");
        }

        private void Child_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@TransferItemId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            Child_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T2.MaterialCode,T2.MaterialId,T3.BundleCode \n");
            sb.Append("FROM   TransferItem T \n");
            sb.Append("       INNER JOIN Transfer T1 ON T1.TransferId = T.TransferId \n");
            sb.Append("       INNER JOIN Bundle T3 ON T3.BundleId = T.BundleId \n");
            sb.Append("       INNER JOIN Material T2 ON T2.MaterialId = T3.MaterialId \n");
            sb.Append("WHERE  T.TransferItemId = @TransferItemId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected void Child_Insert(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@TransferId", TransferId);
                cmd.Parameters.AddWithValue("@BundleId", BundleId);
               // cmd.Parameters.AddWithValue("@Quantity", Quantity);
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@RecievedBy", RecievedBy);
                cmd.Parameters.AddWithValue("@RecievedOn", RecievedOn);
                cmd.Parameters.AddWithValue("@DispatchedBy", DispatchedBy);
                cmd.Parameters.AddWithValue("@DispatchedOn", DispatchedOn);
                cmd.CommandText = InsertSQL();
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                TransferItemId = Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        private string InsertSQL()
        {
            StringBuilder varname1 = new StringBuilder();
            varname1.Append("INSERT INTO [dbo].[TransferItem] \n");
            varname1.Append("            ([TransferId],[BundleId],[Status],[DispatchedBy],[DispatchedOn],[RecievedOn],[RecievedBy]) \n");
            varname1.Append("VALUES      (@TransferId,@BundleId,@Status,@DispatchedBy,@DispatchedOn,@RecievedOn,@RecievedBy)");

            return varname1.ToString();
        }

        #endregion Insert

        #region Update

        protected  void Child_Update(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = UpdateSQL();
                cmd.Parameters.AddWithValue("@TransferItemId", TransferItemId);
                cmd.Parameters.AddWithValue("@TransferId", TransferId);
                cmd.Parameters.AddWithValue("@BundleId", BundleId);
                //cmd.Parameters.AddWithValue("@Quantity", Quantity);
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@RecievedBy", RecievedBy);
                cmd.Parameters.AddWithValue("@RecievedOn", RecievedOn);
                cmd.ExecuteNonQuery();
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[TransferItem] \n");
            sb.Append("SET    [TransferId] = @TransferId,[BundleId] = @BundleId,[Status] = @Status,[RecievedOn] = @RecievedOn,[RecievedBy] = @RecievedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  TransferItemId = @TransferItemId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}