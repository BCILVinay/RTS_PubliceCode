﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using Csla.Rules;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class MaterialBin : MyBusinessBase<MaterialBin>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> MaterialBinIdProperty = RegisterProperty<Int64>(c => c.MaterialBinId);

        public Int64 MaterialBinId
        {
            get { return GetProperty(MaterialBinIdProperty); }
            set { SetProperty(MaterialBinIdProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialBinCodeProperty = RegisterProperty<string>(c => c.MaterialBinCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "MaterialBin code is mandatory.")]
        [StringLength(50, ErrorMessage = "Material Bin code should not exceed to 50 characters")]
        public string MaterialBinCode
        {
            get { return GetProperty(MaterialBinCodeProperty); }
            set { SetProperty(MaterialBinCodeProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialBinNameProperty = RegisterProperty<string>(c => c.MaterialBinName);

        public string MaterialBinName
        {
            get { return GetProperty(MaterialBinNameProperty); }
            set { SetProperty(MaterialBinNameProperty, value); }
        }

        public static readonly PropertyInfo<string> RackNoProperty = RegisterProperty<string>(c => c.RackNo);

        [RequiredButNotDefault(ErrorMessage = "Rack number is mandatory.")]
        public string RackNo
        {
            get { return GetProperty(RackNoProperty); }
            set { SetProperty(RackNoProperty, value); }
        }

        public static readonly PropertyInfo<string> RowNoProperty = RegisterProperty<string>(c => c.RowNo);

        [RequiredButNotDefault(ErrorMessage = "Row number is mandatory.")]
        public string RowNo
        {
            get { return GetProperty(RowNoProperty); }
            set { SetProperty(RowNoProperty, value); }
        }

        public static readonly PropertyInfo<string> ColumnNoProperty = RegisterProperty<string>(c => c.ColumnNo);

        [RequiredButNotDefault(ErrorMessage = "Column number is mandatory.")]
        public string ColumnNo
        {
            get { return GetProperty(ColumnNoProperty); }
            set { SetProperty(ColumnNoProperty, value); }
        }

        public static readonly PropertyInfo<decimal> HeightProperty = RegisterProperty<decimal>(c => c.Height);

        [RequiredButNotDefault(ErrorMessage = "Height is mandatory.")]
        public decimal Height
        {
            get { return GetProperty(HeightProperty); }
            set { SetProperty(HeightProperty, value); }
        }

        public static readonly PropertyInfo<decimal> WidthProperty = RegisterProperty<decimal>(c => c.Width);

        [RequiredButNotDefault(ErrorMessage = "Width is mandatory.")]
        public decimal Width
        {
            get { return GetProperty(WidthProperty); }
            set { SetProperty(WidthProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<int> CapacityProperty = RegisterProperty<int>(c => c.Capacity);
        public int Capacity
        {
            get { return GetProperty(CapacityProperty); }
            set { SetProperty(CapacityProperty, value); }
        }
            
        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsImportedProperty = RegisterProperty<bool>(c => c.IsImported);

        public bool IsImported
        {
            get { return GetProperty(IsImportedProperty); }
            set { SetProperty(IsImportedProperty, value); }
        }

        public string MaterialDesc { get; set; }
        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            BusinessRules.AddRule<MaterialBin>(CreatedByProperty, (x) => { return x.CreatedBy.Key > 0; }, "Created by is mandatory");
            BusinessRules.AddRule<MaterialBin>(UpdatedByProperty, (x) => { return x.UpdatedBy.Key > 0; }, "Updated by is mandatory");
            BusinessRules.AddRule<MaterialBin>(MaterialProperty, (x) => { return x.Material.Key > 0; }, "Material is mandatory");
            BusinessRules.AddRule<MaterialBin>(LocationProperty, (x) => { return x.Location.Key > 0; }, "Location is mandatory");
        }

        #endregion Custom Validations

        #region Factory Methods

        private MaterialBin()
        {
        }

        public static MaterialBin NewMaterialBin()
        {
            return DataPortal.Create<MaterialBin>();
        }

        public static MaterialBin GetMaterialBin(int id)
        {
            return DataPortal.Fetch<MaterialBin>(id);
        }

        public static MaterialBin ValidateMaterialBin(ValidateMaterialBinCriteria criteria)
        {
            return DataPortal.Fetch<MaterialBin>(criteria);
        }

        public static MaterialBin GetMaterialBin(SafeDataReader dr)
        {
            return DataPortal.Fetch<MaterialBin>(dr);
        }

        public static void DeleteMaterialBin(int id)
        {
            DataPortal.Delete<MaterialBin>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            MaterialBinId = dr.GetInt64("MaterialBinId");
            MaterialBinCode = dr.GetString("MaterialBinCode");
            MaterialBinName = dr.GetString("MaterialBinName");
            RackNo = dr.GetString("RackNo");
            RowNo = dr.GetString("RowNo");
            ColumnNo = dr.GetString("ColumnNo");
            Height = dr.GetDecimal("Height");
            Width = dr.GetDecimal("Width");
            Location = new KeyValue<Int64, string>() { Key = dr.GetInt64("LocationId"), Value = dr.GetString("LocationCode") };
            Material = new KeyValue<Int64, string>() { Key = dr.GetInt64("MaterialId"), Value = dr.GetString("MaterialCode") };
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
            IsActive = dr.GetBoolean("IsActive");
            IsImported = dr.GetBoolean("IsImported");
            Capacity = dr.GetInt32("Capacity");
            MaterialDesc = dr.GetString("MaterialDesc");
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialBinId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName ,T3.MaterialCode,T3.MaterialDesc ,T4.LocationCode \n");
            sb.Append("FROM   MaterialBin T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("	      INNER JOIN Material T3 ON T.MaterialId = T3.MaterialId \n");
            sb.Append("	      INNER JOIN Location T4 ON T.LocationId = T4.LocationId \n");
            sb.Append("WHERE \n");
            sb.Append("  MaterialBinId = @MaterialBinId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(ValidateMaterialBinCriteria criteria)
        {
            CodeContract.Required<ArgumentException>(criteria.IsNotNull(), "Criteria should not be null.");
            CodeContract.Required<ArgumentException>(criteria.MaterialId > 0, "Material is required for fetch.");
            CodeContract.Required<ArgumentException>(criteria.LocationId > 0, "Location is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialId", criteria.MaterialId);
                    cmd.Parameters.AddWithValue("@LocationId", criteria.LocationId);
                    cmd.CommandText = FetchByMaterialIdSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByMaterialIdSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.MaterialCode,T3.MaterialDesc,T4.LocationCode \n");
            sb.Append("FROM   MaterialBin T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Material T3 ON T.MaterialId = T3.MaterialId \n");
            sb.Append("       INNER JOIN Location T4 ON T.LocationId = T4.LocationId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.MaterialId = @MaterialId AND T.LocationId = @LocationId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@MaterialBinCode", MaterialBinCode);
                cmd.Parameters.AddWithValue("@MaterialBinId", MaterialBinId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   MaterialBin \n");
            sb.Append("WHERE  MaterialBinCode = @MaterialBinCode \n");
            sb.Append("       AND ( @MaterialBinId = 0 OR MaterialBinId <> @MaterialBinId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Material Bin is already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialBinCode", MaterialBinCode);
                    cmd.Parameters.AddWithValue("@MaterialBinName", MaterialBinName);
                    cmd.Parameters.AddWithValue("@RackNo", RackNo);
                    cmd.Parameters.AddWithValue("@RowNo", RowNo);
                    cmd.Parameters.AddWithValue("@ColumnNo", ColumnNo);
                    cmd.Parameters.AddWithValue("@Height", Height);
                    cmd.Parameters.AddWithValue("@Width", Width);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@Capacity", Capacity);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    MaterialBinId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[MaterialBin] \n");
            sb.Append("            ([MaterialBinCode],[MaterialBinName],[RackNo],[RowNo],[ColumnNo],[Height],[Width],[MaterialId],[LocationId],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[IsActive],[IsImported],[Capacity]) \n");
            sb.Append("VALUES      (@MaterialBinCode,@MaterialBinName,@RackNo,@RowNo,@ColumnNo,@Height,@Width,@MaterialId,@LocationId,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@IsActive,@IsImported,@Capacity )");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Material Bin already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@MaterialBinId", MaterialBinId);
                    cmd.Parameters.AddWithValue("@MaterialBinCode", MaterialBinCode);
                    cmd.Parameters.AddWithValue("@MaterialBinName", MaterialBinName);
                    cmd.Parameters.AddWithValue("@RackNo", RackNo);
                    cmd.Parameters.AddWithValue("@RowNo", RowNo);
                    cmd.Parameters.AddWithValue("@ColumnNo", ColumnNo);
                    cmd.Parameters.AddWithValue("@Height", Height);
                    cmd.Parameters.AddWithValue("@Width", Width);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@Capacity", Capacity);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[MaterialBin] \n");
            sb.Append("SET    [MaterialBinCode] = @MaterialBinCode,[MaterialBinName] = @MaterialBinName,[RackNo] = @RackNo,[RowNo] = @RowNo,[ColumnNo] = @ColumnNo,[Height] = @Height,[Width] = @Width,[MaterialId] = @MaterialId,LocationId = @LocationId,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[IsActive] = @IsActive,[IsImported] = @IsImported ,[Capacity] = @Capacity \n");
            sb.Append("WHERE \n");
            sb.Append("  MaterialBinId = @MaterialBinId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialBinId", Id);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsActive", false);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[MaterialBin] \n");
            sb.Append("SET    [IsActive] = @IsActive,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  MaterialBinId = @MaterialBinId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }

    [Serializable]
    public class ValidateMaterialBinCriteria
    {
        public Int64 MaterialId { get; set; }
        public Int64 LocationId { get; set; }
    }
}