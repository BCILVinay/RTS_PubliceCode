﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class LocationBundle : MyBusinessBase<LocationBundle>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> LocationIdProperty = RegisterProperty<Int64>(c => c.LocationId);

        public Int64 LocationId
        {
            get { return GetProperty(LocationIdProperty); }
            set { SetProperty(LocationIdProperty, value); }
        }

        public static readonly PropertyInfo<string> LocationNameProperty = RegisterProperty<string>(c => c.LocationCode);

        public string LocationCode
        {
            get { return GetProperty(LocationNameProperty); }
            set { SetProperty(LocationNameProperty, value); }
        }

        public static readonly PropertyInfo<Int64> MaterialIdProperty = RegisterProperty<Int64>(c => c.MaterialId);

        public Int64 MaterialId
        {
            get { return GetProperty(MaterialIdProperty); }
            set { SetProperty(MaterialIdProperty, value); }
        }
         
        public static readonly PropertyInfo<string> MaterialCodeProperty = RegisterProperty<string>(c => c.MaterialCode);
        public string MaterialCode
        {
            get { return GetProperty(MaterialCodeProperty); }
            set { SetProperty(MaterialCodeProperty, value); }
        }

        public static readonly PropertyInfo<int> BundleQtyProperty = RegisterProperty<int>(c => c.BundleQty);

        public int BundleQty
        {
            get { return GetProperty(BundleQtyProperty); }
            set { SetProperty(BundleQtyProperty, value); }
        }

        public string MaterialDesc { get; set; }

        #endregion Properties

        #region Factory Methods

        public static LocationBundle NewLocationBundle()
        {
            return DataPortal.Create<LocationBundle>();
        }

        public static LocationBundle GetLocationBundle(Int64 id)
        {
            return DataPortal.Fetch<LocationBundle>(id);
        }

        public static LocationBundle GetLocationBundle(SafeDataReader dr)
        {
            return DataPortal.Fetch<LocationBundle>(dr);
        }

        public static void DeleteLocationBundle(Int64 id)
        {
            DataPortal.Delete<LocationBundle>(id);
        }

        #endregion Factory Methods

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            LocationId = dr.GetInt64("LocationId");
            LocationCode = dr.GetString("LocationCode");
            MaterialId = dr.GetInt64("MaterialId");
            BundleQty = dr.GetInt32("BundleQty");
            MaterialCode = dr.GetString("MaterialCode");
            MaterialDesc = dr.GetString("MaterialDesc");
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@BundleId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T3.ToolingCode,T4.MaterialBinCode,T5.LocationCode,T2.MaterialDesc \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN MaterialBin T4 ON T4.MaterialBinId = T.MaterialBinId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  T.BundleId = @BundleId and T.IsDeleted=0");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string code)
        {
            CodeContract.Required<ArgumentException>(code.IsNotNullOrWhiteSpace(), "Bundle Code is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@BundleCode", code);
                    cmd.CommandText = FetchSQLByCode();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQLByCode()
        {
            StringBuilder sb = new StringBuilder();
          
            return sb.ToString();
        }

        #endregion Fetch
    }
}