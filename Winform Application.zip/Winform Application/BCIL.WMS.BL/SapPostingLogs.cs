﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class SapPostingLogs : BusinessBindingListBase<SapPostingLogs, SapPostingLog>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static SapPostingLogs GetSapPostingLogs(SapPostingLogCriteria criteria)
        {
            return DataPortal.Fetch<SapPostingLogs>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(SapPostingLogCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0)
                            {
                                TotalRowCount = dr.GetInt64("TotalRows");
                            }
                            Add(SapPostingLog.GetSapPostingLog(dr));
                        }
                    }
                }
            }
        }

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Update()
        {
        }

        #endregion Data Functions

        public class SapPostingLogCriteria
        {
            public int PageNumber { get; set; } = 1;
            public int PageSize { get; set; } = 100;
            public int SiteId { get; set; }

            public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT T.*,T1.SiteCode,T2.Name,T3.NAME AS UpdatedByName \n");
                sb.Append("FROM   [PostingLog] T \n");
                sb.Append("       INNER JOIN [Site] T1 ON T.SiteId = T1.SiteId \n");
                sb.Append("       INNER JOIN Employee T2 ON T.CreatedBy = T2.EmployeeId \n");
                sb.Append("       left outer JOIN Employee T3 ON T.UpdatedBy = T3.EmployeeId \n");
                sb.Append("WHERE  T.SiteId=@SideId AND T.LogId = @LogId");
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.Logid");
                cmd.Parameters.AddWithValue("@SiteId", SiteId);
                return cmd;
            }
        }

        public class SapPostingLogCriteria1 : SapPostingLogCriteria
        {
            public DateTime FromDate { get; set; }
            public DateTime ToDate { get; set; }
            public int Process { get; set; }
            public int Status { get; set; }
            public int HandledManually { get; set; }

            public override SqlCommand GetSqlCommand(SqlCommand cmd)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT T.*,T1.SiteCode,T2.NAME,T3.NAME AS UpdatedByName \n");
                sb.Append("FROM   [PostingLog] T \n");
                sb.Append("       INNER JOIN [Site] T1 ON T.SiteId = T1.SiteId \n");
                sb.Append("       INNER JOIN Employee T2 ON T.CreatedBy = T2.EmployeeId \n");
                sb.Append("       left outer JOIN Employee T3 ON T.UpdatedBy = T3.EmployeeId \n");
                sb.Append("       WHERE  1 = 1 AND ( @SiteId = 0 OR T.SiteId = @SiteId ) \n");
                sb.Append("       AND (@HandledManually=-1 OR T.HandledManually=@HandledManually) \n");
                sb.Append("       AND (@Status=-1 OR T.IsSuccess=@Status) \n");
                sb.Append("       AND (@Process=-1 or Process=@Process) AND ( Cast(CONVERT(VARCHAR, T.CreatedOn, 112) AS DATETIME) ) BETWEEN @FromDate AND @ToDate");
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.Logid");
                cmd.Parameters.AddWithValue("@Process", Process);
                cmd.Parameters.AddWithValue("@FromDate", FromDate);
                cmd.Parameters.AddWithValue("@ToDate", ToDate);
                cmd.Parameters.AddWithValue("@HandledManually", HandledManually);
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@SiteId", SiteId);
                return cmd;
            }
        }
    }
}