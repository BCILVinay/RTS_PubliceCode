﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class MaterialStocks : ReadOnlyListBase<MaterialStocks, MaterialStock>
    {
        #region Properties

        public long TotalRowCount { get; set; }

        #endregion Properties

        #region Factory Method

        public static MaterialStocks GetMaterialStocks(MaterialStockSearchCriteria criteria)
        {
            return DataPortal.Fetch<MaterialStocks>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(MaterialStockSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            this.IsReadOnly = false;
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(MaterialStock.GetMaterialStock(dr));
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }

        #endregion Data Functions
    }

    public class MaterialStockSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;
        public int SiteId { get; set; }
        public string LocationCode { get; set; }
        public string MaterialCode { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.LocationId,T1.LocationCode,T1.LocationType,T.MaterialId,T2.MaterialCode,T2.MaterialDesc,Count(T.BundleId) AS BundleQty \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN Location T1 ON T1.LocationId = T.LocationId \n");
            sb.Append("       INNER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR  T1.SiteId = @SiteId)  \n");
            sb.Append("       AND (@MaterialCode = '' OR T2.MaterialCode LIKE '%' + @MaterialCode + '%') \n");
            sb.Append("       AND (@LocationCode = '' OR T1.LocationCode = @LocationCode ) \n");
            sb.Append("       AND T.BundleStatus NOT IN (2) \n");
            sb.Append("       AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate \n");
            sb.Append(" GROUP  BY \n");
            sb.Append("  T.LocationId,T1.LocationCode,T1.LocationType,T.MaterialId,T2.MaterialCode,T2.MaterialDesc \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode ?? "");
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode ?? "");
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            return cmd;
        }
    }

    public class MaterialStock : ReadOnlyBase<MaterialStock>
    {
        #region Properties

        public KeyValue<Int64, string> Material { get; set; }
        public KeyValue<Int64, string> Location { get; set; }
        public LocationType LocationType { get; set; }
        public string MaterialDesc { get; set; }
        public int BundleQty { get; set; }

        #endregion Properties

        #region Factory Methods

        public static MaterialStock GetMaterialStock(SafeDataReader dr)
        {
            return DataPortal.Fetch<MaterialStock>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            Location = new KeyValue<long, string>(dr.GetInt64("LocationId"), dr.GetString("LocationCode"));
            LocationType = (LocationType)dr.GetInt32("LocationType");
            MaterialDesc = dr.GetString("MaterialDesc");
            BundleQty = dr.GetInt32("BundleQty");
        }

        #endregion Fetch

        #endregion Data Functions
    }
}