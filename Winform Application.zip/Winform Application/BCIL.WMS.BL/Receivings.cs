﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Receivings : BusinessBindingListBase<Receivings, Receiving>
    {
        public long TotalRowCount { get; set; }

        #region Properties

        public bool IsLabelPrinted { get; set; }

        #endregion Properties

        #region Factory Method

        public static Receivings GetReceivings(ReceivingGenericSearchCriteria criteria)
        {
            return DataPortal.Fetch<Receivings>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(ReceivingSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Receiving.GetReceiving(dr));
                        }
                    }
                }
            }
        }

        #endregion Data Functions
    }

    public class ReceivingSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.* \n");
            sb.Append("FROM   Receiving T \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ReceivingId");
            return cmd;
        }
    }

    public class ReceivingGenericSearchCriteria : ReceivingSearchCriteria
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public string DeliveryNo { get; set; } = "";

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.* \n");
            sb.Append("FROM   Receiving T \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append(" AND (@DeliveryNo='' or T.DeliveryNo=@DeliveryNo) ");
            sb.Append(" AND (cast(convert(varchar, T.ReceivedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ReceivingId");
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
            return cmd;
        }
    }
}