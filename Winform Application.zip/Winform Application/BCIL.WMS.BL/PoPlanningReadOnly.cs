﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class PoPlanningReadOnlyList : ReadOnlyListBase<PoPlanningReadOnlyList, PoPlanningReadOnly>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static PoPlanningReadOnlyList GetPoPlanningReadOnlyList(PoPlanningReadOnlySearchCriteria criteria)
        {
            return DataPortal.Fetch<PoPlanningReadOnlyList>(criteria);
        }

        #endregion Factory Method

        #region Data Method

        private void DataPortal_Fetch(PoPlanningReadOnlySearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = Data.GetPagingSQL(FetchAllByCriteriaSQL(), criteria.PageNumber, criteria.PageSize, "T.ProductionPlanningId");
                    cm.Parameters.AddWithValue("@PlanningNo", criteria.PlanningNo);
                    cm.Parameters.AddWithValue("@FromDate", criteria.PlannedFrom);
                    cm.Parameters.AddWithValue("@ToDate", criteria.PlannedTo);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(PoPlanningReadOnly.GetPoPlanningReadOnly(dr));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchAllByCriteriaSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,T2.NAME \n");
            sb.Append("FROM   ProductionPlanning T \n");
            sb.Append("       INNER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       INNER JOIN Employee T2 ON T2.EmployeeId = T.PlannedBy \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @PlanningNo = '' OR T.PlanningNo LIKE '%' + @PlanningNo + '%' ) \n");
            sb.Append(" AND (cast(convert(varchar, T.PlannedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");
            return sb.ToString();
        }

        #endregion Data Method
    }

    [Serializable]
    public class PoPlanningReadOnlySearchCriteria : CriteriaBase<PoPlanningReadOnlySearchCriteria>
    {
        public string PlanningNo { get; set; }
        public DateTime PlannedFrom { get; set; }
        public DateTime PlannedTo { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }

    [Serializable]
    public class PoPlanningReadOnly : MyBusinessBase<PoPlanningReadOnly>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ProductionPlanningIdProperty = RegisterProperty<Int64>(c => c.ProductionPlanningId);

        public Int64 ProductionPlanningId
        {
            get { return GetProperty(ProductionPlanningIdProperty); }
            set { SetProperty(ProductionPlanningIdProperty, value); }
        }

        public static readonly PropertyInfo<string> PlanningNoProperty = RegisterProperty<string>(c => c.PlanningNo);

        public string PlanningNo
        {
            get { return GetProperty(PlanningNoProperty); }
            set { SetProperty(PlanningNoProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> SiteProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.Site);

        public KeyValue<Int32, string> Site
        {
            get { return GetProperty(SiteProperty); }
            set { SetProperty(SiteProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> PlannedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.PlannedBy);

        public KeyValue<Int32, string> PlannedBy
        {
            get { return GetProperty(PlannedByProperty); }
            set { SetProperty(PlannedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> PlannedOnProperty = RegisterProperty<DateTime>(c => c.PlannedOn);

        public DateTime PlannedOn
        {
            get { return GetProperty(PlannedOnProperty); }
            set { SetProperty(PlannedOnProperty, value); }
        }

        #endregion Properties

        #region Factory Methods

        public static PoPlanningReadOnly NewPoPlanningReadOnly()
        {
            return DataPortal.Create<PoPlanningReadOnly>();
        }

        public static PoPlanningReadOnly GetPoPlanningReadOnly(Int64 id)
        {
            return DataPortal.Fetch<PoPlanningReadOnly>(id);
        }

        public static PoPlanningReadOnly GetPoPlanningReadOnly(SafeDataReader dr)
        {
            return DataPortal.Fetch<PoPlanningReadOnly>(dr);
        }

        public static void DeletePoPlanningReadOnly(Int64 id)
        {
            DataPortal.Delete<PoPlanningReadOnly>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ProductionPlanningId = dr.GetInt64("ProductionPlanningId");
            PlannedOn = dr.GetDateTime("PlannedOn");
            Site = new KeyValue<int, string>(dr.GetInt32("SiteId"), dr.GetString("SiteCode"));
            PlannedBy = new KeyValue<int, string>(dr.GetInt32("PlannedBy"), dr.GetString("Name"));
            PlanningNo = dr.GetString("PlanningNo");
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ProductionPlanningId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,T2.NAME \n");
            sb.Append("FROM   ProductionPlanning T \n");
            sb.Append("       INNER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       INNER JOIN Employee T2 ON T2.EmployeeId = T.PlannedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  1 = 1 AND T.ProductionPlanningId = @ProductionPlanningId");
            return sb.ToString();
        }

        #endregion Fetch

        #endregion Data Functions
    }
}