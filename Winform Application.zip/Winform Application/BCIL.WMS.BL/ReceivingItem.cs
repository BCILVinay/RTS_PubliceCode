﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ReceivingItem : MyBusinessBase<ReceivingItem>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ReceivingItemIdProperty = RegisterProperty<Int64>(c => c.ReceivingItemId);

        public Int64 ReceivingItemId
        {
            get { return GetProperty(ReceivingItemIdProperty); }
            set { SetProperty(ReceivingItemIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> ReceivingIdProperty = RegisterProperty<Int64>(c => c.ReceivingId);

        public Int64 ReceivingId
        {
            get { return GetProperty(ReceivingIdProperty); }
            set { SetProperty(ReceivingIdProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<string> STONoProperty = RegisterProperty<string>(c => c.STONo);

        public string STONo
        {
            get { return GetProperty(STONoProperty); }
            set { SetProperty(STONoProperty, value); }
        }

        public static readonly PropertyInfo<string> STOLineNoProperty = RegisterProperty<string>(c => c.STOLineNo);

        public string STOLineNo
        {
            get { return GetProperty(STOLineNoProperty); }
            set { SetProperty(STOLineNoProperty, value); }
        }

        public static readonly PropertyInfo<string> DeliveryItemsProperty = RegisterProperty<string>(c => c.DeliveryItems);

        public string DeliveryItems
        {
            get { return GetProperty(DeliveryItemsProperty); }
            set { SetProperty(DeliveryItemsProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialCodeProperty = RegisterProperty<string>(c => c.MaterialCode);

        public string MaterialCode
        {
            get { return GetProperty(MaterialCodeProperty); }
            set { SetProperty(MaterialCodeProperty, value); }
        }

        public static readonly PropertyInfo<int> QuantityProperty = RegisterProperty<int>(c => c.Quantity);

        public int Quantity
        {
            get { return GetProperty(QuantityProperty); }
            set { SetProperty(QuantityProperty, value); }
        }

        public static readonly PropertyInfo<int> NoOfBundalProperty = RegisterProperty<int>(c => c.NoOfBundal);

        public int NoOfBundal
        {
            get { return GetProperty(NoOfBundalProperty); }
            set { SetProperty(NoOfBundalProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private ReceivingItem()
        {
        }

        public static ReceivingItem NewReceivingItem()
        {
            return DataPortal.CreateChild<ReceivingItem>();
        }

        public static ReceivingItem GetReceivingItem(Int64 id)
        {
            return DataPortal.FetchChild<ReceivingItem>(id);
        }

        public static ReceivingItem GetReceivingItem(SafeDataReader dr)
        {
            return DataPortal.FetchChild<ReceivingItem>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void Child_Fetch(SafeDataReader dr)
        {
            ReceivingItemId = dr.GetInt64("ReceivingItemId");
            ReceivingId = dr.GetInt64("ReceivingId");
            SiteId = dr.GetInt32("SiteId");
            STONo = dr.GetString("STONo");
            STOLineNo = dr.GetString("STOLineNo");
            DeliveryItems = dr.GetString("DeliveryItems");
            MaterialCode = dr.GetString("MaterialCode");
            Quantity = dr.GetInt32("Quantity");
            NoOfBundal = dr.GetInt32("NoOfBundal");
        }

        private void Child_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ReceivingItemId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            Child_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.* \n");
            sb.Append("FROM   ReceivingItem T \n");
            sb.Append("       INNER JOIN Receiving T1 ON T1.ReceivingId = T.ReceivingId \n");
            sb.Append("       INNER JOIN Site T2 ON T2.SiteId = T.SiteId \n");
            sb.Append("WHERE  T.ReceivingItemId = @ReceivingItemId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected void Child_Insert(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@ReceivingId", ReceivingId);

                cmd.CommandText = InsertSQL();
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                ReceivingItemId = Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        private string InsertSQL()
        {
            StringBuilder varname1 = new StringBuilder();
            varname1.Append("INSERT INTO [dbo].[TransferItem] \n");
            varname1.Append("            ([TransferId],[BundleId],[Status],[DispatchedBy],[DispatchedOn],[RecievedOn],[RecievedBy]) \n");
            varname1.Append("VALUES      (@TransferId,@BundleId,@Status,@DispatchedBy,@DispatchedOn,@RecievedOn,@RecievedBy)");

            return varname1.ToString();
        }

        #endregion Insert

        #region Update

        protected void Child_Update(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = UpdateSQL();
                cmd.Parameters.AddWithValue("@ReceivingItemId", ReceivingItemId);
                cmd.Parameters.AddWithValue("@ReceivingId", ReceivingId);

                cmd.ExecuteNonQuery();
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[TransferItem] \n");
            sb.Append("SET    [TransferId] = @TransferId,[BundleId] = @BundleId,[Status] = @Status,[RecievedOn] = @RecievedOn,[RecievedBy] = @RecievedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  TransferItemId = @TransferItemId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}