﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class LocationBundles : BusinessBindingListBase<LocationBundles, LocationBundle>
    {
        #region Factory Method

        public static LocationBundles GetLocationBundles(LocationBundleCriteria criteria)
        {
            return DataPortal.Fetch<LocationBundles>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(LocationBundleCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(LocationBundle.GetLocationBundle(dr));
                        }
                    }
                }
            }
        }

        #endregion Data Functions
    }

    public class LocationBundleCriteria
    {
        public Int64 MaterialId { get; set; }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T1.LocationId,T1.LocationCode,COUNT(T.BundleId) AS BundleQty,T.MaterialId,T2.MaterialCode,T2.MaterialDesc \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN Location T1 ON T.LocationId = T1.LocationId \n");
            sb.Append("       INNER JOIN Material T2 ON T.MaterialId = T2.MaterialId \n");
            sb.Append("WHERE T.MaterialId = @MaterialId \n");
            sb.Append("GROUP BY  T1.LocationId,T1.LocationCode,T.MaterialId,T2.MaterialCode,T2.MaterialDesc ");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
            return cmd;
        }
    }
}