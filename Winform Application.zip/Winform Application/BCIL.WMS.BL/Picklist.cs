﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Picklist : MyBusinessBase<Picklist>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> PickListIdProperty = RegisterProperty<Int64>(c => c.PickListId);

        public Int64 PickListId
        {
            get { return GetProperty(PickListIdProperty); }
            set { SetProperty(PickListIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> SiteProperty = RegisterProperty<KeyValue<int, string>>(c => c.Site);

        public KeyValue<int, string> Site
        {
            get { return GetProperty(SiteProperty); }
            set { SetProperty(SiteProperty, value); }
        }

        public static readonly PropertyInfo<string> TruckNoProperty = RegisterProperty<string>(c => c.TruckNo);

        public string TruckNo
        {
            get { return GetProperty(TruckNoProperty); }
            set { SetProperty(TruckNoProperty, value); }
        }

        public static readonly PropertyInfo<string> TransporterProperty = RegisterProperty<string>(c => c.Transporter);

        public string Transporter
        {
            get { return GetProperty(TransporterProperty); }
            set { SetProperty(TransporterProperty, value); }
        }

        public static readonly PropertyInfo<string> LRNoProperty = RegisterProperty<string>(c => c.LRNo);
        public string LRNo
        {
            get { return GetProperty(LRNoProperty); }
            set { SetProperty(LRNoProperty, value); }
        }

        public static readonly PropertyInfo<string> DeliveryNoProperty = RegisterProperty<string>(c => c.DeliveryNo);

        public string DeliveryNo
        {
            get { return GetProperty(DeliveryNoProperty); }
            set { SetProperty(DeliveryNoProperty, value); }
        }

        public static readonly PropertyInfo<PickListStatus> StatusProperty = RegisterProperty<PickListStatus>(c => c.Status);

        public PickListStatus Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);


        public static readonly PropertyInfo<KeyValue<int, string>> ToSiteProperty = RegisterProperty<KeyValue<int, string>>(c => c.ToSite);
        public KeyValue<int, string> ToSite
        {
            get { return GetProperty(ToSiteProperty); }
            set { SetProperty(ToSiteProperty, value); }
        }

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<PicklistItems> ItemsProperty = RegisterProperty<PicklistItems>(c => c.Items);

        public PicklistItems Items
        {
            get { return GetProperty(ItemsProperty); }
            set { SetProperty(ItemsProperty, value); }
        }

        #endregion Properties

        #region Factory Methods
        private Picklist() {  }
        public static Picklist NewPicklist()
        {
            return DataPortal.Create<Picklist>();
        }

        public static Picklist GetPicklist(Int64 id)
        {
            return DataPortal.Fetch<Picklist>(id);
        }

        public static Picklist GetPicklist(SafeDataReader dr)
        {
            return DataPortal.Fetch<Picklist>(dr);
        }

        public static Picklist GetPicklist(string deliveryNo)
        {
            return DataPortal.Fetch<Picklist>(deliveryNo);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            PickListId = dr.GetInt64("PickListId");
            Site = new KeyValue<int, string>(dr.GetInt32("SiteId"), dr.GetString("SiteCode"));
            TruckNo = dr.GetString("TruckNo");
            Transporter = dr.GetString("Transporter");
            LRNo = dr.GetString("LRNo");
            DeliveryNo = dr.GetString("DeliveryNo");
            Status = (PickListStatus)dr.GetInt32("Status");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            ToSite = new KeyValue<int, string> ( dr.GetInt32("ToSiteId"), dr.GetString("ToSiteCode"));
            Items = PicklistItems.GetPicklistItems(dr.GetInt64("PickListId"));
        }

        private void DataPortal_Fetch(string deliveryNo)
        {
            CodeContract.Required<ArgumentException>(deliveryNo.IsNotNullOrWhiteSpace(), "Delivery no is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@DeliveryNo", deliveryNo);
                    cmd.CommandText = FetchByDeliveryNoSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByDeliveryNoSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,ISNULL(T2.SiteCode,'') as ToSiteCode  \n");
            sb.Append("FROM   PickList T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       LEFT OUTER JOIN Site T2 ON T2.SiteId = T.ToSiteId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.DeliveryNo = @DeliveryNo");
            return sb.ToString();
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@PickListId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }



        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,ISNULL(T2.SiteCode,'') as ToSiteCode  \n");
            sb.Append("FROM   PickList T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       LEFT OUTER JOIN Site T2 ON T2.SiteId = T.ToSiteId \n");
            sb.Append("WHERE  T.PickListId = @PickListId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                        cmd.Parameters.AddWithValue("@STONo", TruckNo);
                        cmd.Parameters.AddWithValue("@TruckNo", TruckNo);
                        cmd.Parameters.AddWithValue("@Transporter", Transporter);
                        cmd.Parameters.AddWithValue("@LRNo", LRNo);
                        cmd.Parameters.AddWithValue("@STOLineItems", Transporter);
                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@ToSiteId", ToSite.Key);
                        cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
                        cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                        cmd.CommandText = InsertSQL();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                        PickListId = Convert.ToInt64(cmd.ExecuteScalar());
                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.PickListId = PickListId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [PickList] \n");
            sb.Append("            ([SiteId],[TruckNo],[Transporter],[LRNo],[DeliveryNo],[Status],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[ToSiteId]) \n");
            sb.Append("VALUES      (@SiteId,@TruckNo,@Transporter,@LRNo,@DeliveryNo,@Status,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@ToSiteId)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = UpdateSQL();
                        cmd.Parameters.AddWithValue("@PickListId", PickListId);
                        cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                        cmd.Parameters.AddWithValue("@STONo", TruckNo);
                        cmd.Parameters.AddWithValue("@TruckNo", TruckNo);
                        cmd.Parameters.AddWithValue("@Transporter", Transporter);
                        cmd.Parameters.AddWithValue("@LRNo", LRNo);
                        cmd.Parameters.AddWithValue("@STOLineItems", Transporter);
                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@ToSiteId", ToSite.Key);
                        cmd.Parameters.AddWithValue("@UpdatedOn", UpdatedOn);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.ExecuteNonQuery();
                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.PickListId = PickListId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [PickList] \n");
            sb.Append("   SET [SiteId] = @SiteId \n");
            sb.Append("      ,[TruckNo] = @TruckNo \n");
            sb.Append("      ,[Transporter] = @Transporter \n");
            sb.Append("      ,[LRNo] = @LRNo \n");
            sb.Append("      ,[DeliveryNo] = @DeliveryNo \n");
            sb.Append("      ,[Status] = @Status \n");
            sb.Append("      ,[ToSiteId] = @ToSiteId \n");
            sb.Append("      ,[UpdatedOn] = @UpdatedOn \n");
            sb.Append("      ,[UpdatedBy] = @UpdatedBy \n");
            sb.Append(" WHERE PickListId =@PickListId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}