﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    public class Pickings : BusinessBindingListBase<Pickings, Picking>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static Pickings GetPickings(PickingSearchCriteria criteria)
        {
            return DataPortal.Fetch<Pickings>(criteria);
        }
        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(PickingSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand())) {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        TotalRowCount = 0;
                        while (dr.Read()) {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Picking.GetPicking(dr));
                        }
                    }
                }
            }
        }
        #endregion Data Functions


        #region Criteria
        public class PickingSearchCriteria
        {
            public int PageNumber { get; set; } = 1;
            public int PageSize { get; set; } = 100;
            public Int64 PicklistId { get; set; }

            public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT T.*,T2.MaterialId,T2.MaterialCode,T2.MaterialDesc,T1.BundleCode \n");
                sb.Append("FROM   Picking T \n");
                sb.Append("       INNER JOIN Bundle T1 ON T.BundleId = T1.BundleId \n");
                sb.Append("       INNER JOIN Material T2 ON T2.MaterialId = T1.MaterialId  \n");
                sb.Append("       WHERE  T.PicklistId = @PicklistId  \n");
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.PickingId");
                cmd.Parameters.AddWithValue("@PicklistId", PicklistId);
                return cmd;
            }
        }

        #endregion
    }
}
