﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class Transfers : ReadOnlyListBase<Transfers, Transfer>
    {
        public long TotalRowCount { get; set; }

        public static Transfers GetTransfers(TransferSearchCriteria criteria)
        {
            return DataPortal.Fetch<Transfers>(criteria);
        }

        private void DataPortal_Fetch(TransferSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        TotalRowCount = 0;
                        while (dr.Read())
                        {

                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Transfer.GetTransfer(dr));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
    }

    public class TransferSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T1.SiteId = T.SiteTo \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.TransferId");
            return cmd;
        }
    }

    public class TransferGenericSearchCriteria : TransferSearchCriteria
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T2.SiteId = T.SiteTo \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.TransferId");
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            return cmd;
        }
    }

}