﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class LocationDVL : ReadOnlyListBase<LocationDVL, Location>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static LocationDVL GetLocationDVL(LocationsSearchCriteria criteria)
        {
            return DataPortal.Fetch<LocationDVL>(criteria);
        }

        #endregion Factory Method

        #region Data Method
        private void DataPortal_Fetch(LocationsSearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString)) {
                cn.Open();
                using (var cm = criteria.GetSqlCommand(cn.CreateCommand())) {
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader())) {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read()) {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            Add(Location.GetLocation(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }
        #endregion
    }

    [Serializable]
    public class LocationDVLSearchCriteria : LocationsSearchCriteria
    {
        public string LocationCode { get; set; } = "";
        public string Name { get; set; } = "";
        public int Type { get; set; } = -1;
        public int Mode { get; set; } = -1;
        public int State { get; set; } = -1;
        public int SiteId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T1.Name AS CreatedByName, T2.NAME AS UpdatedByName,T3.SiteName \n");
            sb.Append("FROM   Location T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Site T3 ON T.SiteId = T3.SiteId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @locationCode = '' OR T.LocationCode LIKE '%' + @locationCode + '%' ) \n");
            sb.Append("       AND ( @name = '' OR T.LocationName LIKE '%' + @name + '%' ) \n");
            sb.Append("       AND ( @type = -1 OR T.LocationType = @type ) \n");
            sb.Append("       AND ( @mode = -1 OR T.Mode = @mode ) \n");
            sb.Append("       AND ( @state = -1 OR T.IsActive = @state ) \n");
            sb.Append("       AND ( @SiteId = 0 OR T.SiteId = @SiteId ) \n");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.LocationId");
            cmd.Parameters.AddWithValue("@locationCode", LocationCode ?? "");
            cmd.Parameters.AddWithValue("@name", Name ?? "");
            cmd.Parameters.AddWithValue("@type", Type);
            cmd.Parameters.AddWithValue("@mode", Mode);
            cmd.Parameters.AddWithValue("@state", State);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            return cmd;
        }
    }



    [Serializable]
    public class LocationsSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T1.Name AS CreatedByName, T2.NAME AS UpdatedByName,T3.SiteName \n");
            sb.Append("FROM   Location T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Site T3 ON T.SiteId = T3.SiteId \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            return cmd;
        }
    }
}