﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ProductionPlanning : MyBusinessBase<ProductionPlanning>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ProductionPlanningIdProperty = RegisterProperty<Int64>(c => c.ProductionPlanningId);

        public Int64 ProductionPlanningId
        {
            get { return GetProperty(ProductionPlanningIdProperty); }
            set { SetProperty(ProductionPlanningIdProperty, value); }
        }

        public static readonly PropertyInfo<string> PlanningNoProperty = RegisterProperty<string>(c => c.PlanningNo);

        public string PlanningNo
        {
            get { return GetProperty(PlanningNoProperty); }
            set { SetProperty(PlanningNoProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<int> StatusProperty = RegisterProperty<int>(c => c.Status);

        public int Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> PlannedOnProperty = RegisterProperty<DateTime>(c => c.PlannedOn);

        public DateTime PlannedOn
        {
            get { return GetProperty(PlannedOnProperty); }
            set { SetProperty(PlannedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> PlannedByProperty = RegisterProperty<int>(c => c.PlannedBy);

        public int PlannedBy
        {
            get { return GetProperty(PlannedByProperty); }
            set { SetProperty(PlannedByProperty, value); }
        }

        public static readonly PropertyInfo<ProductionPlanningItems> LineItemsProperty = RegisterProperty<ProductionPlanningItems>(c => c.LineItems);

        public ProductionPlanningItems LineItems
        {
            get { return GetProperty(LineItemsProperty); }
            set { SetProperty(LineItemsProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private ProductionPlanning()
        {
        }

        public static ProductionPlanning NewProductionPlanning()
        {
            return DataPortal.Create<ProductionPlanning>();
        }

        public static ProductionPlanning GetProductionPlanning(Int64 id)
        {
            return DataPortal.Fetch<ProductionPlanning>(id);
        }

        public static ProductionPlanning GetProductionPlanning(SafeDataReader dr)
        {
            return DataPortal.Fetch<ProductionPlanning>(dr);
        }

        public static void DeleteProductionPlanning(Int64 id)
        {
            DataPortal.Delete<ProductionPlanning>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ProductionPlanningId = dr.GetInt64("ProductionPlanningId");
            PlanningNo = dr.GetString("PlanningNo");
            SiteId = dr.GetInt32("SiteId");
            Status = dr.GetInt32("Status");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            PlannedOn = dr.GetDateTime("PlannedOn");
            PlannedBy = dr.GetInt32("PlannedBy");
            LineItems = ProductionPlanningItems.GetProductionPlanningItems(dr.GetInt64("ProductionPlanningId"));
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ProductionPlanningId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode,T2.Name,T.PlannedOn,PlanningNo,ProductionPlanningId \n");
            sb.Append("FROM   ProductionPlanning T \n");
            sb.Append("       INNER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       INNER JOIN Employee T2  ON T2.EmployeeId = T.PlannedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  1 = 1 AND T.ProductionPlanningId = @ProductionPlanningId;");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.Parameters.AddWithValue("@PlanningNo", PlanningNo);
                        cmd.Parameters.AddWithValue("@SiteId", SiteId);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                        cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.Parameters.AddWithValue("@PlannedOn", PlannedOn);
                        cmd.Parameters.AddWithValue("@PlannedBy", PlannedBy);

                        cmd.CommandText = InsertSQL();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                        ProductionPlanningId = Convert.ToInt64(cmd.ExecuteScalar());
                        if (LineItems.HaveItems())
                        {
                            foreach (var item in LineItems)
                            {
                                item.ProductionPlanningId = ProductionPlanningId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[ProductionPlanning] \n");
            sb.Append("            ([PlanningNo],[SiteId],[Status],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[PlannedOn],[PlannedBy]) \n");
            sb.Append("VALUES      (@PlanningNo,@SiteId,@Status,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@PlannedOn,@PlannedBy)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = UpdateSQL();
                        cmd.Parameters.AddWithValue("@PlanningNo", PlanningNo);
                        cmd.Parameters.AddWithValue("@SiteId", SiteId);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                        cmd.Parameters.AddWithValue("@PlannedOn", PlannedOn);
                        cmd.Parameters.AddWithValue("@PlannedBy", PlannedBy);
                        cmd.Parameters.AddWithValue("@ProductionPlanningId", ProductionPlanningId);

                        cmd.ExecuteNonQuery();
                        if (LineItems.HaveItems())
                        {
                            foreach (var item in LineItems)
                            {
                                item.ProductionPlanningId = ProductionPlanningId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[ProductionPlanning] \n");
            sb.Append("SET    [PlanningNo]=@PlanningNo,[SiteId] = @SiteId,[Status] = @Status,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[PlannedOn] = @PlannedOn,[PlannedBy] = @PlannedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  ProductionPlanningId = @ProductionPlanningId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}