﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ProductionPlanningItem : MyBusinessBase<ProductionPlanningItem>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ProductionPlanningItemIdProperty = RegisterProperty<Int64>(c => c.ProductionPlanningItemId);

        public Int64 ProductionPlanningItemId
        {
            get { return GetProperty(ProductionPlanningItemIdProperty); }
            set { SetProperty(ProductionPlanningItemIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public static readonly PropertyInfo<Int64> ProductionPlanningIdProperty = RegisterProperty<Int64>(c => c.ProductionPlanningId);

        [Browsable(false)]
        public Int64 ProductionPlanningId
        {
            get { return GetProperty(ProductionPlanningIdProperty); }
            set { SetProperty(ProductionPlanningIdProperty, value); }
        }

        [DisplayName("Material")]
        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<Int64> ToolingProperty = RegisterProperty<Int64>(c => c.Tooling);

        [DisplayName("Tooling")]
        public Int64 Tooling
        {
            get { return GetProperty(ToolingProperty); }
            set { SetProperty(ToolingProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> PoProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Po);

        [DisplayName("PO No")]
        public KeyValue<Int64, string> Po
        {
            get { return GetProperty(PoProperty); }
            set { SetProperty(PoProperty, value); }
        }

        public static readonly PropertyInfo<int> QuantityProperty = RegisterProperty<int>(c => c.Quantity);

        public int Quantity
        {
            get { return GetProperty(QuantityProperty); }
            set { SetProperty(QuantityProperty, value); }
        }

        public static readonly PropertyInfo<int> LinePrefenceProperty = RegisterProperty<int>(c => c.LinePrefence);

        [DisplayName("Line Prefences")]
        public int LinePrefence
        {
            get { return GetProperty(LinePrefenceProperty); }
            set { SetProperty(LinePrefenceProperty, value); }
        }

        public static readonly PropertyInfo<decimal> AvailableHoursProperty = RegisterProperty<decimal>(c => c.AvailableHours);

        [DisplayName("Available Hours")]
        public decimal AvailableHours
        {
            get { return GetProperty(AvailableHoursProperty); }
            set { SetProperty(AvailableHoursProperty, value); }
        }

        public static readonly PropertyInfo<decimal> OutputProperty = RegisterProperty<decimal>(c => c.Output);

        public decimal Output
        {
            get { return GetProperty(OutputProperty); }
            set { SetProperty(OutputProperty, value); }
        }

        public static readonly PropertyInfo<decimal> ReqShiftHoursProperty = RegisterProperty<decimal>(c => c.ReqShiftHours);

        [DisplayName("Req Shift Hours")]
        public decimal ReqShiftHours
        {
            get { return GetProperty(ReqShiftHoursProperty); }
            set { SetProperty(ReqShiftHoursProperty, value); }
        }

        public static readonly PropertyInfo<int> PacksNoProperty = RegisterProperty<int>(c => c.PacksNo);

        [DisplayName("No of Packs")]
        public int PacksNo
        {
            get { return GetProperty(PacksNoProperty); }
            set { SetProperty(PacksNoProperty, value); }
        }

        public static readonly PropertyInfo<Int64> MaterialBinIdProperty = RegisterProperty<Int64>(c => c.MaterialBinId);

        [DisplayName("MaterialBin")]
        public Int64 MaterialBinId
        {
            get { return GetProperty(MaterialBinIdProperty); }
            set { SetProperty(MaterialBinIdProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> ProductionStartOnProperty = RegisterProperty<DateTime>(c => c.ProductionStartOn);

        [DisplayName("PO Start On")]
        public DateTime ProductionStartOn
        {
            get { return GetProperty(ProductionStartOnProperty); }
            set { SetProperty(ProductionStartOnProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private ProductionPlanningItem()
        {
        }

        public static ProductionPlanningItem NewChildProductionPlanningItem()
        {
            return DataPortal.CreateChild<ProductionPlanningItem>();
        }

        public static ProductionPlanningItem GetProductionPlanningItem(Int64 id)
        {
            return DataPortal.FetchChild<ProductionPlanningItem>(id);
        }

        public static void DeleteProductionPlanningItem(Int64 id)
        {
            DataPortal.Delete<ProductionPlanningItem>(id);
        }

        public static ProductionPlanningItem GetProductionPlanningItem(SafeDataReader dr)
        {
            return DataPortal.FetchChild<ProductionPlanningItem>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void Child_Fetch(SafeDataReader dr)
        {
            ProductionPlanningItemId = dr.GetInt64("ProductionPlanningItemId");
            ProductionPlanningId = dr.GetInt64("ProductionPlanningId");
            Material = new KeyValue<long, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            Tooling = dr.GetInt64("ToolingId");
            Po = new KeyValue<long, string>(dr.GetInt64("PoId"), dr.GetString("POrderNo"));
            LinePrefence = dr.GetInt32("LinePrefenceId");
            AvailableHours = dr.GetDecimal("AvailableHours");
            Output = dr.GetDecimal("Output");
            ReqShiftHours = dr.GetDecimal("ReqShiftHours");
            PacksNo = dr.GetInt32("PacksNo");
            MaterialBinId = dr.GetInt64("MaterialBinId");
            ProductionStartOn = dr.GetDateTime("ProductionStartOn");
            Quantity = dr.GetInt32("Quantity");
        }

        private void Child_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ProductionPlanningItemId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            Child_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T.ProductionPlanningId,T2.MaterialCode,T3.ToolingCode,T4.POrderNo \n");
            sb.Append("FROM   ProductionPlanningItem T \n");
            sb.Append("       INNER JOIN ProductionPlanning T1 ON T1.ProductionPlanningId = T.ProductionPlanningId \n");
            sb.Append("	   LEFT OUTER JOIN Material T2 ON T2.MaterialId =T.MaterialId \n");
            sb.Append("	   LEFT OUTER JOIN Tooling T3 ON T3.ToolingId =T.ToolingId \n");
            sb.Append("	   LEFT OUTER JOIN ProductionOrder T4 ON T4.POrderId =T.PoId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.ProductionPlanningItemId = @ProductionPlanningItemId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected void Child_Insert(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;

                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@ProductionPlanningId", ProductionPlanningId);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@ToolingId", Tooling);
                cmd.Parameters.AddWithValue("@PoId", Po.Key);
                cmd.Parameters.AddWithValue("@LinePrefenceId", LinePrefence);
                cmd.Parameters.AddWithValue("@AvailableHours", AvailableHours);
                cmd.Parameters.AddWithValue("@Output", Output);
                cmd.Parameters.AddWithValue("@ReqShiftHours", ReqShiftHours);
                cmd.Parameters.AddWithValue("@PacksNo", PacksNo);
                cmd.Parameters.AddWithValue("@MaterialBinId", MaterialBinId);
                cmd.Parameters.AddWithValue("@ProductionStartOn", ProductionStartOn);
                cmd.Parameters.AddWithValue("@Quantity", Quantity);
                cmd.CommandText = InsertSQL();
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                ProductionPlanningItemId = Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[ProductionPlanningItem] \n");
            sb.Append("            ([ProductionPlanningId],[MaterialId],[ToolingId],[PoId],[LinePrefenceId],[AvailableHours],[Output],[ReqShiftHours],[PacksNo],[MaterialBinId],[ProductionStartOn],[Quantity]) \n");
            sb.Append("VALUES      (@ProductionPlanningId,@MaterialId,@ToolingId,@PoId,@LinePrefenceId,@AvailableHours,@Output,@ReqShiftHours,@PacksNo,@MaterialBinId,@ProductionStartOn,@Quantity)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected void Child_Update(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = UpdateSQL();
                cmd.Parameters.AddWithValue("@ProductionPlanningItemId", ProductionPlanningItemId);
                cmd.Parameters.AddWithValue("@ProductionPlanningId", ProductionPlanningId);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@ToolingId", Tooling);
                cmd.Parameters.AddWithValue("@PoId", Po.Key);
                cmd.Parameters.AddWithValue("@LinePrefenceId", LinePrefence);
                cmd.Parameters.AddWithValue("@AvailableHours", AvailableHours);
                cmd.Parameters.AddWithValue("@Output", Output);
                cmd.Parameters.AddWithValue("@ReqShiftHours", ReqShiftHours);
                cmd.Parameters.AddWithValue("@PacksNo", PacksNo);
                cmd.Parameters.AddWithValue("@MaterialBinId", MaterialBinId);
                cmd.Parameters.AddWithValue("@ProductionStartOn", ProductionStartOn);
                cmd.Parameters.AddWithValue("@Quantity", Quantity);
                cmd.ExecuteNonQuery();
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[ProductionPlanningItem] \n");
            sb.Append("SET    [ProductionPlanningId] = @ProductionPlanningId,[MaterialId] = @MaterialId,[ToolingId] = @ToolingId,[PoId] = @PoId,[LinePrefenceId] = @LinePrefenceId,[AvailableHours] = @AvailableHours,[Output] = @Output,[ReqShiftHours] = @ReqShiftHours,[PacksNo] = @PacksNo,[MaterialBinId] = @MaterialBinId,[ProductionStartOn] = @ProductionStartOn,[Quantity] = @Quantity \n");
            sb.Append("WHERE \n");
            sb.Append("  ProductionPlanningItemId = @ProductionPlanningItemId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();

            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}