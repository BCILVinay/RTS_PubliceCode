﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ItemViewData : ReadOnlyBase<ItemViewData>
    {
        public long ItemId { get; set; }
        public string ItemCode { get; set; }
        public long MaterialId { get; set; }
        public string MaterialCode { get; set; }
        public bool IsCured { get; set; }
        public DateTime CuringIn { get; set; }
        public DateTime CuringOut { get; set; }

        #region Factory Methods
        public static ItemViewData GetBundleViewData(string itemCode)
        {
            return DataPortal.Fetch<ItemViewData>(itemCode);
        }
        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(string itemCode)
        {
            CodeContract.Required<ArgumentException>(itemCode.IsNotNullOrWhiteSpace(), "Item code is required.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@itemCode", itemCode);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            ItemId = dr.GetInt64("ItemId");
                            ItemCode = dr.GetString("ItemCode");
                            MaterialId = dr.GetInt64("MaterialId");
                            MaterialCode = dr.GetString("MaterialCode");
                            CuringIn = dr.GetDateTime("CuringIn");
                            CuringOut = dr.GetDateTime("CuringOut");
                            IsCured = dr.GetBoolean("IsCured");
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.MaterialCode,Isnull(T2.IsCured, 0) IsCured,Isnull(T2.CuringIn, Cast('1753-1-1' AS DATETIME)) CuringIn,Isnull(T2.CuringOut, Cast('1753-1-1' AS DATETIME)) CuringOut \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN Material T1 ON T1.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Curing T2 ON T.ItemId = T2.ItemId \n");
            sb.Append("WHERE  T.ItemCode = @itemCode");
            return sb.ToString();
        }

        #endregion Fetch

        #endregion
    }
}
