﻿using BCIL.Utility;
using Csla;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class BundleTransferCommand : CommandBase<BundleTransferCommand>
    {
        #region Properties

        private Int64 _location;
        public Int64 LocationId { get { return _location; } set { value = _location; } }

        private List<Int64> _Bundles;
        public List<Int64> Bundles { get { return _Bundles; } set { value = _Bundles; } }

        private int _UpdatedBy;
        public int UpdatedBy { get { return _UpdatedBy; } set { value = _UpdatedBy; } }

        #endregion Properties

        #region Factory Methods

        public BundleTransferCommand(Int64 locationId, int updatedBy, List<Int64> bundles)
        {
            _location = locationId;
            _Bundles = bundles;
            _UpdatedBy = updatedBy;
        }

        public static void BundleTransfer(Int64 locationId, int updatedBy, List<Int64> bundles)
        {
            BundleTransferCommand entity = new BundleTransferCommand(locationId, updatedBy, bundles);
            DataPortal.Execute(entity);
        }

        #endregion Factory Methods

        #region Data Methods

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL(Bundles);
                    cmd.Parameters.AddWithValue("@LocationId", LocationId);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL(List<long> bundles)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE Bundle \n");
            sb.Append("SET    LocationId = @LocationId,UpdatedBy = @UpdatedBy ,UpdatedOn = @UpdatedOn \n");
            sb.Append("WHERE \n");
            sb.AppendFormat("  BundleId in ({0});", string.Join(",", bundles));
            return sb.ToString();
        }

        #endregion Data Methods
    }
}