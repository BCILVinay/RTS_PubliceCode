﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Bundles : BusinessBindingListBase<Bundles, Bundle>
    {
        public long TotalRowCount { get; set; }

        #region Properties

        public bool IsLabelPrinted { get; set; }

        #endregion Properties

        #region Factory Method

        public static Bundles GetBundles(BundleSearchCriteria criteria)
        {
            return DataPortal.Fetch<Bundles>(criteria);
        }

        public static Bundles GetBundleByCriteria(BundleGenericSearchCriteria criteria)
        {
            return DataPortal.Fetch<Bundles>(criteria);
        }

        public static Bundles GetBundleById(BundleSearchCriteriaByPo criteria)
        {
            return DataPortal.Fetch<Bundles>(criteria);
        }

        public static Bundles GetMaterialBundles(MaterialBundleSearchCriteria criteria)
        {
            return DataPortal.Fetch<Bundles>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(BundleSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Bundle.GetBundle(dr));
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T3.ToolingCode,T4.MaterialBinCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN MaterialBin T4 ON T4.MaterialBinId = T.MaterialBinId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  T.POrderId = @POrderId and (@materialLineId=0 or T.MaterialId=@materialLineId) and T.IsDeleted=0");
            return sb.ToString();
        }

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Update()
        {
            List<Bundle> newBndles = this.Where(x => x.IsNew).ToList();

            foreach (var bundle in this)
            {
                var bndl = bundle.Save();
                bundle.BundleId = bndl.BundleId;
            }

            Labels lables = new Labels();

            if (IsLabelPrinted)
            {
                foreach (var newBundle in newBndles)
                {
                    var label = Label.NewLabel();
                    label.LabelCode = newBundle.BundleCode;
                    label.LabelObjType = Enums.LabelType.Bundle;
                    label.LableObjTypeId = newBundle.BundleId;
                    label.LocationId = newBundle.Location.Key;
                    label.CreatedBy = newBundle.CreatedBy;
                    label.CreatedOn = newBundle.CreatedOn;
                    lables.Add(label);
                }
                lables.Save();
            }
        }

        #endregion Data Functions
    }

    public class BundleSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;
        public int SiteId { get; set; }

        public int LineId { get; set; }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = t.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = t.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = t.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR T5.SiteId = @SiteId ) \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.BundleId");
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            return cmd;
        }
    }

    public class BundleGenericSearchCriteria : BundleSearchCriteria
    {
        public string BundleCode { get; set; }
        public string POCode { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public Int64 MaterialLineId { get; set; }

        public string LocationCode { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       INNER JOIN ProductionOrderLineItem T6 ON T6.POId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = t.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = t.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR  T5.SiteId = @SiteId) \n");
            sb.Append(" AND ( @LineId = 0 OR  T6.PPLine = @LineId) \n");
            sb.Append("AND (@BundleCode = '' OR T.BundleCode LIKE '%' + @BundleCode + '%') AND  (@POCode = '' OR T1.POrderNo LIKE '%' + @POCode + '%') AND  (@LocationCode = '' OR T5.LocationCode LIKE '%' + @LocationCode + '%')  \n");
            sb.Append("AND (@materialLineId=0 or T.MaterialId=@materialLineId) and T.IsDeleted=0 \n");
            sb.Append("AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.BundleId");
            cmd.Parameters.AddWithValue("@MaterialLineId", MaterialLineId);
            cmd.Parameters.AddWithValue("@BundleCode", BundleCode);
            cmd.Parameters.AddWithValue("@POCode", POCode);
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            cmd.Parameters.AddWithValue("@LineId", LineId);


            return cmd;
        }
    }

    public class BundleSearchCriteriaByPo : BundleSearchCriteria
    {
        public Int64 POrderId { get; set; }
        public Int64 MaterialLineId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = t.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = t.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = t.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  1 = 1 AND  ( @SiteId = 0 OR T5.SiteId = @SiteId)  \n");
            sb.Append("AND  T.POrderId = @POrderId and (@materialLineId=0 or T.MaterialId=@materialLineId) and T.IsDeleted=0");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "BundleId");
            cmd.Parameters.AddWithValue("@MaterialLineId", MaterialLineId);
            cmd.Parameters.AddWithValue("@POrderId", POrderId);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            return cmd;
        }
    }


    public class MaterialBundleSearchCriteria : BundleSearchCriteria
    {
        public string MaterialCode { get; set; }
        public string LocationCode { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = t.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = t.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = t.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR  T5.SiteId = @SiteId) AND T.BundleStatus NOT IN (2) \n");
            sb.Append("AND (@MaterialCode = '' OR T2.MaterialCode LIKE '%' + @MaterialCode + '%') AND  (@LocationCode = '' OR T5.LocationCode LIKE '%' + @LocationCode + '%')  \n");
          
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.BundleId");
            cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode);
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);

            return cmd;
        }
    }
}