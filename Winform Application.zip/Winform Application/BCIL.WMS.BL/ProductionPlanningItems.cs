﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ProductionPlanningItems : BusinessListBase<ProductionPlanningItems, ProductionPlanningItem>
    {
        public static ProductionPlanningItems GetProductionPlanningItems(Int64 PlanningId)
        {
            return DataPortal.Fetch<ProductionPlanningItems>(PlanningId);
        }

        private void DataPortal_Fetch(Int64 PlanningId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllItems();
                    cm.Parameters.AddWithValue("@ProductionPlanningId", PlanningId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(ProductionPlanningItem.GetProductionPlanningItem(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllItems()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T.ProductionPlanningId,T2.MaterialCode,T3.ToolingCode,T4.POrderNo \n");
            sb.Append("FROM   ProductionPlanningItem T \n");
            sb.Append("       INNER JOIN ProductionPlanning T1 ON T1.ProductionPlanningId = T.ProductionPlanningId \n");
            sb.Append("	   LEFT OUTER JOIN Material T2 ON T2.MaterialId =T.MaterialId \n");
            sb.Append("	   LEFT OUTER JOIN Tooling T3 ON T3.ToolingId =T.ToolingId \n");
            sb.Append("	   LEFT OUTER JOIN ProductionOrder T4 ON T4.POrderId =T.PoId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.ProductionPlanningId = @ProductionPlanningId;");
            return sb.ToString();
        }
    }
}
