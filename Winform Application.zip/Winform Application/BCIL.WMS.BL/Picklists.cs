﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Picklists : ReadOnlyListBase<Picklists, Picklist>
    {
        public long TotalRowCount { get; set; }

        public static Picklists GetPicklists(PicklistSearchCriteria criteria)
        {
            return DataPortal.Fetch<Picklists>(criteria);
        }

        /// <summary>
        /// This function is used for get all pick list for picking
        /// </summary>
        /// <param name="SiteId"></param>
        /// <returns>List of Pick List</returns>
        public static Picklists GetPicklistsBySite(int SiteId)
        {
            return DataPortal.Fetch<Picklists>(SiteId);
        }

        private void DataPortal_Fetch(PicklistSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Picklist.GetPicklist(dr));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private void DataPortal_Fetch(int plantId)
        {
            CodeContract.Required<ArgumentException>(plantId > 0, "Plant id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteId", plantId);
                    cmd.CommandText = FetchByPlantIdSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            this.Add(Picklist.GetPicklist(dr));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchByPlantIdSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT * \n");
            sb.Append("FROM   PickList \n");
            sb.Append("WHERE  PickListId IN (SELECT T.PickListId \n");
            sb.Append("                      FROM   PickListLineItem T \n");
            sb.Append("                             INNER JOIN PickList T1 ON T.PickListId = T1.PickListId \n");
            sb.Append("                      WHERE  T.ItemStatus IN (0, 1) AND  (@SiteId = 0 OR T1.SiteId = @SiteId) \n");
            sb.Append("                      GROUP  BY T.PickListId)");
            return sb.ToString();
        }
    }
}

[Serializable]
public class PicklistSearchCriteria
{
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 100;

    public int SiteId { get; set; }

    public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("SELECT T.*,T1.SiteCode,ISNULL(T2.SiteCode,'') as ToSiteCode  \n");
        sb.Append("FROM   PickList T \n");
        sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
        sb.Append("       LEFT OUTER JOIN Site T2 ON T2.SiteId = T.ToSiteId \n");
        sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR T.SiteId = @SiteId) \n");
        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.PickListId");
        cmd.Parameters.AddWithValue("@SiteId", SiteId);

        return cmd;
    }
}

[Serializable]
public class PicklistGenericSearchCriteria : PicklistSearchCriteria
{
    public DateTime DateFrom { get; set; }
    public DateTime DateTo { get; set; }
    public string DeliveryNo { get; set; } = "";

    public override SqlCommand GetSqlCommand(SqlCommand cmd)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("SELECT T.*,T1.SiteCode,ISNULL(T2.SiteCode,'') as ToSiteCode  \n");
        sb.Append("FROM   PickList T \n");
        sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
        sb.Append("       LEFT OUTER JOIN Site T2 ON T2.SiteId = T.ToSiteId \n");
        sb.Append("WHERE  1 = 1 AND  (@SiteId = 0 OR T.SiteId = @SiteId )  \n");
        sb.Append(" AND (@DeliveryNo='' or T.DeliveryNo=@DeliveryNo) ");
        sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.PickListId");
        cmd.Parameters.AddWithValue("@FromDate", DateFrom);
        cmd.Parameters.AddWithValue("@ToDate", DateTo);
        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
        cmd.Parameters.AddWithValue("@SiteId", SiteId);

        return cmd;
    }
}

[Serializable]
public class PicklistSearchCriteriaById : PicklistSearchCriteria
{
    public Int64 PicklistId { get; set; }

    public override SqlCommand GetSqlCommand(SqlCommand cmd)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("SELECT T.*,T1.SiteCode,ISNULL(T2.SiteCode,'') as ToSiteCode  \n");
        sb.Append("FROM   PickList T \n");
        sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteId \n");
        sb.Append("       LEFT OUTER JOIN Site T2 ON T2.SiteId = T.ToSiteId \n");
        sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR T.SiteId = @SiteId)  \n");
        sb.Append(" AND @PickListId=0 or T.PickListId=@PickListId");

        cmd.CommandType = System.Data.CommandType.Text;
        cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.PickListId");
        cmd.Parameters.AddWithValue("@PicklistId", PicklistId);
        cmd.Parameters.AddWithValue("@SiteId", SiteId);

        return cmd;
    }
}