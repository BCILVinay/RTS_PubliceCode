﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class ProductionOrderDVL : ReadOnlyListBase<ProductionOrderDVL, ProductionOrder>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static ProductionOrderDVL GetProductionOrderDVL(ProductionOrderSearchCriteria criteria)
        {
            return DataPortal.Fetch<ProductionOrderDVL>(criteria);
        }

        #endregion Factory Method

        #region Data Method

        private void DataPortal_Fetch(ProductionOrderSearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = Data.GetPagingSQL(FetchAllProductionOrderSQL(), criteria.PageNumber, criteria.PageSize, "T.POrderId");
                    cm.Parameters.AddWithValue("@POrderNo", criteria.POrderNo);
                    cm.Parameters.AddWithValue("@FromDate", criteria.CreatedFrom );
                    cm.Parameters.AddWithValue("@ToDate", criteria.CreatedTo);
                    cm.Parameters.AddWithValue("@LineId", criteria.LineId);

                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(ProductionOrder.GetProductionOrder(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        private string FetchAllProductionOrderSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.NAME AS ConfirmedByName \n");
            sb.Append("FROM   ProductionOrder T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       LEFT OUTER JOIN Employee T3 ON T.ConfirmedBy = T3.EmployeeId \n");
            sb.Append("       INNER JOIN ProductionOrderLineItem T4 ON T4.POId = T.POrderId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("      AND T4.PPLine= @LineId AND ( @POrderNo = '' OR T.POrderNo LIKE '%' + @POrderNo + '%' ) \n");
            sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");
            return sb.ToString();
        }

        #endregion Data Method
    }

    [Serializable]
    public class ProductionOrderSearchCriteria : CriteriaBase<ProductionOrderSearchCriteria>
    {
        public int LineId { get; set; }
        public string POrderNo { get; set; }
        public DateTime CreatedFrom { get; set; }
        public DateTime CreatedTo { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}