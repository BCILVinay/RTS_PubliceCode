﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class PicklistItems : BusinessListBase<PicklistItems, PicklistItem>
    {
        public static PicklistItems GetPicklistItems(Int64 PickListId)
        {
            return DataPortal.Fetch<PicklistItems>(PickListId);
        }

        private void DataPortal_Fetch(Int64 PickListId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllPicklistItems();
                    cm.Parameters.AddWithValue("@PickListId", PickListId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(PicklistItem.GetPicklistItem(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllPicklistItems()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT T.*,T2.MaterialCode,T3.LocationCode \n");
            sb.Append(" FROM   PickListLineItem T \n");
            sb.Append("        LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("        LEFT OUTER JOIN Location T3 ON T3.LocationId = T.LocationId \n");
            sb.Append(" WHERE  T.PickListId = @PickListId");
            return sb.ToString();
        }
    }
}
