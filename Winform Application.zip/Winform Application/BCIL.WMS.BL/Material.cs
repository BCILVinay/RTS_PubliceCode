﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using Csla.Rules;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Material : MyBusinessBase<Material>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> MaterialIdProperty = RegisterProperty<Int64>(c => c.MaterialId);

        public Int64 MaterialId
        {
            get { return GetProperty(MaterialIdProperty); }
            set { SetProperty(MaterialIdProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialCodeProperty = RegisterProperty<string>(c => c.MaterialCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Material code is mandatory.")]
        [StringLength(100, ErrorMessage = "Material code should not exceed to 100 characters")]
        public string MaterialCode
        {
            get { return GetProperty(MaterialCodeProperty); }
            set { SetProperty(MaterialCodeProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialDescriptionProperty = RegisterProperty<string>(c => c.MaterialDescription);

        [StringLength(500, ErrorMessage = "Material name should not exceed to 100 characters")]
        public string MaterialDescription
        {
            get { return GetProperty(MaterialDescriptionProperty); }
            set { SetProperty(MaterialDescriptionProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> ToolingProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Tooling);

        public KeyValue<Int64, string> Tooling
        {
            get { return GetProperty(ToolingProperty); }
            set { SetProperty(ToolingProperty, value); }
        }

        public static readonly PropertyInfo<string> UOMProperty = RegisterProperty<string>(c => c.UOM);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Material UOM is mandatory.")]
        public string UOM
        {
            get { return GetProperty(UOMProperty); }
            set { SetProperty(UOMProperty, value); }
        }

        public static readonly PropertyInfo<decimal> SectionalWeightProperty = RegisterProperty<decimal>(c => c.SectionalWeight);

        [RequiredButNotDefault(ErrorMessage = "Sectional weight is mandatory.")]
        public decimal SectionalWeight
        {
            get { return GetProperty(SectionalWeightProperty); }
            set { SetProperty(SectionalWeightProperty, value); }
        }

        public static readonly PropertyInfo<decimal> StdBarLengthProperty = RegisterProperty<decimal>(c => c.StdBarLength);

        [RequiredButNotDefault(ErrorMessage = "Standerd bar length is mandatory.")]
        public decimal StdBarLength
        {
            get { return GetProperty(StdBarLengthProperty); }
            set { SetProperty(StdBarLengthProperty, value); }
        }

        public static readonly PropertyInfo<int> PackSizeProperty = RegisterProperty<int>(c => c.PackSize);

        [RequiredButNotDefault(ErrorMessage = "Pack size is mandatory.")]
        public int PackSize
        {
            get { return GetProperty(PackSizeProperty); }
            set { SetProperty(PackSizeProperty, value); }
        }

        public static readonly PropertyInfo<decimal> BundleBreathProperty = RegisterProperty<decimal>(c => c.BundleBreath);

        [RequiredButNotDefault(ErrorMessage = "Breath is mandatory.")]
        public decimal BundleBreath
        {
            get { return GetProperty(BundleBreathProperty); }
            set { SetProperty(BundleBreathProperty, value); }
        }

        public static readonly PropertyInfo<decimal> BundleHeightProperty = RegisterProperty<decimal>(c => c.BundleHeight);

        [RequiredButNotDefault(ErrorMessage = "Height is mandatory.")]
        public decimal BundleHeight
        {
            get { return GetProperty(BundleHeightProperty); }
            set { SetProperty(BundleHeightProperty, value); }
        }

        public static readonly PropertyInfo<decimal> BundleWeightProperty = RegisterProperty<decimal>(c => c.BundleWeight);

        public decimal BundleWeight
        {
            get { return GetProperty(BundleWeightProperty); }
            set { SetProperty(BundleWeightProperty, value); }
        }

        public static readonly PropertyInfo<string> ImageNameProperty = RegisterProperty<string>(c => c.ImageName);
        public string ImageName
        {
            get { return GetProperty(ImageNameProperty); }
            set { SetProperty(ImageNameProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsImportedProperty = RegisterProperty<bool>(c => c.IsImported);

        public bool IsImported
        {
            get { return GetProperty(IsImportedProperty); }
            set { SetProperty(IsImportedProperty, value); }
        }

        public decimal BundleQtyInMtrs
        {
            get { return Convert.ToDecimal(string.Format("{0:F2}", PackSize * StdBarLength)); }
        }

        public decimal CrossSecArea
        {
            get { return Convert.ToDecimal(string.Format("{0:F2}", BundleHeight * BundleBreath)); }
        }

        public decimal BundleVolume
        {
            get { return Convert.ToDecimal(string.Format("{0:F2}", (StdBarLength / 10) * CrossSecArea)); }
        }

        public decimal BundleTotalLengthInMtrs
        {
            get { return Convert.ToDecimal(string.Format("{0:F2}", StdBarLength * PackSize)); }
        }

        public decimal BundleTotalWeight
        {
            get { return Convert.ToDecimal(string.Format("{0:F2}", BundleTotalLengthInMtrs * SectionalWeight)); }
        }

        public static readonly PropertyInfo<bool> IsBrownProperty = RegisterProperty<bool>(c => c.IsBrown);

        public bool IsBrown
        {
            get { return GetProperty(IsBrownProperty); }
            set { SetProperty(IsBrownProperty, value); }
        }

        public string MaterialImagePrn { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            BusinessRules.AddRule<Material>(ToolingProperty, (x) => { return x.Tooling.Key > 0; }, "Tooling is mandatory");
            BusinessRules.AddRule<Material>(CreatedByProperty, (x) => { return x.CreatedBy.Key > 0; }, "Created by is mandatory");
            BusinessRules.AddRule<Material>(UpdatedByProperty, (x) => { return x.UpdatedBy.Key > 0; }, "Updated by is mandatory");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Material()
        {
        }

        public static Material NewMaterial()
        {
            return DataPortal.Create<Material>();
        }

        public static Material GetMaterial(Int64 id)
        {
            return DataPortal.Fetch<Material>(id);
        }

        public static Material GetMaterial(SafeDataReader dr)
        {
            return DataPortal.Fetch<Material>(dr);
        }

        public static Material GetMaterialByCode(string materialCode)
        {
            return DataPortal.Fetch<Material>(materialCode);
        }

        public static void DeleteMaterial(Int64 id)
        {
            DataPortal.Delete<Material>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch Material

        private void DataPortal_Fetch(string materialCode)
        {
            CodeContract.Required<ArgumentException>(materialCode.IsNotNull(), "Material code is required.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialCode", materialCode);
                    cmd.CommandText = FetchByCodeSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByCodeSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  T.MaterialCode = @MaterialCode");
            return sb.ToString();
        }

        private void DataPortal_Fetch(Int64 materialId)
        {
            CodeContract.Required<ArgumentException>(materialId > 0, "Material id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialId", materialId);
                    cmd.CommandText = FetchByIdSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByIdSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  T.MaterialId = @MaterialId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            MaterialId = dr.GetInt64("MaterialId");
            MaterialCode = dr.GetString("MaterialCode");
            MaterialDescription = dr.GetString("MaterialDesc");
            Tooling = new KeyValue<Int64, string>() { Key = dr.GetInt64("ToolingId"), Value = dr.GetString("ToolingName") };
            BundleBreath = dr.GetDecimal("BundleBreath");
            BundleHeight = dr.GetDecimal("BundleHeight");
            BundleWeight = dr.GetDecimal("BundleWeight");
            PackSize = dr.GetInt32("BundleQty");
            UOM = dr.GetString("UOM");
            SectionalWeight = dr.GetDecimal("SectionalWeight");
            StdBarLength = dr.GetDecimal("StdBarLength");
            ImageName = dr.GetString("ImageName");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
            IsActive = dr.GetBoolean("IsActive");
            IsBrown = dr.GetBoolean("IsBrown");
            MaterialImagePrn = dr.GetString("MaterialImagePrn");
        }

        #endregion Fetch Material

        #region Insert Material

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode);
                cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Material \n");
            sb.Append("WHERE  MaterialCode = @MaterialCode \n");
            sb.Append("       AND ( @MaterialId = 0 OR MaterialId <> @MaterialId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Material code already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode);
                    cmd.Parameters.AddWithValue("@MaterialDesc", MaterialDescription);
                    cmd.Parameters.AddWithValue("@ToolingId", Tooling.Key);
                    cmd.Parameters.AddWithValue("@UOM", UOM);
                    cmd.Parameters.AddWithValue("@SectionalWeight", SectionalWeight);
                    cmd.Parameters.AddWithValue("@StdBarLength", StdBarLength);
                    cmd.Parameters.AddWithValue("@BundleQty", PackSize);
                    cmd.Parameters.AddWithValue("@BundleBreath", BundleBreath);
                    cmd.Parameters.AddWithValue("@BundleHeight", BundleHeight);
                    cmd.Parameters.AddWithValue("@BundleWeight", BundleWeight);
                    cmd.Parameters.AddWithValue("@ImageName", ImageName ?? "");
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@IsBrown", IsBrown);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    MaterialId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [Material] \n");
            sb.Append("            ([MaterialCode],[MaterialDesc],[ToolingId],[UOM],[SectionalWeight],[StdBarLength],[BundleQty],[BundleBreath],[BundleHeight],[BundleWeight],[ImageName],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[IsActive],[IsImported],[IsBrown]) \n");
            sb.Append("VALUES      (@MaterialCode,@MaterialDesc,@ToolingId,@UOM,@SectionalWeight,@StdBarLength,@BundleQty,@BundleBreath,@BundleHeight,@BundleWeight,@ImageName,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@IsActive,@IsImported,@IsBrown)");
            return sb.ToString();
        }

        #endregion Insert Material

        #region Update Material

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Material code already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
                    cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode);
                    cmd.Parameters.AddWithValue("@MaterialDesc", MaterialDescription);
                    cmd.Parameters.AddWithValue("@ToolingId", Tooling.Key);
                    cmd.Parameters.AddWithValue("@UOM", UOM);
                    cmd.Parameters.AddWithValue("@SectionalWeight", SectionalWeight);
                    cmd.Parameters.AddWithValue("@StdBarLength", StdBarLength);
                    cmd.Parameters.AddWithValue("@BundleQty", PackSize);
                    cmd.Parameters.AddWithValue("@BundleBreath", BundleBreath);
                    cmd.Parameters.AddWithValue("@BundleHeight", BundleHeight);
                    cmd.Parameters.AddWithValue("@BundleWeight", BundleWeight);
                    cmd.Parameters.AddWithValue("@ImageName", ImageName ?? "");
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@IsBrown", IsBrown);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Material] \n");
            sb.Append("SET    [MaterialCode] = @MaterialCode,[MaterialDesc] = @MaterialDesc,[ToolingId] = @ToolingId,[UOM] = @UOM,[SectionalWeight] = @SectionalWeight,[StdBarLength] = @StdBarLength,[BundleQty] = @BundleQty,[BundleBreath] = @BundleBreath,[BundleHeight] = @BundleHeight,[BundleWeight] = @BundleWeight,[ImageName] = @ImageName,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,IsActive = @IsActive,IsImported = @IsImported,IsBrown=@IsBrown \n");
            sb.Append("WHERE \n");
            sb.Append("  MaterialId = @MaterialId");
            return sb.ToString();
        }

        #endregion Update Material

        #region Delete Material

        private void DataPortal_Delete(Int64 MaterialId)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@MaterialId", MaterialId);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsActive = 0 \n");
            sb.Append("FROM   Material \n");
            sb.Append("WHERE  [MaterialId] = @MaterialId");
            return sb.ToString();
        }

        #endregion Delete Material

        #endregion Data Functions
    }
}