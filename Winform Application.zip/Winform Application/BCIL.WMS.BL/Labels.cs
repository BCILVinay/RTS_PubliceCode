﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Labels : BusinessBindingListBase<Labels, Label>
    {
        #region Factory Method

        public static Labels GetLabelList()
        {
            return DataPortal.Fetch<Labels>();
        }

        #endregion Factory Method

        #region Data Functions

        #region Fetch All

        private void DataPortal_Fetch()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllLabelSQL();
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(Label.GetLabelData(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllLabelSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Label T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            return sb.ToString();
        }

        #endregion Fetch All

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Update()
        {
            foreach (var label in this)
            {
                var lbl = label.Save();
            }
        }

        #endregion Data Functions
    }
}