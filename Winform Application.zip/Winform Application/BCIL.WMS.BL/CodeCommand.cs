﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Csla;
using BCIL.WMS.BL.Enums;
using System.Data.SqlClient;
using BCIL.Utility;
using Csla.Data;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class CodeCommand : CommandBase<CodeCommand>
    {
        private ObjectType _objType;
        private int _siteId;

        private string _NextCode;

        public CodeCommand(ObjectType type, int siteId)
        {
            _objType = type;
            _siteId = siteId;
        }

        public static string GetNextCode(ObjectType type, int siteId)
        {
            CodeCommand cmd = new CodeCommand(type, siteId);
            cmd = DataPortal.Execute(cmd);
            return cmd._NextCode;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {

                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "Getnextcode";
                    cmd.Parameters.AddWithValue("@SiteId", _siteId);
                    cmd.Parameters.AddWithValue("@ObjectType", _objType);
                    _NextCode = cmd.ExecuteScalar()?.ToString();
                }
            }
        }
    }
}
