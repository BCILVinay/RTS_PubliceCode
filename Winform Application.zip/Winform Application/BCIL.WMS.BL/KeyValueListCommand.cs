﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class KeyValueListCommand : CommandBase<KeyValueListCommand>
    {
        private KeyValueListType _type;
        private object[] _parameters;

        public KeyValueListCommand(KeyValueListType type, params object[] parameters)
        {
            KeyValues = new List<KeyValuePair<long, string>>();
            _type = type;
            _parameters = parameters;
        }

        private List<KeyValuePair<long, string>> KeyValues { get; set; }

        public static List<KeyValuePair<long, string>> GetKeyValueList(KeyValueListType type, params object[] parameters)
        {
            KeyValueListCommand entity = new KeyValueListCommand(type, parameters);
            return DataPortal.Execute(entity).KeyValues;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();

                using (var cmd = GetCommand(con.CreateCommand())) {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        while (dr.Read()) {
                            KeyValues.Add(new KeyValuePair<long, string>(dr.GetInt64("Key"), dr.GetString("Value")));
                        }
                    }
                }
            }
        }

        private SqlCommand GetCommand(SqlCommand cmd)
        {
            switch (_type) {
                case KeyValueListType.POToConfirm:
                    return GetPOToConfirmSqlCommand(cmd);
                case KeyValueListType.ActivePickList:
                    return GetActivePickListSqlCommand(cmd);
                case KeyValueListType.ActiveDispatchList:
                    return GetActiveDispatchListSqlCommand(cmd);
                case KeyValueListType.POToPrint:
                    return GetActiveActivePOToPrintListSqlCommand(cmd);
                case KeyValueListType.UnpackedItems:
                    return GetUnpackedItemsSqlCommand(cmd);
                case KeyValueListType.PendingPickList:
                    return GetPendingPicklistSQLCommand(cmd);
                default:
                    throw new Exception();
            }
        }

        private SqlCommand GetActiveActivePOToPrintListSqlCommand(SqlCommand cmd)
        {
            cmd.CommandType = System.Data.CommandType.Text;

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.POrderId as [Key],T1.POrderNo as Value \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T.POrderId = T1.POrderId \n");
            sb.Append("WHERE  T.BundleId = 0 \n");
            sb.Append("GROUP  BY T.POrderId,T1.POrderNo");

            cmd.CommandText = sb.ToString();
            return cmd;
        }

        private SqlCommand GetActiveDispatchListSqlCommand(SqlCommand cmd)
        {
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT PickListId as [Key], DeliveryNo as Value FROM PickList WHERE [Status] = 2";
            return cmd;
        }

        private SqlCommand GetActivePickListSqlCommand(SqlCommand cmd)
        {
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT PickListId as [Key], DeliveryNo as Value FROM PickList WHERE [Status] = 0";
            return cmd;
        }

        private SqlCommand GetPendingPicklistSQLCommand(SqlCommand cmd)
        {
            CodeContract.Required<BCILException>(_parameters.HaveItems(), "Plant code is mandatory");
            CodeContract.Required<BCILException>(((int)_parameters[0]) > 0, "Plant code is mandatory");

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT PickListId as [Key] , DeliveryNo as Value \n");
            sb.Append("FROM   PickList \n");
            sb.Append("WHERE  PickListId IN (SELECT T.PickListId \n");
            sb.Append("                      FROM   PickListLineItem T \n");
            sb.Append("                             INNER JOIN PickList T1 ON T.PickListId = T1.PickListId \n");
            sb.Append("                      WHERE  T.ItemStatus IN ( 0, 1 ) AND T1.SiteId = @SiteId \n");
            sb.Append("                      GROUP  BY T.PickListId)");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@SiteId", (int)_parameters[0]);
            return cmd;
        }

        public SqlCommand GetPOToConfirmSqlCommand(SqlCommand cmd)
        {
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT POrderId as [Key], POrderNo as Value FROM ProductionOrder WHERE [Status] = " + (int)ProductionOrderStatus.BundlePrinted;
            return cmd;
        }

        public SqlCommand GetUnpackedItemsSqlCommand(SqlCommand cmd)
        {
            CodeContract.Required<BCILException>(_parameters.HaveItems(), "PO id is mandatory");
            CodeContract.Required<BCILException>(((long)_parameters[0]) > 0, "PO id is mandatory");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = string.Format("SELECT ItemId as [Key],ItemCode as Value FROM  Item WHERE  POrderId = {0} AND BundleId = 0 ", _parameters[0]);
            return cmd;
        }
    }

    public enum KeyValueListType
    {
        POToConfirm,
        ActivePickList,
        PendingPickList,
        ActiveDispatchList,
        POToPrint,
        UnpackedItems,
    }
}