﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class CodeSetup : BusinessBase<CodeSetup>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> CodeSetupIdProperty = RegisterProperty<Int64>(c => c.CodeSetupId);

        public Int64 CodeSetupId
        {
            get { return GetProperty(CodeSetupIdProperty); }
            set { SetProperty(CodeSetupIdProperty, value); }
        }

        public static readonly PropertyInfo<ObjectType> ObjectTypeProperty = RegisterProperty<ObjectType>(c => c.ObjectType);

        public ObjectType ObjectType
        {
            get { return GetProperty(ObjectTypeProperty); }
            set { SetProperty(ObjectTypeProperty, value); }
        }

        public static readonly PropertyInfo<bool> UseDefaultCodeProperty = RegisterProperty<bool>(c => c.UseDefaultCode);

        public bool UseDefaultCode
        {
            get { return GetProperty(UseDefaultCodeProperty); }
            set { SetProperty(UseDefaultCodeProperty, value); }
        }

        public static readonly PropertyInfo<Int64> SerialNumberProperty = RegisterProperty<Int64>(c => c.SerialNumber);

        public Int64 SerialNumber
        {
            get { return GetProperty(SerialNumberProperty); }
            set { SetProperty(SerialNumberProperty, value); }
        }

        public static readonly PropertyInfo<string> PrefixProperty = RegisterProperty<string>(c => c.Prefix);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Prefix is mandatory.")]
        [StringLength(5, ErrorMessage = "Prefix should not exceed to 5 characters", MinimumLength = 1)]
        public string Prefix
        {
            get { return GetProperty(PrefixProperty); }
            set { SetProperty(PrefixProperty, value); }
        }

        public static readonly PropertyInfo<string> PostFixProperty = RegisterProperty<string>(c => c.PostFix);

        [Required(AllowEmptyStrings = false, ErrorMessage = "PostFix is mandatory.")]
        [StringLength(5, ErrorMessage = "PostFix should not exceed to 5 characters", MinimumLength = 1)]
        public string PostFix
        {
            get { return GetProperty(PostFixProperty); }
            set { SetProperty(PostFixProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods
        private CodeSetup() { }

        public static CodeSetup NewCodeSetup()
        {
            return DataPortal.Create<CodeSetup>();
        }

        public static CodeSetup GetCodeSetup(int id)
        {
            return DataPortal.Fetch<CodeSetup>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch Location

        private void DataPortal_Fetch(int CodeSetupId)
        {
            CodeContract.Required<ArgumentException>(CodeSetupId > 0, "CodeSetup id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@CodeSetup", CodeSetupId);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT * \n");
            sb.Append("FROM   CodeSetup \n");
            sb.Append("WHERE  CodeSetupId = @CodeSetupId");
            return sb.ToString();
        }

        #endregion Fetch Location

        #region Insert Location

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.Parameters.AddWithValue("@Description", "");
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    CodeSetupId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            throw new NotImplementedException();
        }

        #endregion Insert Location

        #region Update CodeSetup

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();

                    cmd.Parameters.AddWithValue("@CodeSetupId", CodeSetupId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            throw new NotImplementedException();
        }

        #endregion Update CodeSetup

        #region Delete CodeSetup

        private void DataPortal_Delete(int codeSetupId)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@CodeSetupId", codeSetupId);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsActive = 0 \n");
            sb.Append("FROM   CodeSetup \n");
            sb.Append("WHERE  [CodeSetupId] = @CodeSetupId");
            return sb.ToString();
        }

        #endregion Delete CodeSetup

        #endregion Data Functions
    }
}