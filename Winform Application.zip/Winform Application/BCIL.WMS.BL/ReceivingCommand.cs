﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ReceivingCommand : CommandBase<ReceivingCommand>
    {
        private ReceivingDetailCriteria _criteria { get; set; }

        private ReceivingDetail RecevingDetail { get; set; }

        public ReceivingCommand(ReceivingDetailCriteria criteria)
        {
            _criteria = criteria;
            RecevingDetail = new ReceivingDetail();
        }

        public static ReceivingDetail GetRecevingDetail(ReceivingDetailCriteria criteria)
        {
            ReceivingCommand entity = new ReceivingCommand(criteria);
            return DataPortal.Execute(entity).RecevingDetail;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = RecevingDetailSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            RecevingDetail = ReadRecevingDetail(dr);
                        }
                    }
                }
            }
        }

        private ReceivingDetail ReadRecevingDetail(SafeDataReader dr)
        {
            ReceivingDetail entity = new ReceivingDetail()
            {
                InvoiceId = dr.GetInt64("InvoiceId"),
                InvoiceNo = dr.GetString("InvoiceNo"),
                InvoiceDate = dr.GetDateTime("InvoiceDate"),
                DeliveryNo = dr.GetString("DeliveryNo"),
                LRNo = dr.GetString("LRNo"),
                STONo = dr.GetString("STONo"),
                Transporter = dr.GetString("Transporter"),
                TruckNo = dr.GetString("TruckNo")
            };

            entity.BundleDetails = new List<BundleDetail>();
            if (entity.InvoiceId > 0)
                entity.BundleDetails = BundleDetailListCommand.GetBundleDetails(BundleDetailType.ForReceive, new BundleDetailCriteria() { DeliveryNo = entity.DeliveryNo });
            return entity;
        }
    

        private SqlCommand RecevingDetailSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.InvoiceId,T.InvoiceNo,T.InvoiceDate,T1.STONo,T2.LRNo,T5.MaterialId,T1.DeliveryNo,T4.BundleCode,T2.TruckNo,T2.Transporter \n");
            sb.Append("FROM   Invoice T \n");
            sb.Append("       INNER JOIN Transfer T1 \n");
            sb.Append("               ON T1.DeliveryNo = T.DeliveryNo \n");
            sb.Append("       INNER JOIN PickList T2 \n");
            sb.Append("               ON T2.DeliveryNo = T.DeliveryNo \n");
            sb.Append("       LEFT OUTER JOIN TransferItem T3 \n");
            sb.Append("                    ON T3.TransferId = T1.TransferId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T4 \n");
            sb.Append("                    ON T4.BundleId = T3.BundleId \n");
            sb.Append("       LEFT OUTER JOIN PickListLineItem T5 \n");
            sb.Append("                    ON T5.PickListId = T2.PickListId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.InvoiceNo = @InvoiceNo AND T1.SiteTo = @PlantId;");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@InvoiceNo", _criteria.InvoiceNo);
            cmd.Parameters.AddWithValue("@PlantId", _criteria.PlantId);
            return cmd;
        }
    }

    #region DTO

    [Serializable]
    public class ReceivingDetail
    {
        public Int64 InvoiceId { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string STONo { get; set; }
        public string LRNo { get; set; }
        public string DeliveryNo { get; set; }
        public string TruckNo { get; set; }
        public string Transporter { get; set; }
        public List<BundleDetail> BundleDetails { get; set; }
    }

    #endregion DTO

    #region Criteria

    [Serializable]
    public class ReceivingDetailCriteria
    {
        public string InvoiceNo { get; set; }

        public int PlantId { get; set; }
    }

    #endregion Criteria
}