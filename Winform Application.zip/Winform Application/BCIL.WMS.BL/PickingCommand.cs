﻿using BCIL.Utility;
using Csla;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class PickingCommand : CommandBase<PickingCommand>
    {
        #region Properties

        private Int64 _pickingId;
        public Int64 PickingId { get { return _pickingId; } set { value = _pickingId; } }

        private Int64 _PicklistId;
        public Int64 PicklistId { get { return _PicklistId; } set { value = _PicklistId; } }

        private Int64 _trollyId;
        public Int64 TrollyId { get { return _trollyId; } set { value = _trollyId; } }

        private Int64 _BundleId;
        public Int64 BundleId { get { return _BundleId; } set { value = _BundleId; } }

        private int _PickedBy;
        public int PickedBy { get { return _PickedBy; } set { value = _PickedBy; } }

        private DateTime _PickedOn;
        public DateTime PickedOn { get { return _PickedOn; } set { value = _PickedOn; } }

        private int _SiteId;
        public int SiteId { get { return _SiteId; } set { value = _SiteId; } }

        #endregion Properties

        #region Factory Methods

        public PickingCommand(Int64 pickListId, Int64 trollyId, int pickedBy, Int64 bundleId, int siteId)
        {
            _PicklistId = pickListId;
            _trollyId = trollyId;
            _PickedBy = pickedBy;
            _BundleId = bundleId;
            _PickedOn = DateTime.Now;
            _SiteId = siteId;
        }

        public static void SavePicking(Int64 pickListId, Int64 trollyId, int pickedBy, Int64 bundleId, int siteId)
        {
            PickingCommand entity = new PickingCommand(pickListId, trollyId, pickedBy, bundleId, siteId);
            DataPortal.Execute(entity);
        }

        #endregion Factory Methods

        #region Data Methods

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@PicklistId", PicklistId);
                cmd.Parameters.AddWithValue("@BundleId", BundleId);
                cmd.Parameters.AddWithValue("@SiteId", SiteId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(*) \n");
            sb.Append("FROM   Picking \n");
            sb.Append("WHERE \n");
            sb.Append("  BundleId = @BundleId AND SiteId = @SiteId AND PickingId = @PicklistId");
            return sb.ToString();
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Bundle already picked.");

                using (var cmd = con.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = PickingSQL();
                        cmd.Parameters.AddWithValue("@PicklistId", PicklistId);
                        cmd.Parameters.AddWithValue("@BundleId", BundleId);
                        cmd.Parameters.AddWithValue("@LocationId", TrollyId);
                        cmd.Parameters.AddWithValue("@PickedBy", PickedBy);
                        cmd.Parameters.AddWithValue("@SiteId", SiteId);
                        cmd.Parameters.AddWithValue("@PickedOn", DateTime.Now);
                        cmd.ExecuteNonQuery();
                    }
            }
        }

        private string PickingSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Picking] \n");
            sb.Append("            ([PicklistId],[BundleId],[PickedOn],[PickedBy],[SiteId]) \n");
            sb.Append("VALUES      (@PicklistId,@BundleId,@PickedOn,@PickedBy,@SiteId);");
            return sb.ToString();
        }

        #endregion Data Methods
    }
}