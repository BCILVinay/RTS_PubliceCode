﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Items : BusinessBindingListBase<Items, Item>
    {
        public long TotalRowCount { get; set; }

        #region Properties

        public bool IsLabelPrinted { get; set; }

        #endregion Properties

        #region Factory Method

        public static Items GetItems(ItemSearchCriteria criteria)
        {
            return DataPortal.Fetch<Items>(criteria);
        }

        public static Items GetItemsByCriteria(ItemGenericSearchCriteria criteria)
        {
            return DataPortal.Fetch<Items>(criteria);
        }

        public static Items GetItemsById(ItemSearchCriteriaById criteria)
        {
            return DataPortal.Fetch<Items>(criteria);
        }

        public static Items GetItemsByBundleId(ItemSearchCriteriaByBundleId criteria)
        {
            return DataPortal.Fetch<Items>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(ItemSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                           // if (TotalRowCount == 0) //TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Item.GetItemData(dr));
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE   T.ItemId = @ItemId ");
            return sb.ToString();
        }

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Update()
        {
            List<Item> newItems = this.Where(x => x.IsNew).ToList();

            foreach (var item in this)
            {
                var itemObj = item.Save();
                item.ItemId = itemObj.ItemId;
            }

            Labels lables = new Labels();

            if (IsLabelPrinted)
            {
                foreach (var newItem in newItems)
                {
                    var label = Label.NewLabel();
                    label.LabelCode = newItem.ItemCode;
                    label.LabelObjType = Enums.LabelType.Material;
                    label.LableObjTypeId = newItem.ItemId;
                    label.LocationId = newItem.Location.Key;
                    label.CreatedBy = newItem.CreatedBy;
                    label.CreatedOn = newItem.CreatedOn;
                    lables.Add(label);
                }
                lables.Save();
            }
        }

        #endregion Data Functions
    }

    public class ItemSearchCriteria
    {
        public int SiteId { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
            return cmd;
        }
    }

    public class ItemsByCodeSearchCriteria : ItemSearchCriteria
    {
        public List<string> ItemCode { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.AppendFormat("AND  T.ItemCode in ('{0}') \n", string.Join("','", ItemCode));

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
            return cmd;
        }
    }

    public class ItemGenericSearchCriteria : ItemSearchCriteria
    {
         public string BundleCode { get; set; }
        public string ItemCode { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("AND  (@BundleCode = '' OR T5.BundleCode LIKE '%' + @BundleCode + '%') \n");
            sb.Append("AND  (@ItemCode = '' OR T.ItemCode LIKE '%' + @ItemCode + '%') \n");
            sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
            cmd.Parameters.AddWithValue("@BundleCode", BundleCode);
            cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            return cmd;
        }
    }

    public class ItemSearchCriteriaById : ItemSearchCriteria
    {
        public Int64 BundleId { get; set; }
        public Int64 ItemId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("AND  T.ItemId = @ItemId and (@BundleId=0 or T.BundleId=@BundleId)");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ItemId");
            cmd.Parameters.AddWithValue("@BundleId", BundleId);
            cmd.Parameters.AddWithValue("@ItemId", ItemId);
            return cmd;
        }
    }

    public class ItemSearchCriteriaByBundleId : ItemSearchCriteria
    {
        public Int64 BundleId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append(" FROM   Item T \n");
            sb.Append("        INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("        LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("        LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("        LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("        LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append(" WHERE  1 = 1 \n");
            sb.Append(" AND T.BundleId=@BundleId");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@BundleId", BundleId);
            return cmd;
        }
    }

    public class ItemSearchCriteriaByPOrderId : ItemSearchCriteria
    {
        public Int64 POrderId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append(" FROM   Item T \n");
            sb.Append("        INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("        LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("        LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("        LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("        LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append(" WHERE  1 = 1 \n");
            sb.Append(" AND T.POrderId=@POrderId");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@POrderId", POrderId);
            return cmd;
        }
    }

    

}