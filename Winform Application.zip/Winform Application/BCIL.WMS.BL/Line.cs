﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Line : MyBusinessBase<Line>
    {
        #region Properties

        public static readonly PropertyInfo<int> LineIdProperty = RegisterProperty<int>(c => c.LineId);

        public int LineId
        {
            get { return GetProperty(LineIdProperty); }
            set { SetProperty(LineIdProperty, value); }
        }

        public static readonly PropertyInfo<string> CodeProperty = RegisterProperty<string>(c => c.Code);

        public string Code
        {
            get { return GetProperty(CodeProperty); }
            set { SetProperty(CodeProperty, value); }
        }

        public static readonly PropertyInfo<decimal> SpeedProperty = RegisterProperty<decimal>(c => c.Speed);

        public decimal Speed
        {
            get { return GetProperty(SpeedProperty); }
            set { SetProperty(SpeedProperty, value); }
        }

        public static readonly PropertyInfo<long> LocationIdProperty = RegisterProperty<long>(c => c.LocationId);

        public long LocationId
        {
            get { return GetProperty(LocationIdProperty); }
            set { SetProperty(LocationIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> ToolingProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Tooling);

        public KeyValue<Int64, string> Tooling
        {
            get { return GetProperty(ToolingProperty); }
            set { SetProperty(ToolingProperty, value); }
        }

        #endregion Properties

        #region Factory

        public static Line NewLine()
        {
            return DataPortal.Create<Line>();
        }

        public static Line GetLine(SafeDataReader dr)
        {
            return DataPortal.Fetch<Line>(dr);
        }

        public static Line GetLine(Int32 lineId)
        {
            return DataPortal.Fetch<Line>(lineId);
        }

        protected void DataPortal_Fetch(SafeDataReader dr)
        {
            LineId = dr.GetInt32("LineId");
            Code = dr.GetString("LineCode");
            Speed = dr.GetDecimal("LineSpeed");
            LocationId = dr.GetInt64("LocationId");
            Tooling = new KeyValue<long, string>(dr.GetInt64("ToolingId"), dr.GetString("ToolingCode"));
        }

        private void DataPortal_Fetch(Int32 id)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = SelectSQL();
                    cm.Parameters.AddWithValue("@LineId", id);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            GetLine(dr);
                        }
                    }
                }
            }
        }

        private string SelectSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.LocationId,T2.ToolingId,T2.ToolingCode \n");
            sb.Append("FROM   Line T \n");
            sb.Append("       INNER JOIN Location T1 ON T.LocationId = T1.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T2 ON T.ToolingId = T2.ToolingId \n");
            sb.Append("WHERE  T.LineId = @LineId");
            return sb.ToString();
        }

        public static Line GetLineByCode(string code)
        {
            Line line = null;
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = SelectSQLBYCode();
                    cm.Parameters.AddWithValue("@LineCode", code);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            line = new Line()
                            {
                                LineId = dr.GetInt32("LineId"),
                                Code = dr.GetString("LineCode"),
                                Speed = dr.GetDecimal("LineSpeed"),
                                LocationId = dr.GetInt64("LocationId"),
                                Tooling = new KeyValue<long, string>(dr.GetInt64("ToolingId"), dr.GetString("ToolingCode"))
                            };
                        }
                    }
                }
            }
            return line;
        }

        private static string SelectSQLBYCode()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.LocationId,T2.ToolingId,T2.ToolingCode \n");
            sb.Append("FROM   Line T \n");
            sb.Append("       INNER JOIN Location T1 ON T.LocationId = T1.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T2 ON T.ToolingId = T2.ToolingId \n");
            sb.Append("WHERE  T.LineCode = @LineCode");
            return sb.ToString();
        }

        #endregion Factory
    }
}