﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ProductionOrder : MyBusinessBase<ProductionOrder>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> POrderIdProperty = RegisterProperty<Int64>(c => c.POrderId);

        public Int64 POrderId
        {
            get { return GetProperty(POrderIdProperty); }
            set { SetProperty(POrderIdProperty, value); }
        }

        public static readonly PropertyInfo<string> POrderNoProperty = RegisterProperty<string>(c => c.POrderNo);

        [Required(ErrorMessage = "Production order is mandatory.")]
        public string POrderNo
        {
            get { return GetProperty(POrderNoProperty); }
            set { SetProperty(POrderNoProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> POrderDateProperty = RegisterProperty<DateTime>(c => c.POrderDate);

        [RequiredButNotDefault(ErrorMessage = "Production order date is mandatory.")]
        public DateTime POrderDate
        {
            get { return GetProperty(POrderDateProperty); }
            set { SetProperty(POrderDateProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> FinishDateProperty = RegisterProperty<DateTime>(c => c.FinishDate);

        public DateTime FinishDate
        {
            get { return GetProperty(FinishDateProperty); }
            set { SetProperty(FinishDateProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        [RequiredButNotDefault(ErrorMessage = "Site location is mandatory.")]
        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<string> MovementTypeProperty = RegisterProperty<string>(c => c.MovementType);

        public string MovementType
        {
            get { return GetProperty(MovementTypeProperty); }
            set { SetProperty(MovementTypeProperty, value); }
        }

        public static readonly PropertyInfo<ProductionOrderStatus> StatusProperty = RegisterProperty<ProductionOrderStatus>(c => c.Status);

        public ProductionOrderStatus Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<int> QtyProperty = RegisterProperty<int>(c => c.Qty);

        public int Qty
        {
            get { return GetProperty(QtyProperty); }
            set { SetProperty(QtyProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> CreatedByProperty = RegisterProperty<KeyValue<int, string>>(c => c.CreatedBy);

        public KeyValue<int, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> UpdatedByProperty = RegisterProperty<KeyValue<int, string>>(c => c.UpdatedBy);

        public KeyValue<int, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> ImportedOnProperty = RegisterProperty<DateTime>(c => c.ImportedOn);

        public DateTime ImportedOn
        {
            get { return GetProperty(ImportedOnProperty); }
            set { SetProperty(ImportedOnProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsImportedProperty = RegisterProperty<bool>(c => c.IsImported);

        public bool IsImported
        {
            get { return GetProperty(IsImportedProperty); }
            set { SetProperty(IsImportedProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> ConfirmedOnProperty = RegisterProperty<DateTime>(c => c.ConfirmedOn);

        public DateTime ConfirmedOn
        {
            get { return GetProperty(ConfirmedOnProperty); }
            set { SetProperty(ConfirmedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<int, string>> ConfirmedByProperty = RegisterProperty<KeyValue<int, string>>(c => c.ConfirmedBy);

        public KeyValue<int, string> ConfirmedBy
        {
            get { return GetProperty(ConfirmedByProperty); }
            set { SetProperty(ConfirmedByProperty, value); }
        }

        public static readonly PropertyInfo<POLineItemList> POLineItemsProperty = RegisterProperty<POLineItemList>(c => c.POLineItems);

        public POLineItemList POLineItems
        {
            get { return GetProperty(POLineItemsProperty); }
            set { SetProperty(POLineItemsProperty, value); }
        }

        public string Material { get { return POLineItems[0].Material.Value; } }
        public string MaterialDesc { get { return POLineItems[0].MaterialDescription; } }

        public string Tooling { get { return POLineItems[0].ToolingCode; } }

        public string LinePrefences { get { return POLineItems[0].LineCode; } }

        public int Bundles { get { return POLineItems.Sum(x => x.BundleQty); } }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private ProductionOrder()
        {
            ConfirmedOn = SqlDateTime.MinValue.Value;
        }

        public static ProductionOrder NewProductionOrder()
        {
            var newObj = DataPortal.Create<ProductionOrder>();
            newObj.POLineItems = new POLineItemList();
            return newObj;
        }

        public static ProductionOrder GetProductionOrder(Int64 id)
        {
            return DataPortal.Fetch<ProductionOrder>(id);
        }

        public static ProductionOrder GetProductionOrder(SafeDataReader dr)
        {
            return DataPortal.Fetch<ProductionOrder>(dr);
        }

        public static ProductionOrder GetProductionOrderByNumber(string PoNumber)
        {
            return DataPortal.Fetch<ProductionOrder>(PoNumber);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            POrderId = dr.GetInt64("POrderId");
            POrderNo = dr.GetString("POrderNo");
            POrderDate = dr.GetDateTime("POrderDate");
            SiteId = dr.GetInt32("SiteId");
            MovementType = dr.GetString("MovementType");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = new KeyValue<int, string>(dr.GetInt32("CreatedBy"), dr.GetString("CreatedByName"));
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = new KeyValue<int, string>(dr.GetInt32("UpdatedBy"), dr.GetString("UpdatedByName"));
            ImportedOn = dr.GetDateTime("ImportedOn");
            IsImported = dr.GetBoolean("IsImported");
            Status = (ProductionOrderStatus)dr.GetInt32("Status");
            ConfirmedOn = dr.GetDateTime("ConfirmedOn");
            ConfirmedBy = new KeyValue<int, string>(dr.GetInt32("ConfirmedBy"), dr.GetString("ConfirmedByName"));
            POLineItems = POLineItemList.GetPOLineItemList(dr.GetInt64("POrderId"));
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@POrderId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.NAME AS ConfirmedByName \n");
            sb.Append("FROM   ProductionOrder T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       LEFT OUTER JOIN Employee T3 ON T.ConfirmedBy = T3.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  POrderId = @POrderId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string poNumber)
        {
            CodeContract.Required<ArgumentException>(poNumber.IsNotNullOrWhiteSpace(), "PO number is required");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@POrderNo", poNumber);
                    cmd.CommandText = FetchByPONoSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByPONoSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.NAME AS ConfirmedByName \n");
            sb.Append("FROM   ProductionOrder T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       LEFT OUTER JOIN Employee T3 ON T.ConfirmedBy = T3.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  POrderNo = @POrderNo");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@POId", POrderId);
                cmd.Parameters.AddWithValue("@PONumber", POrderNo);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   ProductionOrder \n");
            sb.Append("WHERE  POrderNo = @PONumber \n");
            sb.Append("       AND ( @POId = 0 OR POrderId <> @POId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Production is already exist.");
                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;

                        cmd.Parameters.AddWithValue("@POrderNo", POrderNo);
                        cmd.Parameters.AddWithValue("@POrderDate", POrderDate);
                        cmd.Parameters.AddWithValue("@SiteId", SiteId);
                        cmd.Parameters.AddWithValue("@MovementType", MovementType);
                        cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                        cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                        cmd.Parameters.AddWithValue("@ImportedOn", ImportedOn);
                        cmd.Parameters.AddWithValue("@IsImported", IsImported);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@ConfirmedOn", ConfirmedOn);
                        cmd.Parameters.AddWithValue("@ConfirmedBy", ConfirmedBy.Key);

                        cmd.CommandText = InsertSQL();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                        POrderId = Convert.ToInt64(cmd.ExecuteScalar());
                        if (POLineItems.HaveItems())
                        {
                            foreach (var item in POLineItems)
                            {
                                item.PO = new KeyValue<long, string>(POrderId, POrderNo);
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[ProductionOrder] \n");
            sb.Append("            ([POrderNo],[POrderDate],[SiteId],[MovementType],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[ImportedOn],[IsImported],[Status],[ConfirmedOn],[ConfirmedBy]) \n");
            sb.Append("VALUES      (@POrderNo,@POrderDate,@SiteId,@MovementType,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@ImportedOn,@IsImported,@Status,@ConfirmedOn,@ConfirmedBy)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Production order is already exist.");
                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = UpdateSQL();
                        cmd.Parameters.AddWithValue("@POrderId", POrderId);
                        cmd.Parameters.AddWithValue("@POrderNo", POrderNo);
                        cmd.Parameters.AddWithValue("@POrderDate", POrderDate);
                        cmd.Parameters.AddWithValue("@SiteId", SiteId);
                        cmd.Parameters.AddWithValue("@MovementType", MovementType);
                        cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                        cmd.Parameters.AddWithValue("@ImportedOn", ImportedOn);
                        cmd.Parameters.AddWithValue("@IsImported", IsImported);
                        cmd.Parameters.AddWithValue("@Status", Status);
                        cmd.Parameters.AddWithValue("@ConfirmedOn", ConfirmedOn);
                        cmd.Parameters.AddWithValue("@ConfirmedBy", ConfirmedBy.Key);

                        cmd.ExecuteNonQuery();
                        if (POLineItems.HaveItems())
                        {
                            foreach (var item in POLineItems)
                            {
                                item.PO = new KeyValue<long, string>(POrderId, POrderNo);
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[ProductionOrder] \n");
            sb.Append("SET    [POrderNo] = @POrderNo,[POrderDate] = @POrderDate,[SiteId] = @SiteId,[MovementType] = @MovementType,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[ImportedOn] = @ImportedOn,[IsImported] = @IsImported,[Status]=@Status,[ConfirmedOn]=@ConfirmedOn,[ConfirmedBy]= @ConfirmedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  POrderId = @POrderId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsActive = 0 \n");
            sb.Append("FROM   Material \n");
            sb.Append("WHERE  [MaterialId] = @MaterialId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}