﻿namespace BCIL.WMS.BL.Enums
{
    public enum PickListStatus
    {
        New = 0,
        Pending = 1,
        Picked = 2,
        Dispatch=3
    }

    public enum PickListItemStatus
    {
        New = 0,
        Pending = 1,
        Picked = 2,
        Dispatch = 3
    }
}