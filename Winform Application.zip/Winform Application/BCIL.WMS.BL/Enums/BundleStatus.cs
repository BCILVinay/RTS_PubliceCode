﻿using System;

namespace BCIL.WMS.BL.Enums
{
    [Serializable]
    public enum BundleStatus
    {
        New = 0,
        Picked = 1,
        Dispatch = 2,
        Putaway = 3,
        Received = 4,
        InCurring = 5
    }
}