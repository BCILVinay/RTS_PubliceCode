﻿using System;
using System.ComponentModel;

namespace BCIL.WMS.BL
{
    [Serializable]
    public enum LocationType
    {
        [Description("Interim")]
        Interim = 0,

        [Description("Curing")]
        Curing = 1,

        [Description("Scrap")]
        Scrap = 2,

        [Description("Quality")]
        Quality = 3,

        [Description("Production")]
        Production =4,

        [Description("Warehouse")]
        Warehouse =5
    }

    [Serializable]
    public enum Mode
    {
        [Description("Trolley")]
        Trolley = 0,

        [Description("Bin")]
        Bin = 1,

        [Description("Grid")]
        Grid = 2,
    }
}