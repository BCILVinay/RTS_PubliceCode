﻿using System;

namespace BCIL.WMS.BL.Enums
{
    public enum ObjectType
    {
        [PreFix("LA")]
        Location = 0,

        [PreFix("M")]
        Material = 1,

        [PreFix("")]
        Bundle = 2,

        [PreFix("I")]
        Item = 3,

        [PreFix("PPL")]
        ProductionPlanning = 4
    }

    [AttributeUsage(AttributeTargets.Field)]
    public class PreFixAttribute : Attribute
    {
        public PreFixAttribute(string value)
        {
            this.Value = value;
        }

        public string Value { get; set; }
    }

    public enum LabelType
    {
        Location = 0,

        Material = 1,

        Bundle = 2,

        Item = 3,

        Invoice = 4,

        MaterialBin = 5
    }
}