﻿namespace BCIL.WMS.BL.Enums
{
    public enum TransferStatus
    {
        New = 0,
        Dispatch = 1,
        Recieved = 2
    }

    public enum TransferItemStatus
    {
        New = 0,
        Dispatch = 1,
        Recieved = 2
    }
}