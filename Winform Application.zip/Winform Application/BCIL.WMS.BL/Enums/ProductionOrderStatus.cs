﻿using System;
using System.ComponentModel;

namespace BCIL.WMS.BL.Enums
{
    [Serializable]
    public enum ProductionOrderStatus
    {
        [Description("New")]
        New = 0,

        [Description("Bundle Printed")]
        BundlePrinted = 1,

        [Description("Confirmed")]
        Confirmed = 2,

        [Description("Complete")]
        Complete = 3,

        [Description("Item Printed")]
        ItemPrinted = 4,
    }

    [Serializable]
    public enum MovementType
    {
        [Description("Curing")]
        Curing = 0,

        [Description("Foiling")]
        Foiling = 1
    }
}