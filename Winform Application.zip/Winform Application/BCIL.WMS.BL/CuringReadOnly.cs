﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class CuringReadOnlyList : ReadOnlyListBase<CuringReadOnlyList, CuringReadOnly>
    {
        #region Properties

        public long TotalRowCount { get; set; }

        #endregion Properties

        #region Factory Method

        public static CuringReadOnlyList GetCuringReadOnlyList(CuringReadOnlySearchCriteria criteria)
        {
            return DataPortal.Fetch<CuringReadOnlyList>(criteria);
        }

        #endregion Factory Method

        #region Data Functions

        private void DataPortal_Fetch(CuringReadOnlySearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            this.IsReadOnly = false;
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(CuringReadOnly.GetCuringReadOnly(dr));
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }

        #endregion Data Functions
    }

    public class CuringReadOnlySearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;
        public int SiteId { get; set; }
        public string MaterialCode { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.CuringId,T.CuringIn,T.CuringOut,T.IsCured,T1.ItemCode,T2.MaterialCode,T2.MaterialDesc,T3.LocationCode \n");
            sb.Append("FROM   Curing T \n");
            sb.Append("       INNER JOIN Item T1 ON T1.ItemId = T.ItemId \n");
            sb.Append("       INNER JOIN Material T2 ON T1.MaterialId = T2.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Location T3 ON T3.LocationId = T1.LocationId \n");
            sb.Append("WHERE  1 = 1 AND ( @SiteId = 0 OR  T.SiteId = @SiteId)  \n");
            sb.Append("       AND (@MaterialCode = '' OR T2.MaterialCode LIKE '%' + @MaterialCode + '%') \n");
            sb.Append("       AND (cast(convert(varchar, T.CuringIn, 112) as datetime)) BETWEEN @FromDate AND @ToDate \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.CuringId");
            cmd.Parameters.AddWithValue("@MaterialCode", MaterialCode ?? "");
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            return cmd;
        }
    }

    public class CuringReadOnly : ReadOnlyBase<CuringReadOnly>
    {
        #region Properties

        public string ItemCode { get; set; }
        public DateTime CuringIn { get; set; }
        public DateTime CuringOut { get; set; }
        public string IsCured { get; set; }
        public string Material { get; set; }
        public string MaterialDesc { get; set; }
        public string Location { get; set; }

        #endregion Properties

        #region Factory Methods

        public static CuringReadOnly GetCuringReadOnly(SafeDataReader dr)
        {
            return DataPortal.Fetch<CuringReadOnly>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ItemCode = dr.GetString("ItemCode");
            Material = dr.GetString("MaterialCode");
            Location = dr.GetString("LocationCode");
            MaterialDesc = dr.GetString("MaterialDesc");
            IsCured = (dr.GetBoolean("IsCured")) ? "Yes" : "No";
            CuringIn = dr.GetDateTime("CuringIn");
            CuringOut = dr.GetDateTime("CuringOut");

        }

        #endregion Fetch

        #endregion Data Functions
    }
}