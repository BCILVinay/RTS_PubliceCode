﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class BundleDetailListCommand : CommandBase<BundleDetailListCommand>
    {
        private BundleDetailCriteria _criteria { get; set; }
        private BundleDetailType _type;
        private List<BundleDetail> BundleDetails { get; set; }

        public BundleDetailListCommand(BundleDetailType type, BundleDetailCriteria criteria)
        {
            _criteria = criteria;
            _type = type;
            BundleDetails = new List<BundleDetail>();
        }

        public static List<BundleDetail> GetBundleDetails(BundleDetailType type, BundleDetailCriteria criteria)
        {
            BundleDetailListCommand bdlc = new BundleDetailListCommand(type, criteria);
            return DataPortal.Execute(bdlc).BundleDetails;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = GetCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            BundleDetails.Add(new BundleDetail()
                            {
                                BundleCode = dr.GetString("BundleCode"),
                                BundleId = dr.GetInt64("BundleId"),
                                LocationId = dr.GetInt64("LocationId"),
                                LocationCode = dr.GetString("LocationCode"),
                                MaterialId = dr.GetInt64("MaterialId"),
                                MaterialCode = dr.GetString("MaterialCode"),
                            });
                        }
                    }
                }
            }
        }

        private SqlCommand GetCommand(SqlCommand cmd)
        {
            switch (_type)
            {
                case BundleDetailType.ForDelivery:
                    return GetForDeliverySqlCommand(cmd);

                case BundleDetailType.ForReceive:
                    return GetForReceiveSqlCommand(cmd);

                default:
                    throw new Exception();
            }
        }

        private SqlCommand GetForReceiveSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.BundleId,T3.BundleCode,T3.LocationId,T4.LocationCode,T5.MaterialCode,T3.MaterialId \n");
            sb.Append("FROM   TransferItem T \n");
            sb.Append("       INNER JOIN Transfer T2 ON T2.TransferId = T.TransferId \n");
            sb.Append("       INNER JOIN Bundle T3 ON T3.BundleId = T.BundleId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Material T5 ON T5.MaterialId = T3.MaterialId \n");
            sb.Append("WHERE \n");
            sb.Append("  T2.DeliveryNo = @DeliveryNo; \n");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@DeliveryNo", _criteria.DeliveryNo);
            return cmd;
        }

        private SqlCommand GetForDeliverySqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.PickingId,T.BundleId,T3.BundleCode,T3.LocationId,T4.LocationCode,T5.MaterialCode,T3.MaterialId \n");
            sb.Append("FROM   Picking T \n");
            sb.Append("       INNER JOIN PickList T2  ON T2.PickListId = T.PickListId \n");
            sb.Append("       INNER JOIN Bundle T3 ON T3.BundleId = T.BundleId \n");
            sb.Append("       INNER JOIN Location T4  ON T4.LocationId = T3.LocationId \n");
            sb.Append("	   INNER JOIN Material T5  ON T5.MaterialId = T3.MaterialId \n");
            sb.Append("WHERE \n");
            sb.Append("  T2.DeliveryNo = @DeliveryNo;");
             
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@DeliveryNo", _criteria.DeliveryNo);
            return cmd;
        }
    }

    #region DTO

   
    [Serializable]
    public class BundleDetail
    {
        public Int64 BundleId { get; set; }
        public string BundleCode { get; set; }
        public Int64 LocationId { get; set; }
        public string LocationCode { get; set; }
        public Int64 MaterialId { get; set; }
        public string MaterialCode { get; set; }
    }

    #endregion DTO

    #region Enum

    [Serializable]
    public enum BundleDetailType
    {
        ForDelivery,
        ForReceive,
        ForPutaway
    }

    #endregion Enum

    #region Criteria

    [Serializable]
    public class BundleDetailCriteria
    {
        public string DeliveryNo { get; set; }
    }

    #endregion Criteria
}