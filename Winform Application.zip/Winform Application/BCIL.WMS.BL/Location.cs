﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Location : MyBusinessBase<Location>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> LocationIdProperty = RegisterProperty<Int64>(c => c.LocationId);

        public Int64 LocationId
        {
            get { return GetProperty(LocationIdProperty); }
            set { SetProperty(LocationIdProperty, value); }
        }

        public static readonly PropertyInfo<string> CodeProperty = RegisterProperty<string>(c => c.LocationCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Location code is mandatory.")]
        [StringLength(50, ErrorMessage = "Location code should not exceed to 50 characters")]
        public string LocationCode
        {
            get { return GetProperty(CodeProperty); }
            set { SetProperty(CodeProperty, value); }
        }

        public static readonly PropertyInfo<string> NameProperty = RegisterProperty<string>(c => c.LocationName);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Location name is mandatory.")]
        [StringLength(100, ErrorMessage = "Location name should not exceed to 100 characters")]
        public string LocationName
        {
            get { return GetProperty(NameProperty); }
            set { SetProperty(NameProperty, value); }
        }

        public static readonly PropertyInfo<string> DescriptionProperty = RegisterProperty<string>(c => c.Description);

        [StringLength(500, ErrorMessage = "Location name should not exceed to 500 characters")]
        public string Description
        {
            get { return GetProperty(DescriptionProperty); }
            set { SetProperty(DescriptionProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> SiteProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.Site);
        [RequiredButNotDefault(ErrorMessage = "Site is mandatory.")]
        public KeyValue<Int32, string> Site
        {
            get { return GetProperty(SiteProperty); }
            set { SetProperty(SiteProperty, value); }
        }
            
        public static readonly PropertyInfo<LocationType> TypeProperty = RegisterProperty<LocationType>(c => c.Type);
        public LocationType Type
        {
            get { return GetProperty(TypeProperty); }
            set { SetProperty(TypeProperty, value); }
        }

        public static readonly PropertyInfo<Mode> ModeProperty = RegisterProperty<Mode>(c => c.Mode);

        public Mode Mode
        {
            get { return GetProperty(ModeProperty); }
            set { SetProperty(ModeProperty, value); }
        }

        public static readonly PropertyInfo<decimal> DimensionLengthProperty = RegisterProperty<decimal>(c => c.DimensionLength);

        public decimal DimensionLength
        {
            get { return GetProperty(DimensionLengthProperty); }
            set { SetProperty(DimensionLengthProperty, value); }
        }

        public static readonly PropertyInfo<decimal> DimensionWidthProperty = RegisterProperty<decimal>(c => c.DimensionWidth);

        public decimal DimensionWidth
        {
            get { return GetProperty(DimensionWidthProperty); }
            set { SetProperty(DimensionWidthProperty, value); }
        }

        public static readonly PropertyInfo<decimal> DimensionHeightProperty = RegisterProperty<decimal>(c => c.DimensionHeight);

        public decimal DimensionHeight
        {
            get { return GetProperty(DimensionHeightProperty); }
            set { SetProperty(DimensionHeightProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsImportedProperty = RegisterProperty<bool>(c => c.IsImported);
        public bool IsImported
        {
            get { return GetProperty(IsImportedProperty); }
            set { SetProperty(IsImportedProperty, value); }
        }
        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<Location>(CodeProperty, (x) => { return x.Code.Length > 0; }, "Person's code should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Location()
        {
            /* Restrict class to create object from outside*/
        }

        public static Location NewLocation() => DataPortal.Create<Location>();

        public static Location GetLocationByCode(string code)
        {
            return DataPortal.Fetch<Location>(code);
        }

        public static Location GetLocation(long id) => DataPortal.Fetch<Location>(id);

        public static void DeleteLocation(long id)
        {
            DataPortal.Delete<Location>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch Location

        public static Location GetLocation(SafeDataReader dr)
        {
            Location Location = new Location()
            {
                LocationId = dr.GetInt64("LocationId"),
                LocationName = dr.GetString("LocationName"),
                LocationCode = dr.GetString("LocationCode"),
                Site = new KeyValue<Int32, string>() { Key = dr.GetInt32("SiteId"), Value = dr.GetString("SiteName") },
                Type = (LocationType)dr.GetInt32("LocationType"),
                Description = dr.GetString("Description"),
                DimensionHeight = dr.GetDecimal("DimensionHeight"),
                DimensionLength = dr.GetDecimal("DimensionLength"),
                DimensionWidth = dr.GetDecimal("DimensionWidth"),
                Mode = (Mode)dr.GetInt32("Mode"),
                CreatedOn = dr.GetDateTime("CreatedOn"),
                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") },
                UpdatedOn = dr.GetDateTime("UpdatedOn"),
                UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") },
                IsActive = dr.GetBoolean("IsActive"),
                IsImported=dr.GetBoolean("IsImported")
            };
            Location.MarkOld();
            return Location;
        }

        private void DataPortal_Fetch(Int64 locationId)
        {
            CodeContract.Required<ArgumentException>(locationId > 0, "Location id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LocationId", locationId);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            LocationId = dr.GetInt64("LocationId");
                            LocationName = dr.GetString("LocationName");
                            LocationCode = dr.GetString("LocationCode");
                            Site = new KeyValue<Int32, string>() { Key = dr.GetInt32("SiteId"), Value = dr.GetString("SiteName") };
                            LoadProperty(TypeProperty, dr.GetInt32("LocationType"));
                            Description = dr.GetString("Description");
                            DimensionHeight = dr.GetDecimal("DimensionHeight");
                            DimensionLength = dr.GetDecimal("DimensionLength");
                            DimensionWidth = dr.GetDecimal("DimensionWidth");
                            Mode = (Mode)dr.GetInt32("Mode");
                            CreatedOn = dr.GetDateTime("CreatedOn");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                            UpdatedOn = dr.GetDateTime("UpdatedOn");
                            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
                            IsActive = dr.GetBoolean("IsActive");
                            IsImported = dr.GetBoolean("IsImported");
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.SiteName \n");
            sb.Append("FROM   Location T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Site T3 ON T.SiteId = T3.SiteId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.LocationId = @LocationId");

            return sb.ToString();
        }

        private void DataPortal_Fetch(string code)
        {
            CodeContract.Required<ArgumentException>(code.IsNotNullOrWhiteSpace(), "Location code is required.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LocationCode", code);
                    cmd.CommandText = FetchByCodeSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            LocationId = dr.GetInt64("LocationId");
                            LocationName = dr.GetString("LocationName");
                            LocationCode = dr.GetString("LocationCode");
                            Site = new KeyValue<Int32, string>() { Key = dr.GetInt32("SiteId"), Value = dr.GetString("SiteName") };
                            LoadProperty(TypeProperty, dr.GetInt32("LocationType"));
                            Description = dr.GetString("Description");
                            DimensionHeight = dr.GetDecimal("DimensionHeight");
                            DimensionLength = dr.GetDecimal("DimensionLength");
                            DimensionWidth = dr.GetDecimal("DimensionWidth");
                            Mode = (Mode)dr.GetInt32("Mode");
                            CreatedOn = dr.GetDateTime("CreatedOn");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                            UpdatedOn = dr.GetDateTime("UpdatedOn");
                            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
                            IsActive = dr.GetBoolean("IsActive");
                            IsImported = dr.GetBoolean("IsImported");
                        }
                    }
                }
            }
        }
        private string FetchByCodeSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.SiteName \n");
            sb.Append("FROM   Location T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Site T3 ON T.SiteId = T3.SiteId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.LocationCode = @LocationCode");

            return sb.ToString();
        }
        #endregion Fetch Location

        #region Insert Location

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
                cmd.Parameters.AddWithValue("@LocationId", LocationId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Location \n");
            sb.Append("WHERE  LocationCode = @LocationCode \n");
            sb.Append("       AND ( @LocationId = 0 OR LocationId <> @LocationId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                if (IsExists(con)) throw new BCILException("'Location already exists.");
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
                    cmd.Parameters.AddWithValue("@LocationName", LocationName);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@LocationType", Type);
                    cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                    cmd.Parameters.AddWithValue("@Mode", Mode);
                    cmd.Parameters.AddWithValue("@DimensionLength", DimensionLength);
                    cmd.Parameters.AddWithValue("@DimensionWidth", DimensionWidth);
                    cmd.Parameters.AddWithValue("@DimensionHeight", DimensionHeight);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    LocationId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Location] \n");
            sb.Append("            ([LocationCode],[LocationName],[Description],[LocationType],[SiteId],[Mode],[DimensionLength],[DimensionWidth],[DimensionHeight],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[IsActive],[IsImported]) \n");
            sb.Append("VALUES      (@LocationCode,@LocationName,@Description,@LocationType,@SiteId,@Mode,@DimensionLength,@DimensionWidth,@DimensionHeight,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@IsActive,@IsImported)");
            return sb.ToString();
        }

        #endregion Insert Location

        #region Update Location

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Location is already exist");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@LocationId", LocationId);
                    cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
                    cmd.Parameters.AddWithValue("@LocationName", LocationName);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@LocationType", Type);
                    cmd.Parameters.AddWithValue("@Mode", Mode);
                    cmd.Parameters.AddWithValue("@SiteId", Site.Key);
                    cmd.Parameters.AddWithValue("@DimensionLength", DimensionLength);
                    cmd.Parameters.AddWithValue("@DimensionWidth", DimensionWidth);
                    cmd.Parameters.AddWithValue("@DimensionHeight", DimensionHeight);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);

                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [Location] \n");
            sb.Append("SET    [LocationCode] = @LocationCode,[LocationName] = @LocationName,[Description] = @Description,[LocationType] = @LocationType,[SiteId] = @SiteId,[Mode] = @Mode,[DimensionLength] = @DimensionLength,[DimensionWidth] = @DimensionWidth,[DimensionHeight] = @DimensionHeight,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[IsActive] = @IsActive,IsImported=@IsImported \n");
            sb.Append("WHERE \n");
            sb.Append("  LocationId = @LocationId");
            return sb.ToString();
        }

        #endregion Update Location

        #region Delete Location

        private void DataPortal_Delete(int locationId)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LocationId", locationId);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE Location \n");
            sb.Append("SET  IsActive = 0 \n");
            sb.Append("WHERE  [LocationId] = @LocationId");
            return sb.ToString();
        }

        #endregion Delete Location

        #endregion Data Functions
    }
}