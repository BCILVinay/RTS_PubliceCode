﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Invoice : MyBusinessBase<Invoice>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> InvoiceIdProperty = RegisterProperty<Int64>(c => c.InvoiceId);

        public Int64 InvoiceId
        {
            get { return GetProperty(InvoiceIdProperty); }
            set { SetProperty(InvoiceIdProperty, value); }
        }

        public static readonly PropertyInfo<string> DeliveryNoProperty = RegisterProperty<string>(c => c.DeliveryNo);
        public string DeliveryNo
        {
            get { return GetProperty(DeliveryNoProperty); }
            set { SetProperty(DeliveryNoProperty, value); }
        }

        public static readonly PropertyInfo<string> InvoiceNoProperty = RegisterProperty<string>(c => c.InvoiceNo);

        public string InvoiceNo
        {
            get { return GetProperty(InvoiceNoProperty); }
            set { SetProperty(InvoiceNoProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> InvoiceDateProperty = RegisterProperty<DateTime>(c => c.InvoiceDate);
        public DateTime InvoiceDate
        {
            get { return GetProperty(InvoiceDateProperty); }
            set { SetProperty(InvoiceDateProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);
        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);
        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
        }

        #endregion Custom Validations

        #region Factory Methods

        public static Invoice NewInvoice()
        {
            return DataPortal.Create<Invoice>();
        }

        public static Invoice GetInvoice(Int64 id)
        {
            return DataPortal.Fetch<Invoice>(id);
        }

        public static Invoice GetInvoice(string invoiceNumber)
        {
            return DataPortal.Fetch<Invoice>(invoiceNumber);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortalFetch(SafeDataReader dr)
        {
            InvoiceId = dr.GetInt64("InvoiceId");
            DeliveryNo = dr.GetString("DeliveryNo");
            InvoiceNo = dr.GetString("InvoiceNo");
            InvoiceDate = dr.GetDateTime("InvoiceDate");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@InvoiceId", Id);
                    cmd.CommandText = "Select * from Invoice where InvoiceId=@InvoiceId";
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortalFetch(dr);
                        }
                    }
                }
            }
        }

        private void DataPortal_Fetch(string invoiceNumber)
        {
            CodeContract.Required<ArgumentException>(invoiceNumber.IsNotNullOrWhiteSpace(), "Invoice number is mandatory.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@InvoiceNo", invoiceNumber);
                    cmd.CommandText = "Select * from Invoice where InvoiceNo=@InvoiceNo";
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            DataPortalFetch(dr);
                        }
                    }
                }
            }
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@InvoiceId", InvoiceId);
                    cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                    cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                    cmd.Parameters.AddWithValue("@InvoiceDate", InvoiceDate);
                    cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    InvoiceId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [Invoice] \n");
            sb.Append("            ([DeliveryNo],[InvoiceNo],[InvoiceDate],[CreatedOn],[CreatedBy]) \n");
            sb.Append("VALUES      (@DeliveryNo,@InvoiceNo,@InvoiceDate,@CreatedOn,@CreatedBy )");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@InvoiceId", InvoiceId);
                    cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                    cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                    cmd.Parameters.AddWithValue("@InvoiceDate", InvoiceDate);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
           sb.Append("UPDATE [Invoice] \n");
           sb.Append("   SET [DeliveryNo] = @DeliveryNo \n");
           sb.Append("      ,[InvoiceNo] = @InvoiceNo \n");
           sb.Append("      ,[InvoiceDate] = @InvoiceDate \n");
            sb.Append(" WHERE InvoiceId=@InvoiceId");
            return sb.ToString();
        }

        #endregion Update

        #endregion Data Functions
    }
}