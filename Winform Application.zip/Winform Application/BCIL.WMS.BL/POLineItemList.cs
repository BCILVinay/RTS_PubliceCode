﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class POLineItemList : BusinessListBase<POLineItemList, ProductionOrderLineItem>
    {
        #region Factory Method

        public static POLineItemList GetPOLineItemList(Int64 POrderId)
        {
            return DataPortal.Fetch<POLineItemList>(POrderId);
        }

        #endregion Factory Method

        #region Data Functions

        #region Fetch All

        private void DataPortal_Fetch(Int64 POrderId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllPOSQL();
                    cm.Parameters.AddWithValue("@POId", POrderId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(ProductionOrderLineItem.GetProductionOrderLineItem(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllPOSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T3.MaterialBinCode,T2.MaterialDesc,T4.ToolingCode,T5.LineCode \n");
            sb.Append("FROM   ProductionOrderLineItem T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T.POId = T1.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN MaterialBin T3 ON T3.MaterialBinId = T.MaterialBinId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T4 ON T4.ToolingId = T2.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Line T5 ON T5.LineId = T.PPLine   \n");
            sb.Append("WHERE \n");
            sb.Append("  T.POId = @POId");
            return sb.ToString();
        }

        #endregion Fetch All


        #endregion Data Functions
    }
}