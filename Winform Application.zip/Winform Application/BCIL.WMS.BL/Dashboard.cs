﻿using BCIL.Utility;
using Csla;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Dashboard : CommandBase<Dashboard>
    {
        private DashboardSearchCriteria _criteria;
        private DashboardDataType _type;
        private DataTable putawayData = new DataTable("PutawayData");
        private DataTable productionData = new DataTable("ProductionData");
        private DataTable pickingData = new DataTable("PickingData");

        public Dashboard(DashboardSearchCriteria criteria, DashboardDataType type)
        {
            _criteria = criteria;
            _type = type;
            putawayData.Rows.Clear();
            productionData.Rows.Clear();
            pickingData.Rows.Clear();
        }

        public static DataTable GetPutawayData(DashboardSearchCriteria criteria, DashboardDataType type)
        {
            Dashboard dashboard = new Dashboard(criteria, type);
            return DataPortal.Execute(dashboard).putawayData;
        }

        public static DataTable GetPickingData(DashboardSearchCriteria criteria, DashboardDataType type)
        {
            Dashboard dashboard = new Dashboard(criteria, type);
            return DataPortal.Execute(dashboard).pickingData;
        }

        public static DataTable GetProductionData(DashboardSearchCriteria criteria, DashboardDataType type)
        {
            Dashboard dashboard = new Dashboard(criteria, type);
            return DataPortal.Execute(dashboard).productionData;
        }

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = GetSqlCommand(con.CreateCommand()))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        if (_type == DashboardDataType.Putaway)
                            da.Fill(putawayData);
                        if (_type == DashboardDataType.Picked)
                            da.Fill(pickingData);
                        if (_type == DashboardDataType.Production)
                            da.Fill(productionData);
                    }
                }
            }
        }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            switch (_type)
            {
                case DashboardDataType.Putaway:
                    return GetPutawaySqlCommand(cmd);

                case DashboardDataType.Picked:
                    return GetPickedSqlCommand(cmd);

                case DashboardDataType.Production:
                    return GetProductionSqlCommand(cmd);

                default:
                    throw new Exception();
            }
        }

        private SqlCommand GetProductionSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Row_number() \n");
            sb.Append("         OVER( \n");
            sb.Append("           ORDER BY (SELECT 1)) AS SNo,T6.LineCode,T1.POrderNo,T4.MaterialCode,T4.MaterialDesc,T5.ToolingCode,T2.Length AS Quantity,T2.Bundles AS NoOfBundle,Count(T.BundleId) AS BarcodePrinted \n");
            sb.Append("FROM   BundleHistory T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       INNER JOIN ProductionOrderLineItem T2 ON T2.POId = T.POrderId \n");
            sb.Append("       INNER JOIN Location T3 ON T3.LocationId = T.LocationId \n");
            sb.Append("       INNER JOIN Material T4 ON T4.MaterialId = T.MaterialId \n");
            sb.Append("       INNER JOIN Tooling T5 ON T5.ToolingId = T.ToolingId \n");
            sb.Append("       INNER JOIN Line T6 ON  T2.PPLine = T6.LineId \n");
            sb.Append("WHERE \n");
            sb.Append("  ( @SiteId = 0  OR T1.SiteId = @SiteId ) AND T.[BundleStatus] IN ( 0 ) \n");
            sb.Append("  AND (cast(convert(varchar, T.ChangeDate, 112) as datetime)) BETWEEN @FromDate AND @ToDate  \n");
            sb.Append("GROUP  BY \n");
            sb.Append("  T6.LineCode,T1.POrderNo,T4.MaterialCode,T4.MaterialDesc,T5.ToolingCode,T2.Length,T2.Bundles");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@FromDate", _criteria.FromDate);
            cmd.Parameters.AddWithValue("@ToDate", _criteria.ToDate);
            cmd.Parameters.AddWithValue("@SiteId", _criteria.SiteId);
            return cmd;
        }

        private SqlCommand GetPickedSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            //sb.Append(" select T4.DeliveryNo,T1.BundleCode,T3.POrderNo,T2.LocationName,T1.ChangeDate as PickedOn  from Picking T \n");
            //sb.Append(" inner join BundleHistory T1  on T.BundleId =T1.BundleId \n");
            //sb.Append(" inner join Location T2  on T2.LocationId=T1.LocationId \n");
            //sb.Append(" inner join ProductionOrder T3  on T3.POrderId =T1.POrderId \n");
            //sb.Append(" inner join PickList T4  on T.PicklistId =T4.PicklistId \n");
            //sb.Append(" WHERE  T3.SiteId = @SiteId and T1.BundleStatus = 1 \n");
            //sb.Append(" AND (cast(convert(varchar, T1.ChangeDate, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            sb.Append("select T1.LocationCode as LocationCode,count(T.BundleId) as PickedQuantity  from BundleHistory T    \n");
            sb.Append(" inner join Location T1  on T.LocationId=T1.LocationId \n");
            sb.Append(" inner join ProductionOrder T2  on T.POrderId =T2.POrderId \n");
            sb.Append(" WHERE  T2.SiteId = @SiteId and T.BundleStatus = 1 \n");
            sb.Append(" AND (cast(convert(varchar, T.ChangeDate, 112) as datetime)) BETWEEN @FromDate AND @ToDate \n");
            sb.Append("group by T1.LocationCode,T1.LocationName");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@FromDate", _criteria.FromDate);
            cmd.Parameters.AddWithValue("@ToDate", _criteria.ToDate);
            cmd.Parameters.AddWithValue("@SiteId", _criteria.SiteId);
            return cmd;
        }

        private SqlCommand GetPutawaySqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select T1.LocationCode as LocationCode,T3.MaterialCode,T3.MaterialDesc,count(T.BundleId) as PutawayQuantity  from BundleHistory T  \n");
            sb.Append(" inner join Location T1  on T.LocationId=T1.LocationId \n");
            sb.Append(" inner join ProductionOrder T2  on T.POrderId =T2.POrderId \n");
            sb.Append(" INNER JOIN Material T3 ON T3.MaterialId = T.MaterialId \n");
            sb.Append(" WHERE  T2.SiteId = @SiteId and T.BundleStatus = 3 \n");
            sb.Append(" AND (cast(convert(varchar, T.ChangeDate, 112) as datetime)) BETWEEN @FromDate AND @ToDate \n");
            sb.Append("group by T1.LocationCode,T1.LocationName,T3.MaterialCode,T3.MaterialDesc ");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@FromDate", _criteria.FromDate);
            cmd.Parameters.AddWithValue("@ToDate", _criteria.ToDate);
            cmd.Parameters.AddWithValue("@SiteId", _criteria.SiteId);
            return cmd;
        }
    }

    [Serializable]
    public class DashboardSearchCriteria
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int SiteId { get; set; }
    }

    [Serializable]
    public enum DashboardDataType
    {
        Putaway = 0,
        Production = 1,
        Picked = 2,
    }
}