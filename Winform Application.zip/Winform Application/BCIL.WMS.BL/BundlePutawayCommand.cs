﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class BulkBundleUpdateCommand : CommandBase<BulkBundleUpdateCommand>
    {
        #region Properties

        private Int64 LocationId { get; set; }
        private List<Int64> Bundles { get; set; }
        private int UpdatedBy { get; set; }
        private BundleStatus Status { get; set; }

        #endregion Properties

        #region Factory Methods

        public BulkBundleUpdateCommand(Int64 locationId, int updatedBy, List<Int64> bundles, BundleStatus status)
        {
            this.LocationId = locationId;
            this.Bundles = bundles;
            this.UpdatedBy = updatedBy;
            this.Status = status;
        }

        public static void BulkBundleUpdate(Int64 locationId, int updatedBy, List<Int64> bundles, BundleStatus Status)
        {
            BulkBundleUpdateCommand entity = new BulkBundleUpdateCommand(locationId, updatedBy, bundles, Status);
            DataPortal.Execute(entity);
        }

        #endregion Factory Methods

        #region Data Methods

        protected override void DataPortal_Execute()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL(Bundles);
                    cmd.Parameters.AddWithValue("@Status", Status);
                    cmd.Parameters.AddWithValue("@LocationId", LocationId);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL(List<long> bundles)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE Bundle \n");
            sb.Append("SET    LocationId = CASE WHEN @LocationId > 0 THEN @LocationId ELSE LocationId END, \n");
            sb.Append("       BundleStatus = CASE WHEN @Status > 0 THEN @Status ELSE BundleStatus END, \n");
            sb.Append("       UpdatedBy = @UpdatedBy, \n");
            sb.Append("       UpdatedOn = @UpdatedOn \n");
            sb.AppendFormat(" WHERE BundleId in ({0});", string.Join(",", bundles));
            return sb.ToString();
        }

        #endregion Data Methods
    }
}