﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class ToolingDVL : ReadOnlyListBase<ToolingDVL, Tooling>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static ToolingDVL GetToolingDVL()
        {
            return DataPortal.Fetch<ToolingDVL>();
        }

        public static ToolingDVL GetToolingDVL(ToolingsSearchCriteria criteria)
        {
            return DataPortal.Fetch<ToolingDVL>(criteria);
        }

        #endregion Factory Method

        #region Data Method

        private void DataPortal_Fetch()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllToolingSQL();
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            this.Add(Tooling.GetTooling(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        private string FetchAllToolingSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.LocationCode,T4.LineCode AS 'LineName',T5.LineCode AS 'LinePrefencesName'  \n");
            sb.Append("FROM   Tooling T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Location T3 ON T.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Line T4 ON T.LineId = T4.LineId \n");
            sb.Append("       INNER JOIN Line T5 ON T.LinePrefences = T5.LineId \n");
            return sb.ToString();
        }

        private void DataPortal_Fetch(ToolingsSearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = criteria.GetSqlCommand(cn.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Tooling.GetTooling(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        #endregion Data Method
    }

    [Serializable]
    public class ToolingsSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.LocationCode,T4.LineCode AS 'LineName',T5.LineCode AS 'LinePrefencesName'  \n");
            sb.Append("FROM   Tooling T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Location T3 ON T.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Line T4 ON T.LineId = T4.LineId \n");
            sb.Append("       INNER JOIN Line T5 ON T.LinePrefences = T5.LineId \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ToolingId");
            return cmd;
        }
    }

    [Serializable]
    public class ToolingDVLSearchCriteria : ToolingsSearchCriteria
    {
        public Int64 ToolingId { get; set; }
        public string ToolingCode { get; set; }

        public int LineId { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.LocationCode,T4.LineCode AS 'LineName',T5.LineCode AS 'LinePrefencesName'  \n");
            sb.Append("FROM   Tooling T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Location T3 ON T.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Line T4 ON T.LineId = T4.LineId \n");
            sb.Append("       INNER JOIN Line T5 ON T.LinePrefences = T5.LineId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @ToolingCode = '' OR T.ToolingCode LIKE '%' + @ToolingCode + '%' ) \n");
            sb.Append("       AND ( @ToolingId = 0 OR T.ToolingId = @ToolingId ) \n");
            sb.Append("       AND ( @LineId = 0 OR T.LineId = @LineId ) \n");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.ToolingId");
            cmd.Parameters.AddWithValue("@ToolingCode", ToolingCode ?? "");
            cmd.Parameters.AddWithValue("@ToolingId", ToolingId);
            cmd.Parameters.AddWithValue("@LineId", LineId);
            return cmd;
        }
    }
}