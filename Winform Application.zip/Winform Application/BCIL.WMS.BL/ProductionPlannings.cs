﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class ProductionPlannings : ReadOnlyListBase<ProductionPlannings, ProductionPlanning>
    {
        public long TotalRowCount { get; set; }

        public static ProductionPlannings GetProductionPlannings(ProductionPlanningSearchCriteria criteria)
        {
            return DataPortal.Fetch<ProductionPlannings>(criteria);
        }

        private void DataPortal_Fetch(ProductionPlanningSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            //this.Add(ProductionPlanning.GetProductionPlanning(dr));
                        }
                    }
                }
            }
        }
    }

    public class ProductionPlanningSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T1.SiteId = T.SiteTo \n");
            sb.Append("WHERE  1 = 1 \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.TransferId");
            return cmd;
        }
    }

    public class ProductionPlanningGenericSearchCriteria : ProductionPlanningSearchCriteria
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.SiteCode AS 'SiteFromCode' ,T2.SiteCode AS 'SiteToCode' \n");
            sb.Append("FROM   Transfer T \n");
            sb.Append("       LEFT OUTER JOIN Site T1 ON T1.SiteId = T.SiteFrom \n");
            sb.Append("	   LEFT OUTER JOIN Site T2 ON T1.SiteId = T.SiteTo \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append(" AND (cast(convert(varchar, T.CreatedOn, 112) as datetime)) BETWEEN @FromDate AND @ToDate");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.TransferId");
            cmd.Parameters.AddWithValue("@FromDate", DateFrom);
            cmd.Parameters.AddWithValue("@ToDate", DateTo);
            return cmd;
        }
    }
}