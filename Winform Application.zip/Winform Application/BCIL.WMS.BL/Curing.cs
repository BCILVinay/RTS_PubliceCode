﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Curing : MyBusinessBase<Curing>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> CuringIdProperty = RegisterProperty<Int64>(c => c.CuringId);

        public Int64 CuringId
        {
            get { return GetProperty(CuringIdProperty); }
            set { SetProperty(CuringIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> ItemIdProperty = RegisterProperty<Int64>(c => c.ItemId);

        public Int64 ItemId
        {
            get { return GetProperty(ItemIdProperty); }
            set { SetProperty(ItemIdProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CuringInProperty = RegisterProperty<DateTime>(c => c.CuringIn);

        public DateTime CuringIn
        {
            get { return GetProperty(CuringInProperty); }
            set { SetProperty(CuringInProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CuringOutProperty = RegisterProperty<DateTime>(c => c.CuringOut);

        public DateTime CuringOut
        {
            get { return GetProperty(CuringOutProperty); }
            set { SetProperty(CuringOutProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public static readonly PropertyInfo<bool> IsCuredProperty = RegisterProperty<bool>(c => c.IsCured);

        public bool IsCured
        {
            get { return GetProperty(IsCuredProperty); }
            set { SetProperty(IsCuredProperty, value); }
        }

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public KeyValue<Int64, string> Material { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
        }

        #endregion Custom Validations

        #region Factory Methods

        public static Curing NewCuring()
        {
            return DataPortal.Create<Curing>();
        }

        public static Curing GetCuring(Int64 curingId)
        {
            return DataPortal.Fetch<Curing>(curingId);
        }

        public static Curing GetCuring(SafeDataReader dr)
        {
            return DataPortal.Fetch<Curing>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            CuringId = dr.GetInt64("CuringId");
            ItemId = dr.GetInt64("ItemId");
            CuringIn = dr.GetDateTime("CuringIn");
            CuringOut = dr.GetDateTime("CuringOut");
            SiteId = dr.GetInt32("SiteId");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            IsCured = dr.GetBoolean("IsCured");
            Material = new KeyValue<long, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Curing Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@CuringId", CuringId);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T2.MaterialId,T2.MaterialCode \n");
            sb.Append("FROM   Curing T \n");
            sb.Append("       INNER JOIN Item T1 ON T.ItemId = T1.ItemId \n");
            sb.Append("       INNER JOIN Material T2 ON T1.MaterialId = T2.MaterialId \n");
            sb.Append("WHERE  T.CuringId = @CuringId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Curing already exists");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ItemId", ItemId);
                    cmd.Parameters.AddWithValue("@CuringIn", CuringIn);
                    cmd.Parameters.AddWithValue("@CuringOut", CuringOut);
                    cmd.Parameters.AddWithValue("@SiteId", SiteId);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@IsCured", IsCured);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    CuringId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@CuringId", CuringId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Curing \n");
            sb.Append("WHERE  CuringId = @CuringId \n");
            return sb.ToString();
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [Curing] \n");
            sb.Append("            ([ItemId],[CuringIn],[CuringOut],[SiteId],[CreatedBy],[UpdatedBy],[IsCured]) \n");
            sb.Append("VALUES      (@ItemId,@CuringIn,@CuringOut,@SiteId,@CreatedBy,@UpdatedBy,@IsCured)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@ItemId", ItemId);
                    cmd.Parameters.AddWithValue("@CuringIn", CuringIn);
                    cmd.Parameters.AddWithValue("@CuringOut", CuringOut);
                    cmd.Parameters.AddWithValue("@SiteId", SiteId);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@CuringId", CuringId);
                    cmd.Parameters.AddWithValue("@IsCured", IsCured);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [Curing] \n");
            sb.Append("SET    [ItemId] = @ItemId, \n");
            sb.Append("       [CuringIn] = @CuringIn, \n");
            sb.Append("       [CuringOut] = @CuringOut, \n");
            sb.Append("       [SiteId] = @SiteId, \n");
            sb.Append("       [CreatedBy] = @CreatedBy, \n");
            sb.Append("       [UpdatedBy] = @UpdatedBy, \n");
            sb.Append("       [IsCured] = @IsCured \n");
            sb.Append("WHERE  CuringId = @CuringId");
            return sb.ToString();
        }

        #endregion Update

        #endregion Data Functions
    }
}