﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Item : MyBusinessBase<Item>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ItemIdProperty = RegisterProperty<Int64>(c => c.ItemId);

        public Int64 ItemId
        {
            get { return GetProperty(ItemIdProperty); }
            set { SetProperty(ItemIdProperty, value); }
        }

        public static readonly PropertyInfo<string> ItemCodeProperty = RegisterProperty<string>(c => c.ItemCode);

        public string ItemCode
        {
            get { return GetProperty(ItemCodeProperty); }
            set { SetProperty(ItemCodeProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> BundleProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Bundle);

        public KeyValue<Int64, string> Bundle
        {
            get { return GetProperty(BundleProperty); }
            set { SetProperty(BundleProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> POrderIdProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.POrder);

        public KeyValue<Int64, string> POrder
        {
            get { return GetProperty(POrderIdProperty); }
            set { SetProperty(POrderIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<ItemStatus> ItemStatusProperty = RegisterProperty<ItemStatus>(c => c.ItemStatus);

        public ItemStatus ItemStatus
        {
            get { return GetProperty(ItemStatusProperty); }
            set { SetProperty(ItemStatusProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> ToolingProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Tooling);

        public KeyValue<Int64, string> Tooling
        {
            get { return GetProperty(ToolingProperty); }
            set { SetProperty(ToolingProperty, value); }
        }


        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> PrintedOnProperty = RegisterProperty<DateTime>(c => c.PrintedOn);

        public DateTime PrintedOn
        {
            get { return GetProperty(PrintedOnProperty); }
            set { SetProperty(PrintedOnProperty, value); }
        }

        public string MaterialDesc { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        public static Item NewItem()
        {
            return DataPortal.Create<Item>();
        }

        public static Item GetItem(int id)
        {
            return DataPortal.Fetch<Item>(id);
        }

        public static void DeleteItem(int id)
        {
            DataPortal.Delete<Item>(id);
        }

        public static Item GetItemData(SafeDataReader dr)
        {
            return DataPortal.Fetch<Item>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ItemId = dr.GetInt64("ItemId");
            ItemCode = dr.GetString("ItemCode");
            Bundle = new KeyValue<Int64, string>(dr.GetInt64("BundleId"), dr.GetString("BundleCode"));
            POrder = new KeyValue<Int64, string>(dr.GetInt64("POrderId"), dr.GetString("POrderNo"));
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            ItemStatus = (ItemStatus)dr.GetInt32("ItemStatus");
            Location = new KeyValue<Int64, string>(dr.GetInt64("LocationId"), dr.GetString("LocationCode"));
            Tooling = new KeyValue<Int64, string>(dr.GetInt64("ToolingId"), dr.GetString("ToolingCode"));
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            PrintedOn = dr.GetDateTime("PrintedOn");
            MaterialDesc = dr.GetString("MaterialDesc");
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ItemId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.LocationCode,T5.BundleCode \n");
            sb.Append("FROM   Item T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T4 ON T4.LocationId = T.LocationId \n");
            sb.Append("       LEFT OUTER JOIN Bundle T5 ON T5.BundleId = T.BundleId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.ItemId = @ItemId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
                cmd.Parameters.AddWithValue("@ItemId", ItemId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Item \n");
            sb.Append("WHERE  ItemCode = @ItemCode \n");
            sb.Append("       AND ( @ItemId = 0 OR ItemId <> @ItemId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Item already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
                    cmd.Parameters.AddWithValue("@BundleId", Bundle.Key);
                    cmd.Parameters.AddWithValue("@POrderId", POrder.Key);
                    cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                    cmd.Parameters.AddWithValue("@ItemStatus", ItemStatus);
                    cmd.Parameters.AddWithValue("@ToolingId", Tooling.Key);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@PrintedOn", DateTime.Now);
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    ItemId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Item] \n");
            sb.Append("            ([ItemCode],[BundleId],[POrderId],[MaterialId],[ItemStatus],[ToolingId],[LocationId],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[PrintedOn]) \n");
            sb.Append("VALUES      (@ItemCode,@BundleId,@POrderId,@MaterialId,@ItemStatus,@ToolingId,@LocationId,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@PrintedOn)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Item already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@ItemId", ItemId);
                    cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
                    cmd.Parameters.AddWithValue("@BundleId", Bundle.Key);
                    cmd.Parameters.AddWithValue("@POrderId", POrder.Key);
                    cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                    cmd.Parameters.AddWithValue("@ItemStatus", ItemStatus);
                    cmd.Parameters.AddWithValue("@ToolingId", Tooling.Key);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@PrintedOn", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Item] \n");
            sb.Append("SET    [ItemCode] = @ItemCode,[BundleId] = @BundleId,[POrderId] = @POrderId,[MaterialId] = @MaterialId,[ItemStatus] = @ItemStatus,[ToolingId] = @ToolingId,[LocationId] = @LocationId,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[PrintedOn] = @PrintedOn \n");
            sb.Append("WHERE \n");
            sb.Append("  ItemId = @ItemId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsActive = 0 \n");
            sb.Append("FROM   Material \n");
            sb.Append("WHERE  [MaterialId] = @MaterialId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}