﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Label : MyBusinessBase<Label>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> LabelIdProperty = RegisterProperty<Int64>(c => c.LabelId);

        public Int64 LabelId
        {
            get { return GetProperty(LabelIdProperty); }
            set { SetProperty(LabelIdProperty, value); }
        }

        public static readonly PropertyInfo<string> LabelCodeProperty = RegisterProperty<string>(c => c.LabelCode);

        public string LabelCode
        {
            get { return GetProperty(LabelCodeProperty); }
            set { SetProperty(LabelCodeProperty, value); }
        }

        public static readonly PropertyInfo<LabelType> LabelObjTypeProperty = RegisterProperty<LabelType>(c => c.LabelObjType);

        public LabelType LabelObjType
        {
            get { return GetProperty(LabelObjTypeProperty); }
            set { SetProperty(LabelObjTypeProperty, value); }
        }

        public static readonly PropertyInfo<Int64> LableObjTypeIdProperty = RegisterProperty<Int64>(c => c.LableObjTypeId);

        public Int64 LableObjTypeId
        {
            get { return GetProperty(LableObjTypeIdProperty); }
            set { SetProperty(LableObjTypeIdProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);
        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> LocationIdProperty = RegisterProperty<Int64>(c => c.LocationId);

        public Int64 LocationId
        {
            get { return GetProperty(LocationIdProperty); }
            set { SetProperty(LocationIdProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<Int32> CreatedByProperty = RegisterProperty<Int32>(c => c.CreatedBy);
        public Int32 CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Label()
        {
        }

        public static Label NewLabel()
        {
            return DataPortal.Create<Label>();
        }

        public static Label GetLabel(Int64 id)
        {
            return DataPortal.Fetch<Label>(id);
        }

        public static void DeleteLabel(Int64 id)
        {
            DataPortal.Delete<Label>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        public static Label GetLabelData(SafeDataReader dr)
        {
            Label label = new Label()
            {
                LabelId = dr.GetInt64("LabelId"),
                LabelCode = dr.GetString("LabelCode"),
                SiteId = dr.GetInt32("SiteId"),
                LocationId = dr.GetInt64("LocationId"),
                LabelObjType =(LabelType) dr.GetInt32("ObjectType"),
                LableObjTypeId = dr.GetInt64("ObjectTypeId"),
                CreatedOn = dr.GetDateTime("CreatedOn"),
                CreatedBy  = dr.GetInt32("CreatedBy"),
            };

            label.MarkOld();
            return label;
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LabelId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            LabelId = dr.GetInt64("LabelId");
                            LabelCode = dr.GetString("LabelCode");
                            LocationId = dr.GetInt64("LocationId");
                            LabelObjType = (LabelType)dr.GetInt32("ObjectType");
                            LableObjTypeId = dr.GetInt64("ObjectTypeId");
                            CreatedOn = dr.GetDateTime("CreatedOn");
                            CreatedOn = dr.GetDateTime("CreatedOn");
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Label T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("WHERE  LabelId = @LabelId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LabelCode", LabelCode);
                    cmd.Parameters.AddWithValue("@ObjectType", LabelObjType);
                    cmd.Parameters.AddWithValue("@ObjectTypeId", LableObjTypeId);
                    cmd.Parameters.AddWithValue("@SiteId", SiteId);
                    cmd.Parameters.AddWithValue("@LocationId", LocationId);
                    cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    LabelId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Label] \n");
            sb.Append("            ([LabelCode],[ObjectType],[ObjectTypeId],[SiteId],[LocationId],[CreatedOn],[CreatedBy]) \n");
            sb.Append("VALUES      (@LabelCode,@ObjectType,@ObjectTypeId,@SiteId,@LocationId,@CreatedOn,@CreatedBy)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@LabelId", LabelId);
                    cmd.Parameters.AddWithValue("@LabelCode", LabelCode);
                    cmd.Parameters.AddWithValue("@ObjectType", LabelObjType);
                    cmd.Parameters.AddWithValue("@ObjectTypeId", LableObjTypeId);
                    cmd.Parameters.AddWithValue("@SiteId", SiteId);
                    cmd.Parameters.AddWithValue("@LocationId", LocationId);
                    cmd.Parameters.AddWithValue("@CreatedOn", CreatedOn);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Label] \n");
            sb.Append("SET    [LabelCode] = @LabelCode,[ObjectType] = @ObjectType,[ObjectTypeId] = @ObjectTypeId,[LocationId] = @LocationId,[SiteId]=@SiteId \n");
            sb.Append("WHERE \n");
            sb.Append("  LabelId = @LabelId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(Int64 Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LabelId", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsActive = 0 \n");
            sb.Append("FROM   Label \n");
            sb.Append("WHERE  [LabelId] = @LabelId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}