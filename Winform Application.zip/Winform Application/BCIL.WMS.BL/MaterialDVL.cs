﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class MaterialDVL : ReadOnlyListBase<MaterialDVL, Material>
    {
        public long TotalRowCount { get; set; }

        #region Factory Method

        public static MaterialDVL GetMaterialDVL(MaterialSearchCriteria criteria)
        {
            return DataPortal.Fetch<MaterialDVL>(criteria);
        }

        public static MaterialDVL GetMaterialDVLByCodes(List<string> codes)
        {
            return DataPortal.Fetch<MaterialDVL>(new MaterialSearchCriteriaByCodes() { Codes = codes });
        }

        public static MaterialDVL GetMaterialDVLByIds(List<Int64> ids)
        {
            return DataPortal.Fetch<MaterialDVL>(new MaterialSearchCriteriaByIds() { MaterialIds = ids });
        }
        #endregion Factory Method

        #region Data Method

        private void DataPortal_Fetch(MaterialSearchCriteria criteria)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = criteria.GetSqlCommand(con.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        TotalRowCount = 0;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            if (TotalRowCount == 0) TotalRowCount = dr.GetInt64("TotalRows");
                            this.Add(Material.GetMaterial(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        #endregion Data Method
    }

    [Serializable]
    public class MaterialGenericSearchCriteria : MaterialSearchCriteria
    {
        public string MeterialCode { get; set; }
        public string MeterialDesc { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @MaterialCode = '' OR T.MaterialCode LIKE @MaterialCode + '%' ) \n");
            sb.Append("       AND ( @MaterialDesc = '' OR T.MaterialDesc LIKE '%' + @MaterialDesc + '%' ) \n");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            cmd.Parameters.AddWithValue("@MaterialCode", MeterialCode);
            cmd.Parameters.AddWithValue("@MaterialDesc", MeterialDesc);
            return cmd;
        }
    }

    [Serializable]
    public class MaterialSearchCriteriaByCodes : MaterialSearchCriteria
    {
        public List<string> Codes { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.AppendFormat("       AND T.MaterialCode in ('{0}') \n", string.Join("','", Codes));

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            return cmd;
        }
    }

    [Serializable]
    public class MaterialSearchCriteriaByIds : MaterialSearchCriteria
    {
        public List<Int64> MaterialIds { get; set; }

        public override SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.AppendFormat("       AND T.MaterialId in ({0}) \n", string.Join(",", MaterialIds));

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            return cmd;
        }
    }

    [Serializable]
    public class MaterialSearchCriteria
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 100;

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd )
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*, T3.ToolingName,T3.MaterialImagePrn,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName \n");
            sb.Append("FROM   Material T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Tooling T3 ON T.ToolingId = T3.ToolingId \n");
            sb.Append("WHERE  1 = 1 \n");

            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = Data.GetPagingSQL(sb.ToString(), PageNumber, PageSize, "T.MaterialId");
            return cmd;
        }
    }
}