﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Tooling : MyBusinessBase<Tooling>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ToolingIdProperty = RegisterProperty<Int64>(c => c.ToolingId);

        public Int64 ToolingId
        {
            get { return GetProperty(ToolingIdProperty); }
            set { SetProperty(ToolingIdProperty, value); }
        }

        public static readonly PropertyInfo<string> ToolingCodeProperty = RegisterProperty<string>(c => c.ToolingCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Tooling code is mandatory.")]
        [StringLength(50, ErrorMessage = "Tooling code should not exceed to 50 characters")]
        public string ToolingCode
        {
            get { return GetProperty(ToolingCodeProperty); }
            set { SetProperty(ToolingCodeProperty, value); }
        }

        public static readonly PropertyInfo<string> ToolingNameProperty = RegisterProperty<string>(c => c.ToolingName);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Tooling name is mandatory.")]
        [StringLength(50, ErrorMessage = "Tooling name should not exceed to 50 characters")]
        public string ToolingName
        {
            get { return GetProperty(ToolingNameProperty); }
            set { SetProperty(ToolingNameProperty, value); }
        }

        public static readonly PropertyInfo<decimal> ToolingSpeedProperty = RegisterProperty<decimal>(c => c.ToolingSpeed);

        [RequiredButNotDefault(ErrorMessage = "Tooling speed is mandatory.")]
        public decimal ToolingSpeed
        {
            get { return GetProperty(ToolingSpeedProperty); }
            set { SetProperty(ToolingSpeedProperty, value); }
        }

        public static readonly PropertyInfo<int> LineIdProperty = RegisterProperty<int>(c => c.LineId);

        [RequiredButNotDefault(ErrorMessage = "Line is mandatory.")]
        public int LineId
        {
            get { return GetProperty(LineIdProperty); }
            set { SetProperty(LineIdProperty, value); }
        }

        public static readonly PropertyInfo<int> LinePrefencesProperty = RegisterProperty<int>(c => c.LinePrefences);

        [RequiredButNotDefault(ErrorMessage = "Line preferences is mandatory.")]
        public int LinePrefences
        {
            get { return GetProperty(LinePrefencesProperty); }
            set { SetProperty(LinePrefencesProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        [RequiredButNotDefault(ErrorMessage = "Location is mandatory.")]
        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsImportedProperty = RegisterProperty<bool>(c => c.IsImported);

        public bool IsImported
        {
            get { return GetProperty(IsImportedProperty); }
            set { SetProperty(IsImportedProperty, value); }
        }

        public static readonly PropertyInfo<string> OtherInfoProperty = RegisterProperty<string>(c => c.OtherInfo);

        public string OtherInfo
        {
            get { return GetProperty(OtherInfoProperty); }
            set { SetProperty(OtherInfoProperty, value); }
        }

        public string LineName { get; set; }
        public string LinePrefencesName { get; set; }

        public string MaterialImagePrn { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Tooling()
        {
        }

        public static Tooling NewTooling()
        {
            return DataPortal.Create<Tooling>();
        }

        public static Tooling GetTooling(Int64 id)
        {
            return DataPortal.Fetch<Tooling>(id);
        }

        public static Tooling GetTooling(SafeDataReader dr)
        {
            return DataPortal.Fetch<Tooling>(dr);
        }

        public static Tooling GetToolingByCode(string code)
        {
            return DataPortal.Fetch<Tooling>(code);
        }

        public static void DeleteTooling(int id)
        {
            DataPortal.Delete<Tooling>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ToolingId = dr.GetInt64("ToolingId");
            ToolingName = dr.GetString("ToolingName");
            ToolingCode = dr.GetString("ToolingCode");
            ToolingSpeed = dr.GetDecimal("ToolingSpeed");
            Location = new KeyValue<Int64, string>(dr.GetInt64("LocationId"), dr.GetString("LocationCode"));
            LineId = dr.GetInt32("LineId");
            LinePrefences = dr.GetInt32("LinePrefences");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
            IsActive = dr.GetBoolean("IsActive");
            IsImported = dr.GetBoolean("IsImported");
            LineName = dr.GetString("LineName");
            LinePrefencesName = dr.GetString("LinePrefencesName");
            MaterialImagePrn = dr.GetString("MaterialImagePrn");
            OtherInfo = dr.GetString("OtherInfo");
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Tooling Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ToolingId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.LocationCode,T4.LineCode AS 'LineName',T5.LineCode AS 'LinePrefencesName'  \n");
            sb.Append("FROM   Tooling T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Location T3 ON T.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Line T4 ON T.LineId = T4.LineId \n");
            sb.Append("       INNER JOIN Line T5 ON T.LinePrefences = T5.LineId \n");
            sb.Append("WHERE  T.ToolingId = @ToolingId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string toolingCode)
        {
            CodeContract.Required<ArgumentException>(toolingCode.IsNotNullOrWhiteSpace(), "Tooling code is mandatory.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ToolingCode", toolingCode);
                    cmd.CommandText = FetchByCodeSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchByCodeSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS UpdatedByName,T3.LocationCode,T4.LineCode AS 'LineName',T5.LineCode AS 'LinePrefencesName'  \n");
            sb.Append("FROM   Tooling T \n");
            sb.Append("       INNER JOIN Employee T1 ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.UpdatedBy = T2.EmployeeId \n");
            sb.Append("       INNER JOIN Location T3 ON T.LocationId = T3.LocationId \n");
            sb.Append("       INNER JOIN Line T4 ON T.LineId = T4.LineId \n");
            sb.Append("       INNER JOIN Line T5 ON T.LinePrefences = T5.LineId \n");
            sb.Append("WHERE  T.ToolingCode = @ToolingCode");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@ToolingCode", ToolingCode);
                cmd.Parameters.AddWithValue("@LineId", LineId);
                cmd.Parameters.AddWithValue("@ToolingId", ToolingId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Tooling \n");
            sb.Append("WHERE  ToolingCode = @ToolingCode AND LineId = @LineId \n");
            sb.Append("       AND ( @ToolingId = 0 OR ToolingId <> @ToolingId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Tooling already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ToolingCode", ToolingCode);
                    cmd.Parameters.AddWithValue("@ToolingName", ToolingName);
                    cmd.Parameters.AddWithValue("@ToolingSpeed", ToolingSpeed);
                    cmd.Parameters.AddWithValue("@LineId", LineId);
                    cmd.Parameters.AddWithValue("@LinePrefences", LinePrefences);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@OtherInfo", OtherInfo);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    ToolingId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Tooling] \n");
            sb.Append("            ([ToolingCode],[ToolingName],[ToolingSpeed],[LineId],[LinePrefences],[LocationId],[IsActive],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[IsImported],[OtherInfo]) \n");
            sb.Append("VALUES      (@ToolingCode,@ToolingName,@ToolingSpeed,@LineId,@LinePrefences,@LocationId,@IsActive,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@IsImported,@OtherInfo)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Tooling already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@ToolingId", ToolingId);
                    cmd.Parameters.AddWithValue("@ToolingCode", ToolingCode);
                    cmd.Parameters.AddWithValue("@ToolingName", ToolingName);
                    cmd.Parameters.AddWithValue("@ToolingSpeed", ToolingSpeed);
                    cmd.Parameters.AddWithValue("@LineId", LineId);
                    cmd.Parameters.AddWithValue("@LinePrefences", LinePrefences);
                    cmd.Parameters.AddWithValue("@LocationId", Location.Key);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@IsImported", IsImported);
                    cmd.Parameters.AddWithValue("@OtherInfo", OtherInfo);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Tooling] \n");
            sb.Append("SET    [ToolingCode] = @ToolingCode,[ToolingName] = @ToolingName,[ToolingSpeed] = @ToolingSpeed,[LineId] = @LineId,[LinePrefences] = @LinePrefences,[LocationId] = @LocationId,[IsActive] = @IsActive,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy,[IsImported] = @IsImported,[OtherInfo] = @OtherInfo \n");
            sb.Append("WHERE \n");
            sb.Append("  ToolingId = @ToolingId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Tooling] \n");
            sb.Append("SET    [IsActive] = @IsActive,[UpdatedOn] = @UpdatedOn,[UpdatedBy] = @UpdatedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  ToolingId = @ToolingId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}