﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Csla;
using Csla.Data;
using System.Data.SqlClient;
using BCIL.Utility;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class TransferItems : BusinessListBase<TransferItems, TransferItem>
    {
        public static TransferItems GetTransferItems(Int64 TransferId)
        {
            return DataPortal.Fetch<TransferItems>(TransferId);
        }

        private void DataPortal_Fetch(Int64 TransferId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllTransferItems();
                    cm.Parameters.AddWithValue("@TransferId", TransferId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(TransferItem.GetTransferItem(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllTransferItems()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T2.MaterialCode,T2.MaterialId,T3.BundleCode \n");
            sb.Append("FROM   TransferItem T \n");
            sb.Append("       INNER JOIN Transfer T1 ON T1.TransferId = T.TransferId \n");
            sb.Append("       INNER JOIN Bundle T3 ON T3.BundleId = T.BundleId \n");
            sb.Append("       INNER JOIN Material T2 ON T2.MaterialId = T3.MaterialId \n");
            sb.Append("WHERE  T.TransferId = @TransferId");
            return sb.ToString();
        }
    }
}
