﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Receiving : MyBusinessBase<Receiving>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> ReceivingIdProperty = RegisterProperty<Int64>(c => c.ReceivingId);

        public Int64 ReceivingId
        {
            get { return GetProperty(ReceivingIdProperty); }
            set { SetProperty(ReceivingIdProperty, value); }
        }

        public static readonly PropertyInfo<string> DeliveryNoProperty = RegisterProperty<string>(c => c.DeliveryNo);

        public string DeliveryNo
        {
            get { return GetProperty(DeliveryNoProperty); }
            set { SetProperty(DeliveryNoProperty, value); }
        }

        public static readonly PropertyInfo<string> InvoiceNoProperty = RegisterProperty<string>(c => c.InvoiceNo);

        public string InvoiceNo
        {
            get { return GetProperty(InvoiceNoProperty); }
            set { SetProperty(InvoiceNoProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> ReceivedOnProperty = RegisterProperty<DateTime>(c => c.ReceivedOn);

        public static readonly PropertyInfo<int> SiteFromProperty = RegisterProperty<int>(c => c.SiteFrom);

        public int SiteFrom
        {
            get { return GetProperty(SiteFromProperty); }
            set { SetProperty(SiteFromProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteToProperty = RegisterProperty<int>(c => c.SiteTo);

        public int SiteTo
        {
            get { return GetProperty(SiteToProperty); }
            set { SetProperty(SiteToProperty, value); }
        }

        public DateTime ReceivedOn
        {
            get { return GetProperty(ReceivedOnProperty); }
            set { SetProperty(ReceivedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> ReceivedByProperty = RegisterProperty<int>(c => c.ReceivedBy);

        public int ReceivedBy
        {
            get { return GetProperty(ReceivedByProperty); }
            set { SetProperty(ReceivedByProperty, value); }
        }

        public static readonly PropertyInfo<ReceivingItems> ItemsProperty = RegisterProperty<ReceivingItems>(c => c.Items);

        public ReceivingItems Items
        {
            get { return GetProperty(ItemsProperty); }
            set { SetProperty(ItemsProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Receiving()
        {
        }

        public static Receiving NewReceiving()
        {
            return DataPortal.Create<Receiving>();
        }

        public static Receiving GetReceiving(Int64 receivingId)
        {
            return DataPortal.Fetch<Receiving>(receivingId);
        }

        public static Receiving GetReceiving(SafeDataReader dr)
        {
            return DataPortal.Fetch<Receiving>(dr);
        }

        public static void DeleteReceiving(Int64 receivingId)
        {
            DataPortal.Delete<Receiving>(receivingId);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            ReceivingId = dr.GetInt64("ReceivingId");
            DeliveryNo = dr.GetString("DeliveryNo");
            InvoiceNo = dr.GetString("InvoiceNo");
            SiteFrom = dr.GetInt32("SiteFrom");
            SiteTo = dr.GetInt32("SiteTo");
            ReceivedOn = dr.GetDateTime("ReceivedOn");
            ReceivedBy = dr.GetInt32("ReceivedBy");
            Items = ReceivingItems.GetReceivingItems(dr.GetInt64("ReceivingId"));
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@ReceivingId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT * \n");
            sb.Append("FROM   Receiving \n");
            sb.Append("WHERE  ReceivingId = @ReceivingId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                cmd.Parameters.AddWithValue("@ReceivingId", ReceivingId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Receiving \n");
            sb.Append("WHERE  InvoiceNo = @InvoiceNo \n");
            sb.Append("       AND ( @ReceivingId = 0 OR ReceivingId <> @ReceivingId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Invoice is already exist.");

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                        cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom);
                        cmd.Parameters.AddWithValue("@SiteTo", SiteTo);
                        cmd.Parameters.AddWithValue("@ReceivedOn", ReceivedOn);
                        cmd.Parameters.AddWithValue("@ReceivedBy", ReceivedBy);
                        cmd.CommandText = InsertSQL();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                        ReceivingId = Convert.ToInt64(cmd.ExecuteScalar());

                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.ReceivingId = ReceivingId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Receiving] \n");
            sb.Append("            ([DeliveryNo],[InvoiceNo],[SiteFrom],[SiteTo],[ReceivedOn],[ReceivedBy]) \n");
            sb.Append("VALUES      (@DeliveryNo,@InvoiceNo,@SiteFrom,@SiteTo,@ReceivedOn,@ReceivedBy)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new Exception("Invoice is already exist.");

                using (var transaction = con.BeginTransaction())
                {
                    using (var cmd = transaction.Connection.CreateCommand())
                    {
                        cmd.Transaction = transaction;
                        cmd.CommandType = System.Data.CommandType.Text;
                        cmd.CommandText = UpdateSQL();
                        cmd.Parameters.AddWithValue("@DeliveryNo", DeliveryNo);
                        cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                        cmd.Parameters.AddWithValue("@SiteFrom", SiteFrom);
                        cmd.Parameters.AddWithValue("@SiteTo", SiteTo);
                        cmd.Parameters.AddWithValue("@ReceivedOn", ReceivedOn);
                        cmd.Parameters.AddWithValue("@ReceivedBy", ReceivedBy);
                        cmd.ExecuteNonQuery();

                        if (Items.HaveItems())
                        {
                            foreach (var item in Items)
                            {
                                item.ReceivingId = ReceivingId;
                            }
                        }
                        FieldManager.UpdateChildren(this, transaction);
                    }
                    transaction.Commit();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Receiving] \n");
            sb.Append("SET    [DeliveryNo] = @DeliveryNo,[InvoiceNo] = @InvoiceNo,[SiteFrom] = @SiteFrom,[SiteTo] = @SiteTo,[ReceivedOn] = @ReceivedOn,[ReceivedBy] = @ReceivedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  RecevingId = @RecevingId");
            return sb.ToString();
        }

        #endregion Update

        #endregion Data Functions
    }
}