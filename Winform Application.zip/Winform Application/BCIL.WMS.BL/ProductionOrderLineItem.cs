﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ProductionOrderLineItem : MyBusinessBase<ProductionOrderLineItem>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> POLineItemIdProperty = RegisterProperty<Int64>(c => c.POLineItemId);

        public Int64 POLineItemId
        {
            get { return GetProperty(POLineItemIdProperty); }
            set { SetProperty(POLineItemIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> POProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.PO);

        public KeyValue<Int64, string> PO
        {
            get { return GetProperty(POProperty); }
            set { SetProperty(POProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<int> BundleQtyProperty = RegisterProperty<int>(c => c.BundleQty);

        public int BundleQty
        {
            get { return GetProperty(BundleQtyProperty); }
            set { SetProperty(BundleQtyProperty, value); }
        }

        public static readonly PropertyInfo<decimal> LengthProperty = RegisterProperty<decimal>(c => c.Length);

        public decimal Length
        {
            get { return GetProperty(LengthProperty); }
            set { SetProperty(LengthProperty, value); }
        }

        public static readonly PropertyInfo<string> UOMProperty = RegisterProperty<string>(c => c.UOM);

        public string UOM
        {
            get { return GetProperty(UOMProperty); }
            set { SetProperty(UOMProperty, value); }
        }

        public static readonly PropertyInfo<int> PPLineProperty = RegisterProperty<int>(c => c.PPLine);

        public int PPLine
        {
            get { return GetProperty(PPLineProperty); }
            set { SetProperty(PPLineProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> ChangeOnProperty = RegisterProperty<DateTime>(c => c.ChangeOn);

        public DateTime ChangeOn
        {
            get { return GetProperty(ChangeOnProperty); }
            set { SetProperty(ChangeOnProperty, value); }
        }

        public string MaterialDescription { get; set; }

        public string LineCode { get; set; }

        public string ToolingCode { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private ProductionOrderLineItem()
        {
        }

        public static void NewProductionOrderLineItem(EventHandler<DataPortalResult<ProductionOrderLineItem>> callback)
        {
            DataPortal.BeginCreate<ProductionOrderLineItem>(callback);
        }

        public static void GetProductionOrderLineItem(int id, EventHandler<DataPortalResult<ProductionOrderLineItem>> callback)
        {
            DataPortal.BeginFetch<ProductionOrderLineItem>(id, callback);
        }

        public static ProductionOrderLineItem NewProductionOrderLineItem()
        {
            return DataPortal.CreateChild<ProductionOrderLineItem>();
        }

        public static ProductionOrderLineItem GetProductionOrderLineItem(int id)
        {
            return DataPortal.FetchChild<ProductionOrderLineItem>(id);
        }

        public static ProductionOrderLineItem GetProductionOrderLineItem(SafeDataReader dr)
        {
            return DataPortal.FetchChild<ProductionOrderLineItem>(dr);
        }

        public static void DeleteProductionOrderLineItem(int id)
        {
            DataPortal.Delete<ProductionOrderLineItem>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void Child_Fetch(SafeDataReader dr)
        {
            POLineItemId = dr.GetInt64("POLineItemId");
            PO = new KeyValue<Int64, string>(dr.GetInt64("POId"), dr.GetString("POrderNo"));
            BundleQty = dr.GetInt32("Bundles");
            PPLine = dr.GetInt32("PPLine");
            Length = dr.GetDecimal("Length");
            Location = new KeyValue<Int64, string>(dr.GetInt64("MaterialBinId"), dr.GetString("MaterialBinCode"));
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            MaterialDescription = dr.GetString("MaterialDesc");
            UOM = dr.GetString("UOM");
            ChangeOn = dr.GetDateTime("ChangeOn");
            LineCode = dr.GetString("LineCode");
            ToolingCode = dr.GetString("ToolingCode");
        }

        private void Child_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@POLineItemId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            Child_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T3.MaterialBinCode,T2.MaterialDesc,T4.ToolingCode,T5.LineCode \n");
            sb.Append("FROM   ProductionOrderLineItem T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T.POId = T1.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN MaterialBin T3 ON T3.MaterialBinId = T.MaterialBinId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T4 ON T4.ToolingId = T2.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Line T5 ON T5.LineId = T.PPLine   \n");
            sb.Append("WHERE \n");
            sb.Append("  T.POLineItemId = @POLineItemId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected void Child_Insert(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@POId", PO.Key);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@Bundles", BundleQty);
                cmd.Parameters.AddWithValue("@MaterialBinId", Location.Key);
                cmd.Parameters.AddWithValue("@Length", Length);
                cmd.Parameters.AddWithValue("@UOM", UOM);
                cmd.Parameters.AddWithValue("@PPLine", PPLine);
                cmd.Parameters.AddWithValue("@ChangeOn", DateTime.Now);

                cmd.CommandText = InsertSQL();
                cmd.ExecuteNonQuery();
                cmd.CommandText = "SELECT IDENT_CURRENT('ProductionOrderLineItem');";
                POLineItemId = Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[ProductionOrderLineItem] \n");
            sb.Append("            ([POId],[MaterialId],[Bundles],[MaterialBinId],[Length],[UOM],[PPLine],[ChangeOn]) \n");
            sb.Append("VALUES      (@POId,@MaterialId,@Bundles,@MaterialBinId,@Length,@UOM,@PPLine,@ChangeOn)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected void Child_Update(object parentEntity, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = UpdateSQL();

                cmd.Parameters.AddWithValue("@POLineItemId", POLineItemId);
                cmd.Parameters.AddWithValue("@POId", PO.Key);
                cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                cmd.Parameters.AddWithValue("@Bundles", BundleQty);
                cmd.Parameters.AddWithValue("@MaterialBinId", Location.Key);
                cmd.Parameters.AddWithValue("@Length", Length);
                cmd.Parameters.AddWithValue("@UOM", UOM);
                cmd.Parameters.AddWithValue("@PPLine", PPLine);
                cmd.Parameters.AddWithValue("@ChangeOn", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[ProductionOrderLineItem] \n");
            sb.Append("SET    [POId] = @POId,[MaterialId] = @MaterialId,[Bundles] = @Bundles,[MaterialBinId] = @MaterialBinId,[Length] = @Length,[UOM] = @UOM,[PPLine] = @PPLine,[ChangeOn] = @ChangeOn \n");
            sb.Append("WHERE \n");
            sb.Append("  POLineItemId = @POLineItemId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void Child_Delete(Int64 POLineItemId, SqlTransaction transaction)
        {
            CodeContract.Required<ArgumentException>(transaction != null, "Database transaction should not be null.");
            using (var cmd = transaction.Connection.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@POLineItemId", POLineItemId);
                cmd.CommandText = DeleteSQL();
                cmd.ExecuteNonQuery();
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE FROM ProductionOrderLineItem \n");
            sb.Append("WHERE  POLineItemId = @POLineItemId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}