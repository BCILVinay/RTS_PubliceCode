﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;

namespace BCIL.WMS.BL
{
    public class Picking : MyBusinessBase<Picking>
    {
        #region Properties
        public static readonly PropertyInfo<Int64> PickingIdProperty = RegisterProperty<Int64>(c => c.PickingId);

        public Int64 PickingId
        {
            get { return GetProperty(PickingIdProperty); }
            set { SetProperty(PickingIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> PicklistIdProperty = RegisterProperty<Int64>(c => c.PicklistId);

        public Int64 PicklistId
        {
            get { return GetProperty(PicklistIdProperty); }
            set { SetProperty(PicklistIdProperty, value); }
        }

        public static readonly PropertyInfo<Int64> BundleIdProperty = RegisterProperty<Int64>(c => c.BundleId);

        public Int64 BundleId
        {
            get { return GetProperty(BundleIdProperty); }
            set { SetProperty(BundleIdProperty, value); }
        }

        public static readonly PropertyInfo<string> BundleCodeProperty = RegisterProperty<string>(c => c.BundleCode);
        public string BundleCode
        {
            get { return GetProperty(BundleCodeProperty); }
            set { SetProperty(BundleCodeProperty, value); }
        }


        public static readonly PropertyInfo<DateTime> PickedOnProperty = RegisterProperty<DateTime>(c => c.PickedOn);

        public DateTime PickedOn
        {
            get { return GetProperty(PickedOnProperty); }
            set { SetProperty(PickedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> PickedByProperty = RegisterProperty<int>(c => c.PickedBy);

        public int PickedBy
        {
            get { return GetProperty(PickedByProperty); }
            set { SetProperty(PickedByProperty, value); }
        }

        public static readonly PropertyInfo<Int32> SiteIdProperty = RegisterProperty<Int32>(c => c.SiteId);
        public Int32 SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);
        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<string> MaterialDescProperty = RegisterProperty<string>(c => c.MaterialDesc);
        public string MaterialDesc
        {
            get { return GetProperty(MaterialDescProperty); }
            set { SetProperty(MaterialDescProperty, value); }
        }


        #endregion

        #region Factory Methods
        public static Picking GetPicking(SafeDataReader dr)
        {
            return DataPortal.Fetch<Picking>(dr);
        }
        #endregion

        #region Data Functions
        private void DataPortal_Fetch(SafeDataReader dr)
        {
            BundleId = dr.GetInt64("BundleId");
            BundleCode = dr.GetString("BundleCode");
            PickingId = dr.GetInt64("PickingId");
            PicklistId = dr.GetInt64("PicklistId");
            PickedOn = dr.GetDateTime("PickedOn");
            PickedBy = dr.GetInt32("PickedBy");
            SiteId = dr.GetInt32("SiteId");
            Material = new KeyValue<long, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            MaterialDesc = dr.GetString("MaterialDesc");
        }
        #endregion
    }
}