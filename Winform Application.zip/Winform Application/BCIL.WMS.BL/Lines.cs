﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    public class Lines : BusinessBindingListBase<Lines, Line>
    {
        public static Lines GetLines(LinesSearchCriteria criteria)
        {
            return DataPortal.Fetch<Lines>(criteria);
        }

        private void DataPortal_Fetch(LinesSearchCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = criteria.GetSqlCommand(cn.CreateCommand()))
                {
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            Add(Line.GetLine(dr));
                        }
                    }
                }
            }
        }
    }

    public class LinesSearchCriteria
    {
        public int SiteId { get; set; }
        public Int64 LocationId { get; set; }

        public virtual SqlCommand GetSqlCommand(SqlCommand cmd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.LocationId,T3.ToolingCode \n");
            sb.Append("FROM   Line T \n");
            sb.Append("       INNER JOIN Location T1 ON T.LocationId = T1.LocationId \n");
            sb.Append("       INNER JOIN [Site] T2 ON T2.SiteId = T1.SiteId \n");
            sb.Append("       LEFT OUTER JOIN [Tooling] T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("WHERE  1 = 1 \n");
            sb.Append("       AND ( @SiteId = 0 OR T2.SiteId = @SiteId ) \n");
            sb.Append("       AND ( @LocationId = 0 OR T.LocationId = @LocationId ) \n");
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sb.ToString();
            cmd.Parameters.AddWithValue("@SiteId", SiteId);
            cmd.Parameters.AddWithValue("@LocationId", LocationId);
            return cmd;
        }
    }
}