﻿using BCIL.Utility;
using BCIL.WMS.BL.Enums;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class Bundle : MyBusinessBase<Bundle>
    {
        #region Properties

        public static readonly PropertyInfo<Int64> BundleIdProperty = RegisterProperty<Int64>(c => c.BundleId);

        public Int64 BundleId
        {
            get { return GetProperty(BundleIdProperty); }
            set { SetProperty(BundleIdProperty, value); }
        }

        public static readonly PropertyInfo<int> BundleSrNoProperty = RegisterProperty<int>(c => c.BundleSrNo);

        public int BundleSrNo
        {
            get { return GetProperty(BundleSrNoProperty); }
            set { SetProperty(BundleSrNoProperty, value); }
        }

        public static readonly PropertyInfo<string> BundleCodeProperty = RegisterProperty<string>(c => c.BundleCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Bundle code is mandatory.")]
        [StringLength(50, ErrorMessage = "Bundle code should not exceed to 50 characters")]
        public string BundleCode
        {
            get { return GetProperty(BundleCodeProperty); }
            set { SetProperty(BundleCodeProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> PoProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Po);

        public KeyValue<Int64, string> Po
        {
            get { return GetProperty(PoProperty); }
            set { SetProperty(PoProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> MaterialProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Material);

        public KeyValue<Int64, string> Material
        {
            get { return GetProperty(MaterialProperty); }
            set { SetProperty(MaterialProperty, value); }
        }

        public static readonly PropertyInfo<int> QtyProperty = RegisterProperty<int>(c => c.Qty);

        [RequiredButNotDefault(ErrorMessage = "Quantity is mandatory.")]
        public int Qty
        {
            get { return GetProperty(QtyProperty); }
            set { SetProperty(QtyProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> LocationProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Location);

        [RequiredButNotDefault(ErrorMessage = "Location is mandatory.")]
        public KeyValue<Int64, string> Location
        {
            get { return GetProperty(LocationProperty); }
            set { SetProperty(LocationProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int64, string>> ToolingProperty = RegisterProperty<KeyValue<Int64, string>>(c => c.Tooling);

        public KeyValue<Int64, string> Tooling
        {
            get { return GetProperty(ToolingProperty); }
            set { SetProperty(ToolingProperty, value); }
        }

        public static readonly PropertyInfo<BundleStatus> StatusProperty = RegisterProperty<BundleStatus>(c => c.Status);

        public BundleStatus Status
        {
            get { return GetProperty(StatusProperty); }
            set { SetProperty(StatusProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedOnProperty = RegisterProperty<DateTime>(c => c.CreatedOn);

        public DateTime CreatedOn
        {
            get { return GetProperty(CreatedOnProperty); }
            set { SetProperty(CreatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);

        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedOnProperty = RegisterProperty<DateTime>(c => c.UpdatedOn);

        public DateTime UpdatedOn
        {
            get { return GetProperty(UpdatedOnProperty); }
            set { SetProperty(UpdatedOnProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);

        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsConfirmedProperty = RegisterProperty<bool>(c => c.IsConfirmed);

        public bool IsConfirmed
        {
            get { return GetProperty(IsConfirmedProperty); }
            set { SetProperty(IsConfirmedProperty, value); }
        }

        public bool IsBrown { get; set; }

        public string MaterialDesc { get; set; }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Bundle()
        {
        }

        public static Bundle NewBundle()
        {
            return DataPortal.Create<Bundle>();
        }

        public static Bundle GetBundle(Int64 id)
        {
            return DataPortal.Fetch<Bundle>(id);
        }

        public static Bundle GetBundleByCode(string code)
        {
            return DataPortal.Fetch<Bundle>(code);
        }

        public static Bundle GetBundle(SafeDataReader dr)
        {
            return DataPortal.Fetch<Bundle>(dr);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            BundleId = dr.GetInt64("BundleId");
            BundleSrNo = dr.GetInt32("BundleSrNo");
            BundleCode = dr.GetString("BundleCode");
            Po = new KeyValue<Int64, string>(dr.GetInt64("POrderId"), dr.GetString("POrderNo"));
            Material = new KeyValue<Int64, string>(dr.GetInt64("MaterialId"), dr.GetString("MaterialCode"));
            Tooling = new KeyValue<Int64, string>(dr.GetInt64("ToolingId"), dr.GetString("ToolingCode"));
            Location = new KeyValue<long, string>(dr.GetInt64("LocationId"), dr.GetString("LocationCode"));
            Status = (BundleStatus)dr.GetInt32("BundleStatus");
            CreatedOn = dr.GetDateTime("CreatedOn");
            CreatedBy = dr.GetInt32("CreatedBy");
            UpdatedOn = dr.GetDateTime("UpdatedOn");
            UpdatedBy = dr.GetInt32("UpdatedBy");
            IsConfirmed = dr.GetBoolean("IsConfirmed");
            IsBrown = dr.GetBoolean("IsBrown");
            MaterialDesc = dr.GetString("MaterialDesc");
        }

        private void DataPortal_Fetch(Int64 Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@BundleId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T4.MaterialBinCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  T.BundleId = @BundleId and T.IsDeleted=0");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string code)
        {
            CodeContract.Required<ArgumentException>(code.IsNotNullOrWhiteSpace(), "Bundle Code is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@BundleCode", code);
                    cmd.CommandText = FetchSQLByCode();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            DataPortal_Fetch(dr);
                        }
                    }
                }
            }
        }

        private string FetchSQLByCode()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.POrderNo,T2.MaterialCode,T2.MaterialDesc,T3.ToolingCode,T5.LocationCode,T2.IsBrown \n");
            sb.Append("FROM   Bundle T \n");
            sb.Append("       INNER JOIN ProductionOrder T1 ON T1.POrderId = T.POrderId \n");
            sb.Append("       LEFT OUTER JOIN Material T2 ON T2.MaterialId = T.MaterialId \n");
            sb.Append("       LEFT OUTER JOIN Tooling T3 ON T3.ToolingId = T.ToolingId \n");
            sb.Append("       LEFT OUTER JOIN Location T5 ON T5.LocationId = T.LocationId \n");
            sb.Append("WHERE  T.BundleCode = @BundleCode and T.IsDeleted=0");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@BundleCode", BundleCode);
                cmd.Parameters.AddWithValue("@BundleId", BundleId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Bundle \n");
            sb.Append("WHERE  BundleCode = @BundleCode \n");
            sb.Append("       AND ( @BundleId = 0 OR BundleId <> @BundleId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Bundle already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = InsertSQL();

                    cmd.Parameters.AddWithValue("@BundleSrNo", BundleSrNo);
                    cmd.Parameters.AddWithValue("@BundleCode", BundleCode);
                    cmd.Parameters.AddWithValue("@POrderId", Po.Key);
                    cmd.Parameters.AddWithValue("@MaterialId", Material.Key);
                    cmd.Parameters.AddWithValue("@BundleStatus", Status);
                    cmd.Parameters.AddWithValue("@ToolingId", Tooling.Key);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.Parameters.AddWithValue("@IsDeleted", 0);
                    cmd.Parameters.AddWithValue("@LocationId", this.Location.Key);
                    cmd.Parameters.AddWithValue("@IsConfirmed", IsConfirmed);

                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    BundleId = Convert.ToInt64(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [Bundle] \n");
            sb.Append("            ([BundleSrNo],[BundleCode],[POrderId],[MaterialId],[BundleStatus],[ToolingId],[CreatedOn],[CreatedBy],[UpdatedOn],[UpdatedBy],[IsDeleted],[LocationId],[IsConfirmed]) \n");
            sb.Append("VALUES      (@BundleSrNo,@BundleCode,@POrderId,@MaterialId,@BundleStatus,@ToolingId,@CreatedOn,@CreatedBy,@UpdatedOn,@UpdatedBy,@IsDeleted,@LocationId,@IsConfirmed) \n");
            sb.Append("");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@BundleStatus", this.Status);
                    cmd.Parameters.AddWithValue("@ToolingId", this.Tooling.Key);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", this.UpdatedBy);
                    cmd.Parameters.AddWithValue("@BundleId", this.BundleId);
                    cmd.Parameters.AddWithValue("@LocationId", this.Location.Key);
                    cmd.Parameters.AddWithValue("@IsConfirmed", IsConfirmed);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [Bundle] \n");
            sb.Append("SET    [BundleStatus] = @BundleStatus, \n");
            sb.Append("       [ToolingId] = @ToolingId, \n");
            sb.Append("       [UpdatedOn] = @UpdatedOn, \n");
            sb.Append("       [UpdatedBy] = @UpdatedBy, \n");
            sb.Append("       [LocationId] = @LocationId, \n");
            sb.Append("       [IsConfirmed] = @IsConfirmed \n");
            sb.Append("WHERE  BundleId = @BundleId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        protected override void DataPortal_DeleteSelf()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@BundleId", BundleId);
                    cmd.Parameters.AddWithValue(" @UpdatedOn", UpdatedOn);
                    cmd.Parameters.AddWithValue(" @UpdatedBy", UpdatedBy);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE T \n");
            sb.Append("SET    T.IsDeleted = 1, \n");
            sb.Append("       T.[UpdatedOn] = @UpdatedOn, \n");
            sb.Append("       T.[UpdatedBy] = @UpdatedBy \n");
            sb.Append("FROM   Bundle \n");
            sb.Append("WHERE  [BundleId] = @BundleId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}