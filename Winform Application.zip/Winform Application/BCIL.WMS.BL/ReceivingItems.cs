﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.BL
{
    [Serializable]
    public class ReceivingItems : BusinessListBase<ReceivingItems, ReceivingItem>
    {
        public static ReceivingItems GetReceivingItems(Int64 receivingId)
        {
            return DataPortal.Fetch<ReceivingItems>(receivingId);
        }

        private void DataPortal_Fetch(Int64 receivingId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllTransferItems();
                    cm.Parameters.AddWithValue("@ReceivingId", receivingId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Add(ReceivingItem.GetReceivingItem(dr));
                        }
                    }
                }
            }
        }

        private string FetchAllTransferItems()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.* \n");
            sb.Append("FROM   ReceivingItem T \n");
            sb.Append("       INNER JOIN Receiving T1 ON T1.ReceivingId = T.ReceivingId \n");
            sb.Append("       INNER JOIN Site T2 ON T2.SiteId = T.SiteId \n");
            sb.Append("WHERE  T.ReceivingId = @ReceivingId");
            return sb.ToString();
        }
    }
}
