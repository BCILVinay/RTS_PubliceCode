﻿using System;

namespace BCIL.Administration.BL
{
    [Serializable]
    public class Node
    {
        #region Properties

        public int NodeId { get; set; }

        public string NodeCode { get; set; }

        public string NodeName { get; set; }

        public string ShortName { get; set; }

        public string ParentNode { get; set; }

        public string Description { get; set; }

        public int NodeBelongsTo { get; set; }

        public string ImageName { get; set; }

        public Int16 DisplayIndex { get; set; }

        public string Class { get; set; }

        public AppType AppType { get; set; }

        #endregion Properties
    }

    [Serializable]
    public enum AppType
    {
        All=0,
        Desktop = 1,
        MobileDevice = 2
    }
}