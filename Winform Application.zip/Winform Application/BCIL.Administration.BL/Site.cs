﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.Administration.BL
{
    [Serializable]
    public class Site : MyBusinessBase<Site>
    {
        #region Properties

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<string> SiteNameProperty = RegisterProperty<string>(c => c.SiteName);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Site name is mandatory.")]
        [StringLength(50, ErrorMessage = "Site name should not exceed to 50 characters", MinimumLength = 1)]
        public string SiteName
        {
            get { return GetProperty(SiteNameProperty); }
            set { SetProperty(SiteNameProperty, value); }
        }

        public static readonly PropertyInfo<string> SiteCodeProperty = RegisterProperty<string>(c => c.SiteCode);

        [Required(AllowEmptyStrings = false, ErrorMessage = "Site code is mandatory.")]
        [StringLength(50, ErrorMessage = "Site code should not exceed to 50 characters", MinimumLength = 1)]
        public string SiteCode
        {
            get { return GetProperty(SiteCodeProperty); }
            set { SetProperty(SiteCodeProperty, value); }
        }

        public static readonly PropertyInfo<string> DescriptionProperty = RegisterProperty<string>(c => c.Description);

        public string Description
        {
            get { return GetProperty(DescriptionProperty); }
            set { SetProperty(DescriptionProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);
        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedDateProperty = RegisterProperty<DateTime>(c => c.UpdatedDate);

        public DateTime UpdatedDate
        {
            get { return GetProperty(UpdatedDateProperty); }
            set { SetProperty(UpdatedDateProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

      

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Site() { }

        public static Site NewSite()
        {
            return DataPortal.Create<Site>();
        }

        public static Site GetSite(int id)
        {
            return DataPortal.Fetch<Site>(id);
        }

        public static Site GetSiteBySiteCode(string siteCode)
        {
            return DataPortal.Fetch<Site>(siteCode);
        }
        public static void DeleteSite(int id)
        {
            DataPortal.Delete<Site>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        public static Site GetSiteAsChild(SafeDataReader dr)
        {
            Site site = new Site()
            {
                SiteId = dr.GetInt32("SiteId"),
                SiteName = dr.GetString("SiteName"),
                SiteCode = dr.GetString("SiteCode"),
                Description = dr.GetString("Description"),
                IsActive = dr.GetBoolean("IsActive"),
                CreatedDate = dr.GetDateTime("CreatedDate"),
                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") },
                UpdatedDate = dr.GetDateTime("UpdatedDate"),
                UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") }
            };
            site.MarkOld();
            return site;
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            SiteId = dr.GetInt32("SiteId");
                            SiteName = dr.GetString("SiteName");
                            SiteCode = dr.GetString("SiteCode");
                            Description = dr.GetString("Description");
                            IsActive = dr.GetBoolean("IsActive");
                            CreatedDate = dr.GetDateTime("CreatedDate");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                            UpdatedDate = dr.GetDateTime("UpdatedDate");
                            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,CreatedBy.NAME AS CreatedByName,UpdatedBy.NAME AS UpdatedByName \n");
            sb.Append("FROM   [Site] T \n");
            sb.Append("       INNER JOIN Employee CreatedBy ON T.CreatedBy = CreatedBy.EmployeeId \n");
            sb.Append("       INNER JOIN Employee UpdatedBy ON T.CreatedBy = UpdatedBy.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  SiteId = @SiteId");
            return sb.ToString();
        }

        private void DataPortal_Fetch(string siteCode)
        {
            CodeContract.Required<ArgumentException>( siteCode.IsNotNullOrWhiteSpace() , "Site code is mandatory.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString)) {
                con.Open();
                using (var cmd = con.CreateCommand()) {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteCode", siteCode);
                    cmd.CommandText = FetchByCodeSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader())) {
                        if (dr.Read()) {
                            SiteId = dr.GetInt32("SiteId");
                            SiteName = dr.GetString("SiteName");
                            SiteCode = dr.GetString("SiteCode");
                            Description = dr.GetString("Description");
                            IsActive = dr.GetBoolean("IsActive");
                            CreatedDate = dr.GetDateTime("CreatedDate");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                            UpdatedDate = dr.GetDateTime("UpdatedDate");
                            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("UpdatedBy"), Value = dr.GetString("UpdatedByName") };
                        }
                    }
                }
            }
        }

        private string FetchByCodeSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,CreatedBy.NAME AS CreatedByName,UpdatedBy.NAME AS UpdatedByName \n");
            sb.Append("FROM   [Site] T \n");
            sb.Append("       INNER JOIN Employee CreatedBy ON T.CreatedBy = CreatedBy.EmployeeId \n");
            sb.Append("       INNER JOIN Employee UpdatedBy ON T.CreatedBy = UpdatedBy.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  SiteCode = @SiteCode");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@SiteCode", SiteCode);
                cmd.Parameters.AddWithValue("@SiteId", SiteId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Site \n");
            sb.Append("WHERE  SiteCode = @SiteCode \n");
            sb.Append("       AND ( @SiteId = 0 OR SiteId <> @SiteId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Plant already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteName", SiteName);
                    cmd.Parameters.AddWithValue("@SiteCode", SiteCode);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@UpdatedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);

                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    SiteId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [dbo].[Site] \n");
            sb.Append("            ([SiteName],[SiteCode],[Description],[IsActive],[CreatedDate],[CreatedBy],[UpdatedDate],[UpdatedBy]) \n");
            sb.Append("VALUES      (@SiteName,@SiteCode,@Description,@IsActive,@CreatedDate,@CreatedBy,@UpdatedDate,@UpdatedBy)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Plant already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@SiteId", SiteId);
                    cmd.Parameters.AddWithValue("@SiteName", SiteName);
                    cmd.Parameters.AddWithValue("@SiteCode", SiteCode);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@UpdatedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy.Key);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [dbo].[Site] \n");
            sb.Append("SET    [SiteName] = @SiteName,[SiteCode] = @SiteCode,[Description] = @Description,[IsActive] = @IsActive,[UpdatedDate] = @UpdatedDate,[UpdatedBy] = @UpdatedBy \n");
            sb.Append("WHERE \n");
            sb.Append("  SiteId = @SiteId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@SiteId", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [Site] \n");
            sb.Append("SET    [IsActive] = 0 \n");
            sb.Append("WHERE \n");
            sb.Append("  SiteId = @SiteId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}