﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.Administration.BL
{
    [Serializable]
    public class SiteList : ReadOnlyListBase<SiteList, Site>
    {
        #region Factory Method

        public static SiteList GetSites()
        {
            return DataPortal.Fetch<SiteList>();
        }

        #endregion Factory Method

        #region Data Functions

        #region Fetch All

        private void DataPortal_Fetch()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllRoleSQL();
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        this.IsReadOnly = false;
                        while (dr.Read())
                        {
                            this.Add(Site.GetSiteAsChild(dr));
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchAllRoleSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" Select T.*,CreatedBy.Name as CreatedByName,UpdatedBy.Name as UpdatedByName  from [Site] T \n");
            sb.Append("  inner join Employee CreatedBy on T.CreatedBy = CreatedBy.EmployeeId \n");
            sb.Append("  inner join Employee UpdatedBy on T.CreatedBy = UpdatedBy.EmployeeId");
            return sb.ToString();
        }

        #endregion Fetch All

        #endregion Data Functions
    }
}