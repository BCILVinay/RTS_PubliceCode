﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Csla;
using System.Data.SqlClient;
using BCIL.Utility;
using Csla.Data;

namespace BCIL.Administration.BL
{
    [Serializable]
    public class NodeDvl : ReadOnlyListBase<NodeDvl, Node>
    {
        public static async Task<NodeDvl> GetNodeDvlAsync()
        {
            return await DataPortal.FetchAsync<NodeDvl>();
        }

        public static NodeDvl GetNodes()
        {
            return DataPortal.Fetch<NodeDvl>();
        }

        private void DataPortal_Fetch()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = " SELECT * FROM   Node ";
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.IsReadOnly = false;
                            Node node = new Node();
                            node.NodeId = dr.GetInt32("NodeId");
                            node.NodeCode = dr.GetString("NodeCode");
                            node.NodeName = dr.GetString("Name");
                            node.ShortName = dr.GetString("ShortName");
                            node.Description = dr.GetString("Description");
                            node.ParentNode = dr.GetString("Parent");
                            node.Class = dr.GetString("Class");
                            node.ImageName = dr.GetString("ImageName");
                            node.NodeBelongsTo = dr.GetInt32("NodeBelongsTo");
                            node.DisplayIndex = dr.GetInt16("DisplayIndex");
                            node.AppType = (AppType)dr.GetInt16("AppType");
                            this.Add(node);
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }
    }
}
