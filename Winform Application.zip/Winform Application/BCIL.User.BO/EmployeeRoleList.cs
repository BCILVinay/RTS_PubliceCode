﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class EmployeeRoleList : ReadOnlyListBase<EmployeeRoleList, EmployeeRole>
    {
        #region Factory Methods

        private EmployeeRoleList()
        {
        }

        public static async Task<EmployeeRoleList> NewEmployeeRolesAsnc() => await DataPortal.CreateAsync<EmployeeRoleList>();

        public static async Task<EmployeeRoleList> GetEmployeeRolesAsync(int employeeId, int siteId) => await DataPortal.FetchAsync<EmployeeRoleList>(new EmployeeRoleCriteria() { EmployeeId = employeeId, SiteId = siteId });

        public static EmployeeRoleList NewEmployeeRoleList() => DataPortal.Create<EmployeeRoleList>();

        public static EmployeeRoleList GetEmployeeRoles(int employeeId, int siteId)
        {
            CodeContract.Required<ArgumentException>(employeeId > 0, "Employee id mandatory");
            CodeContract.Required<ArgumentException>(siteId > 0, "Site id is mandatory");
            return DataPortal.Fetch<EmployeeRoleList>(new EmployeeRoleCriteria() { EmployeeId = employeeId, SiteId = siteId });
        }

        #endregion Factory Methods


        #region Fetch All

        private void DataPortal_Fetch(EmployeeRoleCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cmd = cn.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = FetchAllEmployeeRoleSQL();
                    cmd.Parameters.Add(new SqlParameter("@EmployeeId", criteria.EmployeeId));
                    cmd.Parameters.Add(new SqlParameter("@SiteId", criteria.SiteId));
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            this.Add(EmployeeRole.GetEmployeeRole(dr));
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchAllEmployeeRoleSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME,T2.NAME AS CreatedByName \n");
            sb.Append("FROM   EmployeeRole T \n");
            sb.Append("       INNER JOIN Role T1 ON T.RoleId = T1.RoleId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.CreatedBy = T2.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  T.EmployeeId=@EmployeeId AND T.SiteId=@SiteId ");
            return sb.ToString();
        }

        #endregion Fetch All
    }

    [Serializable]
    public class EmployeeRoleCriteria : CriteriaBase<EmployeeRoleCriteria>
    {
        public int EmployeeId { get; set; }

        public int SiteId { get; set; }
    }
}