﻿using BCIL.Administration.BL;
using BCIL.User.BL;
using BCIL.User.BL.Permission;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class UserAuthenticateCommand : CommandBase<ValidatePasswordCommand>
    {
        private string _password;
        private string _loginId;

        public Employee LoginEmployee { get; private set; }

        public UserPermissionDvl UserPermissions { get; private set; }

        public bool IsSupperUser { get; private set; }

        public bool IsAuthenticated { get; set; }

        public static UserAuthenticateCommand Authenticate(string loginId, string password)
        {
            var userAuth = new UserAuthenticateCommand(loginId, password);
            return DataPortal.Execute(userAuth);
        }

        private UserAuthenticateCommand()
        { }

        private UserAuthenticateCommand(string loginId, string password)
        {
            _password = password;
            _loginId = loginId;
        }

        protected override void DataPortal_Execute()
        {
            string savedPwd, salt;
            int employeeId;

            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@loginId", _loginId);
                    cmd.CommandText = "SELECT  * FROM   [User]  WHERE   loginId = @loginId";

                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (!dr.Read()) throw new BCILException("Invalid login id");
  
                        savedPwd = dr.GetString("Pwd");
                        salt = dr.GetString("salt");
                        employeeId = dr.GetInt32("EmployeeId");
                        IsSupperUser = dr.GetBoolean("IsSupperUser");
                    }
                }
            }

            IsAuthenticated = Hash.Compare(_password, salt, savedPwd, Hash.DefaultHashType, Hash.DefaultEncoding);
            if(IsAuthenticated)
            {
                LoginEmployee = Employee.GetEmployee(employeeId);
            }
        }
    }
}
