﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class Employee : MyBusinessBase<Employee>
    {
        #region Properties

        public static readonly PropertyInfo<int> EmployeeIdProperty = RegisterProperty<int>(c => c.EmployeeId);

        public int EmployeeId
        {
            get { return GetProperty(EmployeeIdProperty); }
            set { SetProperty(EmployeeIdProperty, value); }
        }

        public static readonly PropertyInfo<string> NameProperty = RegisterProperty<string>(c => c.Name);

        [StringLength(100, MinimumLength = 1, ErrorMessage = "Employee name should not exceed 100 characters")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Employee name is mandatory")]
        public string Name
        {
            get { return GetProperty(NameProperty); }
            set { SetProperty(NameProperty, value); }
        }

        public static readonly PropertyInfo<string> EmailProperty = RegisterProperty<string>(c => c.Email);

        [Email(ErrorMessage = "Invalid email")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Employee email is mandatory")]
        public string Email
        {
            get { return GetProperty(EmailProperty); }
            set { SetProperty(EmailProperty, value); }
        }

        public static readonly PropertyInfo<string> AddressProperty = RegisterProperty<string>(c => c.Address);

        [StringLength(256, ErrorMessage = "Address should not exceed 256 characters")]
        public string Address
        {
            get { return GetProperty(AddressProperty); }
            set { SetProperty(AddressProperty, value); }
        }

        public static readonly PropertyInfo<string> Phone1Property = RegisterProperty<string>(c => c.Phone1);

        [Utility.Phone(ErrorMessage = "Invalid phone 1")]
        public string Phone1
        {
            get { return GetProperty(Phone1Property); }
            set { SetProperty(Phone1Property, value); }
        }

        public static readonly PropertyInfo<string> Phone2Property = RegisterProperty<string>(c => c.Phone2);

        [Utility.Phone(ErrorMessage = "Invalid phone 2")]
        public string Phone2
        {
            get { return GetProperty(Phone2Property); }
            set { SetProperty(Phone2Property, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);

        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedDateProperty = RegisterProperty<DateTime>(c => c.UpdatedDate);

        public DateTime UpdatedDate
        {
            get { return GetProperty(UpdatedDateProperty); }
            set { SetProperty(UpdatedDateProperty, value); }
        }

        public static readonly PropertyInfo<string> LoginIdProperty = RegisterProperty<string>(c => c.LoginId);

        public string LoginId
        {
            get { return GetProperty(LoginIdProperty); }
            set { SetProperty(LoginIdProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
        }

        #endregion Custom Validations

        #region Factory Methods

        private Employee()
        {
        }

        public static Employee NewEmployee() => DataPortal.Create<Employee>();

        public static async Task<Employee> NewEmployeeAsync() => await DataPortal.CreateAsync<Employee>();

        public static async Task<Employee> GetEmployeeAsync(int id) => await DataPortal.FetchAsync<Employee>(id);

        public static Employee GetEmployee(int id) => DataPortal.Fetch<Employee>(id);

        public static void DeleteEmployee(int id)
        {
            DataPortal.Delete<Employee>(id);
        }

        public static Employee GetEmployee(SafeDataReader dr)
        {
            Employee employee = new Employee()
            {
                EmployeeId = dr.GetInt32("EmployeeId"),
                Name = dr.GetString("Name"),
                Address = dr.GetString("Address"),
                Email = dr.GetString("Email"),
                Phone1 = dr.GetString("Phone1"),
                Phone2 = dr.GetString("Phone2"),
                IsActive = dr.GetBoolean("IsActive"),
                CreatedDate = dr.GetDateTime("CreatedDate"),
                LoginId = dr.GetString("LoginId"),
                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") },
                UpdatedDate = dr.GetDateTime("ModifiedDate"),
                UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("ModifiedBy"), Value = dr.GetString("updateByName") }
            };
            employee.MarkOld();
            return employee;
        }

        #endregion Factory Methods

        #region Data Functions

        private void DataPortal_Fetch(int employeeId)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchEmployeeSQLQueryString();
                    cm.Parameters.AddWithValue("@EmployeeId", employeeId);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            using (BypassPropertyChecks)
                            {
                                EmployeeId = dr.GetInt32("EmployeeId");
                                Name = dr.GetString("Name");
                                Address = dr.GetString("Address");
                                Email = dr.GetString("Email");
                                Phone1 = dr.GetString("Phone1");
                                Phone2 = dr.GetString("Phone2");
                                IsActive = dr.GetBoolean("IsActive");
                                CreatedDate = dr.GetDateTime("CreatedDate");
                                LoginId = dr.GetString("LoginId");
                                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                                UpdatedDate = dr.GetDateTime("ModifiedDate");
                                UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("ModifiedBy"), Value = dr.GetString("updateByName") };
                            }
                        }
                    }
                }
            }
        }

        private string FetchEmployeeSQLQueryString()
        {
            StringBuilder sb = new StringBuilder();
            sb
                .Append(" Select T.*,CreatedBy.Name as CreatedByName,UpdatedBy.Name as updateByName,T1.LoginId ")
                .Append(" from [Employee] T ")
                .Append(" inner join Employee CreatedBy on T.CreatedBy = CreatedBy.EmployeeId ")
                .Append(" inner join Employee UpdatedBy on T.ModifiedBy = UpdatedBy.EmployeeId ")
                .Append(" LEFT OUTER JOIN [user] T1 ON T.EmployeeId = T1.EmployeeId ")
                .Append(" where T.[EmployeeId]=@EmployeeId");
            return sb.ToString();
        }

        #region Insert

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   Employee \n");
            sb.Append("WHERE  Email = @Email \n");
            sb.Append("       AND ( @EmployeeId = 0 OR EmployeeId <> @EmployeeId )");
            return sb.ToString();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("User already exist");

                using (var cm = con.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = InsertEmployeeSQLString();

                    cm.Parameters.AddWithValue("@Name", Name);
                    cm.Parameters.AddWithValue("@Email", Email);
                    cm.Parameters.AddWithValue("@Address", Address);
                    cm.Parameters.AddWithValue("@Phone1", Phone1);
                    cm.Parameters.AddWithValue("@Phone2", Phone2);
                    cm.Parameters.AddWithValue("@IsActive", IsActive);
                    cm.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cm.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cm.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
                    cm.Parameters.AddWithValue("@ModifiedBy", UpdatedBy.Key);
                    cm.ExecuteNonQuery();
                    cm.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    EmployeeId = Convert.ToInt32(cm.ExecuteScalar());
                }
            }
        }

        private string InsertEmployeeSQLString()
        {
            StringBuilder sb = new StringBuilder();
            sb
                .Append(" INSERT INTO [Employee] ")
                .Append(" ([Name],[Email],[Address],[Phone1],[Phone2],[IsActive],[CreatedDate],[CreatedBy],[ModifiedBy],[ModifiedDate]) ")
                .Append(" VALUES ")
                .Append(" ( @Name, @Email,@Address,@Phone1,@Phone2, @IsActive ,@CreatedDate, @CreatedBy,@ModifiedBy,@ModifiedDate) ");
            return sb.ToString();
        }

        #endregion Insert

        protected override void DataPortal_Update()

        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("User already exist");

                using (var cm = con.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = "Update [employee] Set Name=@Name,Email=@Email,Address=@Address,Phone1=@Phone1,Phone2=@Phone2,IsActive=@IsActive,ModifiedDate=@ModifiedDate,ModifiedBy=@ModifiedBy where EmployeeId=@EmployeeId";
                    cm.Parameters.AddWithValue("@Name", Name);
                    cm.Parameters.AddWithValue("@Email", Email);
                    cm.Parameters.AddWithValue("@Address", Address);
                    cm.Parameters.AddWithValue("@Phone1", Phone1);
                    cm.Parameters.AddWithValue("@Phone2", Phone2);
                    cm.Parameters.AddWithValue("@IsActive", IsActive);
                    cm.Parameters.AddWithValue("@ModifiedBy", UpdatedBy.Key);
                    cm.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
                    cm.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                    cm.ExecuteNonQuery();
                }
            }
        }

        private void DataPortal_Delete(int id)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = "Update employee set IsActive=0 where [employeeId]=@employeeId";
                    cm.Parameters.AddWithValue("@employeeId", id);
                    cm.ExecuteNonQuery();
                }
            }
        }

        #endregion Data Functions
    }
}