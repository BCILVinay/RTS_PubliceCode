﻿using BCIL.Administration.BL;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class User : MyBusinessBase<User>
    {
        #region Properties
        public static readonly PropertyInfo<int> UserIdProperty = RegisterProperty<int>(c => c.UserId);
        public int UserId
        {
            get { return GetProperty(UserIdProperty); }
            set { SetProperty(UserIdProperty, value); }
        }

        public static readonly PropertyInfo<int> EmployeeIdProperty = RegisterProperty<int>(c => c.EmployeeId);
        [Required(AllowEmptyStrings = false, ErrorMessage = "Employee id is mandatory")]
        public int EmployeeId
        {
            get { return GetProperty(EmployeeIdProperty); }
            set { SetProperty(EmployeeIdProperty, value); }
        }

        public static readonly PropertyInfo<string> EmployeeNameProperty = RegisterProperty<string>(c => c.EmployeeName);
        public string EmployeeName
        {
            get { return GetProperty(EmployeeNameProperty); }
            set { SetProperty(EmployeeNameProperty, value); }
        }

        public static readonly PropertyInfo<string> LoginIdProperty = RegisterProperty<string>(c => c.LoginId);
        [Required(AllowEmptyStrings =false, ErrorMessage ="Login id is mandatory")]
        public string LoginId
        {
            get { return GetProperty(LoginIdProperty); }
            set { SetProperty(LoginIdProperty, value); }
        }

        public static readonly PropertyInfo<string> PasswordProperty = RegisterProperty<string>(c => c.Password);
        [Required(AllowEmptyStrings = false, ErrorMessage = "Password is mandatory")]
        public string Password
        {
            private get { return GetProperty(PasswordProperty); }
            set { SetProperty(PasswordProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);
        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);
        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

        public static readonly PropertyInfo<int> UpdatedByProperty = RegisterProperty<int>(c => c.UpdatedBy);
        public int UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedDateProperty = RegisterProperty<DateTime>(c => c.UpdatedDate);
        public DateTime UpdatedDate
        {
            get { return GetProperty(UpdatedDateProperty); }
            set { SetProperty(UpdatedDateProperty, value); }
        }

        public bool IsSupperUser
        {
            get;
        }
        #endregion

        #region Factory Methods
        public static User NewUser() => DataPortal.Create<User>();

        public static User GetUser(int employeeId)
        {
            CodeContract.Required<ArgumentException>(employeeId > 0, "Employee is mandatory.");
            return DataPortal.Fetch<User>(employeeId);
        }

        #endregion

        #region
        public bool ValidPasword(string password)
        {
            return ValidatePasswordCommand.IsValid(UserId, password);
        }

        #endregion

        #region Data Methods

        private void DataPortal_Fetch(int employeeId)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "SELECT  T.*,T1.NAME FROM   [User] T INNER JOIN [Employee] T1 ON T.EmployeeId = T1.EmployeeId WHERE   T1.EmployeeId = @EmployeeId";
                    cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            UserId = dr.GetInt32("UserId");
                            EmployeeId = employeeId;
                            EmployeeName = dr.GetString("Name");
                            LoginId = dr.GetString("LoginId");
                        }
                    }
                }
            }
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                string salt = GetCompanySalt(con);
                if (IsUserExists(con)) throw new BCILException("Login already exists.");
                if (IsLoginIdExists(con)) throw new BCILException("Login id already exists.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                    cmd.Parameters.AddWithValue("@LoginId", LoginId);
                    cmd.Parameters.AddWithValue("@Pwd", Hash.Get(Password, salt, Hash.DefaultHashType, Hash.DefaultEncoding));
                    cmd.Parameters.AddWithValue("@Salt", salt);
                    cmd.Parameters.AddWithValue("@IsSupperUser", false);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy);
                    cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy );
                    cmd.CommandText = InserSql();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    UserId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private bool IsUserExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                cmd.CommandText = "SELECT  count(1) FROM   [User] T INNER JOIN [Employee] T1 ON T.EmployeeId = T1.EmployeeId WHERE   T1.EmployeeId = @EmployeeId";
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private bool IsLoginIdExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                cmd.Parameters.AddWithValue("@loginId", LoginId);
                cmd.CommandText = "SELECT  count(1) FROM   [User] T INNER JOIN [Employee] T1 ON T.EmployeeId = T1.EmployeeId WHERE   T1.EmployeeId <> @EmployeeId and T.LoginId=@loginId";
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string GetCompanySalt(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT Salt FROM  Company ";
                return (string)cmd.ExecuteScalar();
            }
        }

        private string GetUserSalt(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@UserId", UserId);
                cmd.CommandText = "SELECT Salt FROM [User] where userid=@UserId ";
                return (string)cmd.ExecuteScalar();
            }
        }

        private string InserSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [USER] \n");
            sb.Append("            (EmployeeId,LoginId,Pwd,Salt,IsSupperUser,CreatedBy,CreatedOn,UpdatedBy,UpdatedOn) \n");
            sb.Append("VALUES      (@EmployeeId,@LoginId,@Pwd,@Salt,@IsSupperUser,@CreatedBy,@CreatedOn,@UpdatedBy,@UpdatedOn)");
            return sb.ToString();
        }

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsLoginIdExists(con)) throw new BCILException("Login id already exists.");

                string salt = GetUserSalt(con);

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@LoginId", LoginId);
                    cmd.Parameters.AddWithValue("@Userid", UserId);
                    cmd.Parameters.AddWithValue("@Pwd", Hash.Get(Password, salt, Hash.DefaultHashType, Hash.DefaultEncoding));
                    cmd.Parameters.AddWithValue("@UpdatedOn", DateTime.Now);
                    cmd.Parameters.AddWithValue("@UpdatedBy", UpdatedBy);
                    cmd.CommandText = UpdateSql();
                    cmd.ExecuteNonQuery();
                }
            }
        }
        private string UpdateSql()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Update [USER] Set\n");
            sb.Append(" Pwd=@Pwd, ");
            sb.Append(" LoginId=@LoginId, ");
            sb.Append(" UpdatedBy=@UpdatedBy, ");
            sb.Append(" UpdatedOn=@UpdatedOn ");
            sb.Append(" where Userid=@Userid ");
            return sb.ToString();
        }

        protected override void DataPortal_DeleteSelf()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.CommandText = "Delete user where UserId=@UserId";
                    cmd.ExecuteNonQuery();
                }
            }
        }
        #endregion
    }

    public class ValidatePasswordCommand : CommandBase<ValidatePasswordCommand>
    {
        public string _password;
        private int _userId;
        private bool _isValid;

        public static bool IsValid(int userId, string password)
        {
            var person = new ValidatePasswordCommand(userId, password);
            return DataPortal.Execute(person)._isValid;
        }

        private ValidatePasswordCommand()
        { }

        public ValidatePasswordCommand(int userId, string password)
        {
            _password = password;
            _userId = userId;
        }
        protected override void DataPortal_Execute()
        {
            string savedPwd, salt;
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@UserId", _userId);
                    cmd.CommandText = "SELECT  * FROM   [User]  WHERE   UserId = @UserId";

                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        savedPwd = dr.GetString("Pwd");
                        salt = dr.GetString("salt");
                    }
                }
            }

            _isValid = Hash.Compare(_password, salt, savedPwd, Hash.DefaultHashType, Hash.DefaultEncoding);
        }
    }
}
