﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class EmployeeRole : BusinessBase<EmployeeRole>
    {
        #region Properties

        public static readonly PropertyInfo<int> EmployeeRoleIdProperty = RegisterProperty<int>(c => c.EmployeeRoleId);

        public int EmployeeRoleId
        {
            get { return GetProperty(EmployeeRoleIdProperty); }
            set { SetProperty(EmployeeRoleIdProperty, value); }
        }

        public static readonly PropertyInfo<int> EmployeeIDProperty = RegisterProperty<int>(c => c.EmployeeID);

        [RequiredButNotDefault(ErrorMessage = "Employee is mandatory")]
        public int EmployeeID
        {
            get { return GetProperty(EmployeeIDProperty); }
            set { SetProperty(EmployeeIDProperty, value); }
        }

        public static readonly PropertyInfo<int> RoleIdProperty = RegisterProperty<int>(c => c.RoleId);

        [RequiredButNotDefault(ErrorMessage = "Role is mandatory")]
        public int RoleId
        {
            get { return GetProperty(RoleIdProperty); }
            set { SetProperty(RoleIdProperty, value); }
        }

        public static readonly PropertyInfo<string> RoleNameProperty = RegisterProperty<string>(c => c.RoleName);

        public string RoleName
        {
            get { return GetProperty(RoleNameProperty); }
            set { SetProperty(RoleNameProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);

        [RequiredButNotDefault(ErrorMessage = "Site is mandatory")]
        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);

        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedDateProperty = RegisterProperty<DateTime>(c => c.UpdatedDate);

        public DateTime UpdatedDate
        {
            get { return GetProperty(UpdatedDateProperty); }
            set { SetProperty(UpdatedDateProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            //BusinessRules.AddRule<ClassName>(CodeProperty, (x) => { return x.Property.Length > 0; }, "ClassName's Property should not be null");
        }

        public void MarkAsClean()
        {
            this.MarkClean();
        }

        public void MarkAsNew()
        {
            this.MarkNew();
        }

        public void MarkAsOld()
        {
            this.MarkOld();
        }
        #endregion Custom Validations

        #region Factory Methods

        public static void NewEmployeeRole(EventHandler<DataPortalResult<EmployeeRole>> callback)
        {
            DataPortal.BeginCreate<EmployeeRole>(callback);
        }

        public static void GetEmployeeRole(int id, EventHandler<DataPortalResult<EmployeeRole>> callback)
        {
            DataPortal.BeginFetch<EmployeeRole>(id, callback);
        }

        public static async Task<EmployeeRole> NewEmployeeRoleAsync()
        {
            return await DataPortal.CreateAsync<EmployeeRole>();
        }

        public static async Task<EmployeeRole> GetEmployeeRoleAsync(int id)
        {
            return await DataPortal.FetchAsync<EmployeeRole>(id);
        }

        public static EmployeeRole NewEmployeeRole()
        {
            return DataPortal.Create<EmployeeRole>();
        }

        public static EmployeeRole GetEmployeeRole(int id)
        {
            return DataPortal.Fetch<EmployeeRole>(id);
        }

        public static void DeleteEmployeeRole(int id)
        {
            DataPortal.Delete<EmployeeRole>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        public static EmployeeRole GetEmployeeRole(SafeDataReader dr)
        {
            EmployeeRole empRole = new EmployeeRole()
            {
                EmployeeID = dr.GetInt32("EmployeeId"),
                EmployeeRoleId = dr.GetInt32("EmployeeRoleId"),
                RoleId = dr.GetInt32("RoleId"),
                RoleName = dr.GetString("Name"),
                SiteId = dr.GetInt32("SiteId"),
                CreatedDate = dr.GetDateTime("CreatedDate"),
                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") }
            };
            empRole.MarkOld();
            return empRole;
        }
        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@EmployeeRoleId", Id);
                    cmd.CommandText = FetchSQL();
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            EmployeeID = dr.GetInt32("EmployeeId");
                            EmployeeRoleId = dr.GetInt32("EmployeeRoleId");
                            RoleId = dr.GetInt32("RoleId");
                            RoleName = dr.GetString("Name");
                            SiteId = dr.GetInt32("SiteId");
                            CreatedDate = dr.GetDateTime("CreatedDate");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME,T2.NAME AS CreatedByName \n");
            sb.Append("FROM   EmployeeRole T \n");
            sb.Append("       INNER JOIN Role T1 ON T.RoleId = T1.RoleId \n");
            sb.Append("       INNER JOIN Employee T2 ON T.CreatedBy = T2.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  EmployeeRoleId = @EmployeeRoleId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.Add(new SqlParameter("@EmployeeId", EmployeeID));
                    cmd.Parameters.Add(new SqlParameter("@RoleId", RoleId));
                    cmd.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cmd.Parameters.Add(new SqlParameter("@CreatedBy", CreatedBy.Key));
                    cmd.Parameters.Add(new SqlParameter("@CreatedDate", DateTime.Now));
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    EmployeeRoleId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO EmployeeRole \n");
            sb.Append("            (EmployeeId,RoleId,SiteId,CreatedBy,CreatedDate) \n");
            sb.Append("VALUES      (@EmployeeId,@RoleId,@SiteId,@CreatedBy,@CreatedDate)");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.Add(new SqlParameter("@EmployeeId", EmployeeID));
                    cmd.Parameters.Add(new SqlParameter("@RoleId", RoleId));
                    cmd.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cmd.Parameters.Add(new SqlParameter("@EmployeeRoleId", EmployeeRoleId));
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder varname1 = new StringBuilder();
            varname1.Append("UPDATE EmployeeRole \n");
            varname1.Append("SET    EmployeeId = @EmployeeId, \n");
            varname1.Append("       RoleId = @RoleId, \n");
            varname1.Append("       SiteId = @SiteId \n");
            varname1.Append("WHERE  EmployeeRoleId = @EmployeeRoleId");
            return varname1.ToString();
        }

        #endregion Update

        #region Delete

   
        
        protected override void DataPortal_DeleteSelf()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                 using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@EmployeeRoleId", EmployeeRoleId);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE EmployeeRole \n");
            sb.Append("WHERE  EmployeeRoleId = @EmployeeRoleId");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}



