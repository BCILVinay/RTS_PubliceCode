﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class EmployeeDVL : ReadOnlyListBase<EmployeeDVL, Employee>
    {
        public Int64 TotalRecords { get; private set; }

        public void AddEmployee(Employee employee)
        {
            IsReadOnly = false;
            Add(employee);
            IsReadOnly = true;
        }

        public static EmployeeDVL GetEmployees(int pageNumber, int pageSize)
        {
            CodeContract.Required<ArgumentException>(pageNumber > 0, "Page number should be greater than zero");
            CodeContract.Required<ArgumentException>(pageSize > 0, "Page size is should be greater than zero");
            return DataPortal.Fetch<EmployeeDVL>(new EmployeeDVLSearchCriteria() { PageNumber = pageNumber, PageSize = pageSize });
        }

        private void DataPortal_Fetch(EmployeeDVLSearchCriteria crit)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllEmployeeSQLQueryString();
                    cm.Parameters.Add(new SqlParameter("@page", crit.PageNumber));
                    cm.Parameters.Add(new SqlParameter("@pageSize", crit.PageSize));
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.IsReadOnly = false;
                            this.Add(Employee.GetEmployee(dr));
                            TotalRecords = dr.GetInt64("TotalRows");
                        }
                        this.IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchAllEmployeeSQLQueryString()
        {
            StringBuilder sb = new StringBuilder();
            sb
            .Append("WITH RowConstrainedResult \n")
            .Append("     AS ( \n")
            .Append(" SELECT Row_number() OVER(ORDER BY T.EmployeeId desc) AS RowNum ")
            .Append(" , T.*,CreatedBy.Name as CreatedByName,UpdatedBy.Name as updateByName,T1.LoginId ")
            .Append(" FROM  [Employee] T ")
            .Append(" inner join Employee CreatedBy on T.CreatedBy = CreatedBy.EmployeeId ")
            .Append(" inner join Employee UpdatedBy on T.ModifiedBy = UpdatedBy.EmployeeId ")
            .Append(" LEFT OUTER JOIN [user] T1 ON T.EmployeeId = T1.EmployeeId ")
            .Append(" ) \n")
            .Append("SELECT *, (SELECT Max(RowNum) \n")
            .Append("          FROM   RowConstrainedResult) AS 'TotalRows' \n")
            .Append("FROM   RowConstrainedResult \n")
            .Append("WHERE  RowNum > ( @page - 1 ) * @pageSize AND RowNum <= ( @page - 1 ) * @pageSize + @pageSize \n")
            .Append("ORDER  BY RowNum");
            return sb.ToString();
        }
    }

    public class EmployeeDVLSearchCriteria:CriteriaBase <EmployeeDVLSearchCriteria>
    {
        public int PageNumber { get; set; }

        public int PageSize { get; set; }
    }
}
