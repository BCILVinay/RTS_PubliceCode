﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Enums
{
    [Serializable]
    public enum PermissionType
    {
        None = 0,
        ReadOnly = 1,
        All = 2,
        Any = 3
    }

   
}
