﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Enums
{
    [Serializable]
    public enum NodeType
    {
        Common = 0,
        Store = 1,
        Warehouse = 2
    }
}
