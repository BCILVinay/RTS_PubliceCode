﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Data.SqlClient;
using System.Text;

namespace BCIL.User.BL
{
    [Serializable]
    public class RoleDVL : ReadOnlyListBase<RoleDVL, Role>
    {
        #region Factory Method

        public static RoleDVL GetRoles()
        {
            return DataPortal.Fetch<RoleDVL>();
        }

        #region Fetch All

        #region Functions

        public void AddRole(Role role)
        {
            this.IsReadOnly = false;
            this.Add(role);
            this.IsReadOnly = true;
        }

        #endregion Functions

        private void DataPortal_Fetch()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllRoleSQL();
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            this.Add(Role.GetRole(dr));
                        }
                    }
                    IsReadOnly = true;
                }
            }
        }

        private string FetchAllRoleSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb
                .Append(" Select T.*,CreatedBy.Name as CreatedByName,UpdatedBy.Name as updateByName ")
                .Append(" from [Role] T ")
                .Append(" inner join Employee CreatedBy on T.CreatedBy = CreatedBy.EmployeeId ")
                .Append(" inner join Employee UpdatedBy on T.ModifiedBy = UpdatedBy.EmployeeId ");

            return sb.ToString();
        }

        #endregion Fetch All

        #endregion Factory Method
    }
}