﻿using BCIL.User.BL.Permission;
using BCIL.Utility;
using Csla;
using Csla.Data;
using Csla.Rules;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL
{
    [Serializable]
    public class Role : MyBusinessBase<Role>
    {
        #region Properties

        public static readonly PropertyInfo<int> RoleIdProperty = RegisterProperty<int>(c => c.RoleId);

        public int RoleId
        {
            get { return GetProperty(RoleIdProperty); }
            set { SetProperty(RoleIdProperty, value); }
        }

        public static readonly PropertyInfo<string> NameProperty = RegisterProperty<string>(c => c.Name);

        [Required(ErrorMessage = "Role name is mandatory.")]
        [StringLength(100, ErrorMessage = "Role name should not exceed 100 characters")]
        public string Name
        {
            get { return GetProperty(NameProperty); }
            set { SetProperty(NameProperty, value); }
        }

        public static readonly PropertyInfo<string> DescriptionProperty = RegisterProperty<string>(c => c.Description);

        [StringLength(255, ErrorMessage = "Role description should not exceed 255 characters")]
        public string Description
        {
            get { return GetProperty(DescriptionProperty); }
            set { SetProperty(DescriptionProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsActiveProperty = RegisterProperty<bool>(c => c.IsActive);

        public bool IsActive
        {
            get { return GetProperty(IsActiveProperty); }
            set { SetProperty(IsActiveProperty, value); }
        }

        public static readonly PropertyInfo<List<RolePermission>> PermissionsProperty = RegisterProperty<List<RolePermission>>(c => c.Permissions);

        public List<RolePermission> Permissions
        {
            get { return GetProperty(PermissionsProperty); }
            set { SetProperty(PermissionsProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);

        public static readonly PropertyInfo<KeyValue<Int32, string>> CreatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.CreatedBy);

        public KeyValue<Int32, string> CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

        public static readonly PropertyInfo<KeyValue<Int32, string>> UpdatedByProperty = RegisterProperty<KeyValue<Int32, string>>(c => c.UpdatedBy);

        public KeyValue<Int32, string> UpdatedBy
        {
            get { return GetProperty(UpdatedByProperty); }
            set { SetProperty(UpdatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> UpdatedDateProperty = RegisterProperty<DateTime>(c => c.UpdatedDate);

        public DateTime UpdatedDate
        {
            get { return GetProperty(UpdatedDateProperty); }
            set { SetProperty(UpdatedDateProperty, value); }
        }

        #endregion Properties

        #region Custom Validations

        protected override void AddBusinessRules()
        {
            base.AddBusinessRules();
            BusinessRules.AddRule<Role>(CreatedByProperty, (x) => { return x.CreatedBy.Key > 0; }, "Created by is mandatory");
            BusinessRules.AddRule<Role>(UpdatedByProperty, (x) => { return x.UpdatedBy.Key > 0; }, "Updated by is mandatory");
        }

        #endregion Custom Validations

        #region Factory Methods

        private Role()
        {
            this.IsActive = true;
        }

        public static void NewRole(EventHandler<DataPortalResult<Role>> callback)
        {
            DataPortal.BeginCreate<Role>(callback);
        }

        public static void GetRole(int id, EventHandler<DataPortalResult<Role>> callback)
        {
            DataPortal.BeginFetch<Role>(id, callback);
        }

        public static async Task<Role> NewRoleAsync()
        {
            return await DataPortal.CreateAsync<Role>();
        }

        public static async Task<Role> GetRoleAsync(int id)
        {
            return await DataPortal.FetchAsync<Role>(id);
        }

        public static Role NewRole()
        {
            return DataPortal.Create<Role>();
        }

        public static Role GetRole(int id)
        {
            return DataPortal.Fetch<Role>(id);
        }

        public static void DeleteRole(int id)
        {
            DataPortal.Delete<Role>(id);
        }

        #endregion Factory Methods

        #region Data Functions

        #region Fetch

        public static Role GetRole(SafeDataReader dr)
        {
            Role role = new Role()
            {
                RoleId = dr.GetInt32("RoleId"),
                Name = dr.GetString("Name"),
                Description = dr.GetString("Description"),
                CreatedDate = dr.GetDateTime("CreatedDate"),
                CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") },
                UpdatedDate = dr.GetDateTime("ModifiedDate"),
                UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("ModifiedBy"), Value = dr.GetString("updateByName") },
                IsActive = dr.GetBoolean("IsActive")
            };
            role.MarkOld();
            return role;
        }

        private void DataPortal_Fetch(int Id)
        {
            CodeContract.Required<ArgumentException>(Id > 0, "Id is required for fetch.");
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = FetchSQL();
                    cmd.Parameters.AddWithValue("@RoleId", Id);
                    using (SafeDataReader dr = new SafeDataReader(cmd.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            RoleId = dr.GetInt32("RoleId");
                            Name = dr.GetString("Name");
                            Description = dr.GetString("Description");
                            CreatedDate = dr.GetDateTime("CreatedDate");
                            CreatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("CreatedBy"), Value = dr.GetString("CreatedByName") };
                            UpdatedDate = dr.GetDateTime("ModifiedDate");
                            UpdatedBy = new KeyValue<Int32, string>() { Key = dr.GetInt32("ModifiedBy"), Value = dr.GetString("updateByName") };
                            IsActive = dr.GetBoolean("IsActive");
                        }
                    }
                }
            }
        }

        private string FetchSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.*,T1.NAME AS CreatedByName,T2.NAME AS updateByName \n");
            sb.Append("FROM   Role T \n");
            sb.Append("       INNER JOIN Employee T1 \n");
            sb.Append("               ON T.CreatedBy = T1.EmployeeId \n");
            sb.Append("       INNER JOIN Employee T2 \n");
            sb.Append("               ON T.ModifiedBy = T2.EmployeeId \n");
            sb.Append("WHERE \n");
            sb.Append("  RoleId = @RoleId");
            return sb.ToString();
        }

        #endregion Fetch

        #region Insert

        protected override void DataPortal_Insert()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Role is already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@Name", Name);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreatedBy", CreatedBy.Key);
                    cmd.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@ModifiedBy", UpdatedBy.Key);
                    cmd.CommandText = InsertSQL();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    RoleId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private bool IsExists(SqlConnection con)
        {
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@RoleId", RoleId);
                cmd.CommandText = ExistSQL();
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private string ExistSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Count(1) \n");
            sb.Append("FROM   [Role] \n");
            sb.Append("WHERE  NAME = @Name \n");
            sb.Append("       AND ( @RoleId = 0 OR RoleId <> @RoleId )");
            return sb.ToString();
        }

        private string InsertSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb
                .Append(" INSERT INTO [Role] ")
                .Append(" ([Name],[Description],[IsActive],[CreatedDate],[CreatedBy],[ModifiedBy],[ModifiedDate]) ")
                .Append(" VALUES ")
                .Append(" ( @Name, @Description, @IsActive, @CreatedDate, @CreatedBy,@ModifiedBy,@ModifiedDate) ");
            return sb.ToString();
        }

        #endregion Insert

        #region Update

        protected override void DataPortal_Update()
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();

                if (IsExists(con)) throw new BCILException("Role is already exist.");

                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = UpdateSQL();
                    cmd.Parameters.AddWithValue("@Name", Name);
                    cmd.Parameters.AddWithValue("@Description", Description);
                    cmd.Parameters.AddWithValue("@IsActive", IsActive);
                    cmd.Parameters.AddWithValue("@ModifiedBy", UpdatedBy.Key);
                    cmd.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@RoleId", RoleId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string UpdateSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [Role] \n");
            sb.Append("SET    NAME = @Name, \n");
            sb.Append("       Description = @Description, \n");
            sb.Append("       IsActive = @IsActive, \n");
            sb.Append("       ModifiedDate = @ModifiedDate, \n");
            sb.Append("       ModifiedBy = @ModifiedBy \n");
            sb.Append("WHERE  RoleId = @RoleId");
            return sb.ToString();
        }

        #endregion Update

        #region Delete

        private void DataPortal_Delete(int Id)
        {
            using (SqlConnection con = new SqlConnection(AppData.SQLConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.Parameters.AddWithValue("@RoleId", Id);
                    cmd.CommandText = DeleteSQL();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private string DeleteSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Update Role set IsActive=0 where [RoleId]=@RoleId \n");
            return sb.ToString();
        }

        #endregion Delete

        #endregion Data Functions
    }
}