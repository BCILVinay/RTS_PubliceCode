﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class NodeData:BusinessBase<NodeData>
    {
        public static readonly PropertyInfo<int> NodeIdProperty = RegisterProperty<int>(c => c.NodeId);
        [RequiredButNotDefault(ErrorMessage = "Node id mandatory")]
        public int NodeId
        {
            get { return GetProperty(NodeIdProperty); }
            set { SetProperty(NodeIdProperty, value); }
        }

        public static readonly PropertyInfo<string> NameProperty = RegisterProperty<string>(c => c.Name);
        [Required(ErrorMessage = "Node name is mandatory.")]
        public string Name
        {
            get { return GetProperty(NameProperty); }
            set { SetProperty(NameProperty, value); }
        }

        public static readonly PropertyInfo<string> CodeProperty = RegisterProperty<string>(c => c.Code);
        public string Code
        {
            get { return GetProperty(CodeProperty); }
            set { SetProperty(CodeProperty, value); }
        }

        public static readonly PropertyInfo<string> ParentCodeProperty = RegisterProperty<string>(c => c.ParentCode);
        public string ParentCode
        {
            get { return GetProperty(ParentCodeProperty); }
            set { SetProperty(ParentCodeProperty, value); }
        }

        public static readonly PropertyInfo<int> NodeBelongsToProperty = RegisterProperty<int>(c => c.NodeBelongsTo);
        public int NodeBelongsTo
        {
            get { return GetProperty(NodeBelongsToProperty); }
            set { SetProperty(NodeBelongsToProperty, value); }
        }

        public void MarkAsClean()
        {
            this.MarkClean();
        }

        public void MarkAsOld()
        {
            this.MarkClean();
        }

        public void MarkAsNew()
        {
            MarkNew();
        }
    }
}
