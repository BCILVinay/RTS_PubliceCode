﻿using BCIL.Administration.BL;
using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class UserPermissionDvl : ReadOnlyListBase<UserPermissionDvl, UserPermission>
    {
        public static async Task<UserPermissionDvl> GetUserPermissionsAsync(int employeeId, int siteId)
        {
            CodeContract.Required<ArgumentException>(employeeId > 0, "Employee id is mandatory");
            CodeContract.Required<ArgumentException>(siteId > 0, "Site id is mandatory");
            return await DataPortal.FetchAsync<UserPermissionDvl>(new UserPermissionSearchCriteria() { EmployeeId = employeeId, SiteId = siteId });
        }

        public static UserPermissionDvl GetUserPermissions(int employeeId, int siteId, AppType appType)
        {
            CodeContract.Required<ArgumentException>(employeeId > 0, "Employee id is mandatory");
            CodeContract.Required<ArgumentException>(siteId > 0, "Site id is mandatory");
            return DataPortal.Fetch<UserPermissionDvl>(new UserPermissionSearchCriteria() { EmployeeId = employeeId, SiteId = siteId,AppType=appType });
        }

        private void DataPortal_Fetch(UserPermissionSearchCriteria crit)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {

                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = EmployeePermissionQuery();
                    cm.Parameters.AddWithValue("@EmployeeId", crit.EmployeeId);
                    cm.Parameters.AddWithValue("@SiteId", crit.SiteId);
                    cm.Parameters.AddWithValue("@AppType", crit.AppType);
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            UserPermission permission = new UserPermission();
                            permission.NodeId = dr.GetInt32("NodeId");
                            permission.NodeCode = dr.GetString("NodeCode");
                            permission.ParentCode = dr.GetString("Parent");
                            permission.NodeBelongsTo = dr.GetInt32("NodeBelongsTo");
                            permission.Permission = (PermissionType)dr.GetInt32("Permission");
                            permission.SiteId = dr.GetInt32("SiteId");
                            this.Add(permission);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private string EmployeePermissionQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.NodeId,T3.NodeCode,T3.Parent,T3.NodeBelongsTo,T.SiteId,Max(T.Permission) Permission \n");
            sb.Append("FROM   RolePermission T \n");
            sb.Append("       INNER JOIN [EmployeeRole] T1 ON T1.RoleId = T.RoleId AND T.SiteId =@SiteId \n");
            sb.Append("       INNER JOIN [Site] T2 ON T1.SiteId = T2.SiteId \n");
            sb.Append("       INNER JOIN Node T3 ON T3.NodeId = T.NodeId AND T3.AppType=@AppType \n");
            sb.Append("WHERE  T1.EmployeeId = @EmployeeId \n");
            sb.Append("       AND T1.SiteId = @SiteId \n");
            sb.Append("       AND T.Permission > 0 \n");
            sb.Append("       AND NOT EXISTS (SELECT 1 \n");
            sb.Append("                       FROM   EmployeePermission T5 \n");
            sb.Append("                       WHERE  T5.EmployeeId = @EmployeeId \n");
            sb.Append("                              AND T5.SiteId = @SiteId \n");
            sb.Append("                              AND T5.NodeId = T.NodeId) \n");
            sb.Append("GROUP  BY T.NodeId,T3.NodeCode,T3.Parent,T3.NodeBelongsTo,T.SiteId \n");
            sb.Append("UNION ALL \n");
            sb.Append("SELECT T.NodeId,T2.NodeCode,T2.Parent,T2.NodeBelongsTo,T.SiteId,CASE T.IsRestricted WHEN 1 THEN 0 ELSE T.Permission END AS Permission \n");
            sb.Append("FROM   EmployeePermission T \n");
            sb.Append("       INNER JOIN [Site] T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("       INNER JOIN Node T2 ON T2.NodeId = T.NodeId  AND T2.AppType=@AppType \n");
            sb.Append("WHERE  T.EmployeeId = @EmployeeId \n");
            sb.Append("       AND T.SiteId = @SiteId \n");

            return sb.ToString();
        }
    }


    public class UserPermission
    {
        public int NodeId { get; set; }

        public string NodeCode { get; set; }

        public string ParentCode { get; set; }

        public int NodeBelongsTo { get; set; }

        public PermissionType Permission { get; set; }

        public int SiteId { get; set; }
    }

    public class UserPermissionSearchCriteria
    {
        public int EmployeeId { get; set; }
        public int SiteId { get; set; }

        public AppType AppType { get; set; }
    }
}
