﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class RolePermissionList : ReadOnlyListBase<RolePermissionList, RolePermission>
    {
        #region Factory Methods
        private RolePermissionList() { }

        public static RolePermissionList GetRolePermissionList(int roleId, int siteID)
        {
            CodeContract.Required<BCILException>(roleId > 0, "Role id should be greater than zero");
            CodeContract.Required<BCILException>(siteID > 0, "Site id should be greater than zero");
            return DataPortal.Fetch<RolePermissionList>(new RolePermissionsCriteria() { RoleIds = new List<int>() { roleId }, SiteId = siteID });
        }

        public static RolePermissionList GetRolePermissionList(List<int> roleIds, int siteID)
        {
            CodeContract.Required<BCILException>(roleIds.Count() > 0, "Role ids required");
            CodeContract.Required<BCILException>(siteID > 0, "Site id should be greater than zero");
            return DataPortal.Fetch<RolePermissionList>(new RolePermissionsCriteria() { RoleIds = roleIds, SiteId = siteID });
        }

        #endregion

        #region Data Functions

        private string FetchAllRolesSQLQueryString(List<int> roles)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.NodeId,T.Parent, T.NodeCode, T.NAME AS NodeName,T.NodeBelongsTo, \n");
            sb.Append("       T1.* \n");
            sb.Append("FROM   Node T \n");
            sb.AppendFormat("    LEFT OUTER JOIN [RolePermission] T1 ON T.NodeId = T1.NodeId and T1.RoleId in ({0}) and T1.SiteId=@SiteId \n", string.Join(",", roles));
            return sb.ToString();
        }

        protected void DataPortal_Fetch(RolePermissionsCriteria crit)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchAllRolesSQLQueryString(crit.RoleIds);
                    cm.Parameters.Add(new SqlParameter("@SiteId", crit.SiteId));
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            var rolePermission = RolePermission.GetRolePermission(dr);
                            Add(rolePermission);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        #endregion
    }

    [Serializable]
    public class RolePermissionsCriteria : CriteriaBase<RolePermissionsCriteria>
    {
        public List<int> RoleIds { get; set; }

        public int SiteId { get; set; }
    }
}
