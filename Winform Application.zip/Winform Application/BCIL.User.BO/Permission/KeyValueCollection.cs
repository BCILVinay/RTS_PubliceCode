﻿using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class KeyValueCollection : NameValueListBase<long, string>
    {
        public static KeyValueCollection GetSitesHavePermission(int employeeId,int appType)
        {
            return DataPortal.Fetch<KeyValueCollection>(new PermissibleSiteCriteria() { EmployeeId = employeeId, AppType=appType });
        }

        protected void DataPortal_Fetch(PermissibleSiteCriteria criteria)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {

                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = SitesHavePermissionSQL();
                    cm.Parameters.AddWithValue("@EmployeeId", criteria.EmployeeId);
                    cm.Parameters.AddWithValue("@AppType", criteria.AppType );
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        while (dr.Read())
                        {
                            this.Items.Add(new NameValuePair(dr.GetInt32("SiteId"), dr.GetString("SiteName")));

                        }
                    }
                }
            }
        }

        private string SitesHavePermissionSQL()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT     T2.SiteId,T2.SiteName \n");
            sb.Append("FROM       RolePermission T \n");
            sb.Append("INNER JOIN [EmployeeRole] T1 ON T1.RoleId = T.RoleId \n");
            sb.Append("INNER JOIN [Site] T2 ON T1.SiteId = T2.SiteId \n");
            sb.Append("INNER JOIN Node T3 ON T3.NodeId = T.NodeId AND T3.AppType = @AppType \n");
            sb.Append("WHERE      T1.EmployeeId = @EmployeeId AND T.Permission > 0 AND NOT EXISTS (SELECT 1 \n");
            sb.Append("                           FROM   EmployeePermission T5 \n");
            sb.Append("                           WHERE  T5.EmployeeId = @EmployeeId AND T5.NodeId = T.NodeId) \n");
            sb.Append("GROUP      BY T2.SiteId,T2.SiteName \n");
            sb.Append("UNION \n");
            sb.Append("SELECT     T1.SiteId,T1.SiteName \n");
            sb.Append("FROM       EmployeePermission T \n");
            sb.Append("INNER JOIN [Site] T1 ON T1.SiteId = T.SiteId \n");
            sb.Append("INNER JOIN Node T2 ON T2.NodeId = T.NodeId AND T2.AppType = @AppType \n");
            sb.Append("WHERE      T.EmployeeId = @EmployeeId AND T.IsRestricted = 0 \n");
            sb.Append("GROUP      BY T1.SiteId,T1.SiteName");
            return sb.ToString();
        }
        #region Criteria Classes
        protected class PermissibleSiteCriteria:CriteriaBase<PermissibleSiteCriteria>
        {
            public int EmployeeId { get; set; }

            public int AppType { get; set; }
        }
        #endregion
    }


}
