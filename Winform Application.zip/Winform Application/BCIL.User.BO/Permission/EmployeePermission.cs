﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class EmployeePermission : NodePermission<EmployeePermission>
    {
        public static readonly PropertyInfo<int> EmployeeIdProperty = RegisterProperty<int>(c => c.EmployeeId);
        [Required(ErrorMessage = "Employee Id is mandatory")]
        public int EmployeeId
        {
            get { return GetProperty(EmployeeIdProperty); }
            set { SetProperty(EmployeeIdProperty, value); }
        }

        public static readonly PropertyInfo<bool> IsRestrictedProperty = RegisterProperty<bool>(c => c.IsRestricted);
        public bool IsRestricted
        {
            get { return GetProperty(IsRestrictedProperty); }
            set { SetProperty(IsRestrictedProperty, value); }
        }

        public void MarkAsClean()
        {
            this.MarkClean();

            var children = this.FieldManager.GetChildren();
            foreach (NodeData child in children)
            {
                child.MarkAsClean();
            }
        }

        public void MarkAsNew()
        {
            this.MarkNew();
        }

        public static EmployeePermission GetRolePermission(SafeDataReader dr)
        {
            return DataPortal.Fetch<EmployeePermission>(dr);
        }

        #region Data Functions
        private void DataPortal_Fetch(SafeDataReader dr)
        {
            EmployeeId = dr.GetInt32("EmployeeId");
            SiteId = dr.GetInt32("SiteId");
            PermissionId = dr.GetInt32("EmployeePermissionID");
            NodeData node = new NodeData();
            node.NodeId = dr.GetInt32("NodeId");
            node.Code = dr.GetString("NodeCode");
            node.ParentCode = dr.GetString("Parent");
            node.Name = dr.GetString("NodeName");
            node.NodeBelongsTo = dr.GetInt32("NodeBelongsTo");
            Node = node;

            CreatedBy = dr.GetInt32("CreatedBy");
            CreatedDate = dr.GetDateTime("CreatedDate");
            Rights = (PermissionType)dr.GetInt32("Permission");
            IsRestricted = dr.GetBoolean("IsRestricted");
            node.MarkAsOld();
            MarkOld();
        }
        protected override void DataPortal_Insert()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = InsertEmployeePermissionSQLQuery();
                    cm.Parameters.Add(new SqlParameter("@EmployeeId", EmployeeId));
                    cm.Parameters.Add(new SqlParameter("@NodeId", Node.NodeId));
                    cm.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cm.Parameters.Add(new SqlParameter("@Permission", Rights));
                    cm.Parameters.Add(new SqlParameter("@IsRestricted", IsRestricted));
                    cm.Parameters.Add(new SqlParameter("@CreatedBy", CreatedBy));
                    cm.Parameters.Add(new SqlParameter("@CreatedDate", DateTime.Now));
                    cm.ExecuteNonQuery();
                    cm.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    PermissionId = Convert.ToInt32(cm.ExecuteScalar());
                }
            }
        }
        private string InsertEmployeePermissionSQLQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [EmployeePermission] \n");
            sb.Append("            ([EmployeeId],[NodeId],[SiteId],[Permission],[CreatedBy],[CreatedDate],[IsRestricted]) \n");
            sb.Append("VALUES      (@EmployeeId,@NodeId,@SiteId,@Permission,@CreatedBy,@CreatedDate,@IsRestricted) \n");
            return sb.ToString();
        }

        protected override void DataPortal_Update()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = UpdateEmployeePermissionSQLQuery();
                    cm.Parameters.Add(new SqlParameter("@EmployeeId", EmployeeId));
                    cm.Parameters.Add(new SqlParameter("@NodeId", Node.NodeId));
                    cm.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cm.Parameters.Add(new SqlParameter("@Permission", Rights));
                    cm.Parameters.Add(new SqlParameter("@IsRestricted", IsRestricted));
                    cm.Parameters.Add(new SqlParameter("@CreatedBy", CreatedBy));
                    cm.Parameters.Add(new SqlParameter("@CreatedDate", DateTime.Now));
                    cm.Parameters.Add(new SqlParameter("@EmployeePermissionID", PermissionId));
                    cm.ExecuteNonQuery();
                }
            }
        }
        private string UpdateEmployeePermissionSQLQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [EmployeePermission] \n");
            sb.Append("   SET [EmployeeId] = @EmployeeId \n");
            sb.Append("      ,[NodeId] = @NodeId \n");
            sb.Append("      ,[SiteId] = @SiteId \n");
            sb.Append("      ,[Permission] = @Permission \n");
            sb.Append("      ,[CreatedBy] = @CreatedBy \n");
            sb.Append("      ,[CreatedDate] = @CreatedDate \n");
            sb.Append("      ,[IsRestricted] = @IsRestricted \n");
            sb.Append(" WHERE EmployeePermissionID =@EmployeePermissionID");
            return sb.ToString();
        }

        protected override void DataPortal_DeleteSelf()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = "Delete EmployeePermission WHERE EmployeePermissionID =@EmployeePermissionID";
                    cm.Parameters.Add(new SqlParameter("@EmployeePermissionID", PermissionId));
                    cm.ExecuteNonQuery();
                }
            }
        }

        #endregion
    }
}
