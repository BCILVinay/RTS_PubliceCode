﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class EmployeePermissionList : ReadOnlyListBase<EmployeePermissionList, EmployeePermission>
    {
        #region Factory Methods
        private EmployeePermissionList() { }

        public static async Task<EmployeePermissionList> NewEmployeePermissionsAsync() => await DataPortal.CreateAsync<EmployeePermissionList>();

        public static async Task<EmployeePermissionList> GetEmployeePermissionsAsync(int employeeId, int siteId) => await DataPortal.FetchAsync<EmployeePermissionList>(new EmployeePermissionCriteria() { EmployeeId = employeeId, SiteId = siteId });

        public static EmployeePermissionList NewEmployeePermissionList() => DataPortal.Create<EmployeePermissionList>();

        public static EmployeePermissionList GetEmployeePermissions(int employeeId, int siteId)
        {
            CodeContract.Required<ArgumentException>(employeeId > 0, "Employee id mandatory");
            CodeContract.Required<ArgumentException>(siteId > 0, "Site id is mandatory");
            return DataPortal.Fetch<EmployeePermissionList>(new EmployeePermissionCriteria() { EmployeeId = employeeId, SiteId = siteId });
        }
        #endregion

        #region Data Functions
        private void DataPortal_Fetch(EmployeePermissionCriteria crit)
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = FetchEmployeeAllPermissionSQLQueryString();
                    cm.Parameters.Add(new SqlParameter("@EmployeeId", crit.EmployeeId));
                    cm.Parameters.Add(new SqlParameter("@SiteId", crit.SiteId));
                    using (SafeDataReader dr = new SafeDataReader(cm.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            var employeePermission = EmployeePermission.GetRolePermission(dr);
                           
                            this.Add(employeePermission);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }

        private string FetchEmployeeAllPermissionSQLQueryString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT T.NodeId,T.Parent, T.NodeCode, T.NAME AS NodeName,T.NodeBelongsTo, \n");
            sb.Append("       T1.* \n");
            sb.Append("FROM   Node T \n");
            sb.Append("       LEFT OUTER JOIN [EmployeePermission] T1 ON T.NodeId = T1.NodeId and T1.EmployeeId=@EmployeeId and T1.SiteId=@SiteId");
            return sb.ToString();
        }

        #endregion
    }

    [Serializable]
    public class EmployeePermissionCriteria : CriteriaBase<EmployeePermissionCriteria>
    {
        public int EmployeeId { get; set; }

        public int SiteId { get; set; }
    }
}
