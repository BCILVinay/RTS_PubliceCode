﻿using Csla;
using Csla.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class SaveBizObjCommand<T> : CommandBase<SaveBizObjCommand<T>>
    {
        private List<T> _bizObjects;

        public List<T> SavedObjects { get; set; }

        public static List<T> Save(List<T> bizObjects)
        {
            CodeContract.Required<BCILException>(typeof(IBusinessBase).IsAssignableFrom(typeof(T)), "In compatible type");

            SaveBizObjCommand<T> cmd = new SaveBizObjCommand<T>(bizObjects);
            cmd= DataPortal.Execute(cmd);
            return cmd.SavedObjects;
        }
        public SaveBizObjCommand(List<T> bizObjects)
        {
            _bizObjects = bizObjects;
        }

        [Transactional(TransactionalTypes.TransactionScope)]
        protected override void DataPortal_Execute()
        {
            SavedObjects = new List<T>();
            foreach (IBusinessBase obj in _bizObjects)
            {
                SavedObjects.Add((T)obj.Save());
            }
        }
    }
}
