﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class NodePermission<T> : MyBusinessBase<T> where T : NodePermission<T>
    {
        public static readonly PropertyInfo<int> PermissionIdProperty = RegisterProperty<int>(c => c.PermissionId);
        public int PermissionId
        {
            get { return GetProperty(PermissionIdProperty); }
            set { SetProperty(PermissionIdProperty, value); }
        }

        public static readonly PropertyInfo<NodeData> NodeProperty = RegisterProperty<NodeData>(c => c.Node);
        public NodeData Node
        {
            get { return GetProperty(NodeProperty); }
            set { SetProperty(NodeProperty, value); }
        }

        public static readonly PropertyInfo<int> RightsProperty = RegisterProperty<int>(c => c.Rights);
        public PermissionType Rights
        {
            get { return GetPropertyConvert<int, PermissionType>(RightsProperty); }
            set { SetPropertyConvert<int, PermissionType>(RightsProperty, value); }
        }

        public static readonly PropertyInfo<int> SiteIdProperty = RegisterProperty<int>(c => c.SiteId);
        [RequiredButNotDefault(ErrorMessage = "Permission must associated with site.")]
        public int SiteId
        {
            get { return GetProperty(SiteIdProperty); }
            set { SetProperty(SiteIdProperty, value); }
        }

        public static readonly PropertyInfo<int> CreatedByProperty = RegisterProperty<int>(c => c.CreatedBy);
        public int CreatedBy
        {
            get { return GetProperty(CreatedByProperty); }
            set { SetProperty(CreatedByProperty, value); }
        }

        public static readonly PropertyInfo<DateTime> CreatedDateProperty = RegisterProperty<DateTime>(c => c.CreatedDate);
        public DateTime CreatedDate
        {
            get { return GetProperty(CreatedDateProperty); }
            set { SetProperty(CreatedDateProperty, value); }
        }

    }
}
