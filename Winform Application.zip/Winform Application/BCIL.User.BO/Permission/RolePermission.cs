﻿using BCIL.User.BL.Enums;
using BCIL.Utility;
using Csla;
using Csla.Core;
using Csla.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.BL.Permission
{
    [Serializable]
    public class RolePermission : NodePermission<RolePermission>
    {
        public static readonly PropertyInfo<int> RoleIdProperty = RegisterProperty<int>(c => c.RoleId);
        public int RoleId
        {
            get { return GetProperty(RoleIdProperty); }
            set { SetProperty(RoleIdProperty, value); }
        }

        #region Factory Methods
        public static RolePermission GetRolePermissionAsChild()
        {
            var permission = new RolePermission();
            permission.MarkAsChild();
            return permission;
        }

        public static RolePermission GetRolePermission(SafeDataReader dr)
        {
            return DataPortal.Fetch<RolePermission>(dr);
        }
        public void MarkAsClean()
        {
            this.MarkClean();
           
            var children = this.FieldManager.GetChildren();
            foreach (NodeData child in children)
            {
                child.MarkAsClean();
            }
        }

        public void MarkAsNew()
        {
            this.MarkNew();
        }
        #endregion

        #region Data Function

        private void DataPortal_Fetch(SafeDataReader dr)
        {
            RoleId = dr.GetInt32("RoleId");
            SiteId = dr.GetInt32("SiteId");
            PermissionId = dr.GetInt32("RolePermissionID");

            NodeData node = new NodeData();
            node.NodeId = dr.GetInt32("NodeId");
            node.Code = dr.GetString("NodeCode");
            node.ParentCode = dr.GetString("Parent");
            node.Name = dr.GetString("NodeName");
            node.NodeBelongsTo = dr.GetInt32("NodeBelongsTo");
            Node = node;
            CreatedBy = dr.GetInt32("CreatedBy");
            CreatedDate = dr.GetDateTime("CreatedDate");
            Rights = (PermissionType)dr.GetInt32("Permission");

            node.MarkAsOld();
            MarkOld();
        }

        protected override void DataPortal_Insert()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = InsertRolePermissionSQLQuery();
                    cm.Parameters.Add(new SqlParameter("@RoleId", RoleId));
                    cm.Parameters.Add(new SqlParameter("@NodeId", Node.NodeId));
                    cm.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cm.Parameters.Add(new SqlParameter("@Permission", Rights));
                    cm.Parameters.Add(new SqlParameter("@CreatedBy", CreatedBy));
                    cm.Parameters.Add(new SqlParameter("@CreatedDate", DateTime.Now));
                    cm.ExecuteNonQuery();
                    cm.CommandText = "SELECT @@IDENTITY AS 'Identity';";
                    PermissionId = Convert.ToInt32(cm.ExecuteScalar());
                    Node.MarkAsOld();
                    MarkOld();
                }
            }
        }

        private string InsertRolePermissionSQLQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO [RolePermission] \n");
            sb.Append("            ([RoleId],[NodeId],[SiteId],[Permission],[CreatedBy],[CreatedDate]) \n");
            sb.Append("VALUES      (@RoleId,@NodeId,@SiteId,@Permission,@CreatedBy,@CreatedDate) \n");
            return sb.ToString();
        }

        protected override void DataPortal_Update()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = UpdateRolePermissionSQLQuery();
                    cm.Parameters.Add(new SqlParameter("@RoleId", RoleId));
                    cm.Parameters.Add(new SqlParameter("@NodeId", Node.NodeId));
                    cm.Parameters.Add(new SqlParameter("@SiteId", SiteId));
                    cm.Parameters.Add(new SqlParameter("@Permission", Rights));
                    cm.Parameters.Add(new SqlParameter("@CreatedBy", CreatedBy));
                    cm.Parameters.Add(new SqlParameter("@CreatedDate", DateTime.Now));
                    cm.Parameters.Add(new SqlParameter("@RolePermissionId", PermissionId));
                    cm.ExecuteNonQuery();
                    Node.MarkAsOld();
                    MarkOld();
                }
            }
        }

        private string UpdateRolePermissionSQLQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE [RolePermission] \n");
            sb.Append("   SET [RoleId] = @RoleId \n");
            sb.Append("      ,[NodeId] = @NodeId \n");
            sb.Append("      ,[SiteId] = @SiteId \n");
            sb.Append("      ,[Permission] = @Permission \n");
            sb.Append("      ,[CreatedBy] = @CreatedBy \n");
            sb.Append("      ,[CreatedDate] = @CreatedDate \n");
            sb.Append(" WHERE RolePermissionId =@RolePermissionId");
            return sb.ToString();
        }

        protected override void DataPortal_DeleteSelf()
        {
            using (SqlConnection cn = new SqlConnection(AppData.SQLConnectionString))
            {
                cn.Open();
                using (var cm = cn.CreateCommand())
                {
                    cm.CommandType = System.Data.CommandType.Text;
                    cm.CommandText = "Delete RolePermission WHERE RolePermissionId =@RolePermissionId";
                    cm.Parameters.Add(new SqlParameter("@RolePermissionId", PermissionId));
                    cm.ExecuteNonQuery();
                }
            }
        }
        #endregion
    }
}
