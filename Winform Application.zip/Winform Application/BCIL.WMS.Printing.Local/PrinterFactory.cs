﻿using System;
using System.Configuration;

namespace BCIL.WMS.Printing.Local
{
    public class PrinterFactory : IPrinterFactory, IDisposable
    {
        private string _errorMessage = "";

        private PrintStatus _printStatus = PrintStatus.None;

        private string _printerName;

        public string Message
        {
            get { return _errorMessage; }
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }

        private void InitializePrinter()
        {
            try
            {
                _printerName = ConfigurationManager.AppSettings["BarCodePrinter"];

                CodeContract.Required<BCILException>(_printerName.IsNotNullOrWhiteSpace(), "Barcode printer is not defined");
            }
            catch (System.Exception ex)
            {
                _printStatus = PrintStatus.Error;
                _errorMessage = ex.Message;
            }
        }

        public PrintStatus Print(string dataToPrint)
        {
            try
            {
                InitializePrinter();
                Printer.PrintCommand(dataToPrint, _printerName);
                return PrintStatus.Success;
            }
            catch (System.Exception ex)
            {
                _errorMessage = ex.Message;
            }
            return PrintStatus.Error;
        }
    }
}