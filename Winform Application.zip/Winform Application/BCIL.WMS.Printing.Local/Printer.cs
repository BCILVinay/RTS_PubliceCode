﻿using System;
using System.Linq;
using System.Runtime.InteropServices;

namespace BCIL.WMS.Printing.Local
{
    public class Printer
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct DOCINFO
        {
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pDocName;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pOutputFile;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pDataType;
        }

        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
        public static extern long OpenPrinter(string pPrinterName, ref IntPtr phPrinter, int pDefault);
        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
        public static extern long StartDocPrinter(IntPtr hPrinter, int Level, ref DOCINFO pDocInfo);
        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern long StartPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern long WritePrinter(IntPtr hPrinter, string data, int buf, ref int pcWritten);
        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern long EndPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern long EndDocPrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern long ClosePrinter(IntPtr hPrinter);

        public static void PrintCommand(string prnData, string PrinterName)
        {
            int iPrinter = 0;
            DOCINFO di = new DOCINFO();
            di.pDocName = "LABEL";
            di.pDataType = "RAW";
            int pcWritten = 0;
            System.IntPtr lhPrinter = new System.IntPtr();
            for (int i = 0; i < System.Drawing.Printing.PrinterSettings.InstalledPrinters.Count; i++)
            {
                if (System.Drawing.Printing.PrinterSettings.InstalledPrinters[i].ToString().ToUpper() == PrinterName.ToUpper())
                {
                    iPrinter = 1;
                    break;
                }
            }
            if (iPrinter == 1)
            {
                Printer.OpenPrinter(PrinterName, ref lhPrinter, 0);
                Printer.StartDocPrinter(lhPrinter, 1, ref di);
                Printer.StartPagePrinter(lhPrinter);
                Printer.WritePrinter(lhPrinter, prnData, prnData.Length, ref pcWritten);
                Printer.EndPagePrinter(lhPrinter);
                Printer.EndDocPrinter(lhPrinter);
                Printer.ClosePrinter(lhPrinter);
            }
            else
            {
                throw new Exception("Printer Not Found : " + PrinterName);
            }
        }
    }
}