﻿using BCIL.User.BL;
using BCIL.Utility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BCIL.User.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class RoleUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            try
            {
                Role role = Role.NewRole();
                role.Name = "Manager";
                role.Description = "Manager";
                role.IsActive = true;
                role.CreatedDate = DateTime.Now;
                role.CreatedBy = new KeyValue<Int32, string>(1, "");
                if (role.IsValid)
                {
                    role.Save();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, role.BrokenRulesCollection.Select(x => x.Description)));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            Role role = Role.GetRole(1);
        }

        [TestMethod]
        public void TestMethodUpdate()
        {
            Role role = Role.GetRole(1);
            role.Description = "Manage Site App";
            role.Save();
        }

        [TestMethod]
        public void TestRoleList()
        {
            
            Form frm = new Form();
            frm.WindowState = FormWindowState.Maximized;
            RoleListView view = new RoleListView(frm);
            view.Dock = DockStyle.Fill;
            frm.Controls.Add(view);
            frm.ShowDialog();
        }

    }
}