﻿using BCIL.User.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class EmployeeUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            Employee emp = Employee.NewEmployee();
            emp.Name = "Vijay";
            emp.Email = "vijay@gmail.com";
            emp.CreatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
            emp.UpdatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
            emp.Address = "Delhi";
            emp.Phone1 = "11";
            emp.Phone2 = "12345678";
            if (emp.IsValid)
            {
                emp.Save();
            }
            else
            {
                MessageBox.Show(string.Join(Environment.NewLine, emp.BrokenRulesCollection.Select(x => x.Description)));
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            Employee emp = Employee.GetEmployee(1);
        }

        [TestMethod]
        public void TestMethodUpdate()
        {
            Employee emp = Employee.GetEmployee(1);
            emp.Name = "Vijay Kumar";
            if (emp.IsValid)
            {
                emp.Save();
            }
            else
            {
                MessageBox.Show(string.Join(Environment.NewLine, emp.BrokenRulesCollection.Select(x => x.Description)));
            }
        }

        [TestMethod]
        public void TestMethodDelete()
        {
            try
            {
                Employee.DeleteEmployee(2);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGetEmployees()
        {
            try
            {
              var Emps=  EmployeeDVL.GetEmployees(1, 50);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}