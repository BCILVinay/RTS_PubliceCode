﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    [TestClass]
    public class SAPAPITest
    {
        [TestMethod]
        public void MyTestAPI()
        {
            //ServiceReference4.SI_PutwayGetData_OSClient clnt = new ServiceReference4.SI_PutwayGetData_OSClient();
            //clnt.SI_PutwayGetData_OS(new ServiceReference4.DT_PutwayGetDataReq());
        }
    }
}
