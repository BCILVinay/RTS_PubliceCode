﻿using BCIL.WMS.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class LocationUnitTest
    {
        [TestMethod]
        public void TestNewAdd()
        {
            try
            {
                Location location = Location.NewLocation();
                location.LocationName = "Delhi";
                location.LocationCode = "C10002";
                location.DimensionHeight = 50;
                location.DimensionLength = 25;
                location.DimensionWidth = 15;
                location.IsActive = true;
                location.CreatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                location.CreatedOn = DateTime.Now;
                location.UpdatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                location.UpdatedOn = DateTime.Now;
                if (location.IsValid)
                {
                    location.Save();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, location.BrokenRulesCollection.Select(x => x.Description)));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestGet()
        {
            try
            {
                Location location = Location.GetLocation(1);
                MessageBox.Show(location.LocationCode);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestUpdate()
        {
            try
            {
                Location location = Location.GetLocation(1);
                location.LocationCode = "C10001";
                location.LocationName = "Gurugram";
                location.Description = "Gurgaon";
                location.DimensionHeight = 50;
                location.DimensionLength = 25;
                location.DimensionWidth = 15;
                location.IsActive = true;
                location.CreatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                location.CreatedOn = DateTime.Now;
                location.UpdatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                location.UpdatedOn = DateTime.Now;
                if (location.IsValid)
                {
                    location.Save();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, location.BrokenRulesCollection.Select(x => x.Description)));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}