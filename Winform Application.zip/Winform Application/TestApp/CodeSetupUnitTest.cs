﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows.Forms;
using BCIL.WMS.BL;
using System.Linq;

namespace TestApp
{
    [TestClass]
    public class CodeSetupUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            CodeSetup CodeSetup = CodeSetup.NewCodeSetup();
            if (CodeSetup.IsValid) {
                CodeSetup.Save();
            }
            else {
                MessageBox.Show(string.Join(Environment.NewLine, CodeSetup.BrokenRulesCollection.Select(x => x.Description)));
            }
        }
        [TestMethod]
        public void TestMethodAdd1()
        {
            //ServiceReference1.SI_POPostData_OAClient ss = new ServiceReference1.SI_POPostData_OAClient();

            //ServiceReference2.SI_POConfGetData_OSClient cc = new ServiceReference2.SI_POConfGetData_OSClient();
            //var aa=  cc.SI_POConfGetData_OS(new ServiceReference2.DT_POConfGetDataReq());
            //ss.SI_POPostData_OA(;
        }
    }
}
