﻿using BCIL.WMS.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class MaterialUnitTest
    {
        public MaterialUnitTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        [TestMethod]
        public void TestMethodAdd()
        {
            Material material = Material.NewMaterial();
            material.MaterialCode = "M00123";
            if (material.IsValid)
            {
                material.Save();
            }
            else
            {
                MessageBox.Show(string.Join(Environment.NewLine, material.BrokenRulesCollection.Select(x => x.Description)));
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            try
            {
                Material material = Material.GetMaterial(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGetAll()
        {
            try
            {
                var SearchCriteria = new MaterialGenericSearchCriteria() { PageNumber = 1, PageSize = 50, MeterialCode = "", MeterialDesc = "" };
                MaterialDVL material = MaterialDVL.GetMaterialDVL(SearchCriteria);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void PicklistsGet()
        {
            try
            {
               // Picklists pickLists = Picklists.GetPicklists(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}