﻿using BCIL.Utility;
using BCIL.WMS.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class ToolingUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            try
            {
                Tooling tooling = Tooling.NewTooling();
                if (tooling.IsValid)
                {
                    tooling.Save();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, tooling.BrokenRulesCollection.Select(x => x.Description)));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodUpdate()
        {
            try
            {
                Tooling tooling = Tooling.GetTooling(1);
                tooling.ToolingCode = "T1001";
                tooling.ToolingName = "Tool-4x6";
                tooling.LineId = 1;
                tooling.UpdatedBy = new KeyValue<Int32, string>(1, "");
                if (tooling.IsValid)
                {
                    tooling.Save();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodDelete()
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodAll()
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}