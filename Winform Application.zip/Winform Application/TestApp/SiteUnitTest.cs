﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows.Forms;
using BCIL.Administration.BL;
using System.Linq;

namespace TestApp
{
    [TestClass]
    public class SiteUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            try
            {
                Site site = Site.NewSite();
                site.SiteCode = "";
                if (site.IsValid)
                {
                    site.Save();
                }
                else
                {
                    MessageBox.Show(string.Join(Environment.NewLine, site.BrokenRulesCollection.Select(x => x.Description)));
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodUpdate()
        {
        }

        [TestMethod]
        public void TestMethodDelete()
        {
        }

        [TestMethod]
        public void TestMethodGet()
        {
            Site site = Site.GetSite(1);
        }


        [TestMethod]
        public void TestMethodGetAll()
        {
            SiteList SiteList = SiteList.GetSites();
        }

    }
}
