﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestApp
{
    [TestClass]
    public class UserUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {

        }

        [TestMethod]
        public void TestMethodGet()
        {

        }
    }
}
