﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BCIL.WMS.BL;
using System.Windows.Forms;
using System.Linq;

namespace TestApp
{
    [TestClass]
    public class DeliveryUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }

        [TestMethod]
        public void TestMethodAdd()
        {
            try
            {
                //Delivery delivery = Delivery.NewDelivery();
                //delivery.MaterialId = 1;
                //delivery.STONo = "ST001";
                //delivery.DeliveryNo = "DR001";
                //delivery.DeliveryDate = DateTime.Now;
                //delivery.MaterialId = 1;
                //delivery.Quantity = 1;
                //delivery.SiteFrom = 1;
                //delivery.SiteTo = 2;
                //delivery.TruckNo = "DL-02-SN-007";
                //delivery.Transporter = "Mukesh";
                //delivery.LRNo = "LR001";
                //delivery.Status = DeliveryStatus.Pending;
                //delivery.CreatedOn = DateTime.Now;
                //delivery.CreatedBy = 1;
                //delivery.UpdatedOn = DateTime.Now;
                //delivery.UpdatedBy = 1;
                //if (delivery.IsValid) {
                //    delivery.Save();
                //}
                //else {
                //    MessageBox.Show(string.Join(Environment.NewLine, delivery.BrokenRulesCollection.Select(x => x.Description)));
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            try
            {
                Material material = Material.GetMaterial(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGetAll()
        {
            try
            {
                var SearchCriteria = new MaterialGenericSearchCriteria() { PageNumber = 1, PageSize = 50, MeterialCode = "", MeterialDesc = "" };
                MaterialDVL material = MaterialDVL.GetMaterialDVL(SearchCriteria);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
