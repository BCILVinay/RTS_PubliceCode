﻿using BCIL.WMS.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Windows.Forms;

namespace TestApp
{
    [TestClass]
    public class ProductionOrderUnitTest
    {
        [TestMethod]
        public void TestMethodAdd()
        {
            try
            {
                ProductionOrder po = ProductionOrder.NewProductionOrder();
                po.POrderNo = "P001";
                po.SiteId = 1;
                po.POrderDate = DateTime.Now;
                po.CreatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                po.CreatedOn = DateTime.Now;
                po.UpdatedBy = new BCIL.Utility.KeyValue<int, string>(1, "");
                po.UpdatedOn = DateTime.Now;
                po.ImportedOn = DateTime.Now;
                var lineItem = ProductionOrderLineItem.NewProductionOrderLineItem();
                lineItem.Material = new BCIL.Utility.KeyValue<Int64, string>(2, "");
                lineItem.Length = 2;
                lineItem.BundleQty = 2;
                lineItem.PPLine = 5;
                lineItem.ChangeOn = DateTime.Now;
                lineItem.UOM = "ME";
                po.POLineItems.Add(lineItem);
                if (po.IsValid)
                {
                    po.Save();
                }
                else { MessageBox.Show(string.Join(Environment.NewLine, po.BrokenRulesCollection.Select(x => x.Description))); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodUpdate()
        {
            try
            {
                ProductionOrder po = ProductionOrder.GetProductionOrder(1);
                if (po.IsValid)
                {
                    po.Save();
                }
                else { MessageBox.Show(string.Join(Environment.NewLine, po.BrokenRulesCollection.Select(x => x.Description))); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodDelete()
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodGet()
        {
            try
            {
                var po = ProductionOrder.GetProductionOrder(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        [TestMethod]
        public void TestMethodAll()
        {
            try
            {
                ProductionOrderSearchCriteria criteria = new ProductionOrderSearchCriteria() { };
                var data = ProductionOrderDVL.GetProductionOrderDVL(criteria);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}