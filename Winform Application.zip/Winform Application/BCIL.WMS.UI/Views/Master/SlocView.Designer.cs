﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialBinView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialBinView));
            this.requiredPanel5 = new BCIL.UIHelper.RequiredPanel();
            this.txtWidth = new MetroFramework.Controls.MetroTextBox();
            this.MaterialBinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel1 = new BCIL.UIHelper.RequiredPanel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel4 = new BCIL.UIHelper.RequiredPanel();
            this.txtHeight = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel6 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel7 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel8 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel3 = new BCIL.UIHelper.RequiredPanel();
            this.txtMaterial = new MetroFramework.Controls.MetroTextBox();
            this.requiredPanel9 = new BCIL.UIHelper.RequiredPanel();
            this.txtLocation = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.btnSelectMaterial = new System.Windows.Forms.Button();
            this.btnSelectLocation = new System.Windows.Forms.Button();
            this.requiredPanel10 = new BCIL.UIHelper.RequiredPanel();
            this.txtCapacity = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaterialBinBindingSource)).BeginInit();
            this.requiredPanel2.SuspendLayout();
            this.requiredPanel1.SuspendLayout();
            this.requiredPanel4.SuspendLayout();
            this.requiredPanel6.SuspendLayout();
            this.requiredPanel7.SuspendLayout();
            this.requiredPanel8.SuspendLayout();
            this.requiredPanel3.SuspendLayout();
            this.requiredPanel9.SuspendLayout();
            this.requiredPanel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // requiredPanel5
            // 
            this.requiredPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel5.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel5.Controls.Add(this.txtWidth);
            this.requiredPanel5.IsRequired = true;
            this.requiredPanel5.Location = new System.Drawing.Point(101, 164);
            this.requiredPanel5.Name = "requiredPanel5";
            this.requiredPanel5.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel5.TabIndex = 3;
            // 
            // txtWidth
            // 
            // 
            // 
            // 
            this.txtWidth.CustomButton.Image = null;
            this.txtWidth.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtWidth.CustomButton.Name = "";
            this.txtWidth.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtWidth.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtWidth.CustomButton.TabIndex = 1;
            this.txtWidth.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtWidth.CustomButton.UseSelectable = true;
            this.txtWidth.CustomButton.Visible = false;
            this.txtWidth.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "Width", true));
            this.txtWidth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWidth.Lines = new string[0];
            this.txtWidth.Location = new System.Drawing.Point(0, 0);
            this.txtWidth.MaxLength = 50;
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.PasswordChar = '\0';
            this.txtWidth.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtWidth.SelectedText = "";
            this.txtWidth.SelectionLength = 0;
            this.txtWidth.SelectionStart = 0;
            this.txtWidth.ShortcutsEnabled = true;
            this.txtWidth.Size = new System.Drawing.Size(222, 25);
            this.txtWidth.TabIndex = 0;
            this.txtWidth.UseSelectable = true;
            this.txtWidth.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtWidth.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtWidth.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // MaterialBinBindingSource
            // 
            this.MaterialBinBindingSource.DataSource = typeof(BCIL.WMS.BL.MaterialBin);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(23, 167);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(47, 19);
            this.metroLabel4.TabIndex = 32;
            this.metroLabel4.Text = "Width:";
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtCode);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(101, 67);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel2.TabIndex = 0;
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "MaterialBinCode", true));
            this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(0, 0);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(222, 25);
            this.txtCode.TabIndex = 0;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 70);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 30;
            this.metroLabel1.Text = "Code:";
            // 
            // requiredPanel1
            // 
            this.requiredPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel1.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel1.Controls.Add(this.txtName);
            this.requiredPanel1.IsRequired = true;
            this.requiredPanel1.Location = new System.Drawing.Point(101, 100);
            this.requiredPanel1.Name = "requiredPanel1";
            this.requiredPanel1.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel1.TabIndex = 1;
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "MaterialBinName", true));
            this.txtName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(0, 0);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(222, 25);
            this.txtName.TabIndex = 0;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.MaterialBinBindingSource, "IsActive", true));
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(597, 67);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(72, 25);
            this.cboIsActive.TabIndex = 4;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(441, 70);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 28;
            this.lblIsActive.Text = "Active:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(23, 103);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(48, 19);
            this.lblName.TabIndex = 26;
            this.lblName.Text = "Name:";
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(609, 288);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(517, 288);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel4
            // 
            this.requiredPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel4.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel4.Controls.Add(this.txtHeight);
            this.requiredPanel4.IsRequired = true;
            this.requiredPanel4.Location = new System.Drawing.Point(101, 132);
            this.requiredPanel4.Name = "requiredPanel4";
            this.requiredPanel4.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel4.TabIndex = 2;
            // 
            // txtHeight
            // 
            // 
            // 
            // 
            this.txtHeight.CustomButton.Image = null;
            this.txtHeight.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtHeight.CustomButton.Name = "";
            this.txtHeight.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtHeight.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtHeight.CustomButton.TabIndex = 1;
            this.txtHeight.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtHeight.CustomButton.UseSelectable = true;
            this.txtHeight.CustomButton.Visible = false;
            this.txtHeight.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "Height", true));
            this.txtHeight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHeight.Lines = new string[0];
            this.txtHeight.Location = new System.Drawing.Point(0, 0);
            this.txtHeight.MaxLength = 50;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.PasswordChar = '\0';
            this.txtHeight.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtHeight.SelectedText = "";
            this.txtHeight.SelectionLength = 0;
            this.txtHeight.SelectionStart = 0;
            this.txtHeight.ShortcutsEnabled = true;
            this.txtHeight.Size = new System.Drawing.Size(222, 25);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.UseSelectable = true;
            this.txtHeight.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtHeight.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtHeight.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 135);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(50, 19);
            this.metroLabel3.TabIndex = 34;
            this.metroLabel3.Text = "Height:";
            // 
            // requiredPanel6
            // 
            this.requiredPanel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel6.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel6.Controls.Add(this.metroTextBox1);
            this.requiredPanel6.IsRequired = true;
            this.requiredPanel6.Location = new System.Drawing.Point(597, 164);
            this.requiredPanel6.Name = "requiredPanel6";
            this.requiredPanel6.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel6.TabIndex = 7;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "ColumnNo", true));
            this.metroTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox1.MaxLength = 50;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(72, 25);
            this.metroTextBox1.TabIndex = 0;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.metroTextBox1.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(441, 167);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(80, 19);
            this.metroLabel5.TabIndex = 40;
            this.metroLabel5.Text = "Column No:";
            // 
            // requiredPanel7
            // 
            this.requiredPanel7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel7.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel7.Controls.Add(this.metroTextBox2);
            this.requiredPanel7.IsRequired = true;
            this.requiredPanel7.Location = new System.Drawing.Point(597, 100);
            this.requiredPanel7.Name = "requiredPanel7";
            this.requiredPanel7.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel7.TabIndex = 5;
            // 
            // metroTextBox2
            // 
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "RowNo", true));
            this.metroTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox2.MaxLength = 50;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = true;
            this.metroTextBox2.Size = new System.Drawing.Size(72, 25);
            this.metroTextBox2.TabIndex = 0;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(441, 103);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(59, 19);
            this.metroLabel6.TabIndex = 38;
            this.metroLabel6.Text = "Row No:";
            // 
            // requiredPanel8
            // 
            this.requiredPanel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel8.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel8.Controls.Add(this.metroTextBox3);
            this.requiredPanel8.IsRequired = true;
            this.requiredPanel8.Location = new System.Drawing.Point(597, 132);
            this.requiredPanel8.Name = "requiredPanel8";
            this.requiredPanel8.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel8.TabIndex = 6;
            // 
            // metroTextBox3
            // 
            // 
            // 
            // 
            this.metroTextBox3.CustomButton.Image = null;
            this.metroTextBox3.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.metroTextBox3.CustomButton.Name = "";
            this.metroTextBox3.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.CustomButton.TabIndex = 1;
            this.metroTextBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.CustomButton.UseSelectable = true;
            this.metroTextBox3.CustomButton.Visible = false;
            this.metroTextBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "RackNo", true));
            this.metroTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox3.Lines = new string[0];
            this.metroTextBox3.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox3.MaxLength = 50;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.SelectionLength = 0;
            this.metroTextBox3.SelectionStart = 0;
            this.metroTextBox3.ShortcutsEnabled = true;
            this.metroTextBox3.Size = new System.Drawing.Size(72, 25);
            this.metroTextBox3.TabIndex = 0;
            this.metroTextBox3.UseSelectable = true;
            this.metroTextBox3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(441, 135);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(61, 19);
            this.metroLabel7.TabIndex = 37;
            this.metroLabel7.Text = "Rack No:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 200);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(60, 19);
            this.metroLabel2.TabIndex = 41;
            this.metroLabel2.Text = "Material:";
            // 
            // requiredPanel3
            // 
            this.requiredPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel3.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel3.Controls.Add(this.txtMaterial);
            this.requiredPanel3.IsRequired = true;
            this.requiredPanel3.Location = new System.Drawing.Point(101, 197);
            this.requiredPanel3.Name = "requiredPanel3";
            this.requiredPanel3.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel3.TabIndex = 42;
            // 
            // txtMaterial
            // 
            // 
            // 
            // 
            this.txtMaterial.CustomButton.Image = null;
            this.txtMaterial.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtMaterial.CustomButton.Name = "";
            this.txtMaterial.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtMaterial.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMaterial.CustomButton.TabIndex = 1;
            this.txtMaterial.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMaterial.CustomButton.UseSelectable = true;
            this.txtMaterial.CustomButton.Visible = false;
            this.txtMaterial.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "Material", true));
            this.txtMaterial.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMaterial.Lines = new string[0];
            this.txtMaterial.Location = new System.Drawing.Point(0, 0);
            this.txtMaterial.MaxLength = 50;
            this.txtMaterial.Name = "txtMaterial";
            this.txtMaterial.PasswordChar = '\0';
            this.txtMaterial.ReadOnly = true;
            this.txtMaterial.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMaterial.SelectedText = "";
            this.txtMaterial.SelectionLength = 0;
            this.txtMaterial.SelectionStart = 0;
            this.txtMaterial.ShortcutsEnabled = true;
            this.txtMaterial.Size = new System.Drawing.Size(222, 25);
            this.txtMaterial.TabIndex = 0;
            this.txtMaterial.UseSelectable = true;
            this.txtMaterial.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMaterial.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // requiredPanel9
            // 
            this.requiredPanel9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel9.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel9.Controls.Add(this.txtLocation);
            this.requiredPanel9.IsRequired = true;
            this.requiredPanel9.Location = new System.Drawing.Point(101, 229);
            this.requiredPanel9.Name = "requiredPanel9";
            this.requiredPanel9.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel9.TabIndex = 43;
            // 
            // txtLocation
            // 
            // 
            // 
            // 
            this.txtLocation.CustomButton.Image = null;
            this.txtLocation.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtLocation.CustomButton.Name = "";
            this.txtLocation.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtLocation.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLocation.CustomButton.TabIndex = 1;
            this.txtLocation.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLocation.CustomButton.UseSelectable = true;
            this.txtLocation.CustomButton.Visible = false;
            this.txtLocation.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "Location", true));
            this.txtLocation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLocation.Lines = new string[0];
            this.txtLocation.Location = new System.Drawing.Point(0, 0);
            this.txtLocation.MaxLength = 50;
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.PasswordChar = '\0';
            this.txtLocation.ReadOnly = true;
            this.txtLocation.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLocation.SelectedText = "";
            this.txtLocation.SelectionLength = 0;
            this.txtLocation.SelectionStart = 0;
            this.txtLocation.ShortcutsEnabled = true;
            this.txtLocation.Size = new System.Drawing.Size(222, 25);
            this.txtLocation.TabIndex = 0;
            this.txtLocation.UseSelectable = true;
            this.txtLocation.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLocation.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(23, 232);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(61, 19);
            this.metroLabel8.TabIndex = 44;
            this.metroLabel8.Text = "Location:";
            // 
            // btnSelectMaterial
            // 
            this.btnSelectMaterial.Location = new System.Drawing.Point(350, 198);
            this.btnSelectMaterial.Name = "btnSelectMaterial";
            this.btnSelectMaterial.Size = new System.Drawing.Size(56, 22);
            this.btnSelectMaterial.TabIndex = 45;
            this.btnSelectMaterial.Text = "Material";
            this.btnSelectMaterial.UseVisualStyleBackColor = true;
            this.btnSelectMaterial.Click += new System.EventHandler(this.btnSelectMaterial_Click);
            // 
            // btnSelectLocation
            // 
            this.btnSelectLocation.Location = new System.Drawing.Point(349, 230);
            this.btnSelectLocation.Name = "btnSelectLocation";
            this.btnSelectLocation.Size = new System.Drawing.Size(56, 22);
            this.btnSelectLocation.TabIndex = 46;
            this.btnSelectLocation.Text = "Location";
            this.btnSelectLocation.UseVisualStyleBackColor = true;
            this.btnSelectLocation.Click += new System.EventHandler(this.btnSelectLocation_Click);
            // 
            // requiredPanel10
            // 
            this.requiredPanel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel10.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel10.Controls.Add(this.txtCapacity);
            this.requiredPanel10.IsRequired = true;
            this.requiredPanel10.Location = new System.Drawing.Point(597, 197);
            this.requiredPanel10.Name = "requiredPanel10";
            this.requiredPanel10.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel10.TabIndex = 47;
            // 
            // txtCapacity
            // 
            // 
            // 
            // 
            this.txtCapacity.CustomButton.Image = null;
            this.txtCapacity.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.txtCapacity.CustomButton.Name = "";
            this.txtCapacity.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCapacity.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCapacity.CustomButton.TabIndex = 1;
            this.txtCapacity.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCapacity.CustomButton.UseSelectable = true;
            this.txtCapacity.CustomButton.Visible = false;
            this.txtCapacity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialBinBindingSource, "Capacity", true));
            this.txtCapacity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCapacity.Lines = new string[0];
            this.txtCapacity.Location = new System.Drawing.Point(0, 0);
            this.txtCapacity.MaxLength = 50;
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.PasswordChar = '\0';
            this.txtCapacity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCapacity.SelectedText = "";
            this.txtCapacity.SelectionLength = 0;
            this.txtCapacity.SelectionStart = 0;
            this.txtCapacity.ShortcutsEnabled = true;
            this.txtCapacity.Size = new System.Drawing.Size(72, 25);
            this.txtCapacity.TabIndex = 0;
            this.txtCapacity.UseSelectable = true;
            this.txtCapacity.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCapacity.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtCapacity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(441, 200);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(153, 19);
            this.metroLabel9.TabIndex = 48;
            this.metroLabel9.Text = "Capacity(No of Bundles):";
            // 
            // MaterialBinView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 360);
            this.Controls.Add(this.requiredPanel10);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.btnSelectLocation);
            this.Controls.Add(this.btnSelectMaterial);
            this.Controls.Add(this.requiredPanel9);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.requiredPanel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.requiredPanel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.requiredPanel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.requiredPanel8);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.requiredPanel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.requiredPanel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.requiredPanel1);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Name = "MaterialBinView";
            this.Text = "MaterialBin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MaterialBinView_FormClosing);
            this.requiredPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MaterialBinBindingSource)).EndInit();
            this.requiredPanel2.ResumeLayout(false);
            this.requiredPanel1.ResumeLayout(false);
            this.requiredPanel4.ResumeLayout(false);
            this.requiredPanel6.ResumeLayout(false);
            this.requiredPanel7.ResumeLayout(false);
            this.requiredPanel8.ResumeLayout(false);
            this.requiredPanel3.ResumeLayout(false);
            this.requiredPanel9.ResumeLayout(false);
            this.requiredPanel10.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.RequiredPanel requiredPanel5;
        private MetroFramework.Controls.MetroTextBox txtWidth;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.RequiredPanel requiredPanel1;
        private MetroFramework.Controls.MetroTextBox txtName;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private MetroFramework.Controls.MetroLabel lblName;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private System.Windows.Forms.BindingSource MaterialBinBindingSource;
        private UIHelper.RequiredPanel requiredPanel4;
        private MetroFramework.Controls.MetroTextBox txtHeight;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.RequiredPanel requiredPanel6;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private UIHelper.RequiredPanel requiredPanel7;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private UIHelper.RequiredPanel requiredPanel8;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.RequiredPanel requiredPanel3;
        private MetroFramework.Controls.MetroTextBox txtMaterial;
        private UIHelper.RequiredPanel requiredPanel9;
        private MetroFramework.Controls.MetroTextBox txtLocation;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.Button btnSelectMaterial;
        private System.Windows.Forms.Button btnSelectLocation;
        private UIHelper.RequiredPanel requiredPanel10;
        private MetroFramework.Controls.MetroTextBox txtCapacity;
        private MetroFramework.Controls.MetroLabel metroLabel9;
    }
}