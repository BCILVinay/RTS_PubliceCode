﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ProductionOrderView : FormBase, IProductionOrderView
    {
        public ProductionOrderView()
        {
            InitializeComponent();
        }

        public ProductionOrderView(ProductionOrder po) : this()
        {
            Model.ProductionOrder = po;
            txtPoNo.ReadOnly = true;
            cboMovment.Enabled = false;
            cboStatus.Enabled = false;
        }

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SaveRequested;

        public Permission AddEditPermision { get; set; }

        public ProductionOrderModel Model { get; set; }

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(cboStatus, c => c.SelectedValue, Model.ProductionOrder, d => d.Status);
            BindingUtility.CreateBinding(cboMovment, c => c.SelectedValue, Model.ProductionOrder, d => d.MovementType);
            BindingUtility.CreateBinding(txtPoNo, c => c.Text, Model.ProductionOrder, d => d.POrderNo);
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            olvItems.SetObjects(Model.ProductionOrder.POLineItems);
            lblRecords.Text = String.Format("Total records: {0}", Model.ProductionOrder.POLineItems.Count);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionOrderView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (DialogResult != DialogResult.OK) CancelRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionOrderView_Load(object sender, EventArgs e)
        {
            try
            {
                cboStatus.DisplayMember = "Value";
                cboStatus.ValueMember = "Key";
                cboStatus.DataSource = Model.Status;

                cboMovment.DisplayMember = "Value";
                cboMovment.ValueMember = "Key";
                cboMovment.DataSource = Model.MovementTypes;

                RefreshBinding();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

        }

        private void olvItems_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}