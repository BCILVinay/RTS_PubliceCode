﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialView : FormBase, IMaterialView
    {
        #region Constructor

        public MaterialView()
        {
            InitializeComponent();
            this.Text = "Add Material";
        }

        public MaterialView(Material material) : this()
        {
            this.Text = "Edit Material";
            Model.Material = material;
            Model.Material.BeginEdit();
        }

        public MaterialView(Material material, string readonlyview) : this()
        {
            this.Text = "Material";
            pb_MaterialImage.ImageChanged += Pb_MaterialImage_ImageChanged;
            Model.Material = material;
            Model.Material.BeginEdit();
            Model.IsReadOnlyView = true;
            btnSave.Visible = true;
            SetReadOnlyView();
        }

        private void Pb_MaterialImage_ImageChanged(object sender, UIHelper.PictureBox.SelectedImage e)
        {
            try
            {
                if (ImageSerializer.CheckValidImage(ImageSerializer.SerializeImage(e.UserImage).Length))
                {
                    if (Model.ItemImage == null)
                    {
                        Model.ItemImage = new UserFile()
                        {
                            FileName = "ItemImage" + e.ImageExtension,
                            FileData = ImageSerializer.SerializeImage(e.UserImage)
                        };
                    }
                    else
                    {
                        Model.ItemImage.FileData = ImageSerializer.SerializeImage(e.UserImage);
                    }
                }
                else
                {
                    pb_MaterialImage.Image = null;
                    ShowMessage("Image size should be less than 50 KB");
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void SetReadOnlyView()
        {
            txtBundleVolume.ReadOnly = true;
            txtBundleWeight.ReadOnly = true;
            txtCode.ReadOnly = true;
            txtMaterialDesc.ReadOnly = true;
            txtHeight.ReadOnly = true;
            txtNoOfBarQty.ReadOnly = true;
            txtNoOfBarQty.ReadOnly = true;
            txtSectionbalWeigth.ReadOnly = true;
            txtStdBarLength.ReadOnly = true;
            txtTotalLenth.ReadOnly = true;
            txtUOM.ReadOnly = true;
            txtWidth.ReadOnly = true;
            cboToolings.Enabled = false;
            cboIsActive.Enabled = false;
        }

        #endregion Constructor

        #region Public Properties

        public MaterialModel Model { get; set; }

        public Permission AddEditPermision { get; set; }

        #endregion Public Properties

        #region Private Event

        public event EventHandler SaveRequested;

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        #endregion Private Event

        #region Public Methods

        public void RefreshBinding()
        {
            cboToolings.ValueMember = "Key";
            cboToolings.DisplayMember = "Value";
            cboToolings.DataSource = Model.ToolingList;

            materialBindingSource.DataSource = Model.Material;
        }

        #endregion Public Methods

        #region Private Methods

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Model.ItemImage.IsNotNull() && Model.ItemImage.FileData.IsNotNull())
                {
                    Model.Material.ImageName = ImageToBase64(Model.ItemImage.FileData);
                }
                SaveRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (Model.IsReadOnlyView) { this.DialogResult = DialogResult.OK; }
                else
                {
                    this.DialogResult = DialogResult.Cancel;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowNumbericValueOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                ((MetroFramework.Controls.MetroTextBox)sender).ResetBindingOrDefaultValueOnInvalid("0");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtUOM_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowAlphabeticalValueOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialView_Load(object sender, EventArgs e)
        {
            try
            {
                if (Model.Material.ImageName.IsNotNullOrWhiteSpace())
                {
                    pb_MaterialImage.Image = Base64ToImage(Model.Material.ImageName);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods

        public string ImageToBase64(byte[] imageBytes)
        {
            // Convert byte[] to Base64 String
            string base64String = Convert.ToBase64String(imageBytes);
            return base64String;
        }

        public Image Base64ToImage(string base64String)
        {
            // Convert Base64 String to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            MemoryStream ms = new MemoryStream(imageBytes, 0,
              imageBytes.Length);

            // Convert byte[] to Image
            ms.Write(imageBytes, 0, imageBytes.Length);
            Image image = Image.FromStream(ms, true);
            return image;
        }
    }
}