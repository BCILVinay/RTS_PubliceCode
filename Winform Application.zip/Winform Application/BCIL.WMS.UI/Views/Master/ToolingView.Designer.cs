﻿namespace BCIL.WMS.UI.Views
{
    partial class ToolingView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToolingView));
            this.toolingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.requiredPanel4 = new BCIL.UIHelper.RequiredPanel();
            this.cboLinePrefence = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel1 = new BCIL.UIHelper.RequiredPanel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.cboLocations = new MetroFramework.Controls.MetroComboBox();
            this.cboLine = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel3 = new BCIL.UIHelper.RequiredPanel();
            this.requiredPanel5 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.toolingBindingSource)).BeginInit();
            this.requiredPanel4.SuspendLayout();
            this.requiredPanel2.SuspendLayout();
            this.requiredPanel1.SuspendLayout();
            this.requiredPanel3.SuspendLayout();
            this.requiredPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolingBindingSource
            // 
            this.toolingBindingSource.DataSource = typeof(BCIL.WMS.BL.Tooling);
            // 
            // requiredPanel4
            // 
            this.requiredPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel4.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel4.Controls.Add(this.cboLinePrefence);
            this.requiredPanel4.IsRequired = true;
            this.requiredPanel4.Location = new System.Drawing.Point(463, 103);
            this.requiredPanel4.Name = "requiredPanel4";
            this.requiredPanel4.Size = new System.Drawing.Size(167, 25);
            this.requiredPanel4.TabIndex = 5;
            // 
            // cboLinePrefence
            // 
            this.cboLinePrefence.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.toolingBindingSource, "LinePrefences", true));
            this.cboLinePrefence.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboLinePrefence.FormattingEnabled = true;
            this.cboLinePrefence.ItemHeight = 19;
            this.cboLinePrefence.Location = new System.Drawing.Point(0, 0);
            this.cboLinePrefence.Name = "cboLinePrefence";
            this.cboLinePrefence.PromptItemIndex = -1;
            this.cboLinePrefence.Size = new System.Drawing.Size(147, 25);
            this.cboLinePrefence.TabIndex = 49;
            this.cboLinePrefence.UseSelectable = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(366, 105);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(95, 19);
            this.metroLabel3.TabIndex = 33;
            this.metroLabel3.Text = "Line Prefences:";
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtCode);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(120, 70);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(187, 25);
            this.requiredPanel2.TabIndex = 0;
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.toolingBindingSource, "ToolingCode", true));
            this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(0, 0);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(167, 25);
            this.txtCode.TabIndex = 0;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 73);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(90, 19);
            this.metroLabel1.TabIndex = 31;
            this.metroLabel1.Text = "Tooling Code:";
            // 
            // requiredPanel1
            // 
            this.requiredPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel1.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel1.Controls.Add(this.txtName);
            this.requiredPanel1.IsRequired = true;
            this.requiredPanel1.Location = new System.Drawing.Point(120, 102);
            this.requiredPanel1.Name = "requiredPanel1";
            this.requiredPanel1.Size = new System.Drawing.Size(187, 25);
            this.requiredPanel1.TabIndex = 1;
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.toolingBindingSource, "ToolingName", true));
            this.txtName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(0, 0);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(167, 25);
            this.txtName.TabIndex = 0;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.toolingBindingSource, "IsActive", true));
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(463, 70);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(92, 25);
            this.cboIsActive.TabIndex = 6;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(366, 73);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 29;
            this.lblIsActive.Text = "Active:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(23, 105);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(94, 19);
            this.lblName.TabIndex = 27;
            this.lblName.Text = "Tooling Name:";
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(555, 242);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(463, 242);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(23, 168);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(61, 19);
            this.metroLabel5.TabIndex = 36;
            this.metroLabel5.Text = "Location:";
            // 
            // cboLocations
            // 
            this.cboLocations.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.toolingBindingSource, "Location", true));
            this.cboLocations.FormattingEnabled = true;
            this.cboLocations.ItemHeight = 19;
            this.cboLocations.Location = new System.Drawing.Point(120, 165);
            this.cboLocations.Name = "cboLocations";
            this.cboLocations.PromptItemIndex = -1;
            this.cboLocations.Size = new System.Drawing.Size(167, 25);
            this.cboLocations.TabIndex = 46;
            this.cboLocations.UseSelectable = true;
            // 
            // cboLine
            // 
            this.cboLine.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.toolingBindingSource, "LineId", true));
            this.cboLine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboLine.FormattingEnabled = true;
            this.cboLine.ItemHeight = 19;
            this.cboLine.Location = new System.Drawing.Point(0, 0);
            this.cboLine.Name = "cboLine";
            this.cboLine.PromptItemIndex = -1;
            this.cboLine.Size = new System.Drawing.Size(147, 25);
            this.cboLine.TabIndex = 48;
            this.cboLine.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(366, 137);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(35, 19);
            this.metroLabel2.TabIndex = 47;
            this.metroLabel2.Text = "Line:";
            // 
            // requiredPanel3
            // 
            this.requiredPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel3.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel3.Controls.Add(this.cboLine);
            this.requiredPanel3.IsRequired = true;
            this.requiredPanel3.Location = new System.Drawing.Point(463, 134);
            this.requiredPanel3.Name = "requiredPanel3";
            this.requiredPanel3.Size = new System.Drawing.Size(167, 25);
            this.requiredPanel3.TabIndex = 49;
            // 
            // requiredPanel5
            // 
            this.requiredPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel5.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel5.Controls.Add(this.metroTextBox1);
            this.requiredPanel5.IsRequired = true;
            this.requiredPanel5.Location = new System.Drawing.Point(120, 134);
            this.requiredPanel5.Name = "requiredPanel5";
            this.requiredPanel5.Size = new System.Drawing.Size(187, 25);
            this.requiredPanel5.TabIndex = 50;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.toolingBindingSource, "ToolingSpeed", true));
            this.metroTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox1.MaxLength = 50;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(167, 25);
            this.metroTextBox1.TabIndex = 0;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.metroTextBox1.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(23, 137);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(95, 19);
            this.metroLabel4.TabIndex = 51;
            this.metroLabel4.Text = "Tooling Speed:";
            // 
            // metroTextBox2
            // 
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(123, 1);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.toolingBindingSource, "OtherInfo", true));
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(463, 165);
            this.metroTextBox2.MaxLength = 10;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = true;
            this.metroTextBox2.Size = new System.Drawing.Size(147, 25);
            this.metroTextBox2.TabIndex = 52;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(366, 168);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(72, 19);
            this.metroLabel6.TabIndex = 53;
            this.metroLabel6.Text = "Other Info:";
            // 
            // ToolingView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 308);
            this.Controls.Add(this.metroTextBox2);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.requiredPanel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.requiredPanel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.cboLocations);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.requiredPanel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.requiredPanel1);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Name = "ToolingView";
            this.Text = "Tooling";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ToolingView_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.toolingBindingSource)).EndInit();
            this.requiredPanel4.ResumeLayout(false);
            this.requiredPanel2.ResumeLayout(false);
            this.requiredPanel1.ResumeLayout(false);
            this.requiredPanel3.ResumeLayout(false);
            this.requiredPanel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private UIHelper.RequiredPanel requiredPanel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.RequiredPanel requiredPanel1;
        private MetroFramework.Controls.MetroTextBox txtName;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private MetroFramework.Controls.MetroLabel lblName;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.BindingSource toolingBindingSource;
        private MetroFramework.Controls.MetroComboBox cboLocations;
        private MetroFramework.Controls.MetroComboBox cboLinePrefence;
        private MetroFramework.Controls.MetroComboBox cboLine;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.RequiredPanel requiredPanel3;
        private UIHelper.RequiredPanel requiredPanel5;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
    }
}