﻿namespace BCIL.WMS.UI.Views
{
    partial class LocationView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocationView));
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel1 = new BCIL.UIHelper.RequiredPanel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.LocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.txtDescription = new MetroFramework.Controls.MetroTextBox();
            this.lblAdress = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel3 = new BCIL.UIHelper.RequiredPanel();
            this.txtLength = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel4 = new BCIL.UIHelper.RequiredPanel();
            this.txtHeight = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel5 = new BCIL.UIHelper.RequiredPanel();
            this.txtWidth = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.cmbLocationType = new MetroFramework.Controls.MetroComboBox();
            this.cboMode = new MetroFramework.Controls.MetroComboBox();
            this.cboSites = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LocationBindingSource)).BeginInit();
            this.requiredPanel2.SuspendLayout();
            this.requiredPanel3.SuspendLayout();
            this.requiredPanel4.SuspendLayout();
            this.requiredPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(485, 318);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(393, 318);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel1
            // 
            this.requiredPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel1.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel1.Controls.Add(this.txtName);
            this.requiredPanel1.IsRequired = true;
            this.requiredPanel1.Location = new System.Drawing.Point(106, 139);
            this.requiredPanel1.Name = "requiredPanel1";
            this.requiredPanel1.Size = new System.Drawing.Size(187, 25);
            this.requiredPanel1.TabIndex = 1;
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "LocationName", true));
            this.txtName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(0, 0);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(167, 25);
            this.txtName.TabIndex = 0;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // LocationBindingSource
            // 
            this.LocationBindingSource.DataSource = typeof(BCIL.WMS.BL.Location);
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.LocationBindingSource, "IsActive", true));
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(476, 75);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(72, 25);
            this.cboIsActive.TabIndex = 4;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(416, 78);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 10;
            this.lblIsActive.Text = "Active:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(30, 142);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(48, 19);
            this.lblName.TabIndex = 8;
            this.lblName.Text = "Name:";
            // 
            // txtDescription
            // 
            // 
            // 
            // 
            this.txtDescription.CustomButton.Image = null;
            this.txtDescription.CustomButton.Location = new System.Drawing.Point(399, 1);
            this.txtDescription.CustomButton.Name = "";
            this.txtDescription.CustomButton.Size = new System.Drawing.Size(47, 47);
            this.txtDescription.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtDescription.CustomButton.TabIndex = 1;
            this.txtDescription.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtDescription.CustomButton.UseSelectable = true;
            this.txtDescription.CustomButton.Visible = false;
            this.txtDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "Description", true));
            this.txtDescription.Lines = new string[0];
            this.txtDescription.Location = new System.Drawing.Point(106, 239);
            this.txtDescription.MaxLength = 512;
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.PasswordChar = '\0';
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDescription.SelectedText = "";
            this.txtDescription.SelectionLength = 0;
            this.txtDescription.SelectionStart = 0;
            this.txtDescription.ShortcutsEnabled = true;
            this.txtDescription.Size = new System.Drawing.Size(447, 49);
            this.txtDescription.TabIndex = 8;
            this.txtDescription.UseSelectable = true;
            this.txtDescription.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtDescription.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(30, 239);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(77, 19);
            this.lblAdress.TabIndex = 12;
            this.lblAdress.Text = "Description:";
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtCode);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(106, 107);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(187, 25);
            this.requiredPanel2.TabIndex = 0;
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "LocationCode", true));
            this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(0, 0);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(167, 25);
            this.txtCode.TabIndex = 0;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(30, 110);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 14;
            this.metroLabel1.Text = "Code:";
            // 
            // requiredPanel3
            // 
            this.requiredPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel3.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel3.Controls.Add(this.txtLength);
            this.requiredPanel3.IsRequired = true;
            this.requiredPanel3.Location = new System.Drawing.Point(477, 107);
            this.requiredPanel3.Name = "requiredPanel3";
            this.requiredPanel3.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel3.TabIndex = 5;
            // 
            // txtLength
            // 
            // 
            // 
            // 
            this.txtLength.CustomButton.Image = null;
            this.txtLength.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.txtLength.CustomButton.Name = "";
            this.txtLength.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtLength.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLength.CustomButton.TabIndex = 1;
            this.txtLength.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLength.CustomButton.UseSelectable = true;
            this.txtLength.CustomButton.Visible = false;
            this.txtLength.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "DimensionLength", true));
            this.txtLength.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLength.Lines = new string[0];
            this.txtLength.Location = new System.Drawing.Point(0, 0);
            this.txtLength.MaxLength = 50;
            this.txtLength.Name = "txtLength";
            this.txtLength.PasswordChar = '\0';
            this.txtLength.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLength.SelectedText = "";
            this.txtLength.SelectionLength = 0;
            this.txtLength.SelectionStart = 0;
            this.txtLength.ShortcutsEnabled = true;
            this.txtLength.Size = new System.Drawing.Size(72, 25);
            this.txtLength.TabIndex = 0;
            this.txtLength.UseSelectable = true;
            this.txtLength.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLength.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtLength.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(416, 110);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(51, 19);
            this.metroLabel2.TabIndex = 16;
            this.metroLabel2.Text = "Length:";
            // 
            // requiredPanel4
            // 
            this.requiredPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel4.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel4.Controls.Add(this.txtHeight);
            this.requiredPanel4.IsRequired = true;
            this.requiredPanel4.Location = new System.Drawing.Point(477, 171);
            this.requiredPanel4.Name = "requiredPanel4";
            this.requiredPanel4.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel4.TabIndex = 7;
            // 
            // txtHeight
            // 
            // 
            // 
            // 
            this.txtHeight.CustomButton.Image = null;
            this.txtHeight.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.txtHeight.CustomButton.Name = "";
            this.txtHeight.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtHeight.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtHeight.CustomButton.TabIndex = 1;
            this.txtHeight.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtHeight.CustomButton.UseSelectable = true;
            this.txtHeight.CustomButton.Visible = false;
            this.txtHeight.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "DimensionHeight", true));
            this.txtHeight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHeight.Lines = new string[0];
            this.txtHeight.Location = new System.Drawing.Point(0, 0);
            this.txtHeight.MaxLength = 50;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.PasswordChar = '\0';
            this.txtHeight.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtHeight.SelectedText = "";
            this.txtHeight.SelectionLength = 0;
            this.txtHeight.SelectionStart = 0;
            this.txtHeight.ShortcutsEnabled = true;
            this.txtHeight.Size = new System.Drawing.Size(72, 25);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.UseSelectable = true;
            this.txtHeight.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtHeight.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtHeight.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(416, 174);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(50, 19);
            this.metroLabel3.TabIndex = 18;
            this.metroLabel3.Text = "Height:";
            // 
            // requiredPanel5
            // 
            this.requiredPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel5.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel5.Controls.Add(this.txtWidth);
            this.requiredPanel5.IsRequired = true;
            this.requiredPanel5.Location = new System.Drawing.Point(477, 139);
            this.requiredPanel5.Name = "requiredPanel5";
            this.requiredPanel5.Size = new System.Drawing.Size(92, 25);
            this.requiredPanel5.TabIndex = 6;
            // 
            // txtWidth
            // 
            // 
            // 
            // 
            this.txtWidth.CustomButton.Image = null;
            this.txtWidth.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.txtWidth.CustomButton.Name = "";
            this.txtWidth.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtWidth.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtWidth.CustomButton.TabIndex = 1;
            this.txtWidth.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtWidth.CustomButton.UseSelectable = true;
            this.txtWidth.CustomButton.Visible = false;
            this.txtWidth.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.LocationBindingSource, "DimensionWidth", true));
            this.txtWidth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWidth.Lines = new string[0];
            this.txtWidth.Location = new System.Drawing.Point(0, 0);
            this.txtWidth.MaxLength = 50;
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.PasswordChar = '\0';
            this.txtWidth.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtWidth.SelectedText = "";
            this.txtWidth.SelectionLength = 0;
            this.txtWidth.SelectionStart = 0;
            this.txtWidth.ShortcutsEnabled = true;
            this.txtWidth.Size = new System.Drawing.Size(72, 25);
            this.txtWidth.TabIndex = 0;
            this.txtWidth.UseSelectable = true;
            this.txtWidth.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtWidth.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtWidth.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(416, 142);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(47, 19);
            this.metroLabel4.TabIndex = 20;
            this.metroLabel4.Text = "Width:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(30, 208);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(47, 19);
            this.metroLabel5.TabIndex = 22;
            this.metroLabel5.Text = "Mode:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(30, 174);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(40, 19);
            this.metroLabel6.TabIndex = 24;
            this.metroLabel6.Text = "Type:";
            // 
            // cmbLocationType
            // 
            this.cmbLocationType.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.LocationBindingSource, "Type", true));
            this.cmbLocationType.FormattingEnabled = true;
            this.cmbLocationType.ItemHeight = 19;
            this.cmbLocationType.Location = new System.Drawing.Point(106, 171);
            this.cmbLocationType.Name = "cmbLocationType";
            this.cmbLocationType.PromptItemIndex = -1;
            this.cmbLocationType.Size = new System.Drawing.Size(167, 25);
            this.cmbLocationType.TabIndex = 2;
            this.cmbLocationType.UseSelectable = true;
            // 
            // cboMode
            // 
            this.cboMode.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.LocationBindingSource, "Mode", true));
            this.cboMode.FormattingEnabled = true;
            this.cboMode.ItemHeight = 19;
            this.cboMode.Location = new System.Drawing.Point(106, 205);
            this.cboMode.Name = "cboMode";
            this.cboMode.PromptItemIndex = -1;
            this.cboMode.Size = new System.Drawing.Size(167, 25);
            this.cboMode.TabIndex = 25;
            this.cboMode.UseSelectable = true;
            // 
            // cboSites
            // 
            this.cboSites.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboSites.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.LocationBindingSource, "Site", true));
            this.cboSites.DataSource = this.LocationBindingSource;
            this.cboSites.FormattingEnabled = true;
            this.cboSites.ItemHeight = 19;
            this.cboSites.Location = new System.Drawing.Point(106, 75);
            this.cboSites.Name = "cboSites";
            this.cboSites.PromptItemIndex = -1;
            this.cboSites.Size = new System.Drawing.Size(168, 25);
            this.cboSites.TabIndex = 29;
            this.cboSites.UseSelectable = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(30, 78);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(41, 19);
            this.metroLabel7.TabIndex = 30;
            this.metroLabel7.Text = "Plant:";
            // 
            // LocationView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 383);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.cboSites);
            this.Controls.Add(this.cboMode);
            this.Controls.Add(this.cmbLocationType);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.requiredPanel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.requiredPanel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.requiredPanel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lblAdress);
            this.Controls.Add(this.requiredPanel1);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Name = "LocationView";
            this.Text = "Location";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LocationView_FormClosing);
            this.requiredPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LocationBindingSource)).EndInit();
            this.requiredPanel2.ResumeLayout(false);
            this.requiredPanel3.ResumeLayout(false);
            this.requiredPanel4.ResumeLayout(false);
            this.requiredPanel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private UIHelper.RequiredPanel requiredPanel1;
        private MetroFramework.Controls.MetroTextBox txtName;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private MetroFramework.Controls.MetroLabel lblName;
        private MetroFramework.Controls.MetroTextBox txtDescription;
        private MetroFramework.Controls.MetroLabel lblAdress;
        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.RequiredPanel requiredPanel3;
        private MetroFramework.Controls.MetroTextBox txtLength;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.RequiredPanel requiredPanel4;
        private MetroFramework.Controls.MetroTextBox txtHeight;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.RequiredPanel requiredPanel5;
        private MetroFramework.Controls.MetroTextBox txtWidth;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroComboBox cmbLocationType;
        private System.Windows.Forms.BindingSource LocationBindingSource;
        private MetroFramework.Controls.MetroComboBox cboMode;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroComboBox cboSites;
    }
}