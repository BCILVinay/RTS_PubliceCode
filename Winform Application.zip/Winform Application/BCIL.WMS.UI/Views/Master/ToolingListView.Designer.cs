﻿namespace BCIL.WMS.UI.Views
{
    partial class ToolingListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToolingListView));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvToolings = new BCIL.UIHelper.DataListView();
            this.olvColumnCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnToolingSpeed = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLine = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLinePrefences = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnToolingMaterialBin = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedBy = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedDate = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnActive = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnEdit = new System.Windows.Forms.ToolStripButton();
            this.btnImport = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.buttonSearch1 = new BCIL.UIHelper.ButtonSearch();
            this.cboLines = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.olvColumnOtherInfo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvToolings)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvToolings);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 142);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(840, 321);
            this.metroPanel1.TabIndex = 9;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvToolings
            // 
            this.olvToolings.AllColumns.Add(this.olvColumnCode);
            this.olvToolings.AllColumns.Add(this.olvColumnToolingSpeed);
            this.olvToolings.AllColumns.Add(this.olvColumnLine);
            this.olvToolings.AllColumns.Add(this.olvColumnLinePrefences);
            this.olvToolings.AllColumns.Add(this.olvColumnToolingMaterialBin);
            this.olvToolings.AllColumns.Add(this.olvColumnCreatedBy);
            this.olvToolings.AllColumns.Add(this.olvColumnCreatedDate);
            this.olvToolings.AllColumns.Add(this.olvColumnOtherInfo);
            this.olvToolings.AllColumns.Add(this.olvColumnActive);
            this.olvToolings.AllColumns.Add(this.olvColumn1);
            this.olvToolings.CellEditUseWholeCell = false;
            this.olvToolings.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnCode,
            this.olvColumnToolingSpeed,
            this.olvColumnLine,
            this.olvColumnLinePrefences,
            this.olvColumnToolingMaterialBin,
            this.olvColumnCreatedBy,
            this.olvColumnCreatedDate,
            this.olvColumnOtherInfo,
            this.olvColumnActive,
            this.olvColumn1});
            this.olvToolings.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvToolings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvToolings.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvToolings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvToolings.FullRowSelect = true;
            this.olvToolings.HeaderMinimumHeight = 30;
            this.olvToolings.HideSelection = false;
            this.olvToolings.IncludeColumnHeadersInCopy = true;
            this.olvToolings.Location = new System.Drawing.Point(0, 33);
            this.olvToolings.Name = "olvToolings";
            this.olvToolings.RowHeight = 25;
            this.olvToolings.ShowGroups = false;
            this.olvToolings.Size = new System.Drawing.Size(840, 288);
            this.olvToolings.TabIndex = 10;
            this.olvToolings.UseCompatibleStateImageBehavior = false;
            this.olvToolings.View = System.Windows.Forms.View.Details;
            this.olvToolings.VirtualMode = true;
            this.olvToolings.SelectedIndexChanged += new System.EventHandler(this.olvToolings_SelectedIndexChanged);
            this.olvToolings.DoubleClick += new System.EventHandler(this.btnEdit_Click);
            // 
            // olvColumnCode
            // 
            this.olvColumnCode.AspectName = "ToolingCode";
            this.olvColumnCode.Text = "Tooling Code";
            this.olvColumnCode.Width = 150;
            // 
            // olvColumnToolingSpeed
            // 
            this.olvColumnToolingSpeed.AspectName = "ToolingSpeed";
            this.olvColumnToolingSpeed.Text = "Tooling Speed";
            this.olvColumnToolingSpeed.Width = 120;
            // 
            // olvColumnLine
            // 
            this.olvColumnLine.AspectName = "LineName";
            this.olvColumnLine.Text = "Line";
            this.olvColumnLine.Width = 120;
            // 
            // olvColumnLinePrefences
            // 
            this.olvColumnLinePrefences.AspectName = "LinePrefencesName";
            this.olvColumnLinePrefences.Text = "Line Prefences";
            this.olvColumnLinePrefences.Width = 120;
            // 
            // olvColumnToolingMaterialBin
            // 
            this.olvColumnToolingMaterialBin.AspectName = "Location.Value";
            this.olvColumnToolingMaterialBin.Text = "Location";
            this.olvColumnToolingMaterialBin.Width = 200;
            // 
            // olvColumnCreatedBy
            // 
            this.olvColumnCreatedBy.AspectName = "CreatedBy";
            this.olvColumnCreatedBy.Text = "Created By";
            this.olvColumnCreatedBy.Width = 114;
            // 
            // olvColumnCreatedDate
            // 
            this.olvColumnCreatedDate.AspectName = "CreatedDate";
            this.olvColumnCreatedDate.Text = "Created Date";
            this.olvColumnCreatedDate.Width = 135;
            // 
            // olvColumnActive
            // 
            this.olvColumnActive.AspectName = "IsActive";
            this.olvColumnActive.Text = "Active";
            this.olvColumnActive.Width = 111;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.btnEdit,
            this.btnImport,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(840, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.IsActionRestrictedByPermission = false;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(62, 30);
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(60, 30);
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnImport
            // 
            this.btnImport.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImport.IsActionRestrictedByPermission = false;
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(77, 30);
            this.btnImport.Text = "Import";
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(99, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // buttonSearch1
            // 
            this.buttonSearch1.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch1.ButtonImage")));
            this.buttonSearch1.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch1.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch1.ImageSize = 50;
            this.buttonSearch1.Location = new System.Drawing.Point(596, 45);
            this.buttonSearch1.Name = "buttonSearch1";
            this.buttonSearch1.Size = new System.Drawing.Size(85, 64);
            this.buttonSearch1.TabIndex = 38;
            this.buttonSearch1.Text = "Search";
            this.buttonSearch1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch1.UseSelectable = true;
            this.buttonSearch1.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // cboLines
            // 
            this.cboLines.FormattingEnabled = true;
            this.cboLines.ItemHeight = 19;
            this.cboLines.Location = new System.Drawing.Point(320, 64);
            this.cboLines.Name = "cboLines";
            this.cboLines.PromptItemIndex = -1;
            this.cboLines.Size = new System.Drawing.Size(167, 25);
            this.cboLines.TabIndex = 36;
            this.cboLines.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(279, 67);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(35, 19);
            this.metroLabel6.TabIndex = 37;
            this.metroLabel6.Text = "Line:";
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(71, 64);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(167, 25);
            this.txtCode.TabIndex = 34;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(21, 67);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 35;
            this.metroLabel1.Text = "Code:";
            // 
            // olvColumnOtherInfo
            // 
            this.olvColumnOtherInfo.AspectName = "OtherInfo";
            this.olvColumnOtherInfo.Text = "Other Info";
            // 
            // ToolingListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonSearch1);
            this.Controls.Add(this.cboLines);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "ToolingListView";
            this.Size = new System.Drawing.Size(864, 480);
            this.Title = "Toolings";
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.ToolingListView_Showing);
            this.Resize += new System.EventHandler(this.ToolingListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.txtCode, 0);
            this.Controls.SetChildIndex(this.metroLabel6, 0);
            this.Controls.SetChildIndex(this.cboLines, 0);
            this.Controls.SetChildIndex(this.buttonSearch1, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvToolings)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvToolings;
        private BrightIdeasSoftware.OLVColumn olvColumnCode;
        private BrightIdeasSoftware.OLVColumn olvColumnToolingMaterialBin;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedBy;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedDate;
        private BrightIdeasSoftware.OLVColumn olvColumnActive;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripButton btnEdit;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnImport;
        private BrightIdeasSoftware.OLVColumn olvColumnToolingSpeed;
        private UIHelper.ButtonSearch buttonSearch1;
        private MetroFramework.Controls.MetroComboBox cboLines;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private BrightIdeasSoftware.OLVColumn olvColumnLine;
        private BrightIdeasSoftware.OLVColumn olvColumnLinePrefences;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnNext;
        private BrightIdeasSoftware.OLVColumn olvColumnOtherInfo;
    }
}
