﻿using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public interface ILocationView : IBaseView<LocationModel>
    {
        event EventHandler SaveRequested;
        event EventHandler<FormClosingEventArgs> CancelRequested;
        Permission AddEditPermision { get; set; }
        void RefreshBinding();
        DialogResult DialogResult { get; set; }
    }
}
