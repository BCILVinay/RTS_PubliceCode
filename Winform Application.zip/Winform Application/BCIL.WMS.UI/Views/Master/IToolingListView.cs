﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IToolingListView : IBaseView<ToolingListModel>
    {
        event EventHandler AddToolingRequested;
        event EventHandler<Tooling> EditToolingRequested;
        event EventHandler ImportDataRequested;
        event EventHandler SearchRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        void RefreshGridView();
        void RefreshBinding();
    }
}
