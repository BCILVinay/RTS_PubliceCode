﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialBinListView : ControlSliderBase, IMaterialBinListView
    {
        #region Public Constructors

        public MaterialBinListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Material Bin";
            //olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var MaterialBin = o as MaterialBin;
                return MaterialBin.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler ImportDataRequested;

        public event EventHandler AddMaterialBinRequested;

        public event EventHandler<List<MaterialBin>> PrintRequested;

        public event EventHandler<MaterialBin> EditMaterialBinRequested;

        public event EventHandler SearchRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler NextPageResultsRequested;

        #endregion Public Events

        #region Public Properties

        public MaterialBinListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void BindingHeader()
        {
            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.MaterialBinName);
            BindingUtility.CreateBinding(txtLocation, c => c.Text, Model.SearchCriteria, d => d.LocationCode);
            BindingUtility.CreateBinding(txtSearchMaterial, c => c.Text, Model.SearchCriteria, d => d.MaterialCode);
        }

        public void RefreshBinding()
        {
            if (Model.MaterialBins.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.MaterialBins.Count - 1, Model.MaterialBins.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.MaterialBins.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.MaterialBins.Count);
            }

            olvMaterialBins.SetObjects(Model.MaterialBins);
        }

        #endregion Public Methods

        #region Private Event

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddMaterialBinRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvMaterialBins.SelectedObject != null)
                {
                    EditMaterialBinRequested?.Invoke(this, (MaterialBin)olvMaterialBins.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialBinListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvMaterialBins.Width - 20;
                olvColumnCode.Width = withToDistribute.GetPercentValue(8);
                olvColumnMaterialCode.Width = withToDistribute.GetPercentValue(10);
                olvColumnMaterialDesc.Width = withToDistribute.GetPercentValue(15);
                olvColumnLocation.Width = withToDistribute.GetPercentValue(10);
                olvColumnRowNo.Width = withToDistribute.GetPercentValue(5);
                olvColumnRackNo.Width = withToDistribute.GetPercentValue(8);
                olvColumnColumnNo.Width = withToDistribute.GetPercentValue(8);
                olvColumnHeight.Width = withToDistribute.GetPercentValue(8);
                olvColumnWidth.Width = withToDistribute.GetPercentValue(8);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(10);
                olvColumnCapacity.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvMaterialBins_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnPrint.Enabled = true;
                if (olvMaterialBins.SelectedObjects.Count > 0)
                {
                    btnEdit.Enabled = true;
                    btnPrint.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                    // btnPrint.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                ImportDataRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null) { return; }
                var _MaterialBinList = new List<MaterialBin>();
                foreach (MaterialBin item in olvMaterialBins.SelectedObjects)
                {
                    _MaterialBinList.Add(item);
                }
                CodeContract.Required<ArgumentException>(_MaterialBinList.HaveItems(), "Atleast one bin is required");

                PrintRequested?.Invoke(this, _MaterialBinList);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Event
    }
}