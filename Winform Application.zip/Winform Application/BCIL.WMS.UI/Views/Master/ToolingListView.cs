﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ToolingListView : ControlSliderBase, IToolingListView
    {
        #region Public Constructors

        public ToolingListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Toolings";
            olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var tooling = o as Tooling;
                return tooling.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler AddToolingRequested;

        public event EventHandler<Tooling> EditToolingRequested;

        public event EventHandler ImportDataRequested;

        public event EventHandler SearchRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler NextPageResultsRequested;

        #endregion Public Events

        #region Public Properties

        public ToolingListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinding()
        {
            cboLines.DisplayMember = "Code";
            cboLines.ValueMember = "LineId";
            cboLines.DataSource = Model.Lines;

            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.ToolingCode);
            BindingUtility.CreateBinding(cboLines, c => c.SelectedValue, Model.SearchCriteria, d => d.LineId);
        }

        public void RefreshGridView()
        {
            if (Model.Toolings.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.Toolings.Count - 1, Model.Toolings.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.Toolings.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.Toolings.Count);
            }

            olvToolings.SetObjects(Model.Toolings);
        }

        #endregion Public Methods

        #region Private Events

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddToolingRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvToolings.SelectedObject != null)
                {
                    EditToolingRequested?.Invoke(this, (Tooling)olvToolings.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvToolings_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvToolings.SelectedObjects.Count > 0)
                {
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ToolingListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvToolings.Width - 20;
                olvColumnCode.Width = withToDistribute.GetPercentValue(20);
                olvColumnLine.Width = withToDistribute.GetPercentValue(10);
                olvColumnLinePrefences.Width = withToDistribute.GetPercentValue(10);
                olvColumnToolingMaterialBin.Width = withToDistribute.GetPercentValue(10);
                olvColumnToolingSpeed.Width = withToDistribute.GetPercentValue(10);
                olvColumnCreatedBy.Width = withToDistribute.GetPercentValue(10);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(10);
                olvColumnActive.Width = withToDistribute.GetPercentValue(10);
                olvColumnOtherInfo.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                ImportDataRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ToolingListView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}