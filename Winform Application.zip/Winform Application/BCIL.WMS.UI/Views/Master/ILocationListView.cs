﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface ILocationListView : IBaseView<LocationListModel>
    {
        event EventHandler AddLocationRequested;
        event EventHandler<Location> EditLocationRequested;
        event EventHandler ImportDataRequested;
        event EventHandler SearchRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        event EventHandler<List<Location>> PrintRequested;
        void RefreshBinding();
        void RefreshGrid();
    }
}
