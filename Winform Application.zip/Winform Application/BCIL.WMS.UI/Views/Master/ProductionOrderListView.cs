﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using BCIL.WMS.UI.Models;
using System;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ProductionOrderListView : ControlSliderBase, IProductionOrderListView
    {
        #region Constructor

        public ProductionOrderListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Production Orders";

            //olvColumnIsBrown.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };

            olvColumnStatus.AspectToStringConverter = (object o) => { return ((ProductionOrderStatus)o).DisplayName(); };

            olvColumnCreatedOn.AspectGetter = (o) =>
            {
                var obj = o as ProductionOrder;
                return obj.CreatedOn.ToString(App.DateFormat);
            };
            olvColumnPOrderDate.AspectGetter = (o) =>
            {
                var obj = o as ProductionOrder;
                return obj.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Constructor

        #region Public events

        public event EventHandler AddProductionOrderRequested;

        public event EventHandler<ProductionOrder> EditProductionOrderRequested;

        public event EventHandler ImportDataRequested;

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        public event EventHandler<ProductionOrder> PrintRequested;

        public event EventHandler<ProductionOrder> ItemLabelPrintRequested;

        #endregion Public events

        #region Public Property

        public ProductionOrderListModel Model { get; set; }

        #endregion Public Property

        #region Private Events

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddProductionOrderRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvProductionOrders.SelectedObject != null)
                {
                    EditProductionOrderRequested?.Invoke(this, (ProductionOrder)olvProductionOrders.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                ImportDataRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void dtpImported_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                Model.SearchCriteria.CreatedFrom = dtpImportedFrom.Value;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void dtpImportedTo_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                Model.SearchCriteria.CreatedTo = dtpImportedTo.Value;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvProductionOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvProductionOrders.SelectedObjects.Count > 0)
                {
                   
                    var po = (ProductionOrder)olvProductionOrders.SelectedObject;
                    if (po.POLineItems.HaveItems() && po.Status== BL.Enums.ProductionOrderStatus.New)
                    {
                        btnEdit.Enabled = false;
                        btnPrint.Enabled = true;
                    }
                }
                else
                {
                    btnEdit.Enabled = false;
                    btnPrint.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionOrderListView_Load(object sender, EventArgs e)
        {
            try
            {
                BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.POrderNo);

                dtpImportedFrom.Value = Model.SearchCriteria.CreatedFrom;
                dtpImportedTo.Value = Model.SearchCriteria.CreatedTo;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionOrderListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvProductionOrders.Width - 20;
                olvColumnPOrderNo.Width = withToDistribute.GetPercentValue(10);
                olvColumnMaterial.Width = withToDistribute.GetPercentValue(10);
                olvColumnMaterialDesc.Width = withToDistribute.GetPercentValue(14);
                olvColumnMovementType.Width = withToDistribute.GetPercentValue(10);
                olvColumnTooling.Width = withToDistribute.GetPercentValue(8);
                olvColumnLinePrefences.Width = withToDistribute.GetPercentValue(10);
                olvColumnBundles.Width = withToDistribute.GetPercentValue(8);
                olvColumnStatus.Width = withToDistribute.GetPercentValue(10);
                olvColumnPOrderDate.Width = withToDistribute.GetPercentValue(10);
                olvColumnCreatedOn.Width = withToDistribute.GetPercentValue(10);
             
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        public void RefreshGrid()
        {
            if (Model.ProductionOrders.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = string.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.ProductionOrders.Count - 1, Model.ProductionOrders.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.ProductionOrders.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = string.Format("Total records: {0}", Model.ProductionOrders.Count);
            }
            olvProductionOrders.SetObjects(Model.ProductionOrders);
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (App.WorkStation.WMaterialBination.IsNull()) throw new BCILException("First configure workstation settings");
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                CodeContract.Required<BCILException>(App.WorkStation.WSLine.IsNotNull(), "First configure workstation settings");
                if (!App.WorkStation.WMaterialBination.IsNull())
                {
                    PrintRequested?.Invoke(this, (ProductionOrder)olvProductionOrders.SelectedObjects[0]);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionOrderListView_Showing(object sender, ActionArg e)
        {
            try
            {
                if (App.WorkStation.WMaterialBination.IsNull()) throw new BCILException("First configure workstation settings");
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                CodeContract.Required<BCILException>(App.WorkStation.WSLine.IsNotNull(), "First configure workstation settings");
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

     
        private void btnItemPrinting_Click(object sender, EventArgs e)
        {
            try
            {
                if (App.WorkStation.WMaterialBination.IsNull()) throw new BCILException("First configure workstation settings");

                LoginedLocationSelectionView.SelectLocationIfNot(this);

                ItemLabelPrintRequested?.Invoke(this, (ProductionOrder)olvProductionOrders.SelectedObjects[0]);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
        #endregion Private Events

    }
}