﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialListView : ControlSliderBase, IMaterialListView
    {
        #region Public Constructors

        public MaterialListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Materials";
            //olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            olvColumnCrossSecArea.AspectToStringConverter = (object o) => { return string.Format("{0:0.00}", o); };
            olvColumnBundleVolume.AspectToStringConverter = (object o) => { return string.Format("{0:0.00}", o); };
            olvColumnBundleTotalWeight.AspectToStringConverter = (object o) => { return string.Format("{0:0.00}", o); };
            olvColumnBundleTotalLengthInMtrs.AspectToStringConverter = (object o) => { return string.Format("{0:0.00}", o); };

            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var obj = o as Material;
                return obj.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler AddMaterialRequested;

        public event EventHandler<Material> EditMaterialRequested;

        public event EventHandler ImportDataRequested;

        public event EventHandler SearchRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler NextPageResultsRequested;
        public event EventHandler<Material> ReadOnlyViewMaterialRequested;

        #endregion Public Events

        #region Public Properties

        public MaterialListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void BindingHeader()
        {
            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.MeterialCode);
            BindingUtility.CreateBinding(txtLocation, c => c.Text, Model.SearchCriteria, d => d.MeterialDesc);
        }

        public void RefreshBinding()
        {
            if (Model.Materials.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.Materials.Count - 1, Model.Materials.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.Materials.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.Materials.Count);
            }

            olvMaterials.SetObjects(Model.Materials);
        }

        #endregion Public Methods

        #region Private Events

        private void olvMaterials_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvMaterials.SelectedObjects.Count > 0)
                {
                    btnEdit.Enabled = true;
                    btnView.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                    btnView.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvMaterials.Width - 20;
                olvColumnMaterialName.Width = withToDistribute.GetPercentValue(8);
                olvColumnMaterialDescription.Width = withToDistribute.GetPercentValue(15);
                olvColumnToolingId.Width = withToDistribute.GetPercentValue(6);
                olvColumnSectionalWeight.Width = withToDistribute.GetPercentValue(8);
                olvColumnPackSize.Width = withToDistribute.GetPercentValue(7);
                olvColumnStdBarLength.Width = withToDistribute.GetPercentValue(8);
                olvColumnCrossSecArea.Width = withToDistribute.GetPercentValue(10);
                olvColumnBundleVolume.Width = withToDistribute.GetPercentValue(10);
                olvColumnBundleTotalLengthInMtrs.Width = withToDistribute.GetPercentValue(10);
                olvColumnBundleTotalWeight.Width = withToDistribute.GetPercentValue(8);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddMaterialRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvMaterials.SelectedObject != null)
                {
                    EditMaterialRequested?.Invoke(this, (Material)olvMaterials.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                ImportDataRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvMaterials.SelectedObject != null)
                {
                    ReadOnlyViewMaterialRequested?.Invoke(this, (Material)olvMaterials.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}