﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BCIL.WMS.UI.Models;
using BCIL.Administration.BL;
using BCIL.Utility;

namespace BCIL.WMS.UI.Views
{
    public partial class SiteListView : ControlSliderBase, ISiteListView
    {
        #region Public Constructors
        public SiteListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Plants";
            olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var site = o as Site;
                return site.CreatedDate.ToString(App.DateFormat);
            };
        }
        #endregion Public Constructors

        #region Public Events
        public event EventHandler AddSiteRequested;
        public event EventHandler<Site> EditSiteRequested;
        #endregion Public Events

        #region Public Properties
        public SiteListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinding()
        {
            olvSites.SetObjects(Model.Sites);
            lblRecords.Text = "Total records: " + Model.Sites.Count.ToString();
        }

        #endregion Public Methods

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddSiteRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvSites.SelectedObject != null)
                {
                    EditSiteRequested?.Invoke(this, (Site)olvSites.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void SiteListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvSites.Width - 20;
                olvColumnCode.Width = withToDistribute.GetPercentValue(20);
                olvColumnDescription.Width = withToDistribute.GetPercentValue(30);
                olvColumnName.Width = withToDistribute.GetPercentValue(20);
                olvColumnCreatedBy.Width = withToDistribute.GetPercentValue(10);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(10);
                olvColumnActive.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvSites_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvSites.SelectedObjects.Count > 0)
                {
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}
