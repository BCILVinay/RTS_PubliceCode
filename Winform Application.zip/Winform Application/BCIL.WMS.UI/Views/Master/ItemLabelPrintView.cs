﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ItemLabelPrintView : FormBase, IItemLabelPrintView
    {
        public ItemLabelPrintView()
        {
            InitializeComponent();
        }

        public ItemLabelPrintView(ProductionOrder po) : this()
        {
            if (Model == null) Model = new ItemLabelPrintModel();
            Model.POrder = po;
            if (Model.POrder.Status == BL.Enums.ProductionOrderStatus.BundlePrinted || Model.POrder.Status == BL.Enums.ProductionOrderStatus.ItemPrinted)
            {
                ShowReadOnlyView();
            }
            BindUIData();
        }

        public void BindHeader()
        {
            lblMaterialCode.Text = Model.POrder.POLineItems[0].Material.Value;
            lblPODate.Text = Model.POrder.POrderDate.ToString(App.DateFormat);
            lblPONumber.Text = Model.POrder.POrderNo;

            BindingUtility.CreateBinding(txtBundleQty, c => c.Text, Model, d => d.QtyToPrint);
            BindingUtility.CreateBinding(lblTotalItemQty, c => c.Text, Model, d => d.TotalItemQty);
            BindingUtility.CreateBinding(lblBundleQty, c => c.Text, Model, d => d.TotalBundleQty);
            BindingUtility.CreateBinding(txtTotalItemToPrint, c => c.Text, Model, d => d.CalculatedItemQty);
            BindingUtility.CreateBinding(lblPrintedQtyValues, c => c.Text, Model, d => d.TotalPrintedItemQty);
            BindingUtility.CreateBinding(lblTotalPendingBundleQty, c => c.Text, Model, d => d.TotalPendingBundleQty);
            
            //lblPrintedQtyValues.Text = Model.TotalPrintedBundleQty.ToString();
        }

        private void BindUIData()
        {
        }

        private void ShowReadOnlyView()
        {
            btnPrint.Visible = false;
        }

        public ItemLabelPrintModel Model { get; set; }

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SavePrintRequested;

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (SavePrintRequested != null) SavePrintRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowWholeNumberOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtBundleQty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtBundleQty.Text) && txtBundleQty.DataBindings.Count > 0)
                {
                    txtBundleQty.DataBindings[0].ReadValue();
                }
                if (txtBundleQty.DataBindings.Count > 0) txtBundleQty.DataBindings[0].WriteValue();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}