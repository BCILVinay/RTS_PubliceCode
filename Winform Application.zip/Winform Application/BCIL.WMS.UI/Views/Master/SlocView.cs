﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialBinView : FormBase, IMaterialBinView
    {
        #region Constructor

        public MaterialBinView()
        {
            InitializeComponent();
            this.Text = "Add Material Bin";
        }

        public MaterialBinView(MaterialBin MaterialBin) : this()
        {
            this.Text = "Edit Material Bin";
            txtCode.Enabled = false;
            Model.MaterialBin = MaterialBin;
            Model.MaterialBin.BeginEdit();
        }

        #endregion Constructor

        #region Public Properties

        public Permission AddEditPermision { get; set; }

        public MaterialBinModel Model { get; set; }

        #endregion Public Properties

        #region Private Event

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SaveRequested;

        public event EventHandler SelectLocationReq;

        public event EventHandler SelectMaterialReq;

        #endregion Private Event

        #region Public Methods

        public void RefreshBinding()
        {
            //cboMaterial.ValueMember = "Key";
            //cboMaterial.DisplayMember = "Value";
            //cboMaterial.DataSource = Model.Materials;

            MaterialBinBindingSource.DataSource = Model.MaterialBin;
        }

        #endregion Public Methods

        #region Private Methods

        private void MaterialBinView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowNumbericValueOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                ((MetroFramework.Controls.MetroTextBox)sender).ResetBindingOrDefaultValueOnInvalid("0");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSelectMaterial_Click(object sender, EventArgs e)
        {
            try
            {
                SelectMaterialReq?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSelectLocation_Click(object sender, EventArgs e)
        {
            try
            {
                SelectLocationReq?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}