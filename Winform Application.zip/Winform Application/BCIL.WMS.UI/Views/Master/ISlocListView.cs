﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Views
{
    public interface IMaterialBinListView : IBaseView<MaterialBinListModel>
    {
        event EventHandler AddMaterialBinRequested;

        event EventHandler<MaterialBin> EditMaterialBinRequested;
        event EventHandler<List<MaterialBin>> PrintRequested;
        event EventHandler ImportDataRequested;

        event EventHandler PrevPageResultsRequested;

        event EventHandler NextPageResultsRequested;
        event EventHandler SearchRequested;
        void BindingHeader();
        void RefreshBinding();
    }
}