﻿namespace BCIL.WMS.UI.Views
{
    partial class ProductionOrderView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductionOrderView));
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtPoNo = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cboStatus = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cboMovment = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.productionOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.miniToolStrip = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.DataListView();
            this.olvColumnMaterialCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnDescription = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnBundleQty = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnRemove = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productionOrderBindingSource)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtPoNo);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(140, 70);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel2.TabIndex = 31;
            // 
            // txtPoNo
            // 
            // 
            // 
            // 
            this.txtPoNo.CustomButton.Image = null;
            this.txtPoNo.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtPoNo.CustomButton.Name = "";
            this.txtPoNo.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtPoNo.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPoNo.CustomButton.TabIndex = 1;
            this.txtPoNo.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPoNo.CustomButton.UseSelectable = true;
            this.txtPoNo.CustomButton.Visible = false;
            this.txtPoNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPoNo.Lines = new string[0];
            this.txtPoNo.Location = new System.Drawing.Point(0, 0);
            this.txtPoNo.MaxLength = 50;
            this.txtPoNo.Name = "txtPoNo";
            this.txtPoNo.PasswordChar = '\0';
            this.txtPoNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPoNo.SelectedText = "";
            this.txtPoNo.SelectionLength = 0;
            this.txtPoNo.SelectionStart = 0;
            this.txtPoNo.ShortcutsEnabled = true;
            this.txtPoNo.Size = new System.Drawing.Size(222, 25);
            this.txtPoNo.TabIndex = 0;
            this.txtPoNo.UseSelectable = true;
            this.txtPoNo.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPoNo.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 73);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(53, 19);
            this.metroLabel1.TabIndex = 32;
            this.metroLabel1.Text = "PO No:";
            // 
            // cboStatus
            // 
            this.cboStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.ItemHeight = 19;
            this.cboStatus.Location = new System.Drawing.Point(680, 70);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.PromptItemIndex = -1;
            this.cboStatus.Size = new System.Drawing.Size(135, 25);
            this.cboStatus.TabIndex = 42;
            this.cboStatus.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(628, 73);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(46, 19);
            this.metroLabel2.TabIndex = 43;
            this.metroLabel2.Text = "Status:";
            // 
            // cboMovment
            // 
            this.cboMovment.FormattingEnabled = true;
            this.cboMovment.ItemHeight = 19;
            this.cboMovment.Location = new System.Drawing.Point(140, 101);
            this.cboMovment.Name = "cboMovment";
            this.cboMovment.PromptItemIndex = -1;
            this.cboMovment.Size = new System.Drawing.Size(222, 25);
            this.cboMovment.TabIndex = 46;
            this.cboMovment.UseSelectable = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(23, 104);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(107, 19);
            this.metroLabel4.TabIndex = 47;
            this.metroLabel4.Text = "Movement Type:";
            // 
            // productionOrderBindingSource
            // 
            this.productionOrderBindingSource.DataSource = typeof(BCIL.WMS.BL.MaterialBin);
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.miniToolStrip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.miniToolStrip.Location = new System.Drawing.Point(378, 7);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(829, 33);
            this.miniToolStrip.TabIndex = 0;
            this.miniToolStrip.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 147);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(792, 281);
            this.metroPanel1.TabIndex = 48;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllColumns.Add(this.olvColumnMaterialCode);
            this.olvItems.AllColumns.Add(this.olvColumnDescription);
            this.olvItems.AllColumns.Add(this.olvColumnBundleQty);
            this.olvItems.AllColumns.Add(this.olvColumn1);
            this.olvItems.CellEditActivation = BrightIdeasSoftware.ObjectListView.CellEditActivateMode.SingleClickAlways;
            this.olvItems.CellEditUseWholeCell = false;
            this.olvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnMaterialCode,
            this.olvColumnDescription,
            this.olvColumnBundleQty,
            this.olvColumn1});
            this.olvItems.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvItems.FullRowSelect = true;
            this.olvItems.HeaderMinimumHeight = 30;
            this.olvItems.HideSelection = false;
            this.olvItems.IncludeColumnHeadersInCopy = true;
            this.olvItems.Location = new System.Drawing.Point(0, 33);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeight = 25;
            this.olvItems.ShowGroups = false;
            this.olvItems.Size = new System.Drawing.Size(792, 248);
            this.olvItems.TabIndex = 10;
            this.olvItems.UseCompatibleStateImageBehavior = false;
            this.olvItems.View = System.Windows.Forms.View.Details;
            this.olvItems.VirtualMode = true;
            this.olvItems.SelectedIndexChanged += new System.EventHandler(this.olvItems_SelectedIndexChanged);
            // 
            // olvColumnMaterialCode
            // 
            this.olvColumnMaterialCode.AspectName = "Material.Value";
            this.olvColumnMaterialCode.IsEditable = false;
            this.olvColumnMaterialCode.Text = "Material Code";
            this.olvColumnMaterialCode.Width = 219;
            // 
            // olvColumnDescription
            // 
            this.olvColumnDescription.AspectName = "MaterialDescription";
            this.olvColumnDescription.IsEditable = false;
            this.olvColumnDescription.Text = "Description";
            this.olvColumnDescription.Width = 200;
            // 
            // olvColumnBundleQty
            // 
            this.olvColumnBundleQty.AspectName = "Length";
            this.olvColumnBundleQty.CellEditUseWholeCell = true;
            this.olvColumnBundleQty.Text = "Quantity";
            this.olvColumnBundleQty.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.IsEditable = false;
            this.olvColumn1.IsHeaderVertical = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.btnRemove,
            this.lblRecords});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(792, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.IsActionRestrictedByPermission = false;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(62, 30);
            this.btnAdd.Text = "Add";
            this.btnAdd.Visible = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Enabled = false;
            this.btnRemove.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnRemove.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnRemove.Image = ((System.Drawing.Image)(resources.GetObject("btnRemove.Image")));
            this.btnRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(85, 30);
            this.btnRemove.Text = "Remove";
            this.btnRemove.Visible = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 22);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(729, 443);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 50;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(637, 443);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 49;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // ProductionOrderView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 513);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.cboMovment);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.cboStatus);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Name = "ProductionOrderView";
            this.Text = "Production Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProductionOrderView_FormClosing);
            this.Load += new System.EventHandler(this.ProductionOrderView_Load);
            this.requiredPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.productionOrderBindingSource)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtPoNo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroComboBox cboStatus;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cboMovment;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.BindingSource productionOrderBindingSource;
        private MetroFramework.MyCustomControl.MetroToolStrip miniToolStrip;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvItems;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialCode;
        private BrightIdeasSoftware.OLVColumn olvColumnDescription;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripButton btnRemove;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private BrightIdeasSoftware.OLVColumn olvColumnBundleQty;
    }
}