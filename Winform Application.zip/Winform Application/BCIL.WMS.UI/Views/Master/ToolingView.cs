﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ToolingView : FormBase, IToolingView
    {
        #region Constructor

        public ToolingView()
        {
            InitializeComponent();
        }

        public ToolingView(Tooling tooling) : this()
        {
            this.Text = "Edit Tooling";
            Model.Tooling = tooling;
            Model.Tooling.BeginEdit();
        }

        #endregion Constructor

        #region Public Properties

        public ToolingModel Model { get; set; }

        public Permission AddEditPermision { get; set; }

        #endregion Public Properties

        #region Private Event

        public event EventHandler SaveRequested;

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        #endregion Private Event

        #region Public Methods

        public void RefreshBinding()
        {
            cboLocations.DisplayMember = "Value";
            cboLocations.ValueMember = "Key";
            cboLocations.DataSource = Model.LocationList;

            cboLine.DisplayMember = "Code";
            cboLine.ValueMember = "LineId";
            cboLine.DataSource = Model.Lines;

            cboLinePrefence.DisplayMember = "Code";
            cboLinePrefence.ValueMember = "LineId";
            cboLinePrefence.DataSource = Model.LinePrefences;

            toolingBindingSource.DataSource = Model.Tooling;
        }

        #endregion Public Methods

        #region Private Methods

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            try
            {
                SaveRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ToolingView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.Handled = UIExtensions.AllowDecimalValueOnly(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtNumeric_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                ((MetroFramework.Controls.MetroTextBox)sender).ResetBindingOrDefaultValueOnInvalid("0");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}