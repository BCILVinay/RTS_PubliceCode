﻿using BCIL.Administration.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface ISiteListView : IBaseView<SiteListModel>
    {
        event EventHandler AddSiteRequested;
        event EventHandler<Site> EditSiteRequested;

        void RefreshBinding();
    }
}
