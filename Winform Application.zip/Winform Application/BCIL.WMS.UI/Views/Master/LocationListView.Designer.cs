﻿namespace BCIL.WMS.UI.Views
{
    partial class LocationListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocationListView));
            this.miniToolStrip = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvLocations = new BCIL.UIHelper.DataListView();
            this.olvColumnCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnName = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnDescription = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnType = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnActive = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedDate = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd1 = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnEdit1 = new System.Windows.Forms.ToolStripButton();
            this.btnImport = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cboMode = new MetroFramework.Controls.MetroComboBox();
            this.cboLocationType = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.buttonSearch1 = new BCIL.UIHelper.ButtonSearch();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvLocations)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.miniToolStrip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.miniToolStrip.Location = new System.Drawing.Point(122, 7);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(877, 33);
            this.miniToolStrip.TabIndex = 12;
            this.miniToolStrip.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvLocations);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 152);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(918, 343);
            this.metroPanel1.TabIndex = 8;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvLocations
            // 
            this.olvLocations.AllColumns.Add(this.olvColumnCode);
            this.olvLocations.AllColumns.Add(this.olvColumnName);
            this.olvLocations.AllColumns.Add(this.olvColumnDescription);
            this.olvLocations.AllColumns.Add(this.olvColumnType);
            this.olvLocations.AllColumns.Add(this.olvColumnMode);
            this.olvLocations.AllColumns.Add(this.olvColumnActive);
            this.olvLocations.AllColumns.Add(this.olvColumnCreatedDate);
            this.olvLocations.AllColumns.Add(this.olvColumn1);
            this.olvLocations.CellEditUseWholeCell = false;
            this.olvLocations.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnCode,
            this.olvColumnName,
            this.olvColumnDescription,
            this.olvColumnType,
            this.olvColumnMode,
            this.olvColumnActive,
            this.olvColumnCreatedDate,
            this.olvColumn1});
            this.olvLocations.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvLocations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvLocations.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvLocations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvLocations.FullRowSelect = true;
            this.olvLocations.HeaderMinimumHeight = 30;
            this.olvLocations.HideSelection = false;
            this.olvLocations.IncludeColumnHeadersInCopy = true;
            this.olvLocations.Location = new System.Drawing.Point(0, 33);
            this.olvLocations.Name = "olvLocations";
            this.olvLocations.RowHeight = 25;
            this.olvLocations.ShowGroups = false;
            this.olvLocations.Size = new System.Drawing.Size(918, 310);
            this.olvLocations.TabIndex = 10;
            this.olvLocations.UseCompatibleStateImageBehavior = false;
            this.olvLocations.View = System.Windows.Forms.View.Details;
            this.olvLocations.VirtualMode = true;
            this.olvLocations.SelectedIndexChanged += new System.EventHandler(this.olvLocations_SelectedIndexChanged);
            this.olvLocations.DoubleClick += new System.EventHandler(this.btnEdit_Click);
            // 
            // olvColumnCode
            // 
            this.olvColumnCode.AspectName = "LocationCode";
            this.olvColumnCode.Text = "Code";
            this.olvColumnCode.Width = 150;
            // 
            // olvColumnName
            // 
            this.olvColumnName.AspectName = "LocationName";
            this.olvColumnName.Text = "Name";
            this.olvColumnName.Width = 120;
            // 
            // olvColumnDescription
            // 
            this.olvColumnDescription.AspectName = "Description";
            this.olvColumnDescription.Text = "Description";
            this.olvColumnDescription.Width = 200;
            // 
            // olvColumnType
            // 
            this.olvColumnType.AspectName = "Type";
            this.olvColumnType.Text = "Type";
            this.olvColumnType.Width = 120;
            // 
            // olvColumnMode
            // 
            this.olvColumnMode.AspectName = "Mode";
            this.olvColumnMode.Text = "Mode";
            this.olvColumnMode.Width = 120;
            // 
            // olvColumnActive
            // 
            this.olvColumnActive.AspectName = "IsActive";
            this.olvColumnActive.Text = "Active";
            this.olvColumnActive.Width = 111;
            // 
            // olvColumnCreatedDate
            // 
            this.olvColumnCreatedDate.AspectName = "CreatedOn";
            this.olvColumnCreatedDate.Text = "Created Date";
            this.olvColumnCreatedDate.Width = 135;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd1,
            this.btnEdit1,
            this.btnImport,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious,
            this.btnPrint});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(918, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd1
            // 
            this.btnAdd1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd1.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd1.Image")));
            this.btnAdd1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd1.IsActionRestrictedByPermission = false;
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(62, 30);
            this.btnAdd1.Text = "Add";
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit1
            // 
            this.btnEdit1.Enabled = false;
            this.btnEdit1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnEdit1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnEdit1.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit1.Image")));
            this.btnEdit1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit1.Name = "btnEdit1";
            this.btnEdit1.Size = new System.Drawing.Size(60, 30);
            this.btnEdit1.Text = "Edit";
            this.btnEdit1.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnImport
            // 
            this.btnImport.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImport.IsActionRestrictedByPermission = false;
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(77, 30);
            this.btnImport.Text = "Import";
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 30);
            this.lblRecords.Text = "Total records: 0";
            this.lblRecords.Click += new System.EventHandler(this.lblRecords_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.IsActionRestrictedByPermission = false;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(64, 30);
            this.btnPrint.Text = "Print";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(72, 59);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(167, 25);
            this.txtCode.TabIndex = 0;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(10, 62);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 16;
            this.metroLabel1.Text = "Code:";
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(72, 101);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(167, 25);
            this.txtName.TabIndex = 17;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(10, 104);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(48, 19);
            this.metroLabel2.TabIndex = 18;
            this.metroLabel2.Text = "Name:";
            // 
            // cboMode
            // 
            this.cboMode.FormattingEnabled = true;
            this.cboMode.ItemHeight = 19;
            this.cboMode.Location = new System.Drawing.Point(346, 101);
            this.cboMode.Name = "cboMode";
            this.cboMode.PromptItemIndex = -1;
            this.cboMode.Size = new System.Drawing.Size(167, 25);
            this.cboMode.TabIndex = 29;
            this.cboMode.UseSelectable = true;
            // 
            // cboLocationType
            // 
            this.cboLocationType.FormattingEnabled = true;
            this.cboLocationType.ItemHeight = 19;
            this.cboLocationType.Location = new System.Drawing.Point(346, 59);
            this.cboLocationType.Name = "cboLocationType";
            this.cboLocationType.PromptItemIndex = -1;
            this.cboLocationType.Size = new System.Drawing.Size(167, 25);
            this.cboLocationType.TabIndex = 26;
            this.cboLocationType.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(268, 62);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(40, 19);
            this.metroLabel6.TabIndex = 28;
            this.metroLabel6.Text = "Type:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(269, 104);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(47, 19);
            this.metroLabel5.TabIndex = 27;
            this.metroLabel5.Text = "Mode:";
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(593, 59);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(72, 25);
            this.cboIsActive.TabIndex = 30;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(533, 62);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 31;
            this.lblIsActive.Text = "Active:";
            // 
            // buttonSearch1
            // 
            this.buttonSearch1.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch1.ButtonImage")));
            this.buttonSearch1.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch1.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch1.ImageSize = 50;
            this.buttonSearch1.Location = new System.Drawing.Point(721, 62);
            this.buttonSearch1.Name = "buttonSearch1";
            this.buttonSearch1.Size = new System.Drawing.Size(85, 64);
            this.buttonSearch1.TabIndex = 33;
            this.buttonSearch1.Text = "Search";
            this.buttonSearch1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch1.UseSelectable = true;
            this.buttonSearch1.Click += new System.EventHandler(this.buttonSearch1_Click);
            // 
            // LocationListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonSearch1);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.cboMode);
            this.Controls.Add(this.cboLocationType);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "LocationListView";
            this.Size = new System.Drawing.Size(938, 509);
            this.Title = "Locations";
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.LocationListView_Showing);
            this.Load += new System.EventHandler(this.LocationListView_Load);
            this.Resize += new System.EventHandler(this.LocationListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.txtCode, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.txtName, 0);
            this.Controls.SetChildIndex(this.metroLabel5, 0);
            this.Controls.SetChildIndex(this.metroLabel6, 0);
            this.Controls.SetChildIndex(this.cboLocationType, 0);
            this.Controls.SetChildIndex(this.cboMode, 0);
            this.Controls.SetChildIndex(this.lblIsActive, 0);
            this.Controls.SetChildIndex(this.cboIsActive, 0);
            this.Controls.SetChildIndex(this.buttonSearch1, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvLocations)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.MyCustomControl.MetroToolStrip miniToolStrip;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvLocations;
        private BrightIdeasSoftware.OLVColumn olvColumnName;
        private BrightIdeasSoftware.OLVColumn olvColumnDescription;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedDate;
        private BrightIdeasSoftware.OLVColumn olvColumnActive;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd1;
        private System.Windows.Forms.ToolStripButton btnEdit1;
        private BrightIdeasSoftware.OLVColumn olvColumnCode;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnImport;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cboMode;
        private MetroFramework.Controls.MetroComboBox cboLocationType;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private UIHelper.ButtonSearch buttonSearch1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnPrint;
        private BrightIdeasSoftware.OLVColumn olvColumnType;
        private BrightIdeasSoftware.OLVColumn olvColumnMode;
    }
}
