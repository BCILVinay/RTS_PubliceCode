﻿namespace BCIL.WMS.UI.Views
{
    partial class ItemLabelPrintView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemLabelPrintView));
            this.lblBundleQty = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.lblPODate = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lblPONumber = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.lblMaterialCode = new MetroFramework.Controls.MetroLabel();
            this.lblPrintedQtyValues = new MetroFramework.Controls.MetroLabel();
            this.lblPrintedQty = new MetroFramework.Controls.MetroLabel();
            this.txtBundleQty = new MetroFramework.Controls.MetroTextBox();
            this.lblQtyToPrint = new MetroFramework.Controls.MetroLabel();
            this.lblRequestQty = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnPrint = new BCIL.UIHelper.ButtonSave();
            this.BundlePrintingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblTotalItemQty = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtTotalItemToPrint = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.lblTotalPendingBundleQty = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.BundlePrintingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBundleQty
            // 
            this.lblBundleQty.AutoSize = true;
            this.lblBundleQty.Location = new System.Drawing.Point(385, 101);
            this.lblBundleQty.Name = "lblBundleQty";
            this.lblBundleQty.Size = new System.Drawing.Size(95, 19);
            this.lblBundleQty.TabIndex = 66;
            this.lblBundleQty.Text = "Requested Qty";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(299, 101);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(77, 19);
            this.metroLabel6.TabIndex = 65;
            this.metroLabel6.Text = "Bundle Qty:";
            // 
            // lblPODate
            // 
            this.lblPODate.AutoSize = true;
            this.lblPODate.Location = new System.Drawing.Point(385, 72);
            this.lblPODate.Name = "lblPODate";
            this.lblPODate.Size = new System.Drawing.Size(69, 19);
            this.lblPODate.TabIndex = 64;
            this.lblPODate.Text = "XX-XX-XX";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(299, 72);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(62, 19);
            this.metroLabel4.TabIndex = 63;
            this.metroLabel4.Text = "PO Date:";
            // 
            // lblPONumber
            // 
            this.lblPONumber.AutoSize = true;
            this.lblPONumber.Location = new System.Drawing.Point(123, 72);
            this.lblPONumber.Name = "lblPONumber";
            this.lblPONumber.Size = new System.Drawing.Size(33, 19);
            this.lblPONumber.TabIndex = 62;
            this.lblPONumber.Text = "XXX";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 72);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(84, 19);
            this.metroLabel2.TabIndex = 61;
            this.metroLabel2.Text = "PO Number:";
            // 
            // lblMaterialCode
            // 
            this.lblMaterialCode.AutoSize = true;
            this.lblMaterialCode.Location = new System.Drawing.Point(123, 101);
            this.lblMaterialCode.Name = "lblMaterialCode";
            this.lblMaterialCode.Size = new System.Drawing.Size(42, 19);
            this.lblMaterialCode.TabIndex = 60;
            this.lblMaterialCode.Text = "M001";
            // 
            // lblPrintedQtyValues
            // 
            this.lblPrintedQtyValues.AutoSize = true;
            this.lblPrintedQtyValues.Location = new System.Drawing.Point(133, 166);
            this.lblPrintedQtyValues.Name = "lblPrintedQtyValues";
            this.lblPrintedQtyValues.Size = new System.Drawing.Size(76, 19);
            this.lblPrintedQtyValues.TabIndex = 59;
            this.lblPrintedQtyValues.Text = "Printed Qty";
            // 
            // lblPrintedQty
            // 
            this.lblPrintedQty.AutoSize = true;
            this.lblPrintedQty.Location = new System.Drawing.Point(23, 166);
            this.lblPrintedQty.Name = "lblPrintedQty";
            this.lblPrintedQty.Size = new System.Drawing.Size(109, 19);
            this.lblPrintedQty.TabIndex = 58;
            this.lblPrintedQty.Text = "Printed Item Qty:";
            // 
            // txtBundleQty
            // 
            // 
            // 
            // 
            this.txtBundleQty.CustomButton.Image = null;
            this.txtBundleQty.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.txtBundleQty.CustomButton.Name = "";
            this.txtBundleQty.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtBundleQty.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBundleQty.CustomButton.TabIndex = 1;
            this.txtBundleQty.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBundleQty.CustomButton.UseSelectable = true;
            this.txtBundleQty.CustomButton.Visible = false;
            this.txtBundleQty.Lines = new string[0];
            this.txtBundleQty.Location = new System.Drawing.Point(394, 128);
            this.txtBundleQty.MaxLength = 9;
            this.txtBundleQty.Name = "txtBundleQty";
            this.txtBundleQty.PasswordChar = '\0';
            this.txtBundleQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBundleQty.SelectedText = "";
            this.txtBundleQty.SelectionLength = 0;
            this.txtBundleQty.SelectionStart = 0;
            this.txtBundleQty.ShortcutsEnabled = true;
            this.txtBundleQty.Size = new System.Drawing.Size(81, 29);
            this.txtBundleQty.TabIndex = 57;
            this.txtBundleQty.UseSelectable = true;
            this.txtBundleQty.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBundleQty.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtBundleQty.TextChanged += new System.EventHandler(this.txtBundleQty_TextChanged);
            this.txtBundleQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQty_KeyPress);
            // 
            // lblQtyToPrint
            // 
            this.lblQtyToPrint.AutoSize = true;
            this.lblQtyToPrint.Location = new System.Drawing.Point(299, 133);
            this.lblQtyToPrint.Name = "lblQtyToPrint";
            this.lblQtyToPrint.Size = new System.Drawing.Size(77, 19);
            this.lblQtyToPrint.TabIndex = 56;
            this.lblQtyToPrint.Text = "Bundle Qty:";
            // 
            // lblRequestQty
            // 
            this.lblRequestQty.AutoSize = true;
            this.lblRequestQty.Location = new System.Drawing.Point(23, 101);
            this.lblRequestQty.Name = "lblRequestQty";
            this.lblRequestQty.Size = new System.Drawing.Size(60, 19);
            this.lblRequestQty.TabIndex = 55;
            this.lblRequestQty.Text = "Material:";
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(431, 216);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 54;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnPrint.ButtonImage")));
            this.btnPrint.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrint.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnPrint.ImageSize = 50;
            this.btnPrint.Location = new System.Drawing.Point(335, 216);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(85, 56);
            this.btnPrint.TabIndex = 53;
            this.btnPrint.Text = "Print";
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrint.UseSelectable = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // BundlePrintingBindingSource
            // 
            this.BundlePrintingBindingSource.DataSource = typeof(BCIL.WMS.BL.ProductionOrder);
            // 
            // lblTotalItemQty
            // 
            this.lblTotalItemQty.AutoSize = true;
            this.lblTotalItemQty.Location = new System.Drawing.Point(123, 133);
            this.lblTotalItemQty.Name = "lblTotalItemQty";
            this.lblTotalItemQty.Size = new System.Drawing.Size(85, 19);
            this.lblTotalItemQty.TabIndex = 68;
            this.lblTotalItemQty.Text = "TotalItemQty";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 133);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(96, 19);
            this.metroLabel3.TabIndex = 67;
            this.metroLabel3.Text = "Total Item Qty:";
            // 
            // txtTotalItemToPrint
            // 
            // 
            // 
            // 
            this.txtTotalItemToPrint.CustomButton.Image = null;
            this.txtTotalItemToPrint.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.txtTotalItemToPrint.CustomButton.Name = "";
            this.txtTotalItemToPrint.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtTotalItemToPrint.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtTotalItemToPrint.CustomButton.TabIndex = 1;
            this.txtTotalItemToPrint.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtTotalItemToPrint.CustomButton.UseSelectable = true;
            this.txtTotalItemToPrint.CustomButton.Visible = false;
            this.txtTotalItemToPrint.Lines = new string[0];
            this.txtTotalItemToPrint.Location = new System.Drawing.Point(394, 165);
            this.txtTotalItemToPrint.MaxLength = 9;
            this.txtTotalItemToPrint.Name = "txtTotalItemToPrint";
            this.txtTotalItemToPrint.PasswordChar = '\0';
            this.txtTotalItemToPrint.ReadOnly = true;
            this.txtTotalItemToPrint.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTotalItemToPrint.SelectedText = "";
            this.txtTotalItemToPrint.SelectionLength = 0;
            this.txtTotalItemToPrint.SelectionStart = 0;
            this.txtTotalItemToPrint.ShortcutsEnabled = true;
            this.txtTotalItemToPrint.Size = new System.Drawing.Size(81, 29);
            this.txtTotalItemToPrint.TabIndex = 70;
            this.txtTotalItemToPrint.UseSelectable = true;
            this.txtTotalItemToPrint.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtTotalItemToPrint.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(299, 170);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(94, 19);
            this.metroLabel1.TabIndex = 69;
            this.metroLabel1.Text = "Print Item Qty:";
            // 
            // lblTotalPendingBundleQty
            // 
            this.lblTotalPendingBundleQty.AutoSize = true;
            this.lblTotalPendingBundleQty.Location = new System.Drawing.Point(158, 195);
            this.lblTotalPendingBundleQty.Name = "lblTotalPendingBundleQty";
            this.lblTotalPendingBundleQty.Size = new System.Drawing.Size(78, 19);
            this.lblTotalPendingBundleQty.TabIndex = 72;
            this.lblTotalPendingBundleQty.Text = "PendingQty";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(23, 195);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(129, 19);
            this.metroLabel7.TabIndex = 71;
            this.metroLabel7.Text = "Pending Bundle Qty:";
            // 
            // ItemLabelPrintView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 286);
            this.Controls.Add(this.lblTotalPendingBundleQty);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.txtTotalItemToPrint);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.lblTotalItemQty);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.lblBundleQty);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.lblPODate);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.lblPONumber);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblMaterialCode);
            this.Controls.Add(this.lblPrintedQtyValues);
            this.Controls.Add(this.lblPrintedQty);
            this.Controls.Add(this.txtBundleQty);
            this.Controls.Add(this.lblQtyToPrint);
            this.Controls.Add(this.lblRequestQty);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPrint);
            this.Name = "ItemLabelPrintView";
            this.Text = "Item Label Print";
            ((System.ComponentModel.ISupportInitialize)(this.BundlePrintingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblBundleQty;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel lblPODate;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel lblPONumber;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel lblMaterialCode;
        private MetroFramework.Controls.MetroLabel lblPrintedQtyValues;
        private MetroFramework.Controls.MetroLabel lblPrintedQty;
        private MetroFramework.Controls.MetroTextBox txtBundleQty;
        private MetroFramework.Controls.MetroLabel lblQtyToPrint;
        private MetroFramework.Controls.MetroLabel lblRequestQty;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnPrint;
        private System.Windows.Forms.BindingSource BundlePrintingBindingSource;
        private MetroFramework.Controls.MetroLabel lblTotalItemQty;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtTotalItemToPrint;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel lblTotalPendingBundleQty;
        private MetroFramework.Controls.MetroLabel metroLabel7;
    }
}