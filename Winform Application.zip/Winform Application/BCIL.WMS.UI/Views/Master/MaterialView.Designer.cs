﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialView));
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.materialBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel4 = new BCIL.UIHelper.RequiredPanel();
            this.txtHeight = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel5 = new BCIL.UIHelper.RequiredPanel();
            this.txtWidth = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel1 = new BCIL.UIHelper.RequiredPanel();
            this.txtUOM = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel3 = new BCIL.UIHelper.RequiredPanel();
            this.txtSectionbalWeigth = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.cboToolings = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel6 = new BCIL.UIHelper.RequiredPanel();
            this.txtNoOfBarQty = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel7 = new BCIL.UIHelper.RequiredPanel();
            this.txtBundleWeight = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel8 = new BCIL.UIHelper.RequiredPanel();
            this.txtBundleVolume = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel9 = new BCIL.UIHelper.RequiredPanel();
            this.txtMaterialDesc = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel10 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox5 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel11 = new BCIL.UIHelper.RequiredPanel();
            this.txtStdBarLength = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel12 = new BCIL.UIHelper.RequiredPanel();
            this.metroTextBox7 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel13 = new BCIL.UIHelper.RequiredPanel();
            this.txtTotalLenth = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.pb_MaterialImage = new BCIL.UIHelper.PictureBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.materialBindingSource)).BeginInit();
            this.requiredPanel4.SuspendLayout();
            this.requiredPanel5.SuspendLayout();
            this.requiredPanel1.SuspendLayout();
            this.requiredPanel3.SuspendLayout();
            this.requiredPanel6.SuspendLayout();
            this.requiredPanel7.SuspendLayout();
            this.requiredPanel8.SuspendLayout();
            this.requiredPanel9.SuspendLayout();
            this.requiredPanel10.SuspendLayout();
            this.requiredPanel11.SuspendLayout();
            this.requiredPanel12.SuspendLayout();
            this.requiredPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_MaterialImage)).BeginInit();
            this.SuspendLayout();
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtCode);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(175, 69);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(222, 25);
            this.requiredPanel2.TabIndex = 0;
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "MaterialCode", true));
            this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(0, 0);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(202, 25);
            this.txtCode.TabIndex = 0;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // materialBindingSource
            // 
            this.materialBindingSource.DataSource = typeof(BCIL.WMS.BL.Material);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(96, 19);
            this.metroLabel1.TabIndex = 20;
            this.metroLabel1.Text = "Material Code:";
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.materialBindingSource, "IsActive", true));
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(555, 72);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(100, 25);
            this.cboIsActive.TabIndex = 8;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(434, 75);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 18;
            this.lblIsActive.Text = "Active:";
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(599, 349);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(507, 349);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Visible = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel4
            // 
            this.requiredPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel4.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel4.Controls.Add(this.txtHeight);
            this.requiredPanel4.IsRequired = true;
            this.requiredPanel4.Location = new System.Drawing.Point(555, 206);
            this.requiredPanel4.Name = "requiredPanel4";
            this.requiredPanel4.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel4.TabIndex = 12;
            // 
            // txtHeight
            // 
            // 
            // 
            // 
            this.txtHeight.CustomButton.Image = null;
            this.txtHeight.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtHeight.CustomButton.Name = "";
            this.txtHeight.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtHeight.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtHeight.CustomButton.TabIndex = 1;
            this.txtHeight.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtHeight.CustomButton.UseSelectable = true;
            this.txtHeight.CustomButton.Visible = false;
            this.txtHeight.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleHeight", true));
            this.txtHeight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHeight.Lines = new string[0];
            this.txtHeight.Location = new System.Drawing.Point(0, 0);
            this.txtHeight.MaxLength = 50;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.PasswordChar = '\0';
            this.txtHeight.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtHeight.SelectedText = "";
            this.txtHeight.SelectionLength = 0;
            this.txtHeight.SelectionStart = 0;
            this.txtHeight.ShortcutsEnabled = true;
            this.txtHeight.Size = new System.Drawing.Size(100, 25);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.UseSelectable = true;
            this.txtHeight.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtHeight.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtHeight.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(434, 209);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(94, 19);
            this.metroLabel3.TabIndex = 38;
            this.metroLabel3.Text = "Bundle Height:";
            // 
            // requiredPanel5
            // 
            this.requiredPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel5.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel5.Controls.Add(this.txtWidth);
            this.requiredPanel5.IsRequired = true;
            this.requiredPanel5.Location = new System.Drawing.Point(555, 174);
            this.requiredPanel5.Name = "requiredPanel5";
            this.requiredPanel5.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel5.TabIndex = 11;
            // 
            // txtWidth
            // 
            // 
            // 
            // 
            this.txtWidth.CustomButton.Image = null;
            this.txtWidth.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtWidth.CustomButton.Name = "";
            this.txtWidth.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtWidth.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtWidth.CustomButton.TabIndex = 1;
            this.txtWidth.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtWidth.CustomButton.UseSelectable = true;
            this.txtWidth.CustomButton.Visible = false;
            this.txtWidth.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleBreath", true));
            this.txtWidth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWidth.Lines = new string[0];
            this.txtWidth.Location = new System.Drawing.Point(0, 0);
            this.txtWidth.MaxLength = 50;
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.PasswordChar = '\0';
            this.txtWidth.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtWidth.SelectedText = "";
            this.txtWidth.SelectionLength = 0;
            this.txtWidth.SelectionStart = 0;
            this.txtWidth.ShortcutsEnabled = true;
            this.txtWidth.Size = new System.Drawing.Size(100, 25);
            this.txtWidth.TabIndex = 0;
            this.txtWidth.UseSelectable = true;
            this.txtWidth.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtWidth.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtWidth.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(434, 177);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(102, 19);
            this.metroLabel4.TabIndex = 36;
            this.metroLabel4.Text = "Bundle Breadth:";
            // 
            // requiredPanel1
            // 
            this.requiredPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel1.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel1.Controls.Add(this.txtUOM);
            this.requiredPanel1.IsRequired = true;
            this.requiredPanel1.Location = new System.Drawing.Point(555, 106);
            this.requiredPanel1.Name = "requiredPanel1";
            this.requiredPanel1.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel1.TabIndex = 9;
            // 
            // txtUOM
            // 
            // 
            // 
            // 
            this.txtUOM.CustomButton.Image = null;
            this.txtUOM.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtUOM.CustomButton.Name = "";
            this.txtUOM.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUOM.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUOM.CustomButton.TabIndex = 1;
            this.txtUOM.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUOM.CustomButton.UseSelectable = true;
            this.txtUOM.CustomButton.Visible = false;
            this.txtUOM.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "UOM", true));
            this.txtUOM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtUOM.Lines = new string[0];
            this.txtUOM.Location = new System.Drawing.Point(0, 0);
            this.txtUOM.MaxLength = 50;
            this.txtUOM.Name = "txtUOM";
            this.txtUOM.PasswordChar = '\0';
            this.txtUOM.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUOM.SelectedText = "";
            this.txtUOM.SelectionLength = 0;
            this.txtUOM.SelectionStart = 0;
            this.txtUOM.ShortcutsEnabled = true;
            this.txtUOM.Size = new System.Drawing.Size(100, 25);
            this.txtUOM.TabIndex = 0;
            this.txtUOM.UseSelectable = true;
            this.txtUOM.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUOM.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtUOM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUOM_KeyPress);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(434, 109);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(44, 19);
            this.metroLabel2.TabIndex = 40;
            this.metroLabel2.Text = "UOM:";
            // 
            // requiredPanel3
            // 
            this.requiredPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel3.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel3.Controls.Add(this.txtSectionbalWeigth);
            this.requiredPanel3.IsRequired = true;
            this.requiredPanel3.Location = new System.Drawing.Point(555, 139);
            this.requiredPanel3.Name = "requiredPanel3";
            this.requiredPanel3.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel3.TabIndex = 10;
            // 
            // txtSectionbalWeigth
            // 
            // 
            // 
            // 
            this.txtSectionbalWeigth.CustomButton.Image = null;
            this.txtSectionbalWeigth.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtSectionbalWeigth.CustomButton.Name = "";
            this.txtSectionbalWeigth.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtSectionbalWeigth.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSectionbalWeigth.CustomButton.TabIndex = 1;
            this.txtSectionbalWeigth.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSectionbalWeigth.CustomButton.UseSelectable = true;
            this.txtSectionbalWeigth.CustomButton.Visible = false;
            this.txtSectionbalWeigth.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "SectionalWeight", true));
            this.txtSectionbalWeigth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSectionbalWeigth.Lines = new string[0];
            this.txtSectionbalWeigth.Location = new System.Drawing.Point(0, 0);
            this.txtSectionbalWeigth.MaxLength = 50;
            this.txtSectionbalWeigth.Name = "txtSectionbalWeigth";
            this.txtSectionbalWeigth.PasswordChar = '\0';
            this.txtSectionbalWeigth.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSectionbalWeigth.SelectedText = "";
            this.txtSectionbalWeigth.SelectionLength = 0;
            this.txtSectionbalWeigth.SelectionStart = 0;
            this.txtSectionbalWeigth.ShortcutsEnabled = true;
            this.txtSectionbalWeigth.Size = new System.Drawing.Size(100, 25);
            this.txtSectionbalWeigth.TabIndex = 0;
            this.txtSectionbalWeigth.UseSelectable = true;
            this.txtSectionbalWeigth.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSectionbalWeigth.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSectionbalWeigth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtSectionbalWeigth.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(434, 142);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(109, 19);
            this.metroLabel5.TabIndex = 42;
            this.metroLabel5.Text = "Sectional Weight:";
            // 
            // cboToolings
            // 
            this.cboToolings.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.materialBindingSource, "Tooling", true));
            this.cboToolings.FormattingEnabled = true;
            this.cboToolings.ItemHeight = 19;
            this.cboToolings.Location = new System.Drawing.Point(175, 136);
            this.cboToolings.Name = "cboToolings";
            this.cboToolings.PromptItemIndex = -1;
            this.cboToolings.Size = new System.Drawing.Size(202, 25);
            this.cboToolings.TabIndex = 2;
            this.cboToolings.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(23, 139);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(94, 19);
            this.metroLabel6.TabIndex = 43;
            this.metroLabel6.Text = "Tooling Name:";
            // 
            // requiredPanel6
            // 
            this.requiredPanel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel6.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel6.Controls.Add(this.txtNoOfBarQty);
            this.requiredPanel6.IsRequired = true;
            this.requiredPanel6.Location = new System.Drawing.Point(175, 203);
            this.requiredPanel6.Name = "requiredPanel6";
            this.requiredPanel6.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel6.TabIndex = 4;
            // 
            // txtNoOfBarQty
            // 
            // 
            // 
            // 
            this.txtNoOfBarQty.CustomButton.Image = null;
            this.txtNoOfBarQty.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtNoOfBarQty.CustomButton.Name = "";
            this.txtNoOfBarQty.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtNoOfBarQty.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtNoOfBarQty.CustomButton.TabIndex = 1;
            this.txtNoOfBarQty.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtNoOfBarQty.CustomButton.UseSelectable = true;
            this.txtNoOfBarQty.CustomButton.Visible = false;
            this.txtNoOfBarQty.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "PackSize", true));
            this.txtNoOfBarQty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoOfBarQty.Lines = new string[0];
            this.txtNoOfBarQty.Location = new System.Drawing.Point(0, 0);
            this.txtNoOfBarQty.MaxLength = 50;
            this.txtNoOfBarQty.Name = "txtNoOfBarQty";
            this.txtNoOfBarQty.PasswordChar = '\0';
            this.txtNoOfBarQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNoOfBarQty.SelectedText = "";
            this.txtNoOfBarQty.SelectionLength = 0;
            this.txtNoOfBarQty.SelectionStart = 0;
            this.txtNoOfBarQty.ShortcutsEnabled = true;
            this.txtNoOfBarQty.Size = new System.Drawing.Size(100, 25);
            this.txtNoOfBarQty.TabIndex = 0;
            this.txtNoOfBarQty.UseSelectable = true;
            this.txtNoOfBarQty.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtNoOfBarQty.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtNoOfBarQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtNoOfBarQty.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(23, 206);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(65, 19);
            this.metroLabel7.TabIndex = 46;
            this.metroLabel7.Text = "Pack Size:";
            // 
            // requiredPanel7
            // 
            this.requiredPanel7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel7.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel7.Controls.Add(this.txtBundleWeight);
            this.requiredPanel7.IsRequired = true;
            this.requiredPanel7.Location = new System.Drawing.Point(555, 270);
            this.requiredPanel7.Name = "requiredPanel7";
            this.requiredPanel7.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel7.TabIndex = 14;
            // 
            // txtBundleWeight
            // 
            // 
            // 
            // 
            this.txtBundleWeight.CustomButton.Image = null;
            this.txtBundleWeight.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtBundleWeight.CustomButton.Name = "";
            this.txtBundleWeight.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtBundleWeight.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBundleWeight.CustomButton.TabIndex = 1;
            this.txtBundleWeight.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBundleWeight.CustomButton.UseSelectable = true;
            this.txtBundleWeight.CustomButton.Visible = false;
            this.txtBundleWeight.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleTotalWeight", true));
            this.txtBundleWeight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBundleWeight.Lines = new string[0];
            this.txtBundleWeight.Location = new System.Drawing.Point(0, 0);
            this.txtBundleWeight.MaxLength = 50;
            this.txtBundleWeight.Name = "txtBundleWeight";
            this.txtBundleWeight.PasswordChar = '\0';
            this.txtBundleWeight.ReadOnly = true;
            this.txtBundleWeight.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBundleWeight.SelectedText = "";
            this.txtBundleWeight.SelectionLength = 0;
            this.txtBundleWeight.SelectionStart = 0;
            this.txtBundleWeight.ShortcutsEnabled = true;
            this.txtBundleWeight.Size = new System.Drawing.Size(100, 25);
            this.txtBundleWeight.TabIndex = 0;
            this.txtBundleWeight.UseSelectable = true;
            this.txtBundleWeight.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBundleWeight.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(434, 273);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(124, 19);
            this.metroLabel8.TabIndex = 48;
            this.metroLabel8.Text = "Bundle Weight (Kg):";
            // 
            // requiredPanel8
            // 
            this.requiredPanel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel8.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel8.Controls.Add(this.txtBundleVolume);
            this.requiredPanel8.IsRequired = true;
            this.requiredPanel8.Location = new System.Drawing.Point(175, 267);
            this.requiredPanel8.Name = "requiredPanel8";
            this.requiredPanel8.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel8.TabIndex = 6;
            // 
            // txtBundleVolume
            // 
            // 
            // 
            // 
            this.txtBundleVolume.CustomButton.Image = null;
            this.txtBundleVolume.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtBundleVolume.CustomButton.Name = "";
            this.txtBundleVolume.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtBundleVolume.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBundleVolume.CustomButton.TabIndex = 1;
            this.txtBundleVolume.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBundleVolume.CustomButton.UseSelectable = true;
            this.txtBundleVolume.CustomButton.Visible = false;
            this.txtBundleVolume.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleVolume", true));
            this.txtBundleVolume.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBundleVolume.Lines = new string[0];
            this.txtBundleVolume.Location = new System.Drawing.Point(0, 0);
            this.txtBundleVolume.MaxLength = 50;
            this.txtBundleVolume.Name = "txtBundleVolume";
            this.txtBundleVolume.PasswordChar = '\0';
            this.txtBundleVolume.ReadOnly = true;
            this.txtBundleVolume.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBundleVolume.SelectedText = "";
            this.txtBundleVolume.SelectionLength = 0;
            this.txtBundleVolume.SelectionStart = 0;
            this.txtBundleVolume.ShortcutsEnabled = true;
            this.txtBundleVolume.Size = new System.Drawing.Size(100, 25);
            this.txtBundleVolume.TabIndex = 0;
            this.txtBundleVolume.UseSelectable = true;
            this.txtBundleVolume.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBundleVolume.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(23, 270);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(100, 19);
            this.metroLabel9.TabIndex = 50;
            this.metroLabel9.Text = "Bundle Volume:";
            // 
            // requiredPanel9
            // 
            this.requiredPanel9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel9.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel9.Controls.Add(this.txtMaterialDesc);
            this.requiredPanel9.IsRequired = true;
            this.requiredPanel9.Location = new System.Drawing.Point(175, 103);
            this.requiredPanel9.Name = "requiredPanel9";
            this.requiredPanel9.Size = new System.Drawing.Size(222, 25);
            this.requiredPanel9.TabIndex = 1;
            // 
            // txtMaterialDesc
            // 
            // 
            // 
            // 
            this.txtMaterialDesc.CustomButton.Image = null;
            this.txtMaterialDesc.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.txtMaterialDesc.CustomButton.Name = "";
            this.txtMaterialDesc.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtMaterialDesc.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMaterialDesc.CustomButton.TabIndex = 1;
            this.txtMaterialDesc.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMaterialDesc.CustomButton.UseSelectable = true;
            this.txtMaterialDesc.CustomButton.Visible = false;
            this.txtMaterialDesc.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "MaterialDescription", true));
            this.txtMaterialDesc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMaterialDesc.Lines = new string[0];
            this.txtMaterialDesc.Location = new System.Drawing.Point(0, 0);
            this.txtMaterialDesc.MaxLength = 50;
            this.txtMaterialDesc.Name = "txtMaterialDesc";
            this.txtMaterialDesc.PasswordChar = '\0';
            this.txtMaterialDesc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMaterialDesc.SelectedText = "";
            this.txtMaterialDesc.SelectionLength = 0;
            this.txtMaterialDesc.SelectionStart = 0;
            this.txtMaterialDesc.ShortcutsEnabled = true;
            this.txtMaterialDesc.Size = new System.Drawing.Size(202, 25);
            this.txtMaterialDesc.TabIndex = 0;
            this.txtMaterialDesc.UseSelectable = true;
            this.txtMaterialDesc.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMaterialDesc.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(23, 106);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(91, 19);
            this.metroLabel10.TabIndex = 52;
            this.metroLabel10.Text = "Material Desc:";
            // 
            // requiredPanel10
            // 
            this.requiredPanel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel10.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel10.Controls.Add(this.metroTextBox5);
            this.requiredPanel10.IsRequired = true;
            this.requiredPanel10.Location = new System.Drawing.Point(555, 238);
            this.requiredPanel10.Name = "requiredPanel10";
            this.requiredPanel10.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel10.TabIndex = 13;
            // 
            // metroTextBox5
            // 
            // 
            // 
            // 
            this.metroTextBox5.CustomButton.Image = null;
            this.metroTextBox5.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.metroTextBox5.CustomButton.Name = "";
            this.metroTextBox5.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox5.CustomButton.TabIndex = 1;
            this.metroTextBox5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox5.CustomButton.UseSelectable = true;
            this.metroTextBox5.CustomButton.Visible = false;
            this.metroTextBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "CrossSecArea", true));
            this.metroTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox5.Lines = new string[0];
            this.metroTextBox5.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox5.MaxLength = 50;
            this.metroTextBox5.Name = "metroTextBox5";
            this.metroTextBox5.PasswordChar = '\0';
            this.metroTextBox5.ReadOnly = true;
            this.metroTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox5.SelectedText = "";
            this.metroTextBox5.SelectionLength = 0;
            this.metroTextBox5.SelectionStart = 0;
            this.metroTextBox5.ShortcutsEnabled = true;
            this.metroTextBox5.Size = new System.Drawing.Size(100, 25);
            this.metroTextBox5.TabIndex = 0;
            this.metroTextBox5.UseSelectable = true;
            this.metroTextBox5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(434, 241);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(100, 19);
            this.metroLabel11.TabIndex = 54;
            this.metroLabel11.Text = "Cross Sec Area:";
            // 
            // requiredPanel11
            // 
            this.requiredPanel11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel11.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel11.Controls.Add(this.txtStdBarLength);
            this.requiredPanel11.IsRequired = true;
            this.requiredPanel11.Location = new System.Drawing.Point(175, 171);
            this.requiredPanel11.Name = "requiredPanel11";
            this.requiredPanel11.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel11.TabIndex = 3;
            // 
            // txtStdBarLength
            // 
            // 
            // 
            // 
            this.txtStdBarLength.CustomButton.Image = null;
            this.txtStdBarLength.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtStdBarLength.CustomButton.Name = "";
            this.txtStdBarLength.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtStdBarLength.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtStdBarLength.CustomButton.TabIndex = 1;
            this.txtStdBarLength.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtStdBarLength.CustomButton.UseSelectable = true;
            this.txtStdBarLength.CustomButton.Visible = false;
            this.txtStdBarLength.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "StdBarLength", true));
            this.txtStdBarLength.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtStdBarLength.Lines = new string[0];
            this.txtStdBarLength.Location = new System.Drawing.Point(0, 0);
            this.txtStdBarLength.MaxLength = 50;
            this.txtStdBarLength.Name = "txtStdBarLength";
            this.txtStdBarLength.PasswordChar = '\0';
            this.txtStdBarLength.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStdBarLength.SelectedText = "";
            this.txtStdBarLength.SelectionLength = 0;
            this.txtStdBarLength.SelectionStart = 0;
            this.txtStdBarLength.ShortcutsEnabled = true;
            this.txtStdBarLength.Size = new System.Drawing.Size(100, 25);
            this.txtStdBarLength.TabIndex = 0;
            this.txtStdBarLength.UseSelectable = true;
            this.txtStdBarLength.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtStdBarLength.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtStdBarLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            this.txtStdBarLength.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumeric_Validating);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(23, 174);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(132, 19);
            this.metroLabel12.TabIndex = 56;
            this.metroLabel12.Text = "Standard Bar Length:";
            // 
            // requiredPanel12
            // 
            this.requiredPanel12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel12.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel12.Controls.Add(this.metroTextBox7);
            this.requiredPanel12.IsRequired = true;
            this.requiredPanel12.Location = new System.Drawing.Point(175, 235);
            this.requiredPanel12.Name = "requiredPanel12";
            this.requiredPanel12.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel12.TabIndex = 5;
            // 
            // metroTextBox7
            // 
            // 
            // 
            // 
            this.metroTextBox7.CustomButton.Image = null;
            this.metroTextBox7.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.metroTextBox7.CustomButton.Name = "";
            this.metroTextBox7.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox7.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox7.CustomButton.TabIndex = 1;
            this.metroTextBox7.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox7.CustomButton.UseSelectable = true;
            this.metroTextBox7.CustomButton.Visible = false;
            this.metroTextBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleQtyInMtrs", true));
            this.metroTextBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTextBox7.Lines = new string[0];
            this.metroTextBox7.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox7.MaxLength = 50;
            this.metroTextBox7.Name = "metroTextBox7";
            this.metroTextBox7.PasswordChar = '\0';
            this.metroTextBox7.ReadOnly = true;
            this.metroTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox7.SelectedText = "";
            this.metroTextBox7.SelectionLength = 0;
            this.metroTextBox7.SelectionStart = 0;
            this.metroTextBox7.ShortcutsEnabled = true;
            this.metroTextBox7.Size = new System.Drawing.Size(100, 25);
            this.metroTextBox7.TabIndex = 0;
            this.metroTextBox7.UseSelectable = true;
            this.metroTextBox7.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox7.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(23, 238);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(153, 19);
            this.metroLabel13.TabIndex = 58;
            this.metroLabel13.Text = "Bundle Quantity(in mtrs):";
            // 
            // requiredPanel13
            // 
            this.requiredPanel13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel13.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel13.Controls.Add(this.txtTotalLenth);
            this.requiredPanel13.IsRequired = true;
            this.requiredPanel13.Location = new System.Drawing.Point(175, 299);
            this.requiredPanel13.Name = "requiredPanel13";
            this.requiredPanel13.Size = new System.Drawing.Size(120, 25);
            this.requiredPanel13.TabIndex = 7;
            // 
            // txtTotalLenth
            // 
            // 
            // 
            // 
            this.txtTotalLenth.CustomButton.Image = null;
            this.txtTotalLenth.CustomButton.Location = new System.Drawing.Point(76, 1);
            this.txtTotalLenth.CustomButton.Name = "";
            this.txtTotalLenth.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtTotalLenth.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtTotalLenth.CustomButton.TabIndex = 1;
            this.txtTotalLenth.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtTotalLenth.CustomButton.UseSelectable = true;
            this.txtTotalLenth.CustomButton.Visible = false;
            this.txtTotalLenth.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.materialBindingSource, "BundleTotalLengthInMtrs", true));
            this.txtTotalLenth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotalLenth.Lines = new string[0];
            this.txtTotalLenth.Location = new System.Drawing.Point(0, 0);
            this.txtTotalLenth.MaxLength = 50;
            this.txtTotalLenth.Name = "txtTotalLenth";
            this.txtTotalLenth.PasswordChar = '\0';
            this.txtTotalLenth.ReadOnly = true;
            this.txtTotalLenth.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTotalLenth.SelectedText = "";
            this.txtTotalLenth.SelectionLength = 0;
            this.txtTotalLenth.SelectionStart = 0;
            this.txtTotalLenth.ShortcutsEnabled = true;
            this.txtTotalLenth.Size = new System.Drawing.Size(100, 25);
            this.txtTotalLenth.TabIndex = 0;
            this.txtTotalLenth.UseSelectable = true;
            this.txtTotalLenth.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtTotalLenth.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(23, 302);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(108, 19);
            this.metroLabel14.TabIndex = 60;
            this.metroLabel14.Text = "Total Bundle Qty:";
            // 
            // pb_MaterialImage
            // 
            this.pb_MaterialImage.Image = ((System.Drawing.Image)(resources.GetObject("pb_MaterialImage.Image")));
            this.pb_MaterialImage.Location = new System.Drawing.Point(175, 330);
            this.pb_MaterialImage.MaxImageSize = new System.Drawing.Size(0, 0);
            this.pb_MaterialImage.MinImageSize = new System.Drawing.Size(0, 0);
            this.pb_MaterialImage.Name = "pb_MaterialImage";
            this.pb_MaterialImage.Size = new System.Drawing.Size(222, 75);
            this.pb_MaterialImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_MaterialImage.TabIndex = 61;
            this.pb_MaterialImage.TabStop = false;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(28, 354);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(101, 19);
            this.metroLabel15.TabIndex = 62;
            this.metroLabel15.Text = "Material Image:";
            // 
            // MaterialView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 416);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.pb_MaterialImage);
            this.Controls.Add(this.requiredPanel13);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.requiredPanel12);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.requiredPanel11);
            this.Controls.Add(this.metroLabel12);
            this.Controls.Add(this.requiredPanel10);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.requiredPanel9);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.requiredPanel8);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.requiredPanel7);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.requiredPanel6);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.cboToolings);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.requiredPanel3);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.requiredPanel1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.requiredPanel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.requiredPanel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Name = "MaterialView";
            this.Text = "Material";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MaterialView_FormClosing);
            this.Load += new System.EventHandler(this.MaterialView_Load);
            this.requiredPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.materialBindingSource)).EndInit();
            this.requiredPanel4.ResumeLayout(false);
            this.requiredPanel5.ResumeLayout(false);
            this.requiredPanel1.ResumeLayout(false);
            this.requiredPanel3.ResumeLayout(false);
            this.requiredPanel6.ResumeLayout(false);
            this.requiredPanel7.ResumeLayout(false);
            this.requiredPanel8.ResumeLayout(false);
            this.requiredPanel9.ResumeLayout(false);
            this.requiredPanel10.ResumeLayout(false);
            this.requiredPanel11.ResumeLayout(false);
            this.requiredPanel12.ResumeLayout(false);
            this.requiredPanel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_MaterialImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private System.Windows.Forms.BindingSource materialBindingSource;
        private UIHelper.RequiredPanel requiredPanel4;
        private MetroFramework.Controls.MetroTextBox txtHeight;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.RequiredPanel requiredPanel5;
        private MetroFramework.Controls.MetroTextBox txtWidth;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private UIHelper.RequiredPanel requiredPanel1;
        private MetroFramework.Controls.MetroTextBox txtUOM;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.RequiredPanel requiredPanel3;
        private MetroFramework.Controls.MetroTextBox txtSectionbalWeigth;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroComboBox cboToolings;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private UIHelper.RequiredPanel requiredPanel6;
        private MetroFramework.Controls.MetroTextBox txtNoOfBarQty;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private UIHelper.RequiredPanel requiredPanel7;
        private MetroFramework.Controls.MetroTextBox txtBundleWeight;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private UIHelper.RequiredPanel requiredPanel8;
        private MetroFramework.Controls.MetroTextBox txtBundleVolume;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private UIHelper.RequiredPanel requiredPanel9;
        private MetroFramework.Controls.MetroTextBox txtMaterialDesc;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private UIHelper.RequiredPanel requiredPanel10;
        private MetroFramework.Controls.MetroTextBox metroTextBox5;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private UIHelper.RequiredPanel requiredPanel11;
        private MetroFramework.Controls.MetroTextBox txtStdBarLength;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private UIHelper.RequiredPanel requiredPanel12;
        private MetroFramework.Controls.MetroTextBox metroTextBox7;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroTextBox txtTotalLenth;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private UIHelper.RequiredPanel requiredPanel13;
        private UIHelper.PictureBox pb_MaterialImage;
        private MetroFramework.Controls.MetroLabel metroLabel15;
    }
}