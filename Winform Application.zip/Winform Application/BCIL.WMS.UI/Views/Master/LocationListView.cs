﻿using BCIL.User.UI.Views;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class LocationListView : ControlSliderBase, ILocationListView
    {
        #region Public Constructors

        public LocationListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Locations";
            olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var location = o as Location;
                return location.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler AddLocationRequested;

        public event EventHandler<Location> EditLocationRequested;

        public event EventHandler<List<Location>> PrintRequested;

        public event EventHandler ImportDataRequested;

        public event EventHandler SearchRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler NextPageResultsRequested;

        #endregion Public Events

        #region Public Properties

        public LocationListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinding()
        {
            BindComboToKeyValue(cboMode, Model.Mode);
            BindComboToKeyValue(cboIsActive, Model.State);
            BindComboToKeyValue(cboLocationType, Model.Type);

            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.LocationCode);
            BindingUtility.CreateBinding(txtName, c => c.Text, Model.SearchCriteria, d => d.Name);
            BindingUtility.CreateBinding(cboMode, c => c.SelectedValue, Model.SearchCriteria, d => d.Mode);
            BindingUtility.CreateBinding(cboLocationType, c => c.SelectedValue, Model.SearchCriteria, d => d.Type);
            BindingUtility.CreateBinding(cboIsActive, c => c.SelectedValue, Model.SearchCriteria, d => d.State);
        }

        public void RefreshGrid()
        {
            if (Model.Locations.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.Locations.Count - 1, Model.Locations.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.Locations.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.Locations.Count);
            }

            olvLocations.SetObjects(Model.Locations);
        }

        private void BindComboToKeyValue(MetroFramework.Controls.MetroComboBox cbo, List<KeyValue<int, string>> values)
        {
            cbo.DisplayMember = "Value";
            cbo.ValueMember = "Key";
            cbo.DataSource = values;
        }

        #endregion Public Methods

        #region Private Events

        private void LocationListView_Load(object sender, EventArgs e)
        {
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddLocationRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvLocations.SelectedObject != null)
                {
                    EditLocationRequested?.Invoke(this, (Location)olvLocations.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void LocationListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvLocations.Width - 20;
                olvColumnCode.Width = withToDistribute.GetPercentValue(20);
                olvColumnDescription.Width = withToDistribute.GetPercentValue(20);
                olvColumnName.Width = withToDistribute.GetPercentValue(20);
                olvColumnMode.Width = withToDistribute.GetPercentValue(10);
                olvColumnType.Width = withToDistribute.GetPercentValue(10);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(10);
                olvColumnActive.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvLocations_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnPrint.Enabled = true;
                if (olvLocations.SelectedObjects.Count > 0)
                {
                   
                    btnEdit1.Enabled = true;
                }
                else
                {
                    btnEdit1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite != null)
                {
                    ImportDataRequested?.Invoke(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonSearch1_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void lblRecords_Click(object sender, EventArgs e)
        {
        }

        private void LocationListView_Showing(object sender, ActionArg e)
        {
            try
            {
                if (!App.Login.User.IsSupperUser)
                {
                    LoginedLocationSelectionView.SelectLocationIfNot(this);
                    if (App.Login.LoginSite == null)
                    {
                        e.Handled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null) { return; }

                var locationList = new List<Location>();
                foreach (Location item in olvLocations.SelectedObjects)
                {
                    locationList.Add(item);
                }
                CodeContract.Required<ArgumentException>(locationList.HaveItems(), "Atleast one bin is required");

                PrintRequested?.Invoke(this, locationList);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}