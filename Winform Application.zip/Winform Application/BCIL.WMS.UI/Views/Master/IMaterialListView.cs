﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IMaterialListView : IBaseView<MaterialListModel>
    {
        event EventHandler AddMaterialRequested;
        event EventHandler<Material> EditMaterialRequested;
        event EventHandler ImportDataRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler<Material> ReadOnlyViewMaterialRequested;
        event EventHandler NextPageResultsRequested;
        event EventHandler SearchRequested;
        void BindingHeader();
        void RefreshBinding();
    }
}
