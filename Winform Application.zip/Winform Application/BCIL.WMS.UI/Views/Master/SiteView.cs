﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class SiteView : FormBase, ISiteView
    {
        #region Constructor

        public SiteView()
        {
            InitializeComponent();
        }

        public SiteView(Site site) : this()
        {
            txtCode.Enabled = false;
            this.Text = "Edit Plant";
            Model.Site = site;
            Model.Site.BeginEdit();
        }

        #endregion Constructor

        #region Public Properties

        public Permission AddEditPermision { get; set; }
        public SiteModel Model { get; set; }

        #endregion Public Properties

        #region Private Event

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SaveRequested;

        #endregion Private Event

        #region Public Methods

        public void RefreshBinding()
        {
            SiteBindingSource.DataSource = Model.Site;
        }

        #endregion Public Methods

        #region Private Methods

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void SiteView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}