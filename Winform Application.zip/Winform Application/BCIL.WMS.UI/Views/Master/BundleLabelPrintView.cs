﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class BundleLabelPrintView : FormBase, IBundleLabelPrintView
    {
        public BundleLabelPrintView()
        {
            InitializeComponent();
        }

        public BundleLabelPrintView(ProductionOrder po) : this()
        {
            if (Model == null) Model = new BundleLabelPrintModel();
            Model.POrder = po;
            if (Model.POrder.Status == BL.Enums.ProductionOrderStatus.BundlePrinted || Model.POrder.Status == BL.Enums.ProductionOrderStatus.ItemPrinted)
            {
                ShowReadOnlyView();
            }
            BindUIData();
        }

        private void BindUIData()
        {
        }

        private void ShowReadOnlyView()
        {
            btnPrint.Visible = false;
        }

        public void BindHeader()
        {
            BindingUtility.CreateBinding(txtQty, c => c.Text, Model, d => d.QtyToPrint);
            lblMaterialCode.Text = Model.POrder.POLineItems[0].Material.Value;
            lblPODate.Text = Model.POrder.POrderDate.ToString(App.DateFormat);
            lblPONumber.Text = Model.POrder.POrderNo;
            lblBundleQty.Text = Model.TotalBundleQty.ToString();
            lblPrintedQtyValues.Text = Model.TotalPrintedBundleQty.ToString();
        }

        public BundleLabelPrintModel Model { get; set; }

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SavePrintRequested;

        private void BundleLabelPrintView_Load(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (SavePrintRequested != null) SavePrintRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowWholeNumberOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void BundleLabelPrintView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}