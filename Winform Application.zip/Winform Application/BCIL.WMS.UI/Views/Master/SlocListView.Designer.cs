﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialBinListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialBinListView));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvMaterialBins = new BCIL.UIHelper.DataListView();
            this.olvColumnCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialDesc = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocation = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnRackNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnRowNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnColumnNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnHeight = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnWidth = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCapacity = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedDate = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnEdit = new System.Windows.Forms.ToolStripButton();
            this.btnImport = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.buttonSearch1 = new BCIL.UIHelper.ButtonSearch();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtLocation = new MetroFramework.Controls.MetroTextBox();
            this.txtSearchMaterial = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterialBins)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvMaterialBins);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 143);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(820, 262);
            this.metroPanel1.TabIndex = 9;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvMaterialBins
            // 
            this.olvMaterialBins.AllColumns.Add(this.olvColumnCode);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnMaterialCode);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnMaterialDesc);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnLocation);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnRackNo);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnRowNo);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnColumnNo);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnHeight);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnWidth);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnCapacity);
            this.olvMaterialBins.AllColumns.Add(this.olvColumnCreatedDate);
            this.olvMaterialBins.AllColumns.Add(this.olvColumn1);
            this.olvMaterialBins.CellEditUseWholeCell = false;
            this.olvMaterialBins.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnCode,
            this.olvColumnMaterialCode,
            this.olvColumnMaterialDesc,
            this.olvColumnLocation,
            this.olvColumnRackNo,
            this.olvColumnRowNo,
            this.olvColumnColumnNo,
            this.olvColumnHeight,
            this.olvColumnWidth,
            this.olvColumnCapacity,
            this.olvColumnCreatedDate,
            this.olvColumn1});
            this.olvMaterialBins.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvMaterialBins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvMaterialBins.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvMaterialBins.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvMaterialBins.FullRowSelect = true;
            this.olvMaterialBins.HeaderMinimumHeight = 30;
            this.olvMaterialBins.HideSelection = false;
            this.olvMaterialBins.IncludeColumnHeadersInCopy = true;
            this.olvMaterialBins.Location = new System.Drawing.Point(0, 33);
            this.olvMaterialBins.Name = "olvMaterialBins";
            this.olvMaterialBins.RowHeight = 25;
            this.olvMaterialBins.ShowGroups = false;
            this.olvMaterialBins.Size = new System.Drawing.Size(820, 229);
            this.olvMaterialBins.TabIndex = 10;
            this.olvMaterialBins.UseCompatibleStateImageBehavior = false;
            this.olvMaterialBins.View = System.Windows.Forms.View.Details;
            this.olvMaterialBins.VirtualMode = true;
            this.olvMaterialBins.SelectedIndexChanged += new System.EventHandler(this.olvMaterialBins_SelectedIndexChanged);
            this.olvMaterialBins.DoubleClick += new System.EventHandler(this.btnEdit_Click);
            // 
            // olvColumnCode
            // 
            this.olvColumnCode.AspectName = "MaterialBinCode";
            this.olvColumnCode.Text = "Code";
            this.olvColumnCode.Width = 150;
            // 
            // olvColumnMaterialCode
            // 
            this.olvColumnMaterialCode.AspectName = "Material.Value";
            this.olvColumnMaterialCode.Text = "Material Code";
            this.olvColumnMaterialCode.Width = 114;
            // 
            // olvColumnMaterialDesc
            // 
            this.olvColumnMaterialDesc.AspectName = "MaterialDesc";
            this.olvColumnMaterialDesc.Text = "Material Desc";
            this.olvColumnMaterialDesc.Width = 120;
            // 
            // olvColumnLocation
            // 
            this.olvColumnLocation.AspectName = "Location.Value";
            this.olvColumnLocation.Text = "Location";
            this.olvColumnLocation.Width = 150;
            // 
            // olvColumnRackNo
            // 
            this.olvColumnRackNo.AspectName = "RackNo";
            this.olvColumnRackNo.Text = "Rack No";
            this.olvColumnRackNo.Width = 100;
            // 
            // olvColumnRowNo
            // 
            this.olvColumnRowNo.AspectName = "RowNo";
            this.olvColumnRowNo.Text = "Row No";
            this.olvColumnRowNo.Width = 100;
            // 
            // olvColumnColumnNo
            // 
            this.olvColumnColumnNo.AspectName = "ColumnNo";
            this.olvColumnColumnNo.Text = "Column No";
            this.olvColumnColumnNo.Width = 100;
            // 
            // olvColumnHeight
            // 
            this.olvColumnHeight.AspectName = "Height";
            this.olvColumnHeight.Text = "Height";
            this.olvColumnHeight.Width = 100;
            // 
            // olvColumnWidth
            // 
            this.olvColumnWidth.AspectName = "Width";
            this.olvColumnWidth.Text = "Width";
            this.olvColumnWidth.Width = 100;
            // 
            // olvColumnCapacity
            // 
            this.olvColumnCapacity.AspectName = "Capacity";
            this.olvColumnCapacity.Text = "Capacity(No of Bundles)";
            this.olvColumnCapacity.Width = 120;
            // 
            // olvColumnCreatedDate
            // 
            this.olvColumnCreatedDate.AspectName = "CreatedOn";
            this.olvColumnCreatedDate.Text = "Created Date";
            this.olvColumnCreatedDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumnCreatedDate.Width = 135;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.btnEdit,
            this.btnImport,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious,
            this.btnPrint});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(820, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.IsActionRestrictedByPermission = false;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(62, 30);
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(60, 30);
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnImport
            // 
            this.btnImport.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnImport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImport.IsActionRestrictedByPermission = false;
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(77, 30);
            this.btnImport.Text = "Import";
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.IsActionRestrictedByPermission = false;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(64, 30);
            this.btnPrint.Text = "Print";
            this.btnPrint.Visible = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // buttonSearch1
            // 
            this.buttonSearch1.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch1.ButtonImage")));
            this.buttonSearch1.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch1.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch1.ImageSize = 50;
            this.buttonSearch1.Location = new System.Drawing.Point(551, 45);
            this.buttonSearch1.Name = "buttonSearch1";
            this.buttonSearch1.Size = new System.Drawing.Size(85, 64);
            this.buttonSearch1.TabIndex = 38;
            this.buttonSearch1.Text = "Search";
            this.buttonSearch1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch1.UseSelectable = true;
            this.buttonSearch1.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(273, 70);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(61, 19);
            this.metroLabel6.TabIndex = 37;
            this.metroLabel6.Text = "Location:";
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(155, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(76, 67);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(179, 25);
            this.txtCode.TabIndex = 34;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(15, 70);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 35;
            this.metroLabel1.Text = "Code:";
            // 
            // txtLocation
            // 
            // 
            // 
            // 
            this.txtLocation.CustomButton.Image = null;
            this.txtLocation.CustomButton.Location = new System.Drawing.Point(155, 1);
            this.txtLocation.CustomButton.Name = "";
            this.txtLocation.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtLocation.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLocation.CustomButton.TabIndex = 1;
            this.txtLocation.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLocation.CustomButton.UseSelectable = true;
            this.txtLocation.CustomButton.Visible = false;
            this.txtLocation.Lines = new string[0];
            this.txtLocation.Location = new System.Drawing.Point(340, 67);
            this.txtLocation.MaxLength = 50;
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.PasswordChar = '\0';
            this.txtLocation.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLocation.SelectedText = "";
            this.txtLocation.SelectionLength = 0;
            this.txtLocation.SelectionStart = 0;
            this.txtLocation.ShortcutsEnabled = true;
            this.txtLocation.Size = new System.Drawing.Size(179, 25);
            this.txtLocation.TabIndex = 39;
            this.txtLocation.UseSelectable = true;
            this.txtLocation.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLocation.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtSearchMaterial
            // 
            // 
            // 
            // 
            this.txtSearchMaterial.CustomButton.Image = null;
            this.txtSearchMaterial.CustomButton.Location = new System.Drawing.Point(155, 1);
            this.txtSearchMaterial.CustomButton.Name = "";
            this.txtSearchMaterial.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtSearchMaterial.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearchMaterial.CustomButton.TabIndex = 1;
            this.txtSearchMaterial.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearchMaterial.CustomButton.UseSelectable = true;
            this.txtSearchMaterial.CustomButton.Visible = false;
            this.txtSearchMaterial.Lines = new string[0];
            this.txtSearchMaterial.Location = new System.Drawing.Point(76, 107);
            this.txtSearchMaterial.MaxLength = 50;
            this.txtSearchMaterial.Name = "txtSearchMaterial";
            this.txtSearchMaterial.PasswordChar = '\0';
            this.txtSearchMaterial.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearchMaterial.SelectedText = "";
            this.txtSearchMaterial.SelectionLength = 0;
            this.txtSearchMaterial.SelectionStart = 0;
            this.txtSearchMaterial.ShortcutsEnabled = true;
            this.txtSearchMaterial.Size = new System.Drawing.Size(179, 25);
            this.txtSearchMaterial.TabIndex = 42;
            this.txtSearchMaterial.UseSelectable = true;
            this.txtSearchMaterial.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearchMaterial.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(15, 110);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(60, 19);
            this.metroLabel2.TabIndex = 43;
            this.metroLabel2.Text = "Material:";
            // 
            // MaterialBinListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtSearchMaterial);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.buttonSearch1);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "MaterialBinListView";
            this.Size = new System.Drawing.Size(840, 420);
            this.Title = "MaterialBin";
            this.Resize += new System.EventHandler(this.MaterialBinListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.txtCode, 0);
            this.Controls.SetChildIndex(this.metroLabel6, 0);
            this.Controls.SetChildIndex(this.buttonSearch1, 0);
            this.Controls.SetChildIndex(this.txtLocation, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.txtSearchMaterial, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterialBins)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvMaterialBins;
        private BrightIdeasSoftware.OLVColumn olvColumnCode;
        private BrightIdeasSoftware.OLVColumn olvColumnRackNo;
        private BrightIdeasSoftware.OLVColumn olvColumnRowNo;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialCode;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedDate;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripButton btnEdit;
        private BrightIdeasSoftware.OLVColumn olvColumnColumnNo;
        private BrightIdeasSoftware.OLVColumn olvColumnHeight;
        private BrightIdeasSoftware.OLVColumn olvColumnWidth;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnImport;
        private BrightIdeasSoftware.OLVColumn olvColumnLocation;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnNext;
        private UIHelper.ButtonSearch buttonSearch1;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtLocation;
        private BrightIdeasSoftware.OLVColumn olvColumnCapacity;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnPrint;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialDesc;
        private MetroFramework.Controls.MetroTextBox txtSearchMaterial;
        private MetroFramework.Controls.MetroLabel metroLabel2;
    }
}
