﻿namespace BCIL.WMS.UI.Views
{
    partial class BundleLabelPrintView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BundleLabelPrintView));
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnPrint = new BCIL.UIHelper.ButtonSave();
            this.lblMaterialCode = new MetroFramework.Controls.MetroLabel();
            this.lblPrintedQtyValues = new MetroFramework.Controls.MetroLabel();
            this.lblPrintedQty = new MetroFramework.Controls.MetroLabel();
            this.txtQty = new MetroFramework.Controls.MetroTextBox();
            this.lblQtyToPrint = new MetroFramework.Controls.MetroLabel();
            this.lblRequestQty = new MetroFramework.Controls.MetroLabel();
            this.lblPONumber = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.lblPODate = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lblBundleQty = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.BundlePrintingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.BundlePrintingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(431, 218);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnPrint.ButtonImage")));
            this.btnPrint.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrint.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnPrint.ImageSize = 50;
            this.btnPrint.Location = new System.Drawing.Point(335, 218);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(85, 56);
            this.btnPrint.TabIndex = 11;
            this.btnPrint.Text = "Print";
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrint.UseSelectable = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblMaterialCode
            // 
            this.lblMaterialCode.AutoSize = true;
            this.lblMaterialCode.Location = new System.Drawing.Point(113, 103);
            this.lblMaterialCode.Name = "lblMaterialCode";
            this.lblMaterialCode.Size = new System.Drawing.Size(42, 19);
            this.lblMaterialCode.TabIndex = 46;
            this.lblMaterialCode.Text = "M001";
            // 
            // lblPrintedQtyValues
            // 
            this.lblPrintedQtyValues.AutoSize = true;
            this.lblPrintedQtyValues.Location = new System.Drawing.Point(113, 135);
            this.lblPrintedQtyValues.Name = "lblPrintedQtyValues";
            this.lblPrintedQtyValues.Size = new System.Drawing.Size(76, 19);
            this.lblPrintedQtyValues.TabIndex = 45;
            this.lblPrintedQtyValues.Text = "Printed Qty";
            // 
            // lblPrintedQty
            // 
            this.lblPrintedQty.AutoSize = true;
            this.lblPrintedQty.Location = new System.Drawing.Point(23, 135);
            this.lblPrintedQty.Name = "lblPrintedQty";
            this.lblPrintedQty.Size = new System.Drawing.Size(79, 19);
            this.lblPrintedQty.TabIndex = 44;
            this.lblPrintedQty.Text = "Printed Qty:";
            // 
            // txtQty
            // 
            // 
            // 
            // 
            this.txtQty.CustomButton.Image = null;
            this.txtQty.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.txtQty.CustomButton.Name = "";
            this.txtQty.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtQty.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtQty.CustomButton.TabIndex = 1;
            this.txtQty.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtQty.CustomButton.UseSelectable = true;
            this.txtQty.CustomButton.Visible = false;
            this.txtQty.Lines = new string[0];
            this.txtQty.Location = new System.Drawing.Point(381, 130);
            this.txtQty.MaxLength = 9;
            this.txtQty.Name = "txtQty";
            this.txtQty.PasswordChar = '\0';
            this.txtQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtQty.SelectedText = "";
            this.txtQty.SelectionLength = 0;
            this.txtQty.SelectionStart = 0;
            this.txtQty.ShortcutsEnabled = true;
            this.txtQty.Size = new System.Drawing.Size(81, 29);
            this.txtQty.TabIndex = 43;
            this.txtQty.UseSelectable = true;
            this.txtQty.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtQty.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQty_KeyPress);
            // 
            // lblQtyToPrint
            // 
            this.lblQtyToPrint.AutoSize = true;
            this.lblQtyToPrint.Location = new System.Drawing.Point(299, 135);
            this.lblQtyToPrint.Name = "lblQtyToPrint";
            this.lblQtyToPrint.Size = new System.Drawing.Size(64, 19);
            this.lblQtyToPrint.TabIndex = 42;
            this.lblQtyToPrint.Text = "Print Qty:";
            // 
            // lblRequestQty
            // 
            this.lblRequestQty.AutoSize = true;
            this.lblRequestQty.Location = new System.Drawing.Point(23, 103);
            this.lblRequestQty.Name = "lblRequestQty";
            this.lblRequestQty.Size = new System.Drawing.Size(60, 19);
            this.lblRequestQty.TabIndex = 41;
            this.lblRequestQty.Text = "Material:";
            // 
            // lblPONumber
            // 
            this.lblPONumber.AutoSize = true;
            this.lblPONumber.Location = new System.Drawing.Point(113, 74);
            this.lblPONumber.Name = "lblPONumber";
            this.lblPONumber.Size = new System.Drawing.Size(33, 19);
            this.lblPONumber.TabIndex = 48;
            this.lblPONumber.Text = "XXX";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 74);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(84, 19);
            this.metroLabel2.TabIndex = 47;
            this.metroLabel2.Text = "PO Number:";
            // 
            // lblPODate
            // 
            this.lblPODate.AutoSize = true;
            this.lblPODate.Location = new System.Drawing.Point(381, 74);
            this.lblPODate.Name = "lblPODate";
            this.lblPODate.Size = new System.Drawing.Size(69, 19);
            this.lblPODate.TabIndex = 50;
            this.lblPODate.Text = "XX-XX-XX";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(299, 74);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(62, 19);
            this.metroLabel4.TabIndex = 49;
            this.metroLabel4.Text = "PO Date:";
            // 
            // lblBundleQty
            // 
            this.lblBundleQty.AutoSize = true;
            this.lblBundleQty.Location = new System.Drawing.Point(381, 103);
            this.lblBundleQty.Name = "lblBundleQty";
            this.lblBundleQty.Size = new System.Drawing.Size(95, 19);
            this.lblBundleQty.TabIndex = 52;
            this.lblBundleQty.Text = "Requested Qty";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(299, 103);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(77, 19);
            this.metroLabel6.TabIndex = 51;
            this.metroLabel6.Text = "Bundle Qty:";
            // 
            // BundlePrintingBindingSource
            // 
            this.BundlePrintingBindingSource.DataSource = typeof(BCIL.WMS.BL.ProductionOrder);
            // 
            // BundleLabelPrintView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 288);
            this.Controls.Add(this.lblBundleQty);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.lblPODate);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.lblPONumber);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblMaterialCode);
            this.Controls.Add(this.lblPrintedQtyValues);
            this.Controls.Add(this.lblPrintedQty);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.lblQtyToPrint);
            this.Controls.Add(this.lblRequestQty);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPrint);
            this.Name = "BundleLabelPrintView";
            this.Text = "Bundle Label Print";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BundleLabelPrintView_FormClosing);
            this.Load += new System.EventHandler(this.BundleLabelPrintView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BundlePrintingBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnPrint;
        private MetroFramework.Controls.MetroLabel lblMaterialCode;
        private MetroFramework.Controls.MetroLabel lblPrintedQtyValues;
        private MetroFramework.Controls.MetroLabel lblPrintedQty;
        private MetroFramework.Controls.MetroTextBox txtQty;
        private MetroFramework.Controls.MetroLabel lblQtyToPrint;
        private MetroFramework.Controls.MetroLabel lblRequestQty;
        private MetroFramework.Controls.MetroLabel lblPONumber;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel lblPODate;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel lblBundleQty;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.BindingSource BundlePrintingBindingSource;
    }
}