﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialStockListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialStockListView));
            this.txtLocationCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtMaterialCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnSearch = new BCIL.UIHelper.ButtonSearch();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvMaterialStocks = new BCIL.UIHelper.DataListView();
            this.olvColumnMaterial = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialDesc = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocation = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnBundleQty = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnView = new System.Windows.Forms.ToolStripButton();
            this.btnExport = new System.Windows.Forms.ToolStripButton();
            this.olvColumnLocationType = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterialStocks)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLocationCode
            // 
            // 
            // 
            // 
            this.txtLocationCode.CustomButton.Image = null;
            this.txtLocationCode.CustomButton.Location = new System.Drawing.Point(118, 1);
            this.txtLocationCode.CustomButton.Name = "";
            this.txtLocationCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtLocationCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtLocationCode.CustomButton.TabIndex = 1;
            this.txtLocationCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtLocationCode.CustomButton.UseSelectable = true;
            this.txtLocationCode.CustomButton.Visible = false;
            this.txtLocationCode.Lines = new string[0];
            this.txtLocationCode.Location = new System.Drawing.Point(379, 51);
            this.txtLocationCode.MaxLength = 50;
            this.txtLocationCode.Name = "txtLocationCode";
            this.txtLocationCode.PasswordChar = '\0';
            this.txtLocationCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLocationCode.SelectedText = "";
            this.txtLocationCode.SelectionLength = 0;
            this.txtLocationCode.SelectionStart = 0;
            this.txtLocationCode.ShortcutsEnabled = true;
            this.txtLocationCode.Size = new System.Drawing.Size(142, 25);
            this.txtLocationCode.TabIndex = 64;
            this.txtLocationCode.UseSelectable = true;
            this.txtLocationCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtLocationCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(315, 54);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(61, 19);
            this.metroLabel5.TabIndex = 65;
            this.metroLabel5.Text = "Location:";
            // 
            // txtMaterialCode
            // 
            // 
            // 
            // 
            this.txtMaterialCode.CustomButton.Image = null;
            this.txtMaterialCode.CustomButton.Location = new System.Drawing.Point(118, 1);
            this.txtMaterialCode.CustomButton.Name = "";
            this.txtMaterialCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtMaterialCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMaterialCode.CustomButton.TabIndex = 1;
            this.txtMaterialCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMaterialCode.CustomButton.UseSelectable = true;
            this.txtMaterialCode.CustomButton.Visible = false;
            this.txtMaterialCode.Lines = new string[0];
            this.txtMaterialCode.Location = new System.Drawing.Point(138, 54);
            this.txtMaterialCode.MaxLength = 50;
            this.txtMaterialCode.Name = "txtMaterialCode";
            this.txtMaterialCode.PasswordChar = '\0';
            this.txtMaterialCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMaterialCode.SelectedText = "";
            this.txtMaterialCode.SelectionLength = 0;
            this.txtMaterialCode.SelectionStart = 0;
            this.txtMaterialCode.ShortcutsEnabled = true;
            this.txtMaterialCode.Size = new System.Drawing.Size(142, 25);
            this.txtMaterialCode.TabIndex = 62;
            this.txtMaterialCode.UseSelectable = true;
            this.txtMaterialCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMaterialCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(17, 57);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(96, 19);
            this.metroLabel4.TabIndex = 63;
            this.metroLabel4.Text = "Material Code:";
            // 
            // dtpImportedTo
            // 
            this.dtpImportedTo.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedTo.Location = new System.Drawing.Point(379, 87);
            this.dtpImportedTo.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedTo.Name = "dtpImportedTo";
            this.dtpImportedTo.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedTo.TabIndex = 61;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(315, 90);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(27, 19);
            this.metroLabel2.TabIndex = 60;
            this.metroLabel2.Text = "To:";
            // 
            // dtpImportedFrom
            // 
            this.dtpImportedFrom.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedFrom.Location = new System.Drawing.Point(138, 87);
            this.dtpImportedFrom.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedFrom.Name = "dtpImportedFrom";
            this.dtpImportedFrom.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedFrom.TabIndex = 59;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(17, 90);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(118, 19);
            this.metroLabel3.TabIndex = 58;
            this.metroLabel3.Text = "Create Date From:";
            // 
            // btnSearch
            // 
            this.btnSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.ButtonImage")));
            this.btnSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSearch.ImageSize = 50;
            this.btnSearch.Location = new System.Drawing.Point(594, 48);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(85, 64);
            this.btnSearch.TabIndex = 57;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvMaterialStocks);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 144);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(885, 357);
            this.metroPanel1.TabIndex = 56;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvMaterialStocks
            // 
            this.olvMaterialStocks.AllColumns.Add(this.olvColumnMaterial);
            this.olvMaterialStocks.AllColumns.Add(this.olvColumnMaterialDesc);
            this.olvMaterialStocks.AllColumns.Add(this.olvColumnLocation);
            this.olvMaterialStocks.AllColumns.Add(this.olvColumnLocationType);
            this.olvMaterialStocks.AllColumns.Add(this.olvColumnBundleQty);
            this.olvMaterialStocks.AllColumns.Add(this.olvColumn1);
            this.olvMaterialStocks.CellEditUseWholeCell = false;
            this.olvMaterialStocks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnMaterial,
            this.olvColumnMaterialDesc,
            this.olvColumnLocation,
            this.olvColumnLocationType,
            this.olvColumnBundleQty,
            this.olvColumn1});
            this.olvMaterialStocks.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvMaterialStocks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvMaterialStocks.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvMaterialStocks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvMaterialStocks.FullRowSelect = true;
            this.olvMaterialStocks.HeaderMinimumHeight = 30;
            this.olvMaterialStocks.HideSelection = false;
            this.olvMaterialStocks.IncludeColumnHeadersInCopy = true;
            this.olvMaterialStocks.Location = new System.Drawing.Point(0, 33);
            this.olvMaterialStocks.Name = "olvMaterialStocks";
            this.olvMaterialStocks.RowHeight = 25;
            this.olvMaterialStocks.ShowGroups = false;
            this.olvMaterialStocks.Size = new System.Drawing.Size(885, 324);
            this.olvMaterialStocks.TabIndex = 10;
            this.olvMaterialStocks.UseCompatibleStateImageBehavior = false;
            this.olvMaterialStocks.View = System.Windows.Forms.View.Details;
            this.olvMaterialStocks.VirtualMode = true;
            this.olvMaterialStocks.SelectedIndexChanged += new System.EventHandler(this.olvMaterialStocks_SelectedIndexChanged);
            // 
            // olvColumnMaterial
            // 
            this.olvColumnMaterial.AspectName = "Material";
            this.olvColumnMaterial.CellVerticalAlignment = System.Drawing.StringAlignment.Near;
            this.olvColumnMaterial.Text = "Material";
            this.olvColumnMaterial.Width = 200;
            // 
            // olvColumnMaterialDesc
            // 
            this.olvColumnMaterialDesc.AspectName = "MaterialDesc";
            this.olvColumnMaterialDesc.Text = "Material Desc";
            this.olvColumnMaterialDesc.Width = 120;
            // 
            // olvColumnLocation
            // 
            this.olvColumnLocation.AspectName = "Location";
            this.olvColumnLocation.Text = "Location";
            this.olvColumnLocation.Width = 150;
            // 
            // olvColumnBundleQty
            // 
            this.olvColumnBundleQty.AspectName = "BundleQty";
            this.olvColumnBundleQty.Text = "Bundle Qty";
            this.olvColumnBundleQty.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious,
            this.btnView,
            this.btnExport});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(885, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnView
            // 
            this.btnView.Enabled = false;
            this.btnView.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnView.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnView.Image = ((System.Drawing.Image)(resources.GetObject("btnView.Image")));
            this.btnView.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(94, 30);
            this.btnView.Text = "Item View";
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnExport
            // 
            this.btnExport.Enabled = false;
            this.btnExport.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnExport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(76, 30);
            this.btnExport.Text = "Export";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // olvColumnLocationType
            // 
            this.olvColumnLocationType.AspectName = "LocationType";
            this.olvColumnLocationType.Text = "Location Type";
            this.olvColumnLocationType.Width = 120;
            // 
            // MaterialStockListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtLocationCode);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtMaterialCode);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.dtpImportedTo);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dtpImportedFrom);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "MaterialStockListView";
            this.Size = new System.Drawing.Size(909, 515);
            this.Resize += new System.EventHandler(this.MaterialStockListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            this.Controls.SetChildIndex(this.metroLabel3, 0);
            this.Controls.SetChildIndex(this.dtpImportedFrom, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.dtpImportedTo, 0);
            this.Controls.SetChildIndex(this.metroLabel4, 0);
            this.Controls.SetChildIndex(this.txtMaterialCode, 0);
            this.Controls.SetChildIndex(this.metroLabel5, 0);
            this.Controls.SetChildIndex(this.txtLocationCode, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterialStocks)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox txtLocationCode;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox txtMaterialCode;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroDateTime dtpImportedTo;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroDateTime dtpImportedFrom;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.ButtonSearch btnSearch;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvMaterialStocks;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterial;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialDesc;
        private BrightIdeasSoftware.OLVColumn olvColumnLocation;
        private BrightIdeasSoftware.OLVColumn olvColumnBundleQty;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.ToolStripButton btnView;
        private System.Windows.Forms.ToolStripButton btnExport;
        private BrightIdeasSoftware.OLVColumn olvColumnLocationType;
    }
}
