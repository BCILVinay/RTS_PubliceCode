﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialBundleReadOnlyView : FormBase, IMaterialBundleReadOnlyView
    {
        #region Public Constructors

        public MaterialBundleReadOnlyView()
        {
            InitializeComponent();
            olvColumnCreatedOn.AspectGetter = (o) =>
            {
                var bundle = o as Bundle;
                return bundle.CreatedOn.ToString(App.DateFormat);
            };
        }

        public MaterialBundleReadOnlyView(MaterialStock materialStock) : this()
        {
            if (Model == null) Model = new MaterialBundleReadOnlyModel();
            if (Model.SearchCriteria == null) Model.SearchCriteria = new MaterialBundleSearchCriteria();
            Model.SearchCriteria.LocationCode = materialStock.Location.Value;
            Model.SearchCriteria.MaterialCode = materialStock.Material.Value;
            Model.Bundles = Bundles.GetMaterialBundles(Model.SearchCriteria);
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            if (Model.Bundles.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.Bundles.Count - 1, Model.Bundles.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.Bundles.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.Bundles.Count);
            }

            olvBundles.SetObjects(Model.Bundles);
        }

        #endregion Public Constructors

        #region Public Properties

        public MaterialBundleReadOnlyModel Model { get; set; }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialBundleReadOnlyView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvBundles.Width - 20;
                olvColumnCode.Width = withToDistribute.GetPercentValue(15);
                olvColumnCreatedOn.Width = withToDistribute.GetPercentValue(15);
                olvColumnMaterial.Width = withToDistribute.GetPercentValue(15);
                olvColumnMaterialDesc.Width = withToDistribute.GetPercentValue(25);
                olvColumnToolling.Width = withToDistribute.GetPercentValue(15);
                olvColumnLocation.Width = withToDistribute.GetPercentValue(15);
              
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Public Properties
    }
}