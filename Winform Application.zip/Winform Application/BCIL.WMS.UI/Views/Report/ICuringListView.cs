﻿using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public interface ICuringListView : IBaseView<CuringListModel>
    {
        event EventHandler ExportDataRequested;

        event EventHandler SearchRequested;

        event EventHandler PrevPageResultsRequested;

        event EventHandler NextPageResultsRequested;

        void RefreshBinding();

        void RefreshGrid();
    }
}