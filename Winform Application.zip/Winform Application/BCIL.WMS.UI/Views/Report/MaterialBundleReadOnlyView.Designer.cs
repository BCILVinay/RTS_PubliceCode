﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialBundleReadOnlyView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialBundleReadOnlyView));
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvBundles = new BCIL.UIHelper.DataListView();
            this.olvColumnCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterial = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialDesc = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnToolling = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocation = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvBundles)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(797, 382);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 77;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvBundles);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(16, 60);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(866, 316);
            this.metroPanel1.TabIndex = 78;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvBundles
            // 
            this.olvBundles.AllColumns.Add(this.olvColumnCode);
            this.olvBundles.AllColumns.Add(this.olvColumnMaterial);
            this.olvBundles.AllColumns.Add(this.olvColumnMaterialDesc);
            this.olvBundles.AllColumns.Add(this.olvColumnToolling);
            this.olvBundles.AllColumns.Add(this.olvColumnLocation);
            this.olvBundles.AllColumns.Add(this.olvColumnCreatedOn);
            this.olvBundles.AllColumns.Add(this.olvColumn1);
            this.olvBundles.CellEditUseWholeCell = false;
            this.olvBundles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnCode,
            this.olvColumnMaterial,
            this.olvColumnMaterialDesc,
            this.olvColumnToolling,
            this.olvColumnLocation,
            this.olvColumnCreatedOn,
            this.olvColumn1});
            this.olvBundles.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvBundles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvBundles.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvBundles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvBundles.FullRowSelect = true;
            this.olvBundles.HeaderMinimumHeight = 30;
            this.olvBundles.HideSelection = false;
            this.olvBundles.IncludeColumnHeadersInCopy = true;
            this.olvBundles.Location = new System.Drawing.Point(0, 25);
            this.olvBundles.Name = "olvBundles";
            this.olvBundles.RowHeight = 25;
            this.olvBundles.ShowGroups = false;
            this.olvBundles.Size = new System.Drawing.Size(866, 291);
            this.olvBundles.TabIndex = 10;
            this.olvBundles.UseCompatibleStateImageBehavior = false;
            this.olvBundles.View = System.Windows.Forms.View.Details;
            this.olvBundles.VirtualMode = true;
            // 
            // olvColumnCode
            // 
            this.olvColumnCode.AspectName = "BundleCode";
            this.olvColumnCode.Text = "Code";
            this.olvColumnCode.Width = 150;
            // 
            // olvColumnMaterial
            // 
            this.olvColumnMaterial.AspectName = "Material";
            this.olvColumnMaterial.CellVerticalAlignment = System.Drawing.StringAlignment.Near;
            this.olvColumnMaterial.Text = "Material";
            this.olvColumnMaterial.Width = 200;
            // 
            // olvColumnMaterialDesc
            // 
            this.olvColumnMaterialDesc.AspectName = "MaterialDesc";
            this.olvColumnMaterialDesc.Text = "Material Desc";
            this.olvColumnMaterialDesc.Width = 120;
            // 
            // olvColumnToolling
            // 
            this.olvColumnToolling.AspectName = "Tooling";
            this.olvColumnToolling.Text = "Toolling";
            this.olvColumnToolling.Width = 111;
            // 
            // olvColumnLocation
            // 
            this.olvColumnLocation.AspectName = "Location";
            this.olvColumnLocation.Text = "Location";
            this.olvColumnLocation.Width = 150;
            // 
            // olvColumnCreatedOn
            // 
            this.olvColumnCreatedOn.AspectName = "CreatedOn";
            this.olvColumnCreatedOn.Text = "Created On";
            this.olvColumnCreatedOn.Width = 132;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(866, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(99, 22);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // MaterialBundleReadOnlyView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 447);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.btnCancel);
            this.Name = "MaterialBundleReadOnlyView";
            this.Text = "Material Bundles";
            this.Resize += new System.EventHandler(this.MaterialBundleReadOnlyView_Resize);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvBundles)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private UIHelper.ButtonCancel btnCancel;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvBundles;
        private BrightIdeasSoftware.OLVColumn olvColumnCode;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterial;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialDesc;
        private BrightIdeasSoftware.OLVColumn olvColumnToolling;
        private BrightIdeasSoftware.OLVColumn olvColumnLocation;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedOn;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
    }
}