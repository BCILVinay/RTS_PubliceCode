﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IMaterialStockListView : IBaseView<MaterialStockListModel>
    {
        event EventHandler ExportDataRequested;
        event EventHandler SearchRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;

        event EventHandler<MaterialStock> BundleViewRequested;
        void RefreshBinding();
        void RefreshGrid();
    }
}
