﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialStockListView : ControlSliderBase, IMaterialStockListView
    {
        #region Public Constructors

        public MaterialStockListView()
        {
            InitializeComponent();
        }

        public MaterialStockListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Material Stock";
        }

        #endregion Public Constructors

        #region Public Properties

        public MaterialStockListModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler<MaterialStock> BundleViewRequested;

        public event EventHandler ExportDataRequested;

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.DateFrom);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.DateTo);
            BindingUtility.CreateBinding(txtMaterialCode, c => c.Text, Model.SearchCriteria, d => d.MaterialCode);
            BindingUtility.CreateBinding(txtLocationCode, c => c.Text, Model.SearchCriteria, d => d.LocationCode);

            dtpImportedFrom.Value = Model.SearchCriteria.DateFrom;
            dtpImportedTo.Value = Model.SearchCriteria.DateTo;
        }

        public void RefreshGrid()
        {
            if (Model.MaterialStocks.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.MaterialStocks.Count - 1, Model.MaterialStocks.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.MaterialStocks.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.MaterialStocks.Count);
            }

            olvMaterialStocks.SetObjects(Model.MaterialStocks);
            btnExport.Enabled = (Model.MaterialStocks.HaveItems()) ? true : false;
        }

        #endregion Public Methods

        #region Private Events

        private void btnSearch_Click(object sender, System.EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvMaterialStocks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnView.Enabled = olvMaterialStocks.SelectedObject != null;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                BundleViewRequested?.Invoke(this, (MaterialStock)olvMaterialStocks.SelectedObject);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (ExportDataRequested != null) ExportDataRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void MaterialStockListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvMaterialStocks.Width - 20;
                olvColumnMaterial.Width = withToDistribute.GetPercentValue(20);
                olvColumnMaterialDesc.Width = withToDistribute.GetPercentValue(30);
                olvColumnLocation.Width = withToDistribute.GetPercentValue(15);
                olvColumnLocationType.Width = withToDistribute.GetPercentValue(15);
                olvColumnBundleQty.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}