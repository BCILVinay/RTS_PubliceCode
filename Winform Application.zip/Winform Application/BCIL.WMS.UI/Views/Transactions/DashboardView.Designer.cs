﻿namespace BCIL.WMS.UI.Views
{
    partial class DashboardView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.splitContainerLeft = new System.Windows.Forms.SplitContainer();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataTableListViewPicking = new BCIL.UIHelper.DataTableListView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPutaway = new System.Windows.Forms.Label();
            this.dataTableListPutaway = new BCIL.UIHelper.DataTableListView();
            this.splitContainerRight = new System.Windows.Forms.SplitContainer();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.dataTableListViewProduction = new BCIL.UIHelper.DataTableListView();
            this.cboStatus = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).BeginInit();
            this.splitContainerMain.Panel1.SuspendLayout();
            this.splitContainerMain.Panel2.SuspendLayout();
            this.splitContainerMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerLeft)).BeginInit();
            this.splitContainerLeft.Panel1.SuspendLayout();
            this.splitContainerLeft.Panel2.SuspendLayout();
            this.splitContainerLeft.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListViewPicking)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListPutaway)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerRight)).BeginInit();
            this.splitContainerRight.Panel1.SuspendLayout();
            this.splitContainerRight.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListViewProduction)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainerMain
            // 
            this.splitContainerMain.BackColor = System.Drawing.Color.Transparent;
            this.splitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerMain.Location = new System.Drawing.Point(0, 48);
            this.splitContainerMain.Name = "splitContainerMain";
            this.splitContainerMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerMain.Panel1
            // 
            this.splitContainerMain.Panel1.Controls.Add(this.splitContainerLeft);
            this.splitContainerMain.Panel1MinSize = 0;
            // 
            // splitContainerMain.Panel2
            // 
            this.splitContainerMain.Panel2.Controls.Add(this.splitContainerRight);
            this.splitContainerMain.Panel2MinSize = 0;
            this.splitContainerMain.Size = new System.Drawing.Size(1183, 501);
            this.splitContainerMain.SplitterDistance = 208;
            this.splitContainerMain.TabIndex = 48;
            // 
            // splitContainerLeft
            // 
            this.splitContainerLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerLeft.Location = new System.Drawing.Point(0, 0);
            this.splitContainerLeft.Name = "splitContainerLeft";
            // 
            // splitContainerLeft.Panel1
            // 
            this.splitContainerLeft.Panel1.Controls.Add(this.panel2);
            this.splitContainerLeft.Panel1.Controls.Add(this.dataTableListViewPicking);
            // 
            // splitContainerLeft.Panel2
            // 
            this.splitContainerLeft.Panel2.Controls.Add(this.panel1);
            this.splitContainerLeft.Panel2.Controls.Add(this.dataTableListPutaway);
            this.splitContainerLeft.Size = new System.Drawing.Size(1183, 208);
            this.splitContainerLeft.SplitterDistance = 590;
            this.splitContainerLeft.TabIndex = 43;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(590, 26);
            this.panel2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(586, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "                                  Bundles Picked: Racking Details\r\n";
            // 
            // dataTableListViewPicking
            // 
            this.dataTableListViewPicking.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataTableListViewPicking.CellEditUseWholeCell = false;
            this.dataTableListViewPicking.DataSource = null;
            this.dataTableListViewPicking.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataTableListViewPicking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.dataTableListViewPicking.FullRowSelect = true;
            this.dataTableListViewPicking.HeaderMinimumHeight = 30;
            this.dataTableListViewPicking.HideSelection = false;
            this.dataTableListViewPicking.IncludeColumnHeadersInCopy = true;
            this.dataTableListViewPicking.Location = new System.Drawing.Point(0, 35);
            this.dataTableListViewPicking.Name = "dataTableListViewPicking";
            this.dataTableListViewPicking.RowHeight = 25;
            this.dataTableListViewPicking.ShowGroups = false;
            this.dataTableListViewPicking.Size = new System.Drawing.Size(589, 173);
            this.dataTableListViewPicking.TabIndex = 2;
            this.dataTableListViewPicking.UseCompatibleStateImageBehavior = false;
            this.dataTableListViewPicking.View = System.Windows.Forms.View.Details;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblPutaway);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(589, 26);
            this.panel1.TabIndex = 1;
            // 
            // lblPutaway
            // 
            this.lblPutaway.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPutaway.Location = new System.Drawing.Point(0, 0);
            this.lblPutaway.Name = "lblPutaway";
            this.lblPutaway.Size = new System.Drawing.Size(586, 26);
            this.lblPutaway.TabIndex = 0;
            this.lblPutaway.Text = "                                  Bundles Putaway: Racking Details";
            // 
            // dataTableListPutaway
            // 
            this.dataTableListPutaway.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataTableListPutaway.CellEditUseWholeCell = false;
            this.dataTableListPutaway.DataSource = null;
            this.dataTableListPutaway.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataTableListPutaway.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.dataTableListPutaway.FullRowSelect = true;
            this.dataTableListPutaway.HeaderMinimumHeight = 30;
            this.dataTableListPutaway.HideSelection = false;
            this.dataTableListPutaway.IncludeColumnHeadersInCopy = true;
            this.dataTableListPutaway.Location = new System.Drawing.Point(0, 35);
            this.dataTableListPutaway.Name = "dataTableListPutaway";
            this.dataTableListPutaway.RowHeight = 25;
            this.dataTableListPutaway.ShowGroups = false;
            this.dataTableListPutaway.Size = new System.Drawing.Size(589, 173);
            this.dataTableListPutaway.TabIndex = 0;
            this.dataTableListPutaway.UseCompatibleStateImageBehavior = false;
            this.dataTableListPutaway.View = System.Windows.Forms.View.Details;
            // 
            // splitContainerRight
            // 
            this.splitContainerRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerRight.Location = new System.Drawing.Point(0, 0);
            this.splitContainerRight.Name = "splitContainerRight";
            this.splitContainerRight.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerRight.Panel1
            // 
            this.splitContainerRight.Panel1.Controls.Add(this.panel3);
            this.splitContainerRight.Panel1.Controls.Add(this.dataTableListViewProduction);
            this.splitContainerRight.Panel2Collapsed = true;
            this.splitContainerRight.Size = new System.Drawing.Size(1183, 289);
            this.splitContainerRight.SplitterDistance = 147;
            this.splitContainerRight.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1183, 26);
            this.panel3.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1183, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "                                                                        Items pro" +
    "duction at Line against Production Order \r\n\r\n";
            // 
            // dataTableListViewProduction
            // 
            this.dataTableListViewProduction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataTableListViewProduction.CellEditUseWholeCell = false;
            this.dataTableListViewProduction.DataSource = null;
            this.dataTableListViewProduction.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataTableListViewProduction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.dataTableListViewProduction.FullRowSelect = true;
            this.dataTableListViewProduction.HeaderMinimumHeight = 30;
            this.dataTableListViewProduction.HideSelection = false;
            this.dataTableListViewProduction.IncludeColumnHeadersInCopy = true;
            this.dataTableListViewProduction.Location = new System.Drawing.Point(0, 32);
            this.dataTableListViewProduction.Name = "dataTableListViewProduction";
            this.dataTableListViewProduction.RowHeight = 25;
            this.dataTableListViewProduction.ShowGroups = false;
            this.dataTableListViewProduction.Size = new System.Drawing.Size(1183, 257);
            this.dataTableListViewProduction.TabIndex = 4;
            this.dataTableListViewProduction.UseCompatibleStateImageBehavior = false;
            this.dataTableListViewProduction.View = System.Windows.Forms.View.Details;
            // 
            // cboStatus
            // 
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.ItemHeight = 19;
            this.cboStatus.Location = new System.Drawing.Point(932, 52);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.PromptItemIndex = -1;
            this.cboStatus.Size = new System.Drawing.Size(144, 25);
            this.cboStatus.TabIndex = 47;
            this.cboStatus.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(844, 56);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(78, 19);
            this.metroLabel2.TabIndex = 46;
            this.metroLabel2.Text = "Warehouse:";
            // 
            // timer1
            // 
            this.timer1.Interval = 30000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // DashboardView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainerMain);
            this.Controls.Add(this.cboStatus);
            this.Controls.Add(this.metroLabel2);
            this.HeaderVisible = true;
            this.Name = "DashboardView";
            this.Size = new System.Drawing.Size(1183, 549);
            this.Title = "Dashboard";
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.DashboardView_Showing);
            this.Load += new System.EventHandler(this.DashboardView_Load);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.cboStatus, 0);
            this.Controls.SetChildIndex(this.splitContainerMain, 0);
            this.splitContainerMain.Panel1.ResumeLayout(false);
            this.splitContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).EndInit();
            this.splitContainerMain.ResumeLayout(false);
            this.splitContainerLeft.Panel1.ResumeLayout(false);
            this.splitContainerLeft.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerLeft)).EndInit();
            this.splitContainerLeft.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListViewPicking)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListPutaway)).EndInit();
            this.splitContainerRight.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerRight)).EndInit();
            this.splitContainerRight.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTableListViewProduction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainerMain;
        private System.Windows.Forms.SplitContainer splitContainerLeft;
        private System.Windows.Forms.SplitContainer splitContainerRight;
        private MetroFramework.Controls.MetroComboBox cboStatus;
        private System.Windows.Forms.Timer timer1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.DataTableListView dataTableListPutaway;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblPutaway;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private UIHelper.DataTableListView dataTableListViewPicking;
        private System.Windows.Forms.Panel panel3;
        private UIHelper.DataTableListView dataTableListViewProduction;
        private System.Windows.Forms.Label label2;
    }
}
