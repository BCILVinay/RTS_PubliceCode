﻿using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IPickListDetailView:IBaseView<PickListDetailModel>
    {
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        void RefreshGrid();

        void BindingHeader();
    }
}
