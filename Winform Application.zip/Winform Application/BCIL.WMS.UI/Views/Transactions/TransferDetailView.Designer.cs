﻿namespace BCIL.WMS.UI.Views
{
    partial class TransferDetailView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TransferDetailView));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.DataListView();
            this.olvColumnMaterial = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnBundleCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnDispatchedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnRecievedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.txtDeliveryNo = new MetroFramework.Controls.MetroLabel();
            this.txtCreatedOn = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.txtStatus = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.txtSiteFrom = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtSiteTo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 147);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(861, 241);
            this.metroPanel1.TabIndex = 82;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllColumns.Add(this.olvColumnMaterial);
            this.olvItems.AllColumns.Add(this.olvColumnBundleCode);
            this.olvItems.AllColumns.Add(this.olvColumnStatus);
            this.olvItems.AllColumns.Add(this.olvColumnDispatchedOn);
            this.olvItems.AllColumns.Add(this.olvColumnRecievedOn);
            this.olvItems.AllColumns.Add(this.olvColumn1);
            this.olvItems.CellEditUseWholeCell = false;
            this.olvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnMaterial,
            this.olvColumnBundleCode,
            this.olvColumnStatus,
            this.olvColumnDispatchedOn,
            this.olvColumnRecievedOn,
            this.olvColumn1});
            this.olvItems.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvItems.FullRowSelect = true;
            this.olvItems.HeaderMinimumHeight = 30;
            this.olvItems.HideSelection = false;
            this.olvItems.IncludeColumnHeadersInCopy = true;
            this.olvItems.Location = new System.Drawing.Point(0, 25);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeight = 25;
            this.olvItems.ShowGroups = false;
            this.olvItems.Size = new System.Drawing.Size(861, 216);
            this.olvItems.TabIndex = 10;
            this.olvItems.UseCompatibleStateImageBehavior = false;
            this.olvItems.View = System.Windows.Forms.View.Details;
            this.olvItems.VirtualMode = true;
            // 
            // olvColumnMaterial
            // 
            this.olvColumnMaterial.AspectName = "Material";
            this.olvColumnMaterial.Text = "Material";
            this.olvColumnMaterial.Width = 120;
            // 
            // olvColumnBundleCode
            // 
            this.olvColumnBundleCode.AspectName = "BundleCode";
            this.olvColumnBundleCode.Text = "Bundle";
            this.olvColumnBundleCode.Width = 200;
            // 
            // olvColumnStatus
            // 
            this.olvColumnStatus.AspectName = "Status";
            this.olvColumnStatus.Text = "Status";
            this.olvColumnStatus.Width = 120;
            // 
            // olvColumnDispatchedOn
            // 
            this.olvColumnDispatchedOn.AspectName = "DispatchedOn";
            this.olvColumnDispatchedOn.Text = "Dispatched On";
            this.olvColumnDispatchedOn.Width = 120;
            // 
            // olvColumnRecievedOn
            // 
            this.olvColumnRecievedOn.AspectName = "RecievedOn";
            this.olvColumnRecievedOn.Text = "Recieved On";
            this.olvColumnRecievedOn.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(861, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(16, 22);
            this.lblRecords.Text = "  ";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            // 
            // txtDeliveryNo
            // 
            this.txtDeliveryNo.AutoSize = true;
            this.txtDeliveryNo.Location = new System.Drawing.Point(98, 68);
            this.txtDeliveryNo.Name = "txtDeliveryNo";
            this.txtDeliveryNo.Size = new System.Drawing.Size(16, 19);
            this.txtDeliveryNo.TabIndex = 81;
            this.txtDeliveryNo.Text = "0";
            // 
            // txtCreatedOn
            // 
            this.txtCreatedOn.AutoSize = true;
            this.txtCreatedOn.Location = new System.Drawing.Point(656, 66);
            this.txtCreatedOn.Name = "txtCreatedOn";
            this.txtCreatedOn.Size = new System.Drawing.Size(16, 19);
            this.txtCreatedOn.TabIndex = 80;
            this.txtCreatedOn.Text = "0";
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(580, 66);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(77, 19);
            this.metroLabel17.TabIndex = 79;
            this.metroLabel17.Text = "CreatedOn:";
            // 
            // txtStatus
            // 
            this.txtStatus.AutoSize = true;
            this.txtStatus.Location = new System.Drawing.Point(394, 68);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(16, 19);
            this.txtStatus.TabIndex = 78;
            this.txtStatus.Text = "0";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(336, 66);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(46, 19);
            this.metroLabel5.TabIndex = 77;
            this.metroLabel5.Text = "Status:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 68);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(76, 19);
            this.metroLabel1.TabIndex = 76;
            this.metroLabel1.Text = "DeliveryNo:";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(799, 394);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 83;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // txtSiteFrom
            // 
            this.txtSiteFrom.AutoSize = true;
            this.txtSiteFrom.Location = new System.Drawing.Point(98, 98);
            this.txtSiteFrom.Name = "txtSiteFrom";
            this.txtSiteFrom.Size = new System.Drawing.Size(16, 19);
            this.txtSiteFrom.TabIndex = 85;
            this.txtSiteFrom.Text = "0";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 98);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(77, 19);
            this.metroLabel3.TabIndex = 84;
            this.metroLabel3.Text = "Plant From:";
            // 
            // txtSiteTo
            // 
            this.txtSiteTo.AutoSize = true;
            this.txtSiteTo.Location = new System.Drawing.Point(394, 98);
            this.txtSiteTo.Name = "txtSiteTo";
            this.txtSiteTo.Size = new System.Drawing.Size(16, 19);
            this.txtSiteTo.TabIndex = 87;
            this.txtSiteTo.Text = "0";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(336, 98);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(60, 19);
            this.metroLabel6.TabIndex = 86;
            this.metroLabel6.Text = "Plant To:";
            // 
            // TransferDetailView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 459);
            this.Controls.Add(this.txtSiteTo);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txtSiteFrom);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtDeliveryNo);
            this.Controls.Add(this.txtCreatedOn);
            this.Controls.Add(this.metroLabel17);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btnCancel);
            this.Name = "TransferDetailView";
            this.Text = "Dispatch-Receiving";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvItems;
        private BrightIdeasSoftware.OLVColumn olvColumnStatus;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private MetroFramework.Controls.MetroLabel txtDeliveryNo;
        private MetroFramework.Controls.MetroLabel txtCreatedOn;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel txtStatus;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.ButtonCancel btnCancel;
        private MetroFramework.Controls.MetroLabel txtSiteFrom;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel txtSiteTo;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterial;
        private BrightIdeasSoftware.OLVColumn olvColumnRecievedOn;
        private BrightIdeasSoftware.OLVColumn olvColumnDispatchedOn;
        private BrightIdeasSoftware.OLVColumn olvColumnBundleCode;
    }
}