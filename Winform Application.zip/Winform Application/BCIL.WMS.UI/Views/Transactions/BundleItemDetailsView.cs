﻿using BCIL.UIHelper;
using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public partial class BundleItemDetailsView : FormBase, IBundleItemDetailsView
    {
        public BundleItemDetailsView()
        {
            InitializeComponent();
        }

        public event EventHandler<Item> RePrintRequested;

        public BundleItemDetailsView(Bundle bundle) : this()
        {
            if (Model == null) Model = new Models.BundleItemDetailsModel();
            Model.Bundle = bundle;
            Model.Items = Items.GetItemsByBundleId(new ItemSearchCriteriaByBundleId() { BundleId = bundle.BundleId });

            txtCreatedOn.Text = bundle.CreatedOn.ToString(App.DateFormat);
            RefreshGrid();
            BindingHeader();
        }

        public void RefreshGrid()
        {
            olvItems.SetObjects(Model.Items);
            lblRecords.Text = String.Format("Total records: {0}", Model.Items.Count);
        }

        public void BindingHeader()
        {
            BindingUtility.CreateBinding(txtBundleCode, c => c.Text, Model.Bundle, d => d.BundleCode);
            BindingUtility.CreateBinding(txtStatus, c => c.Text, Model.Bundle, d => d.Status);
        }

        public BundleItemDetailsModel Model { get; set; }

        private void BundleItemListView_Load(object sender, EventArgs e)
        {
            try {

            }
            catch (Exception ex) {
                ShowException(ex);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (App.WorkStation.WMaterialBination.IsNull()) throw new BCILException("First configure workstation settings");
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                RePrintRequested?.Invoke(this, (Item)olvItems.SelectedObject);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnPrint.Enabled = olvItems.SelectedObject != null;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}