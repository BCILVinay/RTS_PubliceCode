﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IInvoiceListView : IBaseView<InvoiceListModel>
    {
        event EventHandler SearchRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        event EventHandler<Invoice> PrintRequested;
        void RefreshBinding();
        void RefreshGrid();
    }
}
