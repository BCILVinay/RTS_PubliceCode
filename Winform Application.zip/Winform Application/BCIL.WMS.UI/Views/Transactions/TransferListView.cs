﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class TransferListView : ControlSliderBase, ITransferListView
    {
        #region Public Constructors

        public TransferListView()
        {
            InitializeComponent();
        }

        public TransferListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Dispatch";
            olvColumnCreatedOn.AspectGetter = (o) =>
            {
                var transfer = o as Transfer;
                return transfer.CreatedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Properties

        public TransferListModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        public event EventHandler<Transfer> TransferViewRequested;

        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.DateFrom);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.DateTo);

            dtpImportedFrom.Value = Model.SearchCriteria.DateFrom;
            dtpImportedTo.Value = Model.SearchCriteria.DateTo;
        }

        public void RefreshGrid()
        {
            if (Model.Transfers.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.Transfers.Count - 1, Model.Transfers.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.Transfers.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.Transfers.Count);
            }

            olvTransfers.SetObjects(Model.Transfers);
        }

        #endregion Public Methods

        #region Private Events

        private void TransferListView_Load(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void TransferListView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

        private void TransferListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvTransfers.Width - 20;
                olvColumnDeliveryNo.Width = withToDistribute.GetPercentValue(25);
                olvColumnCreatedOn.Width = withToDistribute.GetPercentValue(15);
                olvColumnSiteFrom.Width = withToDistribute.GetPercentValue(20);
                olvColumnStatus.Width = withToDistribute.GetPercentValue(20);
                olvColumnSiteTo.Width = withToDistribute.GetPercentValue(20);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvTransfers_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnEdit1.Enabled = (olvTransfers.SelectedObjects.Count > 0) ? true : false;
                btnView.Enabled = (olvTransfers.SelectedObjects.Count > 0) ? true : false;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                TransferViewRequested?.Invoke(this, (Transfer)olvTransfers.SelectedObject);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}