﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public partial class PickListDetailView : FormBase, IPickListDetailView
    {
        public PickListDetailView()
        {
            InitializeComponent();
        }

        public PickListDetailView(Picklist _pickList) : this()
        {
            if (Model.Picklist == null) { Model.Picklist = Picklist.NewPicklist(); }
            Model.Picklist = _pickList;
            txtCreatedOn.Text = Model.Picklist.CreatedOn.ToString(App.DateFormat);

            if (Model.Pickings == null) { Model.Pickings = new Pickings(); }

            Model.Pickings = Pickings.GetPickings(new Pickings.PickingSearchCriteria() { PicklistId = _pickList.PickListId, PageNumber = 1, PageSize = 9999 });
        }

        public PickListDetailModel Model { get; set; }

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        #region Public Method

        public void RefreshGrid()
        {
            btnPrevious.Visible = false;
            btnNext.Visible = false;
            olvPickList.SetObjects(Model.Picklist.Items);
            lblRecords.Text = String.Format("Total records: {0}", Model.Picklist.Items.Count);

            //Picked List
            olvPickedList.SetObjects(Model.Pickings);
            lblPickedRecord.Text = String.Format("Total records: {0}", Model.Pickings.Count);
        }

        public void BindingHeader()
        {
            BindingUtility.CreateBinding(txtDeliveryNo, c => c.Text, Model.Picklist, d => d.DeliveryNo);
            BindingUtility.CreateBinding(txtTruckNo, c => c.Text, Model.Picklist, d => d.TruckNo);
            BindingUtility.CreateBinding(txtTransporter, c => c.Text, Model.Picklist, d => d.Transporter);
            BindingUtility.CreateBinding(txtLRNo, c => c.Text, Model.Picklist, d => d.LRNo);
            BindingUtility.CreateBinding(txtStatus, c => c.Text, Model.Picklist, d => d.Status);
        }

        #endregion Public Method

        #region Private Event Method

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (PrevPageResultsRequested != null) PrevPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (NextPageResultsRequested != null) NextPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void PickListDetailView_Resize(object sender, EventArgs e)
        {
            try
            {
                //PickList
                int withToDistribute = olvPickList.Width - 20;
                olvColumnSTONo.Width = withToDistribute.GetPercentValue(15);
                olvColumnSTOLineNo.Width = withToDistribute.GetPercentValue(15);
                olvColumnMaterialId.Width = withToDistribute.GetPercentValue(30);
                olvColumnLocation.Width = withToDistribute.GetPercentValue(10);
                olvColumnLength.Width = withToDistribute.GetPercentValue(10);
                olvColumnItemStatus.Width = withToDistribute.GetPercentValue(10);
                olvColumnBundelQty.Width = withToDistribute.GetPercentValue(10);

                //Picked :List
                int widthToDistribute = olvPickedList.Width - 20;
               
                olvPickedColumnBundleCode.Width = widthToDistribute.GetPercentValue(30);
                olvPickedColumnMaterial.Width = widthToDistribute.GetPercentValue(30);
                olvColumnPickedMaterialDesc.Width = widthToDistribute.GetPercentValue(30);

            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Event Method
    }
}