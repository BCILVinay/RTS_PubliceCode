﻿namespace BCIL.WMS.UI.Views
{
    partial class ProductionPlanningView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductionPlanningView));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.GridView();
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnRemove = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            this.txtPoNo = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.requiredPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(15, 111);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(994, 351);
            this.metroPanel1.TabIndex = 49;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllowUserToAddRows = false;
            this.olvItems.AllowUserToDeleteRows = false;
            this.olvItems.BackgroundColor = System.Drawing.Color.White;
            this.olvItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.olvItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.olvItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(246)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.olvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.olvItems.ColumnHeadersHeight = 30;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.olvItems.DefaultCellStyle = dataGridViewCellStyle4;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.EnableHeadersVisualStyles = false;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.Location = new System.Drawing.Point(0, 33);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeadersVisible = false;
            this.olvItems.RowTemplate.Height = 25;
            this.olvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.olvItems.Size = new System.Drawing.Size(994, 318);
            this.olvItems.TabIndex = 12;
            this.olvItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.olvItems_CellClick);
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.btnRemove,
            this.lblRecords});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(994, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.IsActionRestrictedByPermission = false;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(83, 30);
            this.btnAdd.Text = "Add PO";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnRemove.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnRemove.Image = ((System.Drawing.Image)(resources.GetObject("btnRemove.Image")));
            this.btnRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(85, 30);
            this.btnRemove.Text = "Remove";
            this.btnRemove.Visible = false;
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(99, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(924, 468);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 52;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(832, 468);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 51;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtPoNo);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(132, 69);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(242, 25);
            this.requiredPanel2.TabIndex = 53;
            // 
            // txtPoNo
            // 
            // 
            // 
            // 
            this.txtPoNo.CustomButton.Image = null;
            this.txtPoNo.CustomButton.Location = new System.Drawing.Point(198, 1);
            this.txtPoNo.CustomButton.Name = "";
            this.txtPoNo.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtPoNo.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPoNo.CustomButton.TabIndex = 1;
            this.txtPoNo.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPoNo.CustomButton.UseSelectable = true;
            this.txtPoNo.CustomButton.Visible = false;
            this.txtPoNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPoNo.Lines = new string[0];
            this.txtPoNo.Location = new System.Drawing.Point(0, 0);
            this.txtPoNo.MaxLength = 50;
            this.txtPoNo.Name = "txtPoNo";
            this.txtPoNo.PasswordChar = '\0';
            this.txtPoNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPoNo.SelectedText = "";
            this.txtPoNo.SelectionLength = 0;
            this.txtPoNo.SelectionStart = 0;
            this.txtPoNo.ShortcutsEnabled = true;
            this.txtPoNo.Size = new System.Drawing.Size(222, 25);
            this.txtPoNo.TabIndex = 0;
            this.txtPoNo.UseSelectable = true;
            this.txtPoNo.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPoNo.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(15, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(107, 19);
            this.metroLabel1.TabIndex = 54;
            this.metroLabel1.Text = "PO Planning No:";
            // 
            // ProductionPlanningView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 534);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.metroPanel1);
            this.Name = "ProductionPlanningView";
            this.Text = "Production Planning";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProductionPlanningView_FormClosing);
            this.Load += new System.EventHandler(this.ProductionPlanningView_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.requiredPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripButton btnRemove;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private UIHelper.ButtonCancel btnCancel;
        private UIHelper.ButtonSave btnSave;
        private UIHelper.GridView olvItems;
        private UIHelper.RequiredPanel requiredPanel2;
        private MetroFramework.Controls.MetroTextBox txtPoNo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}