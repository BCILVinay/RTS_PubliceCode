﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using BrightIdeasSoftware;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class DashboardView : ControlSliderBase, IDashboardView
    {
        public event EventHandler RefreshDashboardRequested;

        #region Public Constructors
        public DashboardView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Dashboard";
            timer1.Interval = 30000;
        }

        #endregion Public Constructors

        #region Public Properties

        public DashboardModel Model { get; set; }

        

        #endregion Public Properties

        #region Public Events


        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
          
        }

        public void RefreshGrid()
        {
            if (Model.BundlePutawayData != null && Model.BundlePutawayData.Rows.Count > 0)
            {
                dataTableListPutaway.DataSource = Model.BundlePutawayData;
                foreach (OLVColumn column in dataTableListPutaway.Columns)
                {
                    column.Width = 220;
                }
               ((OLVColumn)dataTableListPutaway.Columns[dataTableListPutaway.Columns.Count - 1]).FillsFreeSpace = true;
                dataTableListPutaway.Refresh();
            }
            if (Model.BundlePickedData != null && Model.BundlePickedData.Rows.Count > 0)
            {
                dataTableListViewPicking.DataSource = Model.BundlePickedData;
                foreach (OLVColumn column in dataTableListViewPicking.Columns)
                {
                    column.Width = 220;
                }
              ((OLVColumn)dataTableListViewPicking.Columns[dataTableListViewPicking.Columns.Count - 1]).FillsFreeSpace = true;
                dataTableListViewPicking.Refresh();
            }

            if (Model.ProductionData != null && Model.ProductionData.Rows.Count > 0)
            {
                dataTableListViewProduction.DataSource = Model.ProductionData;
                foreach (OLVColumn column in dataTableListViewProduction.Columns)
                {
                    column.Width = 145;
                }
              ((OLVColumn)dataTableListViewProduction.Columns[dataTableListViewProduction.Columns.Count - 1]).FillsFreeSpace = true;
                dataTableListViewProduction.Refresh();
            }
        }

        #endregion Public Methods

        #region Private Events

        private void DashboardView_Load(object sender, EventArgs e)
        {
            try
            {
                timer1.Start();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
          
        }

        private void DashboardView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                RefreshDashboardRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }


        #endregion Private Events


    }
}