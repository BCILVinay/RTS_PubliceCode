﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class SapLogListView : ControlSliderBase, ISapLogListView
    {
        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        public event EventHandler<SapPostingLog> ShowSapPostingLogRequested;

        #region Constructor

        public SapLogListView()
        {
            InitializeComponent();
        }

        public SapLogListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "SAP Posting Log";
            olvColumnCreatedOn.AspectGetter = (o) =>
            {
                var log = o as SapPostingLog;
                return log.CreatedOn.ToString(App.DateFormat);
            };
            olvColumnTime.AspectGetter = (o) =>
            {
                var log = o as SapPostingLog;
               
                return string.Format("{0:hh:mm:ss tt}", log.CreatedOn);
            };

            olvColumnStatus.AspectGetter = (o) =>
            {
                var log = o as SapPostingLog;
                return log.IsSuccess ? "Success" : "Failed";
            };
        }

        #endregion Constructor

        #region Properties

        public SapLogListModel Model { get; set; }

        #endregion Properties

        #region Functions

        public void RefreshBinding()
        {
            cboProcess.DataSource = Model.SapProcesses;
            cboProcess.DisplayMember = "Value";
            cboProcess.ValueMember = "Key";

            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.FromDate);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.ToDate);
            BindingUtility.CreateBinding(cboProcess, c => c.SelectedValue, Model.SearchCriteria, d => d.Process);

            dtpImportedFrom.Value = Model.SearchCriteria.FromDate;
            dtpImportedTo.Value = Model.SearchCriteria.ToDate;
        }

        public void RefreshGrid()
        {
            if (Model.SapPostingLogs.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.SapPostingLogs.Count - 1, Model.SapPostingLogs.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.SapPostingLogs.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.SapPostingLogs.Count);
            }

            olvSapPostingLogs.SetObjects(Model.SapPostingLogs);
        }

        #endregion Functions

        #region Events

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                ShowSapPostingLogRequested?.Invoke(this, (SapPostingLog)olvSapPostingLogs.SelectedObject);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        public void ShowSapLogView(SapPostingLog log)
        {
            try
            {
                SapLogView view = new SapLogView(log);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvSapPostingLogs_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                btnView.Enabled = (olvSapPostingLogs.SelectedObjects.Count > 0) ? true : false;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void SapLogListView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Events
    }
}