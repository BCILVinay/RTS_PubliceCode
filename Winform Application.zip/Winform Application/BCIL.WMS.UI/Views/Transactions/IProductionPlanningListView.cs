﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public interface IProductionPlanningListView : IBaseView<ProductionPlanningListModel>
    {
        event EventHandler SearchRequested;

        event EventHandler PrevPageResultsRequested;

        event EventHandler NextPageResultsRequested;

        event EventHandler AddNewRequested;

        event EventHandler<ProductionPlanning> EditRequested;

        event EventHandler ImportDataRequested;
        void RefreshBinding();

        void RefreshGrid();
    }
}