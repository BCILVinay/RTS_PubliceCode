﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using MetroFramework;
using MetroFramework.Controls;
using System;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ProductionPlanningView : FormBase, IProductionPlanningView
    {
        #region Constructor

        public ProductionPlanningView()
        {
            InitializeComponent();
            txtPoNo.ReadOnly = true;
        }

        public ProductionPlanningView(ProductionPlanning productionPlanning) : this()
        {
            this.Text = "Edit Production Planning";
            txtPoNo.Text = productionPlanning.PlanningNo;
            Model.ProductionPlanning = productionPlanning;
            txtPoNo.ReadOnly = true;
        }

        #endregion Constructor

        #region Public Properties

        public ProductionPlanningModel Model { get; set; }
        public Permission AddEditPermision { get; set; }

        #endregion Public Properties

        #region Private Event

        public event EventHandler SaveRequested;

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SelectProductionOrderReq;

        #endregion Private Event

        #region Public Methods

        public void RefreshBinding()
        {
            olvItems.DataSource = null;
            foreach (var item in Model.ProductionPlanning.LineItems)
            {
                item.Output = item.AvailableHours * Model.Lines.FirstOrDefault(x => x.LineId == item.LinePrefence).Speed;
                var tool = Tooling.GetTooling(item.Tooling);
                item.ReqShiftHours = Convert.ToDecimal(string.Format("{0:0.00}", item.Quantity / tool.ToolingSpeed));
            }

            olvItems.DataSource = Model.ProductionPlanning.LineItems;
            //Hide column
            olvItems.Columns["ProductionPlanningItemId"].Visible = false;
            olvItems.Columns["EditLevel"].Visible = false;
            olvItems.Columns["Tooling"].Visible = false;
            olvItems.Columns["MaterialBinId"].Visible = false;
            olvItems.Columns["LinePrefence"].Visible = false;
            //Read only column
            olvItems.Columns["Output"].ReadOnly = true;
            olvItems.Columns["ReqShiftHours"].ReadOnly = true;
            olvItems.Columns["Material"].ReadOnly = true;
            olvItems.Columns["Po"].ReadOnly = true;
            olvItems.Columns["PacksNo"].ReadOnly = true;

            olvItems.SelectionMode = DataGridViewSelectionMode.CellSelect;

            if (olvItems.Columns.Contains("Tooling"))
            {
                DataGridViewComboBoxColumn cboTooling = new DataGridViewComboBoxColumn();
                cboTooling.DataSource = Model.Toolings;
                cboTooling.HeaderText = "Tooling";
                cboTooling.DisplayMember = "Value";
                cboTooling.ValueMember = "Key";
                cboTooling.DataPropertyName = "Tooling";
                cboTooling.Width = 150;
                olvItems.Columns.Add(cboTooling);
            }

            if (olvItems.Columns.Contains("MaterialBinId"))
            {
                DataGridViewComboBoxColumn cboMaterialBin = new DataGridViewComboBoxColumn();
                cboMaterialBin.DataSource = Model.MaterialBins;
                cboMaterialBin.HeaderText = "Material Bin";
                cboMaterialBin.DisplayMember = "Value";
                cboMaterialBin.ValueMember = "Key";
                cboMaterialBin.DataPropertyName = "MaterialBinId";
                cboMaterialBin.Width = 150;
                olvItems.Columns.Add(cboMaterialBin);
            }

            if (olvItems.Columns.Contains("LinePrefence"))
            {
                DataGridViewComboBoxColumn cboLinePrefence = new DataGridViewComboBoxColumn();
                cboLinePrefence.DataSource = Model.LinePrefences;
                cboLinePrefence.HeaderText = "Line Prefence";
                cboLinePrefence.DisplayMember = "Value";
                cboLinePrefence.ValueMember = "Key";
                cboLinePrefence.DataPropertyName = "LinePrefence";
                cboLinePrefence.Width = 150;
                olvItems.Columns.Add(cboLinePrefence);
            }
            lblRecords.Text = string.Format("Total Records: {0}", Model.ProductionPlanning.LineItems.Count);
            olvItems.AutoResizeColumns();
        }

        #endregion Public Methods

        #region Private Methods

        private MetroDateTime dateTimePicker;

        private void olvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex != -1)
                {
                    if (e.ColumnIndex == 11)
                    {
                        dateTimePicker = new MetroDateTime();
                        olvItems.Controls.Add(dateTimePicker);
                        dateTimePicker.Format = DateTimePickerFormat.Short;
                        Rectangle oRectangle = olvItems.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
                        dateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
                        dateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
                        dateTimePicker.TextChanged += new EventHandler(DateTimePickerChange);
                        dateTimePicker.CloseUp += new EventHandler(DateTimePickerClose);
                    }
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void DateTimePickerChange(object sender, EventArgs e)
        {
            olvItems.CurrentCell.Value = dateTimePicker.Value.ToString("dd-MM-yyyy");
        }

        private void DateTimePickerClose(object sender, EventArgs e)
        {
            dateTimePicker.Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SelectProductionOrderReq?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionPlanningView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    if (CancelRequested != null) CancelRequested(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionPlanningView_Load(object sender, EventArgs e)
        {
            try
            {
                BindingUtility.CreateBinding(txtPoNo, c => c.Text, Model.ProductionPlanning, d => d.PlanningNo);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}