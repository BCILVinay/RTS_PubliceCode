﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IBundleItemDetailsView : IBaseView<BundleItemDetailsModel>
    {
        event EventHandler<Item> RePrintRequested;

    }
}
