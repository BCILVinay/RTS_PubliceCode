﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;

namespace BCIL.WMS.UI.Views
{
    public partial class ReceivingView : FormBase, IReceivingView
    {
        #region Public Constructors

        public ReceivingView()
        {
            InitializeComponent();
        }

        public ReceivingView(Receiving receiving)
        {
            InitializeComponent();
            if (Model == null) Model = new ReceivingModel();
            Model.Receiving = receiving;
        }

        #endregion Public Constructors

        #region Public Properties

        public ReceivingModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler ExportDataRequested;

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
            txtDeliveryNo.Text = Model.Receiving.DeliveryNo;
            txtCreatedOn.Text = Model.Receiving.ReceivedOn.ToString(App.DateFormat);
            txtInvoiceNo.Text = Model.Receiving.InvoiceNo;
        }

        public void RefreshGrid()
        {
            lblRecords.Text = String.Format("Total records: {0}", Model.Receiving.Items.Count);

            olvItems.SetObjects(Model.Receiving.Items);
        }

        #endregion Public Methods

        private void ReceivingView_Load(object sender, EventArgs e)
        {
            try
            {
                RefreshBinding();
                RefreshGrid();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}