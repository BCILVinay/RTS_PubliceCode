﻿namespace BCIL.WMS.UI.Views
{
    partial class ItemListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemListView));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.DataListView();
            this.olvColumnItemCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnBundle = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPO = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterial = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnToolling = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocation = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd1 = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnEdit1 = new System.Windows.Forms.ToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnExport = new System.Windows.Forms.ToolStripButton();
            this.txtBundleCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedTo = new MetroFramework.Controls.MetroDateTime();
            this.dtpImportedFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.buttonSearch1 = new BCIL.UIHelper.ButtonSearch();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.olvColumnMaterialDesc = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 179);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(913, 343);
            this.metroPanel1.TabIndex = 36;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllColumns.Add(this.olvColumnItemCode);
            this.olvItems.AllColumns.Add(this.olvColumnBundle);
            this.olvItems.AllColumns.Add(this.olvColumnPO);
            this.olvItems.AllColumns.Add(this.olvColumnMaterial);
            this.olvItems.AllColumns.Add(this.olvColumnMaterialDesc);
            this.olvItems.AllColumns.Add(this.olvColumnToolling);
            this.olvItems.AllColumns.Add(this.olvColumnLocation);
            this.olvItems.AllColumns.Add(this.olvColumnStatus);
            this.olvItems.AllColumns.Add(this.olvColumnCreatedOn);
            this.olvItems.AllColumns.Add(this.olvColumn1);
            this.olvItems.CellEditUseWholeCell = false;
            this.olvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnItemCode,
            this.olvColumnBundle,
            this.olvColumnPO,
            this.olvColumnMaterial,
            this.olvColumnMaterialDesc,
            this.olvColumnToolling,
            this.olvColumnLocation,
            this.olvColumnStatus,
            this.olvColumnCreatedOn,
            this.olvColumn1});
            this.olvItems.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvItems.FullRowSelect = true;
            this.olvItems.HeaderMinimumHeight = 30;
            this.olvItems.HideSelection = false;
            this.olvItems.IncludeColumnHeadersInCopy = true;
            this.olvItems.Location = new System.Drawing.Point(0, 33);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeight = 25;
            this.olvItems.ShowGroups = false;
            this.olvItems.Size = new System.Drawing.Size(913, 310);
            this.olvItems.TabIndex = 10;
            this.olvItems.UseCompatibleStateImageBehavior = false;
            this.olvItems.View = System.Windows.Forms.View.Details;
            this.olvItems.VirtualMode = true;
            this.olvItems.SelectedIndexChanged += new System.EventHandler(this.olvItems_SelectedIndexChanged);
            // 
            // olvColumnItemCode
            // 
            this.olvColumnItemCode.AspectName = "ItemCode";
            this.olvColumnItemCode.Text = "Item Code";
            this.olvColumnItemCode.Width = 150;
            // 
            // olvColumnBundle
            // 
            this.olvColumnBundle.AspectName = "Bundle";
            this.olvColumnBundle.Text = "Bundle";
            // 
            // olvColumnPO
            // 
            this.olvColumnPO.AspectName = "POrder";
            this.olvColumnPO.Text = "PO";
            this.olvColumnPO.Width = 120;
            // 
            // olvColumnMaterial
            // 
            this.olvColumnMaterial.AspectName = "Material";
            this.olvColumnMaterial.CellVerticalAlignment = System.Drawing.StringAlignment.Near;
            this.olvColumnMaterial.Text = "Material";
            this.olvColumnMaterial.Width = 200;
            // 
            // olvColumnToolling
            // 
            this.olvColumnToolling.AspectName = "Tooling";
            this.olvColumnToolling.Text = "Toolling";
            this.olvColumnToolling.Width = 111;
            // 
            // olvColumnLocation
            // 
            this.olvColumnLocation.AspectName = "Location";
            this.olvColumnLocation.Text = "Location";
            this.olvColumnLocation.Width = 150;
            // 
            // olvColumnStatus
            // 
            this.olvColumnStatus.AspectName = "ItemStatus";
            this.olvColumnStatus.Text = "Status";
            this.olvColumnStatus.Width = 120;
            // 
            // olvColumnCreatedOn
            // 
            this.olvColumnCreatedOn.AspectName = "CreatedOn";
            this.olvColumnCreatedOn.Text = "Created On";
            this.olvColumnCreatedOn.Width = 132;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd1,
            this.btnEdit1,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious,
            this.btnPrint,
            this.btnExport});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(913, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd1
            // 
            this.btnAdd1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd1.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd1.Image")));
            this.btnAdd1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd1.IsActionRestrictedByPermission = false;
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(62, 30);
            this.btnAdd1.Text = "Add";
            this.btnAdd1.Visible = false;
            // 
            // btnEdit1
            // 
            this.btnEdit1.Enabled = false;
            this.btnEdit1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnEdit1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnEdit1.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit1.Image")));
            this.btnEdit1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit1.Name = "btnEdit1";
            this.btnEdit1.Size = new System.Drawing.Size(60, 30);
            this.btnEdit1.Text = "Edit";
            this.btnEdit1.Visible = false;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.IsActionRestrictedByPermission = false;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(84, 30);
            this.btnPrint.Text = "Re-Print";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnExport
            // 
            this.btnExport.Enabled = false;
            this.btnExport.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnExport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(76, 30);
            this.btnExport.Text = "Export";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // txtBundleCode
            // 
            // 
            // 
            // 
            this.txtBundleCode.CustomButton.Image = null;
            this.txtBundleCode.CustomButton.Location = new System.Drawing.Point(118, 1);
            this.txtBundleCode.CustomButton.Name = "";
            this.txtBundleCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtBundleCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBundleCode.CustomButton.TabIndex = 1;
            this.txtBundleCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBundleCode.CustomButton.UseSelectable = true;
            this.txtBundleCode.CustomButton.Visible = false;
            this.txtBundleCode.Lines = new string[0];
            this.txtBundleCode.Location = new System.Drawing.Point(416, 66);
            this.txtBundleCode.MaxLength = 50;
            this.txtBundleCode.Name = "txtBundleCode";
            this.txtBundleCode.PasswordChar = '\0';
            this.txtBundleCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBundleCode.SelectedText = "";
            this.txtBundleCode.SelectionLength = 0;
            this.txtBundleCode.SelectionStart = 0;
            this.txtBundleCode.ShortcutsEnabled = true;
            this.txtBundleCode.Size = new System.Drawing.Size(142, 25);
            this.txtBundleCode.TabIndex = 60;
            this.txtBundleCode.UseSelectable = true;
            this.txtBundleCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBundleCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(322, 72);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(88, 19);
            this.metroLabel4.TabIndex = 61;
            this.metroLabel4.Text = "Bundle Code:";
            // 
            // dtpImportedTo
            // 
            this.dtpImportedTo.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedTo.Location = new System.Drawing.Point(416, 105);
            this.dtpImportedTo.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedTo.Name = "dtpImportedTo";
            this.dtpImportedTo.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedTo.TabIndex = 59;
            // 
            // dtpImportedFrom
            // 
            this.dtpImportedFrom.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedFrom.Location = new System.Drawing.Point(124, 102);
            this.dtpImportedFrom.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedFrom.Name = "dtpImportedFrom";
            this.dtpImportedFrom.Size = new System.Drawing.Size(161, 25);
            this.dtpImportedFrom.TabIndex = 58;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(3, 105);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(118, 19);
            this.metroLabel3.TabIndex = 57;
            this.metroLabel3.Text = "Create Date From:";
            // 
            // buttonSearch1
            // 
            this.buttonSearch1.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch1.ButtonImage")));
            this.buttonSearch1.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch1.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch1.ImageSize = 50;
            this.buttonSearch1.Location = new System.Drawing.Point(661, 63);
            this.buttonSearch1.Name = "buttonSearch1";
            this.buttonSearch1.Size = new System.Drawing.Size(85, 64);
            this.buttonSearch1.TabIndex = 56;
            this.buttonSearch1.Text = "Search";
            this.buttonSearch1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch1.UseSelectable = true;
            this.buttonSearch1.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(137, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(124, 69);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(161, 25);
            this.txtCode.TabIndex = 54;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(74, 19);
            this.metroLabel1.TabIndex = 55;
            this.metroLabel1.Text = "Item Code:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(322, 105);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(27, 19);
            this.metroLabel2.TabIndex = 62;
            this.metroLabel2.Text = "To:";
            // 
            // olvColumnMaterialDesc
            // 
            this.olvColumnMaterialDesc.AspectName = "MaterialDesc";
            this.olvColumnMaterialDesc.Text = "Material Desc";
            this.olvColumnMaterialDesc.Width = 120;
            // 
            // ItemListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtBundleCode);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.dtpImportedTo);
            this.Controls.Add(this.dtpImportedFrom);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.buttonSearch1);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "ItemListView";
            this.Size = new System.Drawing.Size(940, 538);
            this.Title = "Items";
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.ItemListView_Showing);
            this.Resize += new System.EventHandler(this.ItemListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.txtCode, 0);
            this.Controls.SetChildIndex(this.buttonSearch1, 0);
            this.Controls.SetChildIndex(this.metroLabel3, 0);
            this.Controls.SetChildIndex(this.dtpImportedFrom, 0);
            this.Controls.SetChildIndex(this.dtpImportedTo, 0);
            this.Controls.SetChildIndex(this.metroLabel4, 0);
            this.Controls.SetChildIndex(this.txtBundleCode, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvItems;
        private BrightIdeasSoftware.OLVColumn olvColumnItemCode;
        private BrightIdeasSoftware.OLVColumn olvColumnPO;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterial;
        private BrightIdeasSoftware.OLVColumn olvColumnToolling;
        private BrightIdeasSoftware.OLVColumn olvColumnLocation;
        private BrightIdeasSoftware.OLVColumn olvColumnStatus;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedOn;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd1;
        private System.Windows.Forms.ToolStripButton btnEdit1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnPrint;
        private System.Windows.Forms.ToolStripButton btnExport;
        private MetroFramework.Controls.MetroTextBox txtBundleCode;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroDateTime dtpImportedTo;
        private MetroFramework.Controls.MetroDateTime dtpImportedFrom;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.ButtonSearch buttonSearch1;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private BrightIdeasSoftware.OLVColumn olvColumnBundle;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialDesc;
    }
}
