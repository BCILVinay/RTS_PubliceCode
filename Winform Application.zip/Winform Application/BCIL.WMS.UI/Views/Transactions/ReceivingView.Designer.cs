﻿namespace BCIL.WMS.UI.Views
{
    partial class ReceivingView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReceivingView));
            this.txtCreatedOn = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.txtDeliveryNo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtInvoiceNo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.DataListView();
            this.olvColumnSTONo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnSTOLineNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnDeliveryItems = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnQuantity = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnNoOfBundal = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCreatedOn
            // 
            this.txtCreatedOn.AutoSize = true;
            this.txtCreatedOn.Location = new System.Drawing.Point(708, 69);
            this.txtCreatedOn.Name = "txtCreatedOn";
            this.txtCreatedOn.Size = new System.Drawing.Size(16, 19);
            this.txtCreatedOn.TabIndex = 71;
            this.txtCreatedOn.Text = "0";
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(610, 69);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(86, 19);
            this.metroLabel17.TabIndex = 70;
            this.metroLabel17.Text = "Received On:";
            // 
            // txtDeliveryNo
            // 
            this.txtDeliveryNo.AutoSize = true;
            this.txtDeliveryNo.Location = new System.Drawing.Point(142, 69);
            this.txtDeliveryNo.Name = "txtDeliveryNo";
            this.txtDeliveryNo.Size = new System.Drawing.Size(16, 19);
            this.txtDeliveryNo.TabIndex = 69;
            this.txtDeliveryNo.Text = "0";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 69);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(111, 19);
            this.metroLabel1.TabIndex = 68;
            this.metroLabel1.Text = "Delivery Number:";
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.AutoSize = true;
            this.txtInvoiceNo.Location = new System.Drawing.Point(142, 99);
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.Size = new System.Drawing.Size(16, 19);
            this.txtInvoiceNo.TabIndex = 73;
            this.txtInvoiceNo.Text = "0";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 99);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(105, 19);
            this.metroLabel3.TabIndex = 72;
            this.metroLabel3.Text = "Invoice Number:";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(750, 366);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 77;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 136);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(812, 224);
            this.metroPanel1.TabIndex = 76;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllColumns.Add(this.olvColumnSTONo);
            this.olvItems.AllColumns.Add(this.olvColumnSTOLineNo);
            this.olvItems.AllColumns.Add(this.olvColumnDeliveryItems);
            this.olvItems.AllColumns.Add(this.olvColumnMaterialCode);
            this.olvItems.AllColumns.Add(this.olvColumnQuantity);
            this.olvItems.AllColumns.Add(this.olvColumnNoOfBundal);
            this.olvItems.AllColumns.Add(this.olvColumn1);
            this.olvItems.CellEditUseWholeCell = false;
            this.olvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnSTONo,
            this.olvColumnSTOLineNo,
            this.olvColumnDeliveryItems,
            this.olvColumnMaterialCode,
            this.olvColumnQuantity,
            this.olvColumnNoOfBundal,
            this.olvColumn1});
            this.olvItems.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvItems.FullRowSelect = true;
            this.olvItems.HeaderMinimumHeight = 30;
            this.olvItems.HideSelection = false;
            this.olvItems.IncludeColumnHeadersInCopy = true;
            this.olvItems.Location = new System.Drawing.Point(0, 25);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeight = 25;
            this.olvItems.ShowGroups = false;
            this.olvItems.Size = new System.Drawing.Size(812, 199);
            this.olvItems.TabIndex = 10;
            this.olvItems.UseCompatibleStateImageBehavior = false;
            this.olvItems.View = System.Windows.Forms.View.Details;
            this.olvItems.VirtualMode = true;
            // 
            // olvColumnSTONo
            // 
            this.olvColumnSTONo.AspectName = "STONo";
            this.olvColumnSTONo.Text = "STO No";
            this.olvColumnSTONo.Width = 120;
            // 
            // olvColumnSTOLineNo
            // 
            this.olvColumnSTOLineNo.AspectName = "STOLineNo";
            this.olvColumnSTOLineNo.Text = "STO Line No";
            this.olvColumnSTOLineNo.Width = 120;
            // 
            // olvColumnDeliveryItems
            // 
            this.olvColumnDeliveryItems.AspectName = "DeliveryItems";
            this.olvColumnDeliveryItems.Text = "Delivery Items";
            this.olvColumnDeliveryItems.Width = 120;
            // 
            // olvColumnMaterialCode
            // 
            this.olvColumnMaterialCode.AspectName = "MaterialCode";
            this.olvColumnMaterialCode.Text = "Material Code";
            this.olvColumnMaterialCode.Width = 120;
            // 
            // olvColumnQuantity
            // 
            this.olvColumnQuantity.AspectName = "Quantity";
            this.olvColumnQuantity.Text = "Quantity";
            this.olvColumnQuantity.Width = 120;
            // 
            // olvColumnNoOfBundal
            // 
            this.olvColumnNoOfBundal.AspectName = "NoOfBundal";
            this.olvColumnNoOfBundal.Text = "No Of Bundle";
            this.olvColumnNoOfBundal.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(812, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(16, 22);
            this.lblRecords.Text = "  ";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            // 
            // ReceivingView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 428);
            this.Controls.Add(this.txtInvoiceNo);
            this.Controls.Add(this.txtDeliveryNo);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txtCreatedOn);
            this.Controls.Add(this.metroLabel17);
            this.Controls.Add(this.metroLabel1);
            this.Name = "ReceivingView";
            this.Text = "Receiving";
            this.Load += new System.EventHandler(this.ReceivingView_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel txtCreatedOn;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel txtDeliveryNo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel txtInvoiceNo;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.ButtonCancel btnCancel;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvItems;
        private BrightIdeasSoftware.OLVColumn olvColumnSTONo;
        private BrightIdeasSoftware.OLVColumn olvColumnSTOLineNo;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private BrightIdeasSoftware.OLVColumn olvColumnDeliveryItems;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialCode;
        private BrightIdeasSoftware.OLVColumn olvColumnQuantity;
        private BrightIdeasSoftware.OLVColumn olvColumnNoOfBundal;
    }
}