﻿namespace BCIL.WMS.UI.Views
{
    partial class SapLogListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SapLogListView));
            this.dtpImportedTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnSearch = new BCIL.UIHelper.ButtonSearch();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvSapPostingLogs = new BCIL.UIHelper.DataListView();
            this.olvColumnProcess = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnCreatedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnTime = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnView = new System.Windows.Forms.ToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.cboProcess = new MetroFramework.Controls.MetroComboBox();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvSapPostingLogs)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpImportedTo
            // 
            this.dtpImportedTo.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedTo.Location = new System.Drawing.Point(329, 93);
            this.dtpImportedTo.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedTo.Name = "dtpImportedTo";
            this.dtpImportedTo.Size = new System.Drawing.Size(136, 25);
            this.dtpImportedTo.TabIndex = 59;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(291, 96);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(25, 19);
            this.metroLabel2.TabIndex = 58;
            this.metroLabel2.Text = "To:";
            // 
            // dtpImportedFrom
            // 
            this.dtpImportedFrom.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedFrom.Location = new System.Drawing.Point(140, 93);
            this.dtpImportedFrom.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedFrom.Name = "dtpImportedFrom";
            this.dtpImportedFrom.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedFrom.TabIndex = 57;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(12, 96);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(118, 19);
            this.metroLabel3.TabIndex = 56;
            this.metroLabel3.Text = "Create Date From:";
            // 
            // btnSearch
            // 
            this.btnSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.ButtonImage")));
            this.btnSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSearch.ImageSize = 50;
            this.btnSearch.Location = new System.Drawing.Point(519, 54);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(85, 64);
            this.btnSearch.TabIndex = 55;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(12, 58);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(56, 19);
            this.metroLabel1.TabIndex = 54;
            this.metroLabel1.Text = "Process:";
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvSapPostingLogs);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(8, 144);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(810, 267);
            this.metroPanel1.TabIndex = 53;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvSapPostingLogs
            // 
            this.olvSapPostingLogs.AllColumns.Add(this.olvColumnProcess);
            this.olvSapPostingLogs.AllColumns.Add(this.olvColumnStatus);
            this.olvSapPostingLogs.AllColumns.Add(this.olvColumnCreatedOn);
            this.olvSapPostingLogs.AllColumns.Add(this.olvColumnTime);
            this.olvSapPostingLogs.AllColumns.Add(this.olvColumn1);
            this.olvSapPostingLogs.CellEditUseWholeCell = false;
            this.olvSapPostingLogs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnProcess,
            this.olvColumnStatus,
            this.olvColumnCreatedOn,
            this.olvColumnTime,
            this.olvColumn1});
            this.olvSapPostingLogs.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvSapPostingLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvSapPostingLogs.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvSapPostingLogs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvSapPostingLogs.FullRowSelect = true;
            this.olvSapPostingLogs.HeaderMinimumHeight = 30;
            this.olvSapPostingLogs.HideSelection = false;
            this.olvSapPostingLogs.IncludeColumnHeadersInCopy = true;
            this.olvSapPostingLogs.Location = new System.Drawing.Point(0, 33);
            this.olvSapPostingLogs.Name = "olvSapPostingLogs";
            this.olvSapPostingLogs.RowHeight = 25;
            this.olvSapPostingLogs.ShowGroups = false;
            this.olvSapPostingLogs.Size = new System.Drawing.Size(810, 234);
            this.olvSapPostingLogs.TabIndex = 10;
            this.olvSapPostingLogs.UseCompatibleStateImageBehavior = false;
            this.olvSapPostingLogs.View = System.Windows.Forms.View.Details;
            this.olvSapPostingLogs.VirtualMode = true;
            this.olvSapPostingLogs.SelectedIndexChanged += new System.EventHandler(this.olvSapPostingLogs_SelectedIndexChanged);
            this.olvSapPostingLogs.DoubleClick += new System.EventHandler(this.btnView_Click);
            // 
            // olvColumnProcess
            // 
            this.olvColumnProcess.AspectName = "Process";
            this.olvColumnProcess.Text = "Process";
            this.olvColumnProcess.Width = 312;
            // 
            // olvColumnStatus
            // 
            this.olvColumnStatus.AspectName = "IsSuccess";
            this.olvColumnStatus.Text = "Status";
            this.olvColumnStatus.Width = 203;
            // 
            // olvColumnCreatedOn
            // 
            this.olvColumnCreatedOn.AspectName = "CreatedOn";
            this.olvColumnCreatedOn.Text = "Created On";
            this.olvColumnCreatedOn.Width = 132;
            // 
            // olvColumnTime
            // 
            this.olvColumnTime.AspectName = "CreatedOn";
            this.olvColumnTime.Text = "Time";
            this.olvColumnTime.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnView,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(810, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnView
            // 
            this.btnView.Enabled = false;
            this.btnView.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnView.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnView.Image = ((System.Drawing.Image)(resources.GetObject("btnView.Image")));
            this.btnView.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(65, 30);
            this.btnView.Text = "View";
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(99, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // cboProcess
            // 
            this.cboProcess.ItemHeight = 19;
            this.cboProcess.Location = new System.Drawing.Point(140, 57);
            this.cboProcess.Name = "cboProcess";
            this.cboProcess.PromptItemIndex = -1;
            this.cboProcess.Size = new System.Drawing.Size(142, 25);
            this.cboProcess.TabIndex = 61;
            this.cboProcess.UseSelectable = true;
            // 
            // SapLogListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cboProcess);
            this.Controls.Add(this.dtpImportedTo);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dtpImportedFrom);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "SapLogListView";
            this.Size = new System.Drawing.Size(823, 414);
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.SapLogListView_Showing);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            this.Controls.SetChildIndex(this.metroLabel3, 0);
            this.Controls.SetChildIndex(this.dtpImportedFrom, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.dtpImportedTo, 0);
            this.Controls.SetChildIndex(this.cboProcess, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvSapPostingLogs)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroDateTime dtpImportedTo;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroDateTime dtpImportedFrom;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.ButtonSearch btnSearch;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvSapPostingLogs;
        private BrightIdeasSoftware.OLVColumn olvColumnProcess;
        private BrightIdeasSoftware.OLVColumn olvColumnStatus;
        private BrightIdeasSoftware.OLVColumn olvColumnCreatedOn;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnView;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private MetroFramework.Controls.MetroComboBox cboProcess;
        private BrightIdeasSoftware.OLVColumn olvColumnTime;
    }
}
