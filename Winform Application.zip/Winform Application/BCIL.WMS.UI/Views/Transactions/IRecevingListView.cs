﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IRecevingListView:IBaseView<RecevingListModel>
    {
        event EventHandler ExportDataRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        event EventHandler SearchRequested;
        event EventHandler<Receiving> ReceivingViewRequested;
        void RefreshBinding();
        void RefreshGrid();
    }
}
