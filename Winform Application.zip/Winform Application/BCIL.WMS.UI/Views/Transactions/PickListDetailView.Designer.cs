﻿namespace BCIL.WMS.UI.Views
{
    partial class PickListDetailView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PickListDetailView));
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtDeliveryNo = new MetroFramework.Controls.MetroLabel();
            this.txtTruckNo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtStatus = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtTransporter = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.txtLRNo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.txtCreatedOn = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.miniToolStrip = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.olvPickList = new BCIL.UIHelper.DataListView();
            this.olvColumnSTONo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnSTOLineNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialId = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLength = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocation = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnBundelQty = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnItemStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.tabCtrlPickListItem = new MetroFramework.Controls.MetroTabControl();
            this.tabPickListItem = new System.Windows.Forms.TabPage();
            this.tabPickedItem = new System.Windows.Forms.TabPage();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.olvPickedList = new BCIL.UIHelper.DataListView();
            this.olvPickedColumnBundleCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvPickedColumnMaterial = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPickedMaterialDesc = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn9 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip2 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.lblPickedRecord = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.olvPickList)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.metroToolStrip1.SuspendLayout();
            this.tabCtrlPickListItem.SuspendLayout();
            this.tabPickListItem.SuspendLayout();
            this.tabPickedItem.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvPickedList)).BeginInit();
            this.metroToolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(768, 462);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 62);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(111, 19);
            this.metroLabel1.TabIndex = 54;
            this.metroLabel1.Text = "Delivery Number:";
            // 
            // txtDeliveryNo
            // 
            this.txtDeliveryNo.AutoSize = true;
            this.txtDeliveryNo.Location = new System.Drawing.Point(128, 62);
            this.txtDeliveryNo.Name = "txtDeliveryNo";
            this.txtDeliveryNo.Size = new System.Drawing.Size(16, 19);
            this.txtDeliveryNo.TabIndex = 55;
            this.txtDeliveryNo.Text = "0";
            // 
            // txtTruckNo
            // 
            this.txtTruckNo.AutoSize = true;
            this.txtTruckNo.Location = new System.Drawing.Point(128, 87);
            this.txtTruckNo.Name = "txtTruckNo";
            this.txtTruckNo.Size = new System.Drawing.Size(16, 19);
            this.txtTruckNo.TabIndex = 57;
            this.txtTruckNo.Text = "0";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 87);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(65, 19);
            this.metroLabel3.TabIndex = 56;
            this.metroLabel3.Text = "Truck No:";
            // 
            // txtStatus
            // 
            this.txtStatus.AutoSize = true;
            this.txtStatus.Location = new System.Drawing.Point(414, 60);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(16, 19);
            this.txtStatus.TabIndex = 59;
            this.txtStatus.Text = "0";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(336, 60);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(46, 19);
            this.metroLabel5.TabIndex = 58;
            this.metroLabel5.Text = "Status:";
            // 
            // txtTransporter
            // 
            this.txtTransporter.AutoSize = true;
            this.txtTransporter.Location = new System.Drawing.Point(414, 85);
            this.txtTransporter.Name = "txtTransporter";
            this.txtTransporter.Size = new System.Drawing.Size(16, 19);
            this.txtTransporter.TabIndex = 61;
            this.txtTransporter.Text = "0";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(336, 85);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(80, 19);
            this.metroLabel7.TabIndex = 60;
            this.metroLabel7.Text = "Transporter:";
            // 
            // txtLRNo
            // 
            this.txtLRNo.AutoSize = true;
            this.txtLRNo.Location = new System.Drawing.Point(704, 85);
            this.txtLRNo.Name = "txtLRNo";
            this.txtLRNo.Size = new System.Drawing.Size(16, 19);
            this.txtLRNo.TabIndex = 69;
            this.txtLRNo.Text = "0";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(628, 85);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(48, 19);
            this.metroLabel15.TabIndex = 68;
            this.metroLabel15.Text = "LR No:";
            // 
            // txtCreatedOn
            // 
            this.txtCreatedOn.AutoSize = true;
            this.txtCreatedOn.Location = new System.Drawing.Point(704, 60);
            this.txtCreatedOn.Name = "txtCreatedOn";
            this.txtCreatedOn.Size = new System.Drawing.Size(16, 19);
            this.txtCreatedOn.TabIndex = 67;
            this.txtCreatedOn.Text = "0";
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(628, 60);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(77, 19);
            this.metroLabel17.TabIndex = 66;
            this.metroLabel17.Text = "CreatedOn:";
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.miniToolStrip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.miniToolStrip.Location = new System.Drawing.Point(0, 7);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(830, 25);
            this.miniToolStrip.TabIndex = 11;
            this.miniToolStrip.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(104, 22);
            this.lblRecords.Text = "Total records : 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // olvPickList
            // 
            this.olvPickList.AllColumns.Add(this.olvColumnSTONo);
            this.olvPickList.AllColumns.Add(this.olvColumnSTOLineNo);
            this.olvPickList.AllColumns.Add(this.olvColumnMaterialId);
            this.olvPickList.AllColumns.Add(this.olvColumnLength);
            this.olvPickList.AllColumns.Add(this.olvColumnLocation);
            this.olvPickList.AllColumns.Add(this.olvColumnBundelQty);
            this.olvPickList.AllColumns.Add(this.olvColumnItemStatus);
            this.olvPickList.AllColumns.Add(this.olvColumn1);
            this.olvPickList.CellEditUseWholeCell = false;
            this.olvPickList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnSTONo,
            this.olvColumnSTOLineNo,
            this.olvColumnMaterialId,
            this.olvColumnLength,
            this.olvColumnLocation,
            this.olvColumnBundelQty,
            this.olvColumnItemStatus,
            this.olvColumn1});
            this.olvPickList.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvPickList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvPickList.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvPickList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvPickList.FullRowSelect = true;
            this.olvPickList.HeaderMinimumHeight = 30;
            this.olvPickList.HideSelection = false;
            this.olvPickList.IncludeColumnHeadersInCopy = true;
            this.olvPickList.Location = new System.Drawing.Point(0, 25);
            this.olvPickList.Name = "olvPickList";
            this.olvPickList.RowHeight = 25;
            this.olvPickList.ShowGroups = false;
            this.olvPickList.Size = new System.Drawing.Size(815, 263);
            this.olvPickList.TabIndex = 10;
            this.olvPickList.UseCompatibleStateImageBehavior = false;
            this.olvPickList.View = System.Windows.Forms.View.Details;
            this.olvPickList.VirtualMode = true;
            // 
            // olvColumnSTONo
            // 
            this.olvColumnSTONo.AspectName = "STONo";
            this.olvColumnSTONo.Text = "STO No";
            this.olvColumnSTONo.Width = 120;
            // 
            // olvColumnSTOLineNo
            // 
            this.olvColumnSTOLineNo.AspectName = "STOLineNo";
            this.olvColumnSTOLineNo.Text = "STO Line No";
            this.olvColumnSTOLineNo.Width = 120;
            // 
            // olvColumnMaterialId
            // 
            this.olvColumnMaterialId.AspectName = "Material";
            this.olvColumnMaterialId.Text = "Material";
            this.olvColumnMaterialId.Width = 150;
            // 
            // olvColumnLength
            // 
            this.olvColumnLength.AspectName = "Length";
            this.olvColumnLength.Text = "Length";
            this.olvColumnLength.Width = 120;
            // 
            // olvColumnLocation
            // 
            this.olvColumnLocation.AspectName = "Location";
            this.olvColumnLocation.Text = "Location";
            this.olvColumnLocation.Width = 120;
            // 
            // olvColumnBundelQty
            // 
            this.olvColumnBundelQty.AspectName = "BundelQty";
            this.olvColumnBundelQty.Text = "Bundle Qty";
            this.olvColumnBundelQty.Width = 120;
            // 
            // olvColumnItemStatus
            // 
            this.olvColumnItemStatus.AspectName = "ItemStatus";
            this.olvColumnItemStatus.Text = "Status";
            this.olvColumnItemStatus.Width = 120;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvPickList);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(3, 3);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(815, 288);
            this.metroPanel1.TabIndex = 24;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(815, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // tabCtrlPickListItem
            // 
            this.tabCtrlPickListItem.Controls.Add(this.tabPickListItem);
            this.tabCtrlPickListItem.Controls.Add(this.tabPickedItem);
            this.tabCtrlPickListItem.Location = new System.Drawing.Point(24, 120);
            this.tabCtrlPickListItem.Name = "tabCtrlPickListItem";
            this.tabCtrlPickListItem.SelectedIndex = 0;
            this.tabCtrlPickListItem.Size = new System.Drawing.Size(829, 336);
            this.tabCtrlPickListItem.TabIndex = 70;
            this.tabCtrlPickListItem.UseSelectable = true;
            // 
            // tabPickListItem
            // 
            this.tabPickListItem.Controls.Add(this.metroPanel1);
            this.tabPickListItem.Location = new System.Drawing.Point(4, 38);
            this.tabPickListItem.Name = "tabPickListItem";
            this.tabPickListItem.Padding = new System.Windows.Forms.Padding(3);
            this.tabPickListItem.Size = new System.Drawing.Size(821, 294);
            this.tabPickListItem.TabIndex = 0;
            this.tabPickListItem.Text = "Picklist Item";
            this.tabPickListItem.UseVisualStyleBackColor = true;
            // 
            // tabPickedItem
            // 
            this.tabPickedItem.Controls.Add(this.metroPanel2);
            this.tabPickedItem.Location = new System.Drawing.Point(4, 38);
            this.tabPickedItem.Name = "tabPickedItem";
            this.tabPickedItem.Padding = new System.Windows.Forms.Padding(3);
            this.tabPickedItem.Size = new System.Drawing.Size(821, 294);
            this.tabPickedItem.TabIndex = 1;
            this.tabPickedItem.Text = "Picked Item";
            this.tabPickedItem.UseVisualStyleBackColor = true;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel2.Controls.Add(this.olvPickedList);
            this.metroPanel2.Controls.Add(this.metroToolStrip2);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(3, 3);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(815, 288);
            this.metroPanel2.TabIndex = 25;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // olvPickedList
            // 
            this.olvPickedList.AllColumns.Add(this.olvPickedColumnBundleCode);
            this.olvPickedList.AllColumns.Add(this.olvPickedColumnMaterial);
            this.olvPickedList.AllColumns.Add(this.olvColumnPickedMaterialDesc);
            this.olvPickedList.AllColumns.Add(this.olvColumn9);
            this.olvPickedList.CellEditUseWholeCell = false;
            this.olvPickedList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvPickedColumnBundleCode,
            this.olvPickedColumnMaterial,
            this.olvColumnPickedMaterialDesc,
            this.olvColumn9});
            this.olvPickedList.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvPickedList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvPickedList.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvPickedList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvPickedList.FullRowSelect = true;
            this.olvPickedList.HeaderMinimumHeight = 30;
            this.olvPickedList.HideSelection = false;
            this.olvPickedList.IncludeColumnHeadersInCopy = true;
            this.olvPickedList.Location = new System.Drawing.Point(0, 25);
            this.olvPickedList.Name = "olvPickedList";
            this.olvPickedList.RowHeight = 25;
            this.olvPickedList.ShowGroups = false;
            this.olvPickedList.Size = new System.Drawing.Size(815, 263);
            this.olvPickedList.TabIndex = 10;
            this.olvPickedList.UseCompatibleStateImageBehavior = false;
            this.olvPickedList.View = System.Windows.Forms.View.Details;
            this.olvPickedList.VirtualMode = true;
            // 
            // olvPickedColumnBundleCode
            // 
            this.olvPickedColumnBundleCode.AspectName = "BundleCode";
            this.olvPickedColumnBundleCode.Text = "Bundle Code";
            this.olvPickedColumnBundleCode.Width = 120;
            // 
            // olvPickedColumnMaterial
            // 
            this.olvPickedColumnMaterial.AspectName = "Material";
            this.olvPickedColumnMaterial.Text = "Material";
            this.olvPickedColumnMaterial.Width = 200;
            // 
            // olvColumnPickedMaterialDesc
            // 
            this.olvColumnPickedMaterialDesc.AspectName = "MaterialDesc";
            this.olvColumnPickedMaterialDesc.Text = "Material Desc";
            this.olvColumnPickedMaterialDesc.Width = 250;
            // 
            // olvColumn9
            // 
            this.olvColumn9.FillsFreeSpace = true;
            this.olvColumn9.Text = "";
            // 
            // metroToolStrip2
            // 
            this.metroToolStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip2.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.lblPickedRecord,
            this.toolStripButton2});
            this.metroToolStrip2.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip2.Name = "metroToolStrip2";
            this.metroToolStrip2.Size = new System.Drawing.Size(815, 25);
            this.metroToolStrip2.TabIndex = 11;
            this.metroToolStrip2.Text = "metroToolStrip2";
            this.metroToolStrip2.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.toolStripButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(30, 30);
            this.toolStripButton1.Visible = false;
            // 
            // lblPickedRecord
            // 
            this.lblPickedRecord.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblPickedRecord.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPickedRecord.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblPickedRecord.Name = "lblPickedRecord";
            this.lblPickedRecord.Size = new System.Drawing.Size(104, 22);
            this.lblPickedRecord.Text = "Total records : 0";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.toolStripButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(30, 30);
            this.toolStripButton2.Visible = false;
            // 
            // PickListDetailView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 526);
            this.Controls.Add(this.tabCtrlPickListItem);
            this.Controls.Add(this.txtLRNo);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.txtCreatedOn);
            this.Controls.Add(this.metroLabel17);
            this.Controls.Add(this.txtTransporter);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtTruckNo);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txtDeliveryNo);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.btnCancel);
            this.Name = "PickListDetailView";
            this.Text = "Picklist";
            this.Resize += new System.EventHandler(this.PickListDetailView_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.olvPickList)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.tabCtrlPickListItem.ResumeLayout(false);
            this.tabPickListItem.ResumeLayout(false);
            this.tabPickedItem.ResumeLayout(false);
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvPickedList)).EndInit();
            this.metroToolStrip2.ResumeLayout(false);
            this.metroToolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private UIHelper.ButtonCancel btnCancel;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel txtDeliveryNo;
        private MetroFramework.Controls.MetroLabel txtTruckNo;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel txtStatus;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel txtTransporter;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel txtLRNo;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel txtCreatedOn;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.MyCustomControl.MetroToolStrip miniToolStrip;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private UIHelper.DataListView olvPickList;
        private BrightIdeasSoftware.OLVColumn olvColumnSTONo;
        private BrightIdeasSoftware.OLVColumn olvColumnSTOLineNo;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialId;
        private BrightIdeasSoftware.OLVColumn olvColumnLength;
        private BrightIdeasSoftware.OLVColumn olvColumnLocation;
        private BrightIdeasSoftware.OLVColumn olvColumnBundelQty;
        private BrightIdeasSoftware.OLVColumn olvColumnItemStatus;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.Controls.MetroTabControl tabCtrlPickListItem;
        private System.Windows.Forms.TabPage tabPickListItem;
        private System.Windows.Forms.TabPage tabPickedItem;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private UIHelper.DataListView olvPickedList;
        private BrightIdeasSoftware.OLVColumn olvPickedColumnBundleCode;
        private BrightIdeasSoftware.OLVColumn olvColumn9;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel lblPickedRecord;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private BrightIdeasSoftware.OLVColumn olvPickedColumnMaterial;
        private BrightIdeasSoftware.OLVColumn olvColumnPickedMaterialDesc;
    }
}