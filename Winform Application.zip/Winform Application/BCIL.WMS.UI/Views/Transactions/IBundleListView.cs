﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IBundleListView : IBaseView<BundleListModel>
    {
        event EventHandler ExportDataRequested;
        event EventHandler SearchRequested;
        event EventHandler PrevPageResultsRequested;
        event EventHandler NextPageResultsRequested;
        event EventHandler<List<Bundle>> RePrintRequested;

        event EventHandler<Bundle> BundleItemViewRequested;
        event EventHandler<Bundle> POConfirmationPostingRequested;
        void RefreshBinding();
        void RefreshGrid();
    }
}
