﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ProductionPlanningListView : ControlSliderBase, IProductionPlanningListView
    {
        #region Public Constructors

        public ProductionPlanningListView()
        {
            InitializeComponent();
        }

        public ProductionPlanningListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Production Planning";
            olvColumnPlannedOn.AspectGetter = (o) =>
            {
                var po = o as PoPlanningReadOnly;
                return po.PlannedOn.ToString(App.DateFormat);
            };
        }

        #endregion Public Constructors

        #region Public Properties

        public ProductionPlanningListModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler AddNewRequested;

        public event EventHandler<ProductionPlanning> EditRequested;

        public event EventHandler ImportDataRequested;

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.PlannedFrom);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.PlannedTo);

            dtpImportedFrom.Value = Model.SearchCriteria.PlannedFrom;
            dtpImportedTo.Value = Model.SearchCriteria.PlannedTo;
        }

        public void RefreshGrid()
        {
            if (Model.ProductionPlannings.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.ProductionPlannings.Count - 1, Model.ProductionPlannings.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.ProductionPlannings.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.ProductionPlannings.Count);
            }

            olvPOPlannings.SetObjects(Model.ProductionPlannings);
        }

        #endregion Public Methods

        #region Private Events

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvPOPlannings_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvPOPlannings.SelectedObjects.Count > 0)
                {
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void ProductionPlanningListView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

        private void ProductionPlanningListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvPOPlannings.Width - 20;
                olvColumnPlanningNo.Width = withToDistribute.GetPercentValue(20);
                olvColumnPlannedOn.Width = withToDistribute.GetPercentValue(20);
                olvColumnPlantCode.Width = withToDistribute.GetPercentValue(20);
                olvColumnPlannedBy.Width = withToDistribute.GetPercentValue(20);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvPOPlannings.SelectedObject != null)
                {
                    var data = (PoPlanningReadOnly)olvPOPlannings.SelectedObject;
                    var PPlanning = ProductionPlanning.GetProductionPlanning(data.ProductionPlanningId);
                    EditRequested?.Invoke(this, PPlanning);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}