﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Data.SqlTypes;

namespace BCIL.WMS.UI.Views
{
    public partial class TransferDetailView : FormBase, ITransferDetailView
    {
        public TransferDetailView()
        {
            InitializeComponent();
            olvColumnDispatchedOn.AspectGetter = (o) =>
            {
                var transferItem = o as TransferItem;
                return (transferItem.DispatchedOn == SqlDateTime.MinValue.Value) ? "" : transferItem.DispatchedOn.ToString(App.DateFormat);
            };
            olvColumnRecievedOn.AspectGetter = (o) =>
            {
                var transferItem = o as TransferItem;
                return (transferItem.RecievedOn == SqlDateTime.MinValue.Value) ? "" : transferItem.RecievedOn.ToString(App.DateFormat);
            };
        }

        public TransferDetailView(Transfer transfer) : this()
        {
            if (Model == null) Model = new TransferDetailModel();
            Model.Transfer = transfer;
            txtCreatedOn.Text = transfer.CreatedOn.ToString(App.DateFormat);
            txtSiteFrom.Text = transfer.SiteFrom.Value;
            txtSiteTo.Text = transfer.SiteTo.Value;
            BindHeader();
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            olvItems.SetObjects(Model.Transfer.Items);
            lblRecords.Text = String.Format("Total records: {0}", Model.Transfer.Items.Count);
        }

        private void BindHeader()
        {
            BindingUtility.CreateBinding(txtDeliveryNo, c => c.Text, Model.Transfer, d => d.DeliveryNo);
            BindingUtility.CreateBinding(txtStatus, c => c.Text, Model.Transfer, d => d.Status);
        }

        public TransferDetailModel Model { get; set; }
    }
}