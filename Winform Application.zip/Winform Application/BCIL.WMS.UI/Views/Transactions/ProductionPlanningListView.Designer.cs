﻿namespace BCIL.WMS.UI.Views
{
    partial class ProductionPlanningListView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductionPlanningListView));
            this.dtpImportedTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnSearch = new BCIL.UIHelper.ButtonSearch();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvPOPlannings = new BCIL.UIHelper.DataListView();
            this.olvColumnPlanningNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPlantCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPlannedBy = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPlannedOn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnAdd = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnEdit = new System.Windows.Forms.ToolStripButton();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvPOPlannings)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpImportedTo
            // 
            this.dtpImportedTo.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedTo.Location = new System.Drawing.Point(340, 63);
            this.dtpImportedTo.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedTo.Name = "dtpImportedTo";
            this.dtpImportedTo.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedTo.TabIndex = 62;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(302, 66);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(27, 19);
            this.metroLabel2.TabIndex = 61;
            this.metroLabel2.Text = "To:";
            // 
            // dtpImportedFrom
            // 
            this.dtpImportedFrom.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedFrom.Location = new System.Drawing.Point(141, 63);
            this.dtpImportedFrom.MinimumSize = new System.Drawing.Size(0, 25);
            this.dtpImportedFrom.Name = "dtpImportedFrom";
            this.dtpImportedFrom.Size = new System.Drawing.Size(142, 25);
            this.dtpImportedFrom.TabIndex = 60;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(13, 66);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(126, 19);
            this.metroLabel3.TabIndex = 59;
            this.metroLabel3.Text = "Planned Date From:";
            // 
            // btnSearch
            // 
            this.btnSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.ButtonImage")));
            this.btnSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSearch.ImageSize = 50;
            this.btnSearch.Location = new System.Drawing.Point(528, 42);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(85, 64);
            this.btnSearch.TabIndex = 58;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvPOPlannings);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(13, 123);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(808, 302);
            this.metroPanel1.TabIndex = 57;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvPOPlannings
            // 
            this.olvPOPlannings.AllColumns.Add(this.olvColumnPlanningNo);
            this.olvPOPlannings.AllColumns.Add(this.olvColumnPlantCode);
            this.olvPOPlannings.AllColumns.Add(this.olvColumnPlannedBy);
            this.olvPOPlannings.AllColumns.Add(this.olvColumnPlannedOn);
            this.olvPOPlannings.AllColumns.Add(this.olvColumn1);
            this.olvPOPlannings.CellEditUseWholeCell = false;
            this.olvPOPlannings.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnPlanningNo,
            this.olvColumnPlantCode,
            this.olvColumnPlannedBy,
            this.olvColumnPlannedOn,
            this.olvColumn1});
            this.olvPOPlannings.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvPOPlannings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvPOPlannings.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvPOPlannings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvPOPlannings.FullRowSelect = true;
            this.olvPOPlannings.HeaderMinimumHeight = 30;
            this.olvPOPlannings.HideSelection = false;
            this.olvPOPlannings.IncludeColumnHeadersInCopy = true;
            this.olvPOPlannings.Location = new System.Drawing.Point(0, 33);
            this.olvPOPlannings.Name = "olvPOPlannings";
            this.olvPOPlannings.RowHeight = 25;
            this.olvPOPlannings.ShowGroups = false;
            this.olvPOPlannings.Size = new System.Drawing.Size(808, 269);
            this.olvPOPlannings.TabIndex = 10;
            this.olvPOPlannings.UseCompatibleStateImageBehavior = false;
            this.olvPOPlannings.View = System.Windows.Forms.View.Details;
            this.olvPOPlannings.VirtualMode = true;
            this.olvPOPlannings.SelectedIndexChanged += new System.EventHandler(this.olvPOPlannings_SelectedIndexChanged);
            // 
            // olvColumnPlanningNo
            // 
            this.olvColumnPlanningNo.AspectName = "PlanningNo";
            this.olvColumnPlanningNo.Text = "Planning No";
            this.olvColumnPlanningNo.Width = 150;
            // 
            // olvColumnPlantCode
            // 
            this.olvColumnPlantCode.AspectName = "Site";
            this.olvColumnPlantCode.Text = "Plant Code";
            this.olvColumnPlantCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumnPlantCode.Width = 135;
            // 
            // olvColumnPlannedBy
            // 
            this.olvColumnPlannedBy.AspectName = "PlannedBy";
            this.olvColumnPlannedBy.Text = "Planned By";
            this.olvColumnPlannedBy.Width = 200;
            // 
            // olvColumnPlannedOn
            // 
            this.olvColumnPlannedOn.AspectName = "PlannedOn";
            this.olvColumnPlannedOn.Text = "Planned On";
            this.olvColumnPlannedOn.Width = 132;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.btnEdit,
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(808, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.IsActionRestrictedByPermission = false;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(62, 30);
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(60, 30);
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 30);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // ProductionPlanningListView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dtpImportedTo);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dtpImportedFrom);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.HeaderVisible = true;
            this.Name = "ProductionPlanningListView";
            this.Size = new System.Drawing.Size(837, 442);
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.ProductionPlanningListView_Showing);
            this.Resize += new System.EventHandler(this.ProductionPlanningListView_Resize);
            this.Controls.SetChildIndex(this.metroPanel1, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            this.Controls.SetChildIndex(this.metroLabel3, 0);
            this.Controls.SetChildIndex(this.dtpImportedFrom, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.dtpImportedTo, 0);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvPOPlannings)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroDateTime dtpImportedTo;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroDateTime dtpImportedFrom;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private UIHelper.ButtonSearch btnSearch;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvPOPlannings;
        private BrightIdeasSoftware.OLVColumn olvColumnPlanningNo;
        private BrightIdeasSoftware.OLVColumn olvColumnPlantCode;
        private BrightIdeasSoftware.OLVColumn olvColumnPlannedOn;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripButton btnEdit;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private BrightIdeasSoftware.OLVColumn olvColumnPlannedBy;
    }
}
