﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class PickingListView : ControlSliderBase, IPickingListView
    {
        #region Public Constructors

        public PickingListView()
        {
            InitializeComponent();
        }

        public PickingListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Picking List";
            olvColumnCreatedOn.AspectGetter = (o) =>
            {
                var bundle = o as Picklist;
                return bundle.CreatedOn.ToString(App.DateFormat);
            };

            //olvColumnPickedOn.AspectGetter = (o) => {
            //    var bundle = o as Picklist;
            //    return bundle.PickedOn.ToString(App.DateFormat);
            //};
        }

        #endregion Public Constructors

        #region Public Properties

        public PickingListModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        public event EventHandler<Bundle> RePrintRequested;

        public event EventHandler<Picklist> DetailViewRequested;

        public event EventHandler ExportDataRequested;

        #endregion Public Events

        #region Public Methods

        public void RefreshBinding()
        {
            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.DeliveryNo);
            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.DateFrom);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.DateTo);

            dtpImportedFrom.Value = Model.SearchCriteria.DateFrom;
            dtpImportedTo.Value = Model.SearchCriteria.DateTo;
        }

        public void RefreshGrid()
        {
            if (Model.PickingList.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.PickingList.Count - 1, Model.PickingList.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.PickingList.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.PickingList.Count);
            }

            olvBundles.SetObjects(Model.PickingList);
            btnExport.Enabled = (Model.PickingList.HaveItems()) ? true : false;
        }

        #endregion Public Methods

        #region Private Events

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void BundleListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvBundles.Width - 20;
                olvColumnDeliveryNo.Width = withToDistribute.GetPercentValue(25);
                olvColumnCreatedOn.Width = withToDistribute.GetPercentValue(10);
                olvColumnTransporter.Width = withToDistribute.GetPercentValue(25);
                olvColumnLRNo.Width = withToDistribute.GetPercentValue(10);
                olvColumnStatus.Width = withToDistribute.GetPercentValue(10);
                olvColumnTruckNo.Width = withToDistribute.GetPercentValue(10);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvBundles.SelectedObject != null)
                {
                    DetailViewRequested?.Invoke(this, (Picklist)olvBundles.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvBundles_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvBundles.SelectedObjects.Count > 0)
                {
                    btnView.Enabled = true;
                }
                else
                {
                    btnView.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (ExportDataRequested != null) ExportDataRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void PickingListView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }
    }
}