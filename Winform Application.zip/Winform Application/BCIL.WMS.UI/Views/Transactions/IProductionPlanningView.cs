﻿using BCIL.WMS.UI.Models;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public interface IProductionPlanningView : IBaseView<ProductionPlanningModel>
    {
        event EventHandler SaveRequested;
        event EventHandler<FormClosingEventArgs> CancelRequested;
        event EventHandler SelectProductionOrderReq;
        Permission AddEditPermision { get; set; }
        void RefreshBinding();
        DialogResult DialogResult { get; set; }
    }
}
