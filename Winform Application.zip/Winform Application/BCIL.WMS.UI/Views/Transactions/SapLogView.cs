﻿using BCIL.UIHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BCIL.WMS.UI.Models;
using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Views
{
    public partial class SapLogView : FormBase, ISapLogView
    {
        public SapLogView(SapPostingLog log)
        {
            InitializeComponent();
            if (Model == null) Model = new SapLogModel();
            Model.PostingLog = log;
        }
        
        public SapLogModel Model { get; set; }

        private void SapLogView_Load(object sender, EventArgs e)
        {
            try {
                lblProcess.Text = Model.PostingLog.Process.DisplayName();
                lblDateTime.Text = Model.PostingLog.CreatedOn.ToString(App.DateFormat);
                lblStatus.Text = Model.PostingLog.IsSuccess ? "Success" : "Failed";
                lblStatus.ForeColor = Model.PostingLog.IsSuccess ? Color.Green : Color.Red;
                webBrowser1.DocumentText = Model.PostingLog.PostingData;
                webBrowser1.Document.BackColor = Color.LightGray;
                webBrowser2.DocumentText = Model.PostingLog.SapResponse;
                webBrowser2.Document.BackColor = Color.LightGray;
            }
            catch (Exception ex) {
                ShowException(ex);
            }
        }
    }
}
