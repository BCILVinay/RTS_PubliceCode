﻿namespace BCIL.WMS.UI.Views
{
    partial class BundleItemDetailsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BundleItemDetailsView));
            this.txtCreatedOn = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.txtStatus = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtBundleCode = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvItems = new BCIL.UIHelper.DataListView();
            this.olvColumnItemCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnPrint = new MetroFramework.MyCustomControl.MetroToolStripButton();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCreatedOn
            // 
            this.txtCreatedOn.AutoSize = true;
            this.txtCreatedOn.Location = new System.Drawing.Point(656, 70);
            this.txtCreatedOn.Name = "txtCreatedOn";
            this.txtCreatedOn.Size = new System.Drawing.Size(16, 19);
            this.txtCreatedOn.TabIndex = 72;
            this.txtCreatedOn.Text = "0";
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(580, 70);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(77, 19);
            this.metroLabel17.TabIndex = 71;
            this.metroLabel17.Text = "CreatedOn:";
            // 
            // txtStatus
            // 
            this.txtStatus.AutoSize = true;
            this.txtStatus.Location = new System.Drawing.Point(388, 72);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(16, 19);
            this.txtStatus.TabIndex = 70;
            this.txtStatus.Text = "0";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(336, 70);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(46, 19);
            this.metroLabel5.TabIndex = 69;
            this.metroLabel5.Text = "Status:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(88, 19);
            this.metroLabel1.TabIndex = 68;
            this.metroLabel1.Text = "Bundle Code:";
            // 
            // txtBundleCode
            // 
            this.txtBundleCode.AutoSize = true;
            this.txtBundleCode.Location = new System.Drawing.Point(117, 72);
            this.txtBundleCode.Name = "txtBundleCode";
            this.txtBundleCode.Size = new System.Drawing.Size(16, 19);
            this.txtBundleCode.TabIndex = 73;
            this.txtBundleCode.Text = "0";
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvItems);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 125);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(776, 265);
            this.metroPanel1.TabIndex = 74;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvItems
            // 
            this.olvItems.AllColumns.Add(this.olvColumnItemCode);
            this.olvItems.AllColumns.Add(this.olvColumnStatus);
            this.olvItems.AllColumns.Add(this.olvColumn1);
            this.olvItems.CellEditUseWholeCell = false;
            this.olvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnItemCode,
            this.olvColumnStatus,
            this.olvColumn1});
            this.olvItems.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvItems.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvItems.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvItems.FullRowSelect = true;
            this.olvItems.HeaderMinimumHeight = 30;
            this.olvItems.HideSelection = false;
            this.olvItems.IncludeColumnHeadersInCopy = true;
            this.olvItems.Location = new System.Drawing.Point(0, 33);
            this.olvItems.Name = "olvItems";
            this.olvItems.RowHeight = 25;
            this.olvItems.ShowGroups = false;
            this.olvItems.Size = new System.Drawing.Size(776, 232);
            this.olvItems.TabIndex = 10;
            this.olvItems.UseCompatibleStateImageBehavior = false;
            this.olvItems.View = System.Windows.Forms.View.Details;
            this.olvItems.VirtualMode = true;
            this.olvItems.SelectedIndexChanged += new System.EventHandler(this.olvItems_SelectedIndexChanged);
            // 
            // olvColumnItemCode
            // 
            this.olvColumnItemCode.AspectName = "ItemCode";
            this.olvColumnItemCode.Text = "Item Code";
            this.olvColumnItemCode.Width = 250;
            // 
            // olvColumnStatus
            // 
            this.olvColumnStatus.AspectName = "ItemStatus";
            this.olvColumnStatus.Text = "Status";
            this.olvColumnStatus.Width = 250;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious,
            this.btnPrint});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(776, 33);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(16, 30);
            this.lblRecords.Text = "  ";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrint.IsActionRestrictedByPermission = false;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(84, 30);
            this.btnPrint.Text = "Re-Print";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(714, 409);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 75;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            // 
            // BundleItemDetailsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 479);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtBundleCode);
            this.Controls.Add(this.txtCreatedOn);
            this.Controls.Add(this.metroLabel17);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel1);
            this.Name = "BundleItemDetailsView";
            this.Text = "Bundle Items";
            this.Load += new System.EventHandler(this.BundleItemListView_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvItems)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel txtCreatedOn;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel txtStatus;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel txtBundleCode;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvItems;
        private BrightIdeasSoftware.OLVColumn olvColumnItemCode;
        private BrightIdeasSoftware.OLVColumn olvColumnStatus;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private UIHelper.ButtonCancel btnCancel;
        private MetroFramework.MyCustomControl.MetroToolStripButton btnPrint;
    }
}