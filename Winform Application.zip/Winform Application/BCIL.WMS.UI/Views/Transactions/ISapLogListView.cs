﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface ISapLogListView : IBaseView<SapLogListModel>
    {
        event EventHandler NextPageResultsRequested;

        event EventHandler PrevPageResultsRequested;

        event EventHandler SearchRequested;

        event EventHandler<SapPostingLog> ShowSapPostingLogRequested;

        void RefreshBinding();
        void RefreshGrid();

        void ShowSapLogView(SapPostingLog log);
    }
}
