﻿namespace BCIL.WMS.UI.Views
{
    partial class LocationSearchView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocationSearchView));
            this.btnSelect = new BCIL.UIHelper.ButtonSave();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.locationSearchCriteriaBS = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.buttonCancel = new BCIL.UIHelper.ButtonCancel();
            this.buttonSearch = new BCIL.UIHelper.ButtonSearch();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvLocations = new BCIL.UIHelper.DataListView();
            this.olvColumnLocationCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnName = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnLocationDescription = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.cboMode = new MetroFramework.Controls.MetroComboBox();
            this.cboLocationType = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.locationSearchCriteriaBS)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvLocations)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSelect
            // 
            this.btnSelect.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSelect.ButtonImage")));
            this.btnSelect.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSelect.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSelect.ImageSize = 50;
            this.btnSelect.Location = new System.Drawing.Point(612, 446);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(85, 56);
            this.btnSelect.TabIndex = 28;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSelect.UseSelectable = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(175, 2);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.locationSearchCriteriaBS, "LocationCode", true));
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(73, 60);
            this.txtCode.MaxLength = 15;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(199, 26);
            this.txtCode.TabIndex = 27;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // locationSearchCriteriaBS
            // 
            this.locationSearchCriteriaBS.DataSource = typeof(BCIL.WMS.BL.LocationDVLSearchCriteria);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 64);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 26;
            this.metroLabel1.Text = "Code:";
            // 
            // buttonCancel
            // 
            this.buttonCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonCancel.ButtonImage")));
            this.buttonCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonCancel.ImageSize = 50;
            this.buttonCancel.Location = new System.Drawing.Point(703, 446);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(85, 56);
            this.buttonCancel.TabIndex = 25;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCancel.UseSelectable = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch.ButtonImage")));
            this.buttonSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch.ImageSize = 50;
            this.buttonSearch.Location = new System.Drawing.Point(703, 57);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(85, 56);
            this.buttonSearch.TabIndex = 24;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch.UseSelectable = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvLocations);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(18, 146);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(770, 294);
            this.metroPanel1.TabIndex = 23;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvLocations
            // 
            this.olvLocations.AllColumns.Add(this.olvColumnLocationCode);
            this.olvLocations.AllColumns.Add(this.olvColumnName);
            this.olvLocations.AllColumns.Add(this.olvColumnLocationDescription);
            this.olvLocations.AllColumns.Add(this.olvColumn1);
            this.olvLocations.CellEditUseWholeCell = false;
            this.olvLocations.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnLocationCode,
            this.olvColumnName,
            this.olvColumnLocationDescription,
            this.olvColumn1});
            this.olvLocations.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvLocations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvLocations.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvLocations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvLocations.FullRowSelect = true;
            this.olvLocations.HeaderMinimumHeight = 30;
            this.olvLocations.HideSelection = false;
            this.olvLocations.IncludeColumnHeadersInCopy = true;
            this.olvLocations.Location = new System.Drawing.Point(0, 25);
            this.olvLocations.Name = "olvLocations";
            this.olvLocations.RowHeight = 25;
            this.olvLocations.ShowGroups = false;
            this.olvLocations.Size = new System.Drawing.Size(770, 269);
            this.olvLocations.TabIndex = 10;
            this.olvLocations.UseCompatibleStateImageBehavior = false;
            this.olvLocations.View = System.Windows.Forms.View.Details;
            this.olvLocations.VirtualMode = true;
            this.olvLocations.DoubleClick += new System.EventHandler(this.btnSelect_Click);
            // 
            // olvColumnLocationCode
            // 
            this.olvColumnLocationCode.AspectName = "LocationCode";
            this.olvColumnLocationCode.Text = "Location Code";
            this.olvColumnLocationCode.Width = 200;
            // 
            // olvColumnName
            // 
            this.olvColumnName.AspectName = "LocationName";
            this.olvColumnName.Text = "Location Name";
            this.olvColumnName.Width = 200;
            // 
            // olvColumnLocationDescription
            // 
            this.olvColumnLocationDescription.AspectName = "Description";
            this.olvColumnLocationDescription.Text = "Location Description";
            this.olvColumnLocationDescription.Width = 300;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(770, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(16, 22);
            this.lblRecords.Text = "  ";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(175, 2);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.locationSearchCriteriaBS, "Name", true));
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(73, 94);
            this.txtName.MaxLength = 15;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(199, 26);
            this.txtName.TabIndex = 30;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 98);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(48, 19);
            this.metroLabel2.TabIndex = 29;
            this.metroLabel2.Text = "Name:";
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(619, 61);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(72, 25);
            this.cboIsActive.TabIndex = 36;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(559, 64);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 37;
            this.lblIsActive.Text = "Active:";
            // 
            // cboMode
            // 
            this.cboMode.FormattingEnabled = true;
            this.cboMode.ItemHeight = 19;
            this.cboMode.Location = new System.Drawing.Point(372, 95);
            this.cboMode.Name = "cboMode";
            this.cboMode.PromptItemIndex = -1;
            this.cboMode.Size = new System.Drawing.Size(167, 25);
            this.cboMode.TabIndex = 35;
            this.cboMode.UseSelectable = true;
            // 
            // cboLocationType
            // 
            this.cboLocationType.FormattingEnabled = true;
            this.cboLocationType.ItemHeight = 19;
            this.cboLocationType.Location = new System.Drawing.Point(372, 61);
            this.cboLocationType.Name = "cboLocationType";
            this.cboLocationType.PromptItemIndex = -1;
            this.cboLocationType.Size = new System.Drawing.Size(167, 25);
            this.cboLocationType.TabIndex = 32;
            this.cboLocationType.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(326, 64);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(40, 19);
            this.metroLabel6.TabIndex = 34;
            this.metroLabel6.Text = "Type:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(327, 98);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(47, 19);
            this.metroLabel5.TabIndex = 33;
            this.metroLabel5.Text = "Mode:";
            // 
            // LocationSearchView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 513);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.cboMode);
            this.Controls.Add(this.cboLocationType);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.metroPanel1);
            this.Name = "LocationSearchView";
            this.Text = "Location";
            ((System.ComponentModel.ISupportInitialize)(this.locationSearchCriteriaBS)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvLocations)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIHelper.ButtonSave btnSelect;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.ButtonCancel buttonCancel;
        private UIHelper.ButtonSearch buttonSearch;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvLocations;
        private BrightIdeasSoftware.OLVColumn olvColumnLocationCode;
        private BrightIdeasSoftware.OLVColumn olvColumnLocationDescription;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.BindingSource locationSearchCriteriaBS;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private MetroFramework.Controls.MetroComboBox cboMode;
        private MetroFramework.Controls.MetroComboBox cboLocationType;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private BrightIdeasSoftware.OLVColumn olvColumnName;
    }
}