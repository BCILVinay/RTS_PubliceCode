﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class MaterialSearchView : FormBase, IMaterialSearchView
    {
        #region Constructor

        public MaterialSearchView()
        {
            InitializeComponent();
        }

        #endregion Constructor

        #region Public Property & Events

        public bool MultiItemSelect
        {
            get { return olvMaterials.MultiSelect; }
            set { olvMaterials.MultiSelect = value; }
        }

        public List<Material> SelectedItems { get; set; }
        public MaterialSearchModel Model { get; set; }

        public event EventHandler SearchRequested;

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PreviousPageResultsRequested;

        #endregion Public Property & Events

        #region Private Events

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (SearchRequested != null) SearchRequested(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (NextPageResultsRequested != null) NextPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (PreviousPageResultsRequested != null) PreviousPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        public void BindHeader()
        {
            MaterialSearchCriteriaBS.DataSource = Model.SearchCriteria;
        }

        public void RefreshResults()
        {
            if (Model.SearchedMaterials.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.SearchedMaterials.Count - 1, Model.SearchedMaterials.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.SearchedMaterials.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.SearchedMaterials.Count);
            }

            olvMaterials.SetObjects(Model.SearchedMaterials);
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedItems = olvMaterials.SelectedObjects.Cast<Material>().ToList();
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}