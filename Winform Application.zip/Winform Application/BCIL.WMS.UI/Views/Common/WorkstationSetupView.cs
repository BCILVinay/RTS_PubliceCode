﻿using BCIL.User.UI.Views;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models.Common;
using System;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views.Common
{
    public partial class WorkstationSetupView : ControlSliderBase, IWorkstationSetupView
    {
        public WorkstationSetupView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Workstation Setup";
        }

        public WorkstationSetupModel Model { get; set; }

        public WorkstationSetupView()
        {
            InitializeComponent();
        }

        public event EventHandler<long> LocationChangeRequested;

        public void BindUI()
        {
            cboLocation.DisplayMember = "LocationCode";
            cboLocation.ValueMember = "LocationId";
            cboLocation.DataSource = Model.Locations;
        }

        public void BindLines()
        {
            cboLine.DisplayMember = "Code";
            cboLine.ValueMember = "LineId";
            cboLine.DataSource = Model.Lines;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<BCILException>((Int64)cboLocation.SelectedValue > 0, "Location selection is required");
                App.WorkStation.WMaterialBination = (Location)cboLocation.SelectedItem;
                if ((Int32)cboLine.SelectedValue > 0)
                {
                    App.WorkStation.WSLine = (Line)cboLine.SelectedItem;
                    ShowMessage("Workstation setup saved.");
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void WorkstationSetupView_Showing(object sender, ActionArg e)
        {
            try
            {
                LoginedLocationSelectionView.SelectLocationIfNot(this);
                if (App.Login.LoginSite == null)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                e.Handled = true;
            }
        }

        private void cboLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (LocationChangeRequested != null)
                {
                    if (cboLocation.DataBindings != null && cboLocation.DataBindings.Count > 0)
                        cboLocation.DataBindings[0].WriteValue();
                    LocationChangeRequested(sender, cboLocation.SelectedValue == null ? 0 : (Int64)cboLocation.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
    }
}