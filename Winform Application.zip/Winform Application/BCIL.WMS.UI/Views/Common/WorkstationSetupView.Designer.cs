﻿namespace BCIL.WMS.UI.Views.Common
{
    partial class WorkstationSetupView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorkstationSetupView));
            this.cboLocation = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cboLine = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.SuspendLayout();
            // 
            // cboLocation
            // 
            this.cboLocation.FormattingEnabled = true;
            this.cboLocation.ItemHeight = 19;
            this.cboLocation.Location = new System.Drawing.Point(94, 84);
            this.cboLocation.Name = "cboLocation";
            this.cboLocation.PromptItemIndex = -1;
            this.cboLocation.Size = new System.Drawing.Size(286, 25);
            this.cboLocation.TabIndex = 32;
            this.cboLocation.UseSelectable = true;
            this.cboLocation.SelectedIndexChanged += new System.EventHandler(this.cboLocation_SelectedIndexChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(27, 84);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(61, 19);
            this.metroLabel1.TabIndex = 31;
            this.metroLabel1.Text = "Location:";
            // 
            // cboLine
            // 
            this.cboLine.FormattingEnabled = true;
            this.cboLine.ItemHeight = 19;
            this.cboLine.Location = new System.Drawing.Point(94, 124);
            this.cboLine.Name = "cboLine";
            this.cboLine.PromptItemIndex = -1;
            this.cboLine.Size = new System.Drawing.Size(286, 25);
            this.cboLine.TabIndex = 34;
            this.cboLine.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(27, 124);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(35, 19);
            this.metroLabel2.TabIndex = 33;
            this.metroLabel2.Text = "Line:";
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(295, 175);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 35;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // WorkstationSetupView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cboLine);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.cboLocation);
            this.Controls.Add(this.metroLabel1);
            this.HeaderVisible = true;
            this.Name = "WorkstationSetupView";
            this.Size = new System.Drawing.Size(787, 420);
            this.Showing += new System.EventHandler<BCIL.pnlSlider.ActionArg>(this.WorkstationSetupView_Showing);
            this.Controls.SetChildIndex(this.metroLabel1, 0);
            this.Controls.SetChildIndex(this.cboLocation, 0);
            this.Controls.SetChildIndex(this.metroLabel2, 0);
            this.Controls.SetChildIndex(this.cboLine, 0);
            this.Controls.SetChildIndex(this.btnSave, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroComboBox cboLocation;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroComboBox cboLine;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private UIHelper.ButtonSave btnSave;
    }
}