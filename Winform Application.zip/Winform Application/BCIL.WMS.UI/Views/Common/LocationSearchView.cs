﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class LocationSearchView : FormBase, ILocationSearchView
    {
        #region Constructor

        public LocationSearchView()
        {
            InitializeComponent();
        }

        #endregion Constructor

        #region Public Property & Events

        public bool MultiItemSelect
        {
            get { return olvLocations.MultiSelect; }
            set { olvLocations.MultiSelect = value; }
        }

        public List<Location> SelectedItems { get; set; }
        public LocationSearchModel Model { get; set; }

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PreviousPageResultsRequested;

        public event EventHandler SearchRequested;

        #endregion Public Property & Events

        #region Public  Method
        private void BindComboToKeyValue(MetroFramework.Controls.MetroComboBox cbo, List<KeyValue<int, string>> values)
        {
            cbo.DisplayMember = "Value";
            cbo.ValueMember = "Key";
            cbo.DataSource = values;
        }
        public void BindHeader()
        {
            BindComboToKeyValue(cboMode, Model.Mode);
            BindComboToKeyValue(cboIsActive, Model.State);
            BindComboToKeyValue(cboLocationType, Model.Type);

            BindingUtility.CreateBinding(txtCode, c => c.Text, Model.SearchCriteria, d => d.LocationCode);
            BindingUtility.CreateBinding(txtName, c => c.Text, Model.SearchCriteria, d => d.Name);
            BindingUtility.CreateBinding(cboMode, c => c.SelectedValue, Model.SearchCriteria, d => d.Mode);
            BindingUtility.CreateBinding(cboLocationType, c => c.SelectedValue, Model.SearchCriteria, d => d.Type);
            BindingUtility.CreateBinding(cboIsActive, c => c.SelectedValue, Model.SearchCriteria, d => d.State);

            locationSearchCriteriaBS.DataSource = Model.SearchCriteria;
        }

        public void RefreshResults()
        {
            if (Model.SearchedLocations.TotalRowCount > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.SearchedLocations.Count - 1, Model.SearchedLocations.TotalRowCount);
                decimal maxPages = Math.Ceiling((decimal)Model.SearchedLocations.TotalRowCount / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.SearchedLocations.Count);
            }

            olvLocations.SetObjects(Model.SearchedLocations);
        }

        #endregion Public  Method

        #region Private Events

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (SearchRequested != null) SearchRequested(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedItems = olvLocations.SelectedObjects.Cast<Location>().ToList();
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (PreviousPageResultsRequested != null) PreviousPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (NextPageResultsRequested != null) NextPageResultsRequested(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}