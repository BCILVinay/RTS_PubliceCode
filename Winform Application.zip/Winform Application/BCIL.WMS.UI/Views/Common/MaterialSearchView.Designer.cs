﻿namespace BCIL.WMS.UI.Views
{
    partial class MaterialSearchView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialSearchView));
            this.txtContact2 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.buttonCancel = new BCIL.UIHelper.ButtonCancel();
            this.buttonSearch = new BCIL.UIHelper.ButtonSearch();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvMaterials = new BCIL.UIHelper.DataListView();
            this.olvColumnMaterialCode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMaterialDescription = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.MaterialSearchCriteriaBS = new System.Windows.Forms.BindingSource(this.components);
            this.btnSelect = new BCIL.UIHelper.ButtonSave();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterials)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaterialSearchCriteriaBS)).BeginInit();
            this.SuspendLayout();
            // 
            // txtContact2
            // 
            // 
            // 
            // 
            this.txtContact2.CustomButton.Image = null;
            this.txtContact2.CustomButton.Location = new System.Drawing.Point(175, 2);
            this.txtContact2.CustomButton.Name = "";
            this.txtContact2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtContact2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtContact2.CustomButton.TabIndex = 1;
            this.txtContact2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtContact2.CustomButton.UseSelectable = true;
            this.txtContact2.CustomButton.Visible = false;
            this.txtContact2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialSearchCriteriaBS, "MeterialCode", true));
            this.txtContact2.Lines = new string[0];
            this.txtContact2.Location = new System.Drawing.Point(60, 67);
            this.txtContact2.MaxLength = 15;
            this.txtContact2.Name = "txtContact2";
            this.txtContact2.PasswordChar = '\0';
            this.txtContact2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContact2.SelectedText = "";
            this.txtContact2.SelectionLength = 0;
            this.txtContact2.SelectionStart = 0;
            this.txtContact2.ShortcutsEnabled = true;
            this.txtContact2.Size = new System.Drawing.Size(199, 26);
            this.txtContact2.TabIndex = 21;
            this.txtContact2.UseSelectable = true;
            this.txtContact2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtContact2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(10, 71);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 20;
            this.metroLabel1.Text = "Code:";
            // 
            // buttonCancel
            // 
            this.buttonCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonCancel.ButtonImage")));
            this.buttonCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonCancel.ImageSize = 50;
            this.buttonCancel.Location = new System.Drawing.Point(672, 402);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(85, 56);
            this.buttonCancel.TabIndex = 19;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCancel.UseSelectable = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSearch.ButtonImage")));
            this.buttonSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSearch.ImageSize = 50;
            this.buttonSearch.Location = new System.Drawing.Point(672, 47);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(85, 56);
            this.buttonSearch.TabIndex = 18;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSearch.UseSelectable = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvMaterials);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(10, 119);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(747, 277);
            this.metroPanel1.TabIndex = 17;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvMaterials
            // 
            this.olvMaterials.AllColumns.Add(this.olvColumnMaterialCode);
            this.olvMaterials.AllColumns.Add(this.olvColumnMaterialDescription);
            this.olvMaterials.AllColumns.Add(this.olvColumn1);
            this.olvMaterials.CellEditUseWholeCell = false;
            this.olvMaterials.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnMaterialCode,
            this.olvColumnMaterialDescription,
            this.olvColumn1});
            this.olvMaterials.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvMaterials.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvMaterials.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvMaterials.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvMaterials.FullRowSelect = true;
            this.olvMaterials.HeaderMinimumHeight = 30;
            this.olvMaterials.HideSelection = false;
            this.olvMaterials.IncludeColumnHeadersInCopy = true;
            this.olvMaterials.Location = new System.Drawing.Point(0, 25);
            this.olvMaterials.Name = "olvMaterials";
            this.olvMaterials.RowHeight = 25;
            this.olvMaterials.ShowGroups = false;
            this.olvMaterials.Size = new System.Drawing.Size(747, 252);
            this.olvMaterials.TabIndex = 10;
            this.olvMaterials.UseCompatibleStateImageBehavior = false;
            this.olvMaterials.View = System.Windows.Forms.View.Details;
            this.olvMaterials.VirtualMode = true;
            this.olvMaterials.DoubleClick += new System.EventHandler(this.btnSelect_Click);
            // 
            // olvColumnMaterialCode
            // 
            this.olvColumnMaterialCode.AspectName = "MaterialCode";
            this.olvColumnMaterialCode.Text = "Material Code";
            this.olvColumnMaterialCode.Width = 114;
            // 
            // olvColumnMaterialDescription
            // 
            this.olvColumnMaterialDescription.AspectName = "MaterialDescription";
            this.olvColumnMaterialDescription.Text = "Material Description";
            this.olvColumnMaterialDescription.Width = 250;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(747, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(16, 22);
            this.lblRecords.Text = "  ";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // MaterialSearchCriteriaBS
            // 
            this.MaterialSearchCriteriaBS.DataSource = typeof(BCIL.WMS.BL.MaterialGenericSearchCriteria);
            // 
            // btnSelect
            // 
            this.btnSelect.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSelect.ButtonImage")));
            this.btnSelect.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSelect.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSelect.ImageSize = 50;
            this.btnSelect.Location = new System.Drawing.Point(581, 402);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(85, 56);
            this.btnSelect.TabIndex = 22;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSelect.UseSelectable = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(175, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.MaterialSearchCriteriaBS, "MeterialDesc", true));
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(409, 68);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(199, 25);
            this.txtName.TabIndex = 23;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(327, 71);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(77, 19);
            this.metroLabel2.TabIndex = 24;
            this.metroLabel2.Text = "Description:";
            // 
            // MaterialSearchView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 467);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txtContact2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.metroPanel1);
            this.Name = "MaterialSearchView";
            this.Text = "Material";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvMaterials)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaterialSearchCriteriaBS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox txtContact2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private UIHelper.ButtonCancel buttonCancel;
        private UIHelper.ButtonSearch buttonSearch;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvMaterials;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialCode;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private BrightIdeasSoftware.OLVColumn olvColumnMaterialDescription;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.BindingSource MaterialSearchCriteriaBS;
        private UIHelper.ButtonSave btnSelect;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
    }
}