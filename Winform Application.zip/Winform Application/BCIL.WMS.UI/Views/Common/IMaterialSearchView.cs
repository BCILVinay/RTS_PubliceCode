﻿using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views
{
    public interface IMaterialSearchView:IBaseView<MaterialSearchModel>
    {
        void BindHeader();

        event EventHandler SearchRequested;

        event EventHandler NextPageResultsRequested;

        event EventHandler PreviousPageResultsRequested;

        void RefreshResults();
    }
}
