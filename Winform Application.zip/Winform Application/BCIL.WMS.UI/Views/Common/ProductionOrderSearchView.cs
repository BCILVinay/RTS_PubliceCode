﻿using BCIL.UIHelper;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.WMS.UI.Views
{
    public partial class ProductionOrderSearchView : FormBase, IProductionOrderSearchView
    {
        #region Constructor

        public ProductionOrderSearchView()
        {
            InitializeComponent();
            olvColumnPOrderDate.AspectGetter = (o) =>
            {
                var obj = o as ProductionOrder;
                return obj.POrderDate.ToString(App.DateFormat);
            };
           
        }

        #endregion Constructor

        #region Public Properties

        public bool MultiItemSelect
        {
            get { return olvProductionOrders.MultiSelect; }
            set { olvProductionOrders.MultiSelect = value; }
        }

        public List<ProductionOrder> SelectedItems { get; set; }
        public ProductionOrderSearchModel Model { get; set; }

        #endregion Public Properties

        #region Public Events

        public event EventHandler NextPageResultsRequested;

        public event EventHandler PrevPageResultsRequested;

        public event EventHandler SearchRequested;

        #endregion Public Events

        #region Public Methods

        public void BindHeader()
        {
            BindingUtility.CreateBinding(dtpImportedFrom, c => c.Value, Model.SearchCriteria, d => d.CreatedFrom);
            BindingUtility.CreateBinding(dtpImportedTo, c => c.Value, Model.SearchCriteria, d => d.CreatedTo);

            dtpImportedFrom.Value = Model.SearchCriteria.CreatedFrom;
            dtpImportedTo.Value = Model.SearchCriteria.CreatedTo;
        }

        public void RefreshGrid()
        {
           
            if (Model.ProductionOrders.Count > Model.SearchCriteria.PageSize)
            {
                btnPrevious.Visible = true;
                btnNext.Visible = true;

                int firstRecorNumber = (Model.SearchCriteria.PageNumber - 1) * Model.SearchCriteria.PageSize + 1;
                lblRecords.Text = String.Format("{0} - {1} out of {2}", firstRecorNumber, firstRecorNumber + Model.ProductionOrders.Count - 1, Model.ProductionOrders.Count);
                decimal maxPages = Math.Ceiling((decimal)Model.ProductionOrders.Count / Model.SearchCriteria.PageSize);
                btnPrevious.Enabled = !(Model.SearchCriteria.PageNumber == 1);
                btnNext.Enabled = !(Model.SearchCriteria.PageNumber >= maxPages);
            }
            else
            {
                btnPrevious.Visible = false;
                btnNext.Visible = false;
                lblRecords.Text = String.Format("Total records: {0}", Model.ProductionOrders.Count);
            }

            olvProductionOrders.SetObjects(Model.ProductionOrders);
        }

        #endregion Public Methods

        #region Private Events

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PrevPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultsRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SearchRequested?.Invoke(this, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                SelectedItems = olvProductionOrders.SelectedObjects.Cast<ProductionOrder>().ToList();
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Events
    }
}