﻿using BCIL.WMS.UI.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Views.Common
{
    public interface IWorkstationSetupView : IBaseView<WorkstationSetupModel>
    {
        event EventHandler<Int64> LocationChangeRequested;
        void BindUI();

        void BindLines();
    }
}
