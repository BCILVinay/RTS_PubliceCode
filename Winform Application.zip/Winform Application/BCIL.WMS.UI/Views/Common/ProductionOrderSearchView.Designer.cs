﻿namespace BCIL.WMS.UI.Views
{
    partial class ProductionOrderSearchView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductionOrderSearchView));
            this.dtpImportedTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.dtpImportedFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.olvProductionOrders = new BCIL.UIHelper.DataListView();
            this.olvColumnPOrderNo = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPOrderDate = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnMovementType = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnStatus = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroToolStrip1 = new MetroFramework.MyCustomControl.MetroToolStrip();
            this.btnNext = new System.Windows.Forms.ToolStripButton();
            this.lblRecords = new System.Windows.Forms.ToolStripLabel();
            this.btnPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnSearch = new BCIL.UIHelper.ButtonSearch();
            this.btnSelect = new BCIL.UIHelper.ButtonSave();
            this.buttonCancel = new BCIL.UIHelper.ButtonCancel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvProductionOrders)).BeginInit();
            this.metroToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpImportedTo
            // 
            this.dtpImportedTo.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedTo.Location = new System.Drawing.Point(329, 101);
            this.dtpImportedTo.MinimumSize = new System.Drawing.Size(4, 25);
            this.dtpImportedTo.Name = "dtpImportedTo";
            this.dtpImportedTo.Size = new System.Drawing.Size(174, 25);
            this.dtpImportedTo.TabIndex = 53;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(296, 104);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(27, 19);
            this.metroLabel2.TabIndex = 52;
            this.metroLabel2.Text = "To:";
            // 
            // dtpImportedFrom
            // 
            this.dtpImportedFrom.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.dtpImportedFrom.Location = new System.Drawing.Point(112, 101);
            this.dtpImportedFrom.MinimumSize = new System.Drawing.Size(4, 25);
            this.dtpImportedFrom.Name = "dtpImportedFrom";
            this.dtpImportedFrom.Size = new System.Drawing.Size(174, 25);
            this.dtpImportedFrom.TabIndex = 51;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(23, 104);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(75, 19);
            this.metroLabel6.TabIndex = 50;
            this.metroLabel6.Text = "Date From:";
            // 
            // txtCode
            // 
            // 
            // 
            // 
            this.txtCode.CustomButton.Image = null;
            this.txtCode.CustomButton.Location = new System.Drawing.Point(150, 1);
            this.txtCode.CustomButton.Name = "";
            this.txtCode.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCode.CustomButton.TabIndex = 1;
            this.txtCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCode.CustomButton.UseSelectable = true;
            this.txtCode.CustomButton.Visible = false;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(112, 68);
            this.txtCode.MaxLength = 50;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.SelectionLength = 0;
            this.txtCode.SelectionStart = 0;
            this.txtCode.ShortcutsEnabled = true;
            this.txtCode.Size = new System.Drawing.Size(174, 25);
            this.txtCode.TabIndex = 48;
            this.txtCode.UseSelectable = true;
            this.txtCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 71);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(87, 19);
            this.metroLabel1.TabIndex = 49;
            this.metroLabel1.Text = "P.O Number:";
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.metroPanel1.Controls.Add(this.olvProductionOrders);
            this.metroPanel1.Controls.Add(this.metroToolStrip1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(12, 138);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(696, 288);
            this.metroPanel1.TabIndex = 54;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // olvProductionOrders
            // 
            this.olvProductionOrders.AllColumns.Add(this.olvColumnPOrderNo);
            this.olvProductionOrders.AllColumns.Add(this.olvColumnPOrderDate);
            this.olvProductionOrders.AllColumns.Add(this.olvColumnMovementType);
            this.olvProductionOrders.AllColumns.Add(this.olvColumnStatus);
            this.olvProductionOrders.AllColumns.Add(this.olvColumn1);
            this.olvProductionOrders.CellEditUseWholeCell = false;
            this.olvProductionOrders.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnPOrderNo,
            this.olvColumnPOrderDate,
            this.olvColumnMovementType,
            this.olvColumnStatus,
            this.olvColumn1});
            this.olvProductionOrders.Cursor = System.Windows.Forms.Cursors.Default;
            this.olvProductionOrders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.olvProductionOrders.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.olvProductionOrders.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.olvProductionOrders.FullRowSelect = true;
            this.olvProductionOrders.HeaderMinimumHeight = 30;
            this.olvProductionOrders.HideSelection = false;
            this.olvProductionOrders.IncludeColumnHeadersInCopy = true;
            this.olvProductionOrders.Location = new System.Drawing.Point(0, 25);
            this.olvProductionOrders.Name = "olvProductionOrders";
            this.olvProductionOrders.RowHeight = 25;
            this.olvProductionOrders.ShowGroups = false;
            this.olvProductionOrders.Size = new System.Drawing.Size(696, 263);
            this.olvProductionOrders.TabIndex = 10;
            this.olvProductionOrders.UseCompatibleStateImageBehavior = false;
            this.olvProductionOrders.View = System.Windows.Forms.View.Details;
            this.olvProductionOrders.VirtualMode = true;
            this.olvProductionOrders.DoubleClick += new System.EventHandler(this.btnSelect_Click);
            // 
            // olvColumnPOrderNo
            // 
            this.olvColumnPOrderNo.AspectName = "POrderNo";
            this.olvColumnPOrderNo.Text = "PO No";
            this.olvColumnPOrderNo.Width = 120;
            // 
            // olvColumnPOrderDate
            // 
            this.olvColumnPOrderDate.AspectName = "POrderDate";
            this.olvColumnPOrderDate.Text = "PO Date";
            this.olvColumnPOrderDate.Width = 120;
            // 
            // olvColumnMovementType
            // 
            this.olvColumnMovementType.AspectName = "MovementType";
            this.olvColumnMovementType.Text = "Movement Type";
            this.olvColumnMovementType.Width = 196;
            // 
            // olvColumnStatus
            // 
            this.olvColumnStatus.AspectName = "Status";
            this.olvColumnStatus.Text = "Status";
            this.olvColumnStatus.Width = 100;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // metroToolStrip1
            // 
            this.metroToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            this.metroToolStrip1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroToolStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.metroToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.metroToolStrip1.ImageScalingSize = new System.Drawing.Size(26, 26);
            this.metroToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNext,
            this.lblRecords,
            this.btnPrevious});
            this.metroToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.metroToolStrip1.Name = "metroToolStrip1";
            this.metroToolStrip1.Size = new System.Drawing.Size(696, 25);
            this.metroToolStrip1.TabIndex = 11;
            this.metroToolStrip1.Text = "metroToolStrip1";
            this.metroToolStrip1.Theme = MetroFramework.MetroThemeStyle.CustomDark1;
            // 
            // btnNext
            // 
            this.btnNext.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnNext.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.Image")));
            this.btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(30, 30);
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblRecords
            // 
            this.lblRecords.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblRecords.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecords.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(100, 22);
            this.lblRecords.Text = "Total records: 0";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.btnPrevious.Image = ((System.Drawing.Image)(resources.GetObject("btnPrevious.Image")));
            this.btnPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(30, 30);
            this.btnPrevious.Visible = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.ButtonImage")));
            this.btnSearch.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSearch.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSearch.ImageSize = 50;
            this.btnSearch.Location = new System.Drawing.Point(529, 62);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(85, 64);
            this.btnSearch.TabIndex = 45;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSelect.ButtonImage")));
            this.btnSelect.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSelect.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSelect.ImageSize = 50;
            this.btnSelect.Location = new System.Drawing.Point(531, 432);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(85, 56);
            this.btnSelect.TabIndex = 56;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSelect.UseSelectable = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonCancel.ButtonImage")));
            this.buttonCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonCancel.ImageSize = 50;
            this.buttonCancel.Location = new System.Drawing.Point(622, 432);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(85, 56);
            this.buttonCancel.TabIndex = 55;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCancel.UseSelectable = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // ProductionOrderSearchView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 497);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.dtpImportedTo);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dtpImportedFrom);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.metroLabel1);
            this.Name = "ProductionOrderSearchView";
            this.Text = "Production Order";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.olvProductionOrders)).EndInit();
            this.metroToolStrip1.ResumeLayout(false);
            this.metroToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroDateTime dtpImportedTo;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroDateTime dtpImportedFrom;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private UIHelper.DataListView olvProductionOrders;
        private BrightIdeasSoftware.OLVColumn olvColumnPOrderNo;
        private BrightIdeasSoftware.OLVColumn olvColumnPOrderDate;
        private BrightIdeasSoftware.OLVColumn olvColumnMovementType;
        private BrightIdeasSoftware.OLVColumn olvColumnStatus;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private MetroFramework.MyCustomControl.MetroToolStrip metroToolStrip1;
        private System.Windows.Forms.ToolStripButton btnNext;
        private System.Windows.Forms.ToolStripLabel lblRecords;
        private System.Windows.Forms.ToolStripButton btnPrevious;
        private UIHelper.ButtonSearch btnSearch;
        private UIHelper.ButtonSave btnSelect;
        private UIHelper.ButtonCancel buttonCancel;
    }
}