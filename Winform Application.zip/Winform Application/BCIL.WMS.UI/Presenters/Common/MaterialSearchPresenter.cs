﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialSearchPresenter : Presenter<IMaterialSearchView>
    {
        #region Constructor

        public MaterialSearchPresenter(IMaterialSearchView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialSearchModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PreviousPageResultsRequested += View_PreviousPageResultsRequested;
        }

        #endregion Constructor

        #region Private Events

        private void DoRefresh()
        {
            View.Model.SearchedMaterials = MaterialDVL.GetMaterialDVL(View.Model.SearchCriteria);
            View.RefreshResults();
        }

        private void View_PreviousPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshResults();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshResults();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.BindHeader();
                View.RefreshResults();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}