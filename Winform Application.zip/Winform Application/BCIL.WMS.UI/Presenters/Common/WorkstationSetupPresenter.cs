﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Models.Common;
using BCIL.WMS.UI.Views.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class WorkstationSetupPresenter : Presenter<IWorkstationSetupView>
    {
        public WorkstationSetupPresenter(IWorkstationSetupView view) : base(view)
        {
            if (View.Model == null) View.Model = new WorkstationSetupModel();
            view.Load += View_Load;
            view.LocationChangeRequested += View_LocationChangeRequested;
        }

        private void View_LocationChangeRequested(object sender, long locationId)
        {
            try
            {
                var criteria = new LinesSearchCriteria() { LocationId = locationId };
                Lines lines = Lines.GetLines(criteria);
                View.Model.Lines = new List<Line>();
                View.Model.Lines.Add(new Line() { LineId = -1, Code = "None" });
                View.Model.Lines.AddRange(lines.ToList());

                View.BindLines();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                LocationDVL locations = LocationDVL.GetLocationDVL(new LocationDVLSearchCriteria() { SiteId = App.Login.LoginSite.SiteId, Type = 4 });
                View.Model.Locations = new List<Location>();
                var loc = Location.NewLocation();
                loc.LocationId = -1;
                loc.LocationCode = "None";
                View.Model.Locations.Add(loc);
                View.Model.Locations.AddRange(locations.ToList());

                View.BindUI();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}