﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ProductionOrderSearchPresenter : Presenter<IProductionOrderSearchView>
    {
        #region Constructor

        public ProductionOrderSearchPresenter(IProductionOrderSearchView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ProductionOrderSearchModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PreviousPageResultsRequested;
        }

        #endregion Constructor

        #region Private Events

        private void DoRefresh()
        {
            var dataList= ProductionOrderDVL.GetProductionOrderDVL(View.Model.SearchCriteria);
            View.Model.ProductionOrders = dataList.Where(x => x.Status == BL.Enums.ProductionOrderStatus.New).ToList();
            View.RefreshGrid();
        }

        private void View_PreviousPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.CreatedFrom = DateTime.Today.AddDays(-7).Date;
                View.Model.SearchCriteria.CreatedTo = DateTime.Today.Date;
                View.BindHeader();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}