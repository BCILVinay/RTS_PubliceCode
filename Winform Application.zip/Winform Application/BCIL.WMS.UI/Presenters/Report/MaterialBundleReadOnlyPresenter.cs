﻿using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialBundleReadOnlyPresenter: Presenter<IMaterialBundleReadOnlyView>
    {
        public MaterialBundleReadOnlyPresenter(IMaterialBundleReadOnlyView view):base(view)
        {

        }
    }
}
