﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialStockListPresenter : Presenter<IMaterialStockListView>
    {
        #region Constructor

        public MaterialStockListPresenter(IMaterialStockListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialStockListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.BundleViewRequested += View_BundleViewRequested;
            view.ExportDataRequested += View_ExportDataRequested;
        }

        #endregion Constructor

        #region Private Method

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull())
            {
                View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
            }
            View.Model.MaterialStocks = MaterialStocks.GetMaterialStocks(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void ExportToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();

            fileDialog.AddExtension = true;
            fileDialog.Filter = "CSV|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                BCIL.Utility.FileHandling.FileWriter writer = new BCIL.Utility.FileHandling.FileWriter();
                writer.WriteFile(fileDialog.FileName, View.Model.MaterialStocks.Select(x => new { Location = x.Location.Value, Material = x.Material.Value, MaterialDesc = x.MaterialDesc, BundleQty = x.BundleQty }).ToList());

                View.ShowMessage("File saved successfully");
            }
        }

        #endregion Private Method

        #region Private Events

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_ExportDataRequested(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<ArgumentException>(View.Model.MaterialStocks.IsNotNull(), "Nothing to export.");
                ExportToExcel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_BundleViewRequested(object sender, BL.MaterialStock materialStock)
        {
            try
            {
                MaterialBundleReadOnlyView view = new MaterialBundleReadOnlyView(materialStock);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events

    }
}