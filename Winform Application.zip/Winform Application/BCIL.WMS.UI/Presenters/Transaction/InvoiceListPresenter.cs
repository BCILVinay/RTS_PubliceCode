﻿using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class InvoiceListPresenter : Presenter<IInvoiceListView>
    {
        #region Constructor

        public InvoiceListPresenter(IInvoiceListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.InvoiceListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.PrintRequested += View_PrintRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            View.Model.InvoiceList = Invoices.GetInvoices(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
        private void View_PrintRequested(object sender, Invoice invoice)
        {
            try
            {
                var prn = Prn.GetPrn(PrnType.Invoice);
                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{InvoiceNo}", invoice.InvoiceNo);

                    string dataToPrint = prn.PrnTemplate;

                    //replace values here
                    if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                    var label = Label.NewLabel();
                    label.LabelCode = invoice.InvoiceNo;
                    label.LabelObjType = BL.Enums.LabelType.Invoice;
                    label.LableObjTypeId = invoice.InvoiceId;
                    label.SiteId = App.Login.LoginSite.SiteId;
                    label.LocationId = (App.WorkStation.WMaterialBination.IsNotNull()) ? App.WorkStation.WMaterialBination.LocationId : 0;
                    label.CreatedBy = App.Login.Employee.EmployeeId;
                    label.CreatedOn = DateTime.Now;
                    label.Save();
                    View.ShowMessage("Invoice is printed");
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
        #endregion Private Events
    }
}