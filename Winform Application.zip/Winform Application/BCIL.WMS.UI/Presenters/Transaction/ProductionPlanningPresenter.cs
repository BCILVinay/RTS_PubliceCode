﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ProductionPlanningPresenter : Presenter<IProductionPlanningView>
    {
        public ProductionPlanningPresenter(IProductionPlanningView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ProductionPlanningModel();
            View.Model.ProductionPlanning.LineItems = new ProductionPlanningItems();
            view.Load += View_Load;
            view.SelectProductionOrderReq += View_SelectProductionOrderReq;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        private bool Save()
        {
            CodeContract.Required<BCILException>(View.Model.ProductionPlanning.PlanningNo.IsNotNullOrWhiteSpace(), "Planning no is required");
            CodeContract.Required<BCILException>(View.Model.ProductionPlanning.LineItems.HaveItems(), "Atleast one production order");
            CodeContract.Required<BCILException>(View.Model.ProductionPlanning.LineItems.Any(x => x.Tooling > 0), "Tooling is required");
            CodeContract.Required<BCILException>(View.Model.ProductionPlanning.LineItems.Any(x => x.Material.Key > 0), "Material is required");
            CodeContract.Required<BCILException>(View.Model.ProductionPlanning.LineItems.Any(x => x.LinePrefence > 0), "Line prefence is required");

            if (View.Model.ProductionPlanning.IsValid)
            {
                View.Model.ProductionPlanning.SiteId = App.Login.LoginSite.SiteId;
                View.Model.ProductionPlanning.PlannedOn = DateTime.Now;
                View.Model.ProductionPlanning.CreatedBy = App.Login.Employee.EmployeeId;
                View.Model.ProductionPlanning.UpdatedBy = App.Login.Employee.EmployeeId;
                View.Model.ProductionPlanning.PlannedBy = App.Login.Employee.EmployeeId;
                View.Model.ProductionPlanning.ApplyEdits();
                try
                {
                    View.Model.ProductionPlanning = View.Model.ProductionPlanning.Save();
                    View.RefreshBinding();
                    //BcilLogger.WriteMessage(LogLevel.Info, "Production planning data :" + Serializer.Json.Serialize(View.Model.ProductionPlanning).ToString() + " saved.");
                    return true;
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                    return false;
                }
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.ProductionPlanning.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.ProductionPlanning == null || View.Model.ProductionPlanning.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.ProductionPlanning.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Production Planning saved.");

                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Production Planning saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SelectProductionOrderReq(object sender, EventArgs e)
        {
            try
            {
                ProductionOrderSearchView searchView = new ProductionOrderSearchView();
                searchView.MultiItemSelect = false;

                if (searchView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    if (searchView.SelectedItems.HaveItems())
                    {
                        var poObj = searchView.SelectedItems[0];
                        if (!View.Model.SelectedPOrders.Exists(x => x.POrderId == poObj.POrderId))
                        {
                            foreach (var item in poObj.POLineItems)
                            {
                                var materialObj = Material.GetMaterial(item.Material.Key);
                                var obj = ProductionPlanningItem.NewChildProductionPlanningItem();
                                obj.Material = item.Material;
                                obj.Po = new Utility.KeyValue<long, string>(item.PO.Key, item.PO.Value);
                                obj.Quantity = item.BundleQty;
                                obj.ProductionStartOn = DateTime.Now;
                                //calculated field
                                decimal lineSpeed = 1;
                                var line = View.Model.Lines.FirstOrDefault(x => x.LineId == item.PPLine);
                                if (line != null && line.Speed > 0)
                                    lineSpeed = line.Speed;
                                obj.Output = obj.AvailableHours * lineSpeed;
                                obj.ReqShiftHours = item.Length / lineSpeed;
                                obj.PacksNo = Convert.ToInt32(materialObj.PackSize / materialObj.BundleTotalLengthInMtrs);
                                View.Model.ProductionPlanning.LineItems.Add(obj);
                            }
                        }
                        View.Model.SelectedPOrders.AddRange(searchView.SelectedItems);
                    }
                    View.RefreshBinding();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                if (View.Model.ProductionPlanning.PlanningNo.IsNullOrWhiteSpace())
                {
                    View.Model.ProductionPlanning.PlanningNo = CodeCommand.GetNextCode(ObjectType.ProductionPlanning, App.Login.LoginSite.SiteId);
                }

                GetDefaultData();
                if (View.Model.ProductionPlanning.LineItems.HaveItems())
                {
                    View.RefreshBinding();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void GetDefaultData()
        {
            var toolingList = ToolingDVL.GetToolingDVL();
            if (toolingList.HaveItems())
            {
                foreach (var item in toolingList)
                {
                    View.Model.Toolings.Add(new KeyValue<long, string>(item.ToolingId, item.ToolingCode));
                }
            }

            var MaterialBinList = MaterialBinDVL.GetMaterialBinDVL(new MaterialBinDVLSearchCriteria() { PageSize = 100, PageNumber = 1, MaterialBinName = "", LocationCode = "" });
            if (MaterialBinList.HaveItems())
            {
                foreach (var item in MaterialBinList)
                {
                    View.Model.MaterialBins.Add(new KeyValue<long, string>(item.MaterialBinId, item.MaterialBinCode));
                }
            }

            var criteria = new LinesSearchCriteria() { SiteId = App.Login.LoginSite.SiteId };
            var lines = Lines.GetLines(criteria);
            if (lines.HaveItems())
            {
                View.Model.Lines.AddRange(lines);
                foreach (var item in lines)
                {
                    View.Model.LinePrefences.Add(new KeyValue<int, string>(item.LineId, item.Code));
                }
            }
        }
    }
}