﻿using BCIL.WMS.UI.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ReceivingPresenter : Presenter<IReceivingView>
    {
        public ReceivingPresenter(IReceivingView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ReceivingModel();
            view.Load += View_Load;
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
               
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}