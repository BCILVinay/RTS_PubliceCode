﻿using BCIL.WMS.UI.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class PickListDetailPresenter : Presenter<IPickListDetailView>
    {
        public PickListDetailPresenter(IPickListDetailView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.PickListDetailModel();
            view.Load += View_Load;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
        }

        private void DoRefresh()
        {
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                // DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                // DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.BindingHeader();
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}