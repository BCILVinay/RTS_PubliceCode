﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class DashboardPresenter : Presenter<IDashboardView>
    {
        public DashboardPresenter(IDashboardView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.DashboardModel();
            view.Load += View_Load;
            view.RefreshDashboardRequested += View_RefreshDashboardRequested;
        }

        private void View_RefreshDashboardRequested(object sender, EventArgs e)
        {
            try
            {
                GetDashboardData();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                GetDashboardData();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void GetDashboardData()
        {
            View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
            View.Model.BundlePutawayData = Dashboard.GetPutawayData(View.Model.SearchCriteria, DashboardDataType.Putaway);
            View.Model.BundlePickedData = Dashboard.GetPickingData(View.Model.SearchCriteria, DashboardDataType.Picked);
            View.Model.ProductionData = Dashboard.GetProductionData(View.Model.SearchCriteria, DashboardDataType.Production);
            View.RefreshGrid();
        }
    }
}
