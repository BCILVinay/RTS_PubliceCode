﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class SapLogListPresenter : Presenter<ISapLogListView>
    {
        public SapLogListPresenter(ISapLogListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.SapLogListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.ShowSapPostingLogRequested += View_ShowSapPostingLogRequested;
        }

        private void View_ShowSapPostingLogRequested(object sender, SapPostingLog log)
        {
            try {
                View.ShowSapLogView(log);
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try {
                DoRefresh();
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull()) { View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId; }
            View.Model.SapPostingLogs = SapPostingLogs.GetSapPostingLogs(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_Load(object sender, EventArgs e)
        {
            try {
                View.Model.SearchCriteria.FromDate = DateTime.Today.Date; ;
                View.Model.SearchCriteria.ToDate = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }
    }
}
