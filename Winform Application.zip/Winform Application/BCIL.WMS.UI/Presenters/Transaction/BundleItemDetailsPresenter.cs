﻿using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class BundleItemDetailsPresenter : Presenter<IBundleItemDetailsView>
    {
        public BundleItemDetailsPresenter(IBundleItemDetailsView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.BundleItemDetailsModel();
            view.Load += View_Load;
            view.RePrintRequested += View_RePrintRequested;
        }

        private void View_RePrintRequested(object sender, BL.Item item)
        {
            try
            {
                //{BundleItemCode}
                var prn = Prn.GetPrn(PrnType.Item);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{ItemCode}", item.ItemCode);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", item.Material.Value);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{CreatedOn}", item.CreatedOn.ToString("dd-MM-yyyy"));

                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();
                    string dataToPrint = prn.PrnTemplate;
                    //replace values here
                    if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                    var label = BL.Label.NewLabel();
                    label.LabelCode = item.ItemCode;
                    label.LabelObjType = BL.Enums.LabelType.Bundle;
                    label.LableObjTypeId = item.ItemId;
                    label.SiteId = App.Login.LoginSite.SiteId;
                    label.LocationId = item.Location.Key;
                    label.CreatedBy = App.Login.Employee.EmployeeId;
                    label.CreatedOn = DateTime.Today.Date;
                    label.Save();
                    View.ShowMessage("Label is printed");
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}