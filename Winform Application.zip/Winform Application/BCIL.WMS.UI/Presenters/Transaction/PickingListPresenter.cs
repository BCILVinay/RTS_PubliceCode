﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class PickingListPresenter : Presenter<IPickingListView>
    {
        #region Constructor

        public PickingListPresenter(IPickingListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.PickingListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.DetailViewRequested += View_DetailViewRequested;
            view.ExportDataRequested += View_ExportDataRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_ExportDataRequested(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<ArgumentException>(View.Model.PickingList.IsNotNull(), "Nothing to export.");
                ExportToExcel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_DetailViewRequested(object sender, Picklist e)
        {
            try
            {
                PickListDetailView view = new PickListDetailView(e);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull())
            {
                View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
            }
            View.Model.PickingList = Picklists.GetPicklists(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void ExportToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();

            fileDialog.AddExtension = true;
            fileDialog.Filter = "CSV|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                BCIL.Utility.FileHandling.FileWriter writer = new BCIL.Utility.FileHandling.FileWriter();
                writer.WriteFile(fileDialog.FileName, View.Model.PickingList.Select(x => new { DeliveryNo = x.DeliveryNo, Transporter = x.Transporter, LRNo = x.LRNo, TruckNo = x.TruckNo, Status = x.Status, CreatedOn = x.CreatedOn.ToString(App.DateFormat) }).ToList());

                View.ShowMessage("File saved successfully");
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}