﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ProductionPlanningListPresenter : Presenter<IProductionPlanningListView>
    {
        #region Constructor

        public ProductionPlanningListPresenter(IProductionPlanningListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ProductionPlanningListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.AddNewRequested += View_AddNewRequested;
            view.EditRequested += View_EditRequested;
        }

        #endregion Constructor

        #region Private Events

        private void DoRefresh()
        {
            View.Model.ProductionPlannings = PoPlanningReadOnlyList.GetPoPlanningReadOnlyList(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PlannedFrom = DateTime.Today.AddDays(-7).Date;
                View.Model.SearchCriteria.PlannedTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditRequested(object sender, ProductionPlanning e)
        {
            try
            {
                ProductionPlanningView view = new ProductionPlanningView(e);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_AddNewRequested(object sender, EventArgs e)
        {
            try
            {
                ProductionPlanningView view = new ProductionPlanningView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}