﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class TransferListPresenter : Presenter<ITransferListView>
    {
        public TransferListPresenter(ITransferListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.TransferListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.TransferViewRequested += View_TransferViewRequested;
        }

        private void DoRefresh()
        {
            View.Model.Transfers = Transfers.GetTransfers(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_TransferViewRequested(object sender, Transfer transfer)
        {
            try
            {
                TransferDetailView view = new TransferDetailView(transfer);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}