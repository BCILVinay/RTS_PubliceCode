﻿using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ItemListPresenter : Presenter<IItemListView>
    {
        #region Constructor

        public ItemListPresenter(IItemListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ItemListModel();
            view.Load += View_Load;
            view.ExportDataRequested += View_ExportDataRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.SearchRequested += View_SearchRequested;
            view.RePrintRequested += View_RePrintRequested;
        }

        #region Method

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull())
            {
                View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
            }
            View.Model.Items = Items.GetItemsByCriteria(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void ExportToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();

            fileDialog.AddExtension = true;
            fileDialog.Filter = "CSV|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                BCIL.Utility.FileHandling.FileWriter writer = new BCIL.Utility.FileHandling.FileWriter();
                writer.WriteFile(fileDialog.FileName, View.Model.Items.Select(x => new { BundleCode = x.ItemCode, Material = x.Material.Value, Tooling = x.Tooling.Value, CreatedOn = x.CreatedOn.ToString(App.DateFormat) }).ToList());

                View.ShowMessage("File saved successfully");
            }
        }

        #endregion Method

        #endregion Constructor

        #region Private Events

        private void View_RePrintRequested(object sender, BL.Item item)
        {
            try
            {
                //{BundleItemCode}
                var prn = Prn.GetPrn(PrnType.Item);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{ItemCode}", item.ItemCode);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", item.Material.Value);
                prn.PrnTemplate = prn.PrnTemplate.Replace("{CreatedOn}", item.CreatedOn.ToString("dd-MM-yyyy"));

                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();
                    string dataToPrint = prn.PrnTemplate;
                    //replace values here
                    if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                    var label = BL.Label.NewLabel();
                    label.LabelCode = item.ItemCode;
                    label.LabelObjType = BL.Enums.LabelType.Bundle;
                    label.LableObjTypeId = item.ItemId;
                    label.SiteId = App.Login.LoginSite.SiteId;
                    label.LocationId = item.Location.Key;
                    label.CreatedBy = App.Login.Employee.EmployeeId;
                    label.CreatedOn = DateTime.Today.Date;
                    label.Save();
                    View.ShowMessage("Label is printed");
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_ExportDataRequested(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<ArgumentException>(View.Model.Items.IsNotNull(), "Nothing to export.");
                ExportToExcel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}