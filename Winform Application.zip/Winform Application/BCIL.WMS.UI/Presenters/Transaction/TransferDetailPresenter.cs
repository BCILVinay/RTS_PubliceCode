﻿using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class TransferDetailPresenter: Presenter<ITransferDetailView>
    {
        public TransferDetailPresenter(ITransferDetailView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.TransferDetailModel();
            view.Load += View_Load;
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {

                View.ShowException(ex);
            }
        }
    }
}
