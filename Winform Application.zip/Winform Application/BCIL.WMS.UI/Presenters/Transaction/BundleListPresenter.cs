﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class BundleListPresenter : Presenter<IBundleListView>
    {
        #region Constructor

        public BundleListPresenter(IBundleListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.BundleListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.RePrintRequested += View_RePrintRequested;
            view.BundleItemViewRequested += View_BundleItemViewRequested;
            view.ExportDataRequested += View_ExportDataRequested;
            view.POConfirmationPostingRequested += View_POConfirmationPostingRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_ExportDataRequested(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<ArgumentException>(View.Model.Bundles.IsNotNull(), "Nothing to export.");
                ExportToExcel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull())
            {
                View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
                View.Model.SearchCriteria.LineId = (App.WorkStation.WSLine.IsNotNull()) ? App.WorkStation.WSLine.LineId : 0;
            }
            View.Model.Bundles = Bundles.GetBundleByCriteria(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void ExportToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();

            fileDialog.AddExtension = true;
            fileDialog.Filter = "CSV|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                BCIL.Utility.FileHandling.FileWriter writer = new BCIL.Utility.FileHandling.FileWriter();
                writer.WriteFile(fileDialog.FileName, View.Model.Bundles.Select(x => new { BundleCode = x.BundleCode, ProductionOrder = x.Po, Material = x.Material.Value, Tooling = x.Tooling.Value, Status = x.Status, CreatedOn = x.CreatedOn.ToString(App.DateFormat) }).ToList());

                View.ShowMessage("File saved successfully");
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_BundleItemViewRequested(object sender, Bundle bundle)
        {
            try
            {
                BundleItemDetailsView view = new BundleItemDetailsView(bundle);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_RePrintRequested(object sender, List<Bundle> bundleList)
        {
            try
            {
                foreach (var bundle in bundleList)
                {
                    var prn = Prn.GetPrn(PrnType.Bundle);

                    var _po = ProductionOrder.GetProductionOrder(bundle.Po.Key);
                    var _material = Material.GetMaterial(bundle.Material.Key);

                    prn.PrnTemplate = prn.PrnTemplate.Replace("{Date}", bundle.CreatedOn.ToString("dd-MM-yyyy"));
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{LineNo}", App.WorkStation.WSLine.Code);
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{PackNo}", string.Format("{0}/{1}", bundle.BundleSrNo, _po.POLineItems.FirstOrDefault(x => x.Material.Key == bundle.Material.Key).BundleQty));
                    //Below {PackSize} value for Pcs/Mr
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{PcsMtr}", string.Format("{0}/{1:0.00}", _material.PackSize, _material.StdBarLength * _material.PackSize));
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{TotalWeight}", string.Format("{0:0.00} {1}", _material.BundleTotalWeight, "Kg"));
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{BundleCode}", bundle.BundleCode);
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", bundle.Material.Value);
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{Tooling}", bundle.Tooling.Value);
                    prn.PrnTemplate = prn.PrnTemplate.Replace("{MaterialImagePrn}", _material.MaterialImagePrn);

                    using (var printingManager = PrintFactory.GetManager())
                    {
                        var printer = printingManager.GetProvider<IPrinterFactory>();
                        string dataToPrint = prn.PrnTemplate;
                        //replace values here
                        if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                        var label = BL.Label.NewLabel();
                        label.LabelCode = bundle.BundleCode;
                        label.LabelObjType = BL.Enums.LabelType.Bundle;
                        label.LableObjTypeId = bundle.BundleId;
                        label.SiteId = App.Login.LoginSite.SiteId;
                        label.LocationId = bundle.Location.Key;
                        label.CreatedBy = App.Login.Employee.EmployeeId;
                        label.CreatedOn = DateTime.Today.Date;
                        label.Save();
                    }
                }

                View.ShowMessage("Label is printed");
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_POConfirmationPostingRequested(object sender, Bundle bundle)
        {
            try
            {
                CodeContract.Required<BCILException>(bundle.IsNotNull() && bundle.BundleId > 0, "Bundle is mandatory");
                CodeContract.Required<BCILException>(bundle.IsConfirmed == false, "Bundle is already confirmed");
                var _bundleIds = new List<Int64>();
                _bundleIds.Add(bundle.BundleId);
                CodeContract.Required<BCILException>(_bundleIds.HaveItems(), "Bundle is mandatory");
                var poConfirmationObj = new PoConfirmation() { PlantCode = App.Login.LoginSite.SiteCode, PoId = bundle.Po.Key, Bundles = _bundleIds, ConfirmBy = App.Login.Employee.EmployeeId };
                HttpHelper.Headers.Add(new KeyValue<string, string>("SiteId", App.Login.LoginSite.SiteId.ToString()));
                var status = HttpHelper.Post<string, PoConfirmation>(ServiceUri.ConfirmPO, poConfirmationObj, App.Login.User.LogInUser, App.Login.User.LogInPassword);
                if (status == "Success")
                {
                    View.ShowMessage("Bundle confirmed successfully");
                }
                else
                {
                    View.ShowException("Bundle Confirmation failed");
                }
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }

    [DataContract]
    public class PoConfirmation
    {
        [DataMember]
        public string PlantCode { get; set; }

        [DataMember]
        public Int64 PoId { get; set; }

        [DataMember]
        public List<Int64> Bundles { get; set; }

        [DataMember]
        public int ConfirmBy { get; set; }
    }
}