﻿using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class RecevingListPresenter : Presenter<IRecevingListView>
    {
        public RecevingListPresenter(IRecevingListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.RecevingListModel();
            view.Load += View_Load;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.ExportDataRequested += View_ExportDataRequested;
            view.ReceivingViewRequested += View_ReceivingViewRequested;
        }

        private void View_ReceivingViewRequested(object sender, Receiving receiving)
        {
            try
            {
                ReceivingView view = new ReceivingView(receiving);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ExportDataRequested(object sender, EventArgs e)
        {
            try
            {
                CodeContract.Required<ArgumentException>(View.Model.Receivings.IsNotNull(), "Nothing to export.");
                CodeContract.Required<ArgumentException>(View.Model.Receivings.HaveItems(), "Nothing to export.");
                ExportToExcel();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void ExportToExcel()
        {
            SaveFileDialog fileDialog = new SaveFileDialog();

            fileDialog.AddExtension = true;
            fileDialog.Filter = "CSV|*.csv";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                BCIL.Utility.FileHandling.FileWriter writer = new BCIL.Utility.FileHandling.FileWriter();
                writer.WriteFile(fileDialog.FileName, View.Model.Receivings.Select(x => new { DeliveryNo = x.DeliveryNo, InvoiceNo = x.InvoiceNo, ReceivedOn = x.ReceivedOn.ToString(App.DateFormat) }).ToList());

                View.ShowMessage("File saved successfully");
            }
        }

        private void DoRefresh()
        {
            View.Model.Receivings = Receivings.GetReceivings(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.DateFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.DateTo = DateTime.Today.Date;
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}