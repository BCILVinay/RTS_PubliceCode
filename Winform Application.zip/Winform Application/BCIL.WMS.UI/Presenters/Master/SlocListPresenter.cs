﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialBinListPresenter : Presenter<IMaterialBinListView>
    {
        #region Constructor

        public MaterialBinListPresenter(IMaterialBinListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialBinListModel();
            view.Load += View_Load;
            view.AddMaterialBinRequested += View_AddMaterialBinRequested;
            view.EditMaterialBinRequested += View_EditMaterialBinRequested;
            view.ImportDataRequested += View_ImportDataRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.SearchRequested += View_SearchRequested;
            view.PrintRequested += View_PrintRequested;
        }

        #endregion Constructor

        #region Private Events

        private void DoRefresh()
        {
            View.Model.MaterialBins = MaterialBinDVL.GetMaterialBinDVL(View.Model.SearchCriteria);
            View.RefreshBinding();
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.BindingHeader();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_AddMaterialBinRequested(object sender, EventArgs e)
        {
            try
            {
                MaterialBinView view = new MaterialBinView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditMaterialBinRequested(object sender, MaterialBin MaterialBin)
        {
            try
            {
                MaterialBinView view = new MaterialBinView(MaterialBin);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var IsProcessDone = ImportMaterialBin();
                if (IsProcessDone)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool ImportMaterialBin()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                  { "MaterialBinCode", true }, { "RackNo", true },   { "RowNo", true },  { "ColumnNo", true }
                ,  { "Height", true },  { "Width", true } ,  { "MaterialCode", true }, {"LocationCode",true }, {"Capacity",true }
            };
            ImportView view = new ImportView();
            view.Text = "Import Material Bin";
            view.TemplateDataSet = new Template().GetImportMaterialBinTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "MaterialBinCode", "Height", "Width", "MaterialCode");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable slotTable = dtToImport.DefaultView.ToTable(true);

                    foreach (DataRow MaterialBinRow in slotTable.Rows)
                    {
                        try
                        {
                            var materialData = Material.GetMaterialByCode(MaterialBinRow["MaterialCode"].ToString());
                            var _location = Location.GetLocationByCode(MaterialBinRow["LocationCode"].ToString());
                            CodeContract.Required<BCILException>(_location.IsNotNull() && _location.LocationId > 0, "Location is invalid");
                            if (materialData.IsNotNull() && materialData.MaterialId > 0)
                            {
                                var MaterialBin = BL.MaterialBin.NewMaterialBin();
                                MaterialBin.MaterialBinCode = MaterialBinRow["MaterialBinCode"].ToString();
                                MaterialBin.MaterialBinName = MaterialBinRow["MaterialBinCode"].ToString();
                                MaterialBin.RackNo = MaterialBinRow["RackNo"].ToString();
                                MaterialBin.RowNo = MaterialBinRow["RowNo"].ToString();
                                MaterialBin.ColumnNo = MaterialBinRow["ColumnNo"].ToString();
                                MaterialBin.Height = Convert.ToDecimal(MaterialBinRow["Height"].ToString());
                                MaterialBin.Width = Convert.ToDecimal(MaterialBinRow["Width"].ToString());
                                MaterialBin.Material = new KeyValue<Int64, string>() { Key = materialData.MaterialId, Value = materialData.MaterialCode };
                                MaterialBin.Location = new KeyValue<long, string>() { Key = _location.LocationId, Value = _location.LocationCode };
                                MaterialBin.Capacity = Convert.ToInt32(MaterialBinRow["Capacity"].ToString());
                                MaterialBin.CreatedOn = DateTime.Now;
                                MaterialBin.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                MaterialBin.UpdatedOn = DateTime.Now;
                                MaterialBin.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                MaterialBin.IsActive = true;
                                if (MaterialBin.IsValid)
                                {
                                    MaterialBin.Save();
                                }
                                else
                                {
                                    throw new Exception(string.Join("\n", MaterialBin.BrokenRulesCollection.Select(x => x.Description)));
                                }
                            }
                            else
                            {
                                throw new Exception(string.Format("Material Code is invalid {0}", MaterialBinRow["MaterialCode"].ToString()));
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("MaterialBinCode='{0}'", MaterialBinRow["MaterialBinCode"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };

            view.ShowDialog(App.Shell);
            return true;
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_PrintRequested(object sender, List<MaterialBin> materialBinList)
        {
            try
            {
                foreach (var materialBin in materialBinList)
                {
                    var prn = Prn.GetPrn(PrnType.Location);
                    using (var printingManager = PrintFactory.GetManager())
                    {
                        var printer = printingManager.GetProvider<IPrinterFactory>();
                        var location = Location.GetLocation(materialBin.Location.Key);
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{LocationCode}", materialBin.MaterialBinCode);
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{PlantCode}", App.Login.LoginSite.SiteCode);
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{Type}", location.Type.DisplayName());
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{Mode}", location.Mode.DisplayName());
                        string dataToPrint = prn.PrnTemplate;

                        //replace values here
                        if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                        var label = BL.Label.NewLabel();
                        label.LabelCode = materialBin.MaterialBinCode;
                        label.LabelObjType = BL.Enums.LabelType.MaterialBin;
                        label.LableObjTypeId = location.LocationId;
                        label.SiteId = App.Login.LoginSite.SiteId;
                        label.LocationId = materialBin.MaterialBinId;
                        label.CreatedBy = App.Login.Employee.EmployeeId;
                        label.CreatedOn = DateTime.Now;
                        label.Save();
                    }
                }
                View.ShowMessage("Label is printed");
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}