﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class BundleLabelPrintPresenter : Presenter<IBundleLabelPrintView>
    {
        #region Constructor

        private Dictionary<Int64, Material> m_Materials = null;

        public BundleLabelPrintPresenter(IBundleLabelPrintView view) : base(view)
        {
            if (view.Model == null)
                view.Model = new Models.BundleLabelPrintModel();
            view.Load += View_Load;
            view.SavePrintRequested += View_SavePrintRequested;
            view.CancelRequested += View_CancelRequested;
        }

        #endregion Constructor

        #region Methods

        private bool BundleLabelPrint()
        {
            ProductionOrder po = View.Model.POrder;
            Bundles bundles = null;
            ProgressView pview = new ProgressView(App.Shell);
            pview.DoWork = (backgroudEvent) =>
            {
                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();

                    bundles = Bundles.GetBundleById(new BundleSearchCriteriaByPo() { POrderId = po.POrderId, SiteId = App.Login.LoginSite.SiteId });

                    pview.TotalRecords = View.Model.TotalBundleQty - View.Model.TotalPrintedBundleQty;

                    int totalbundlePrinted = 0;

                    m_Materials = MaterialDVL.GetMaterialDVLByIds(po.POLineItems.Select(x => x.Material.Key).ToList()).ToDictionary(z => z.MaterialId);
                    foreach (var poItem in po.POLineItems)
                    {
                        var bundlesToPrint = View.Model.QtyToPrint;
                        var printedBundles = 0;

                        if (printedBundles <= bundlesToPrint)
                        {
                            bundles.IsLabelPrinted = true;
                            for (int i = 0; i < bundlesToPrint; i++)
                            {
                                View.Model.TotalPrintedBundleQty = View.Model.TotalPrintedBundleQty + 1;
                                View.Model.LastPrintedSrNo = View.Model.LastPrintedSrNo + 1;
                                var bundle = Bundle.NewBundle();
                                bundle.BundleSrNo = View.Model.LastPrintedSrNo;
                                bundle.BundleCode = CodeCommand.GetNextCode(ObjectType.Bundle, App.Login.LoginSite.SiteId);
                                bundle.Po = new KeyValue<long, string>(po.POrderId, "");
                                bundle.Material = new KeyValue<long, string>(poItem.Material.Key, "");
                                bundle.Qty = m_Materials[poItem.Material.Key].PackSize;
                                bundle.Location = poItem.Location;
                                bundle.Tooling = m_Materials[poItem.Material.Key].Tooling;
                                bundle.CreatedOn = DateTime.Now;
                                bundle.CreatedBy = App.Login.Employee.EmployeeId;
                                bundle.UpdatedOn = DateTime.Now;
                                bundle.UpdatedBy = App.Login.Employee.EmployeeId;
                                bundles.Add(bundle);
                                ++printedBundles;

                                var prn = Prn.GetPrn(PrnType.Bundle);
                                var _material = Material.GetMaterial(bundle.Material.Key);
                                var _toolingDetails = Tooling.GetTooling(bundle.Tooling.Key);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Date}", bundle.CreatedOn.ToString("dd-MM-yyyy"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{LineNo}", App.WorkStation.WSLine.Code);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PackNo}", string.Format("{0}/{1}", bundle.BundleSrNo, po.POLineItems.FirstOrDefault(x => x.Material.Key == bundle.Material.Key).BundleQty));
                                //Below {PackSize} value for Pcs/Mr
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PcsMtr}", string.Format("{0}/{1:0.00}", _material.PackSize, _material.StdBarLength * _material.PackSize));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{TotalWeight}", string.Format("{0:0.00} {1}", _material.BundleTotalWeight, "Kg"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{BundleCode}", bundle.BundleCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", _material.MaterialCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Tooling}", string.Format("{0}{1}", _toolingDetails.ToolingCode, _toolingDetails.OtherInfo));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{MaterialImagePrn}", _material.MaterialImagePrn);

                                string dataToPrint = prn.PrnTemplate;
                                if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                                backgroudEvent.DoWorkEventArgs.Result = string.Format("Total printed labels: {0}.", ++totalbundlePrinted);
                                backgroudEvent.ReportProgress(0);
                            }
                        }
                    }
                }
            };

            pview.OnProgressChanged = (o) =>
            {
                if (o.UserState != null)
                    return Convert.ToString(((DoWorkEventArgs)o.UserState).Result);
                else return "Printing is in progress";
            };

            pview.RunWorkerCompleted = (o) =>
            {
                try
                {
                    if (o.IsNotNull() && o.Error.IsNotNull()) throw o.Error;

                    if (!bundles.IsValid) throw new BCILException(string.Join(Environment.NewLine, bundles.SelectMany(x => x.BrokenRulesCollection.Select(y => y.Description))));

                    bundles.Save();
                    if (View.Model.TotalBundleQty == View.Model.TotalPrintedBundleQty)
                    {
                        po.Status = ProductionOrderStatus.BundlePrinted;
                        po.ConfirmedOn = SqlDateTime.MinValue.Value;
                        po.Save();
                    }
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                }
            };

            pview.Run(null);

            return true;
        }

        #endregion Methods

        #region Event's Methods

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                View.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                View.ShowException(ex.Message);
            }
        }

        private void View_SavePrintRequested(object sender, EventArgs e)
        {
            try
            {
                if (View.Model.QtyToPrint == 0)
                {
                    View.ShowException("Print quantity should be greater than zero");
                    return;
                }
                if (View.Model.QtyToPrint > (View.Model.TotalBundleQty - View.Model.TotalPrintedBundleQty))
                {
                    View.ShowException("Print quantity should not be greater than " + (View.Model.TotalBundleQty - View.Model.TotalPrintedBundleQty) + "");
                    return;
                }

                if (BundleLabelPrint()) { View.DialogResult = DialogResult.OK; };
            }
            catch (TargetInvocationException ex)
            {
                View.ShowException(ex.InnerException);
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                var bundles = Bundles.GetBundleById(new BundleSearchCriteriaByPo() { POrderId = View.Model.POrder.POrderId, SiteId = App.Login.LoginSite.SiteId });
                View.Model.TotalPrintedBundleQty = Convert.ToInt32(bundles.TotalRowCount);
                View.Model.TotalBundleQty = View.Model.POrder.POLineItems.Sum(x => x.BundleQty);
                View.Model.LastPrintedSrNo = (bundles.HaveItems()) ? bundles.Max(x => x.BundleSrNo) : 0;
                View.BindHeader();
            }
            catch (Exception ex)
            {
                View.ShowException(ex.Message);
            }
        }

        #endregion Event's Methods
    }
}