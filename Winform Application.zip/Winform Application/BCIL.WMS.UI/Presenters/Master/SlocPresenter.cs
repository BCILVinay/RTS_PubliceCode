﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialBinPresenter : Presenter<IMaterialBinView>
    {
        #region Constructor

        public MaterialBinPresenter(IMaterialBinView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialBinModel();
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
            view.Load += View_Load;
            view.SelectLocationReq += View_SelectLocationReq;
            view.SelectMaterialReq += View_SelectMaterialReq;
        }

        #endregion Constructor

        #region Private Event

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                var SearchCriteria = new MaterialSearchCriteria() { PageNumber = 1, PageSize =  100 };
                var materialsDVL = MaterialDVL.GetMaterialDVL(SearchCriteria);
                View.Model.Materials = GetMaterialChunk(materialsDVL);
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private List<KeyValue<long, string>> GetMaterialChunk(MaterialDVL materialsDVL)
        {
            List<KeyValue<long, string>> _materials = new List<KeyValue<long, string>>();
            if (materialsDVL.HaveItems())
            {
                foreach (var item in materialsDVL)
                {
                    _materials.Add(new KeyValue<long, string>(item.MaterialId, string.Format("{0}-{1}", item.MaterialCode, item.MaterialDescription)));
                }
            }
            return _materials;
        }

        private bool Save()
        {
            if (View.Model.MaterialBin.IsValid)
            {
                View.Model.MaterialBin.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.MaterialBin.ApplyEdits();
                try
                {
                    View.Model.MaterialBin = View.Model.MaterialBin.Save();
                    View.RefreshBinding();
                    //BcilLogger.WriteMessage(LogLevel.Info, "Material bin data :" + Serializer.Json.Serialize(View.Model.MaterialBin).ToString() + " saved.");
                    return true;
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                    return false;
                }
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.MaterialBin.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.MaterialBin == null || View.Model.MaterialBin.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.MaterialBin.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("MaterialBin saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Material bin saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SelectMaterialReq(object sender, EventArgs e)
        {
            try
            {
                MaterialSearchView searchView = new MaterialSearchView();
                searchView.MultiItemSelect = false;
                if (searchView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    if (searchView.SelectedItems.HaveItems())
                    {
                        var data = searchView.SelectedItems[0];
                        if (data.IsNotNull())
                            View.Model.MaterialBin.Material = new KeyValue<long, string>(data.MaterialId, data.MaterialCode);
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SelectLocationReq(object sender, EventArgs e)
        {
            try
            {
                LocationSearchView searchView = new LocationSearchView();
                searchView.MultiItemSelect = false;
                if (searchView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    if (searchView.SelectedItems.HaveItems())
                    {
                        var data = searchView.SelectedItems[0];
                        if (data.IsNotNull())
                            View.Model.MaterialBin.Location = new KeyValue<long, string>(data.LocationId, data.LocationCode);
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Event
    }
}