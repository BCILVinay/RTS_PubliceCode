﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ProductionOrderListPresenter : Presenter<IProductionOrderListView>
    {
        #region Variables

        private Dictionary<PrnType, string> _prns = new Dictionary<PrnType, string>();
        private Dictionary<Int64, Material> m_Materials = null;

        #endregion Variables

        #region Constructor

        public ProductionOrderListPresenter(IProductionOrderListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ProductionOrderListModel();
            view.Load += View_Load;
            view.AddProductionOrderRequested += View_AddProductionOrderRequested;
            view.EditProductionOrderRequested += View_EditProductionOrderRequested;
            view.ImportDataRequested += View_ImportDataRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.SearchRequested += View_SearchRequested;
            view.PrintRequested += View_PrintRequested;
        }

        #endregion Constructor

        #region Private Method

        private void DoRefresh()
        {
            View.Model.ProductionOrders = ProductionOrderDVL.GetProductionOrderDVL(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private bool ImportProductionOrder()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                  { "PONo", true }, { "PODate", true },  { "PlantCode", true }, { "MovementType",true},
                 { "ChangeDate", true },  { "PPLine", true }, { "MaterialCode",true},{ "BundleQty", true }, {"UoM",true }, { "Length",true},{ "SLoc", true }
            };
            ImportView view = new ImportView();
            view.Text = "Import Production Order";
            view.TemplateDataSet = new Template().GetImportPOTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "PONo", "PODate", "PlantCode", "MovementType", "ChangeDate", "PPLine", "MaterialCode", "BundleQty", "UoM", "Length", "SLoc");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable pOrderTable = dtToImport.DefaultView.ToTable(true);

                    foreach (DataRow pOrderRow in pOrderTable.Rows)
                    {
                        try
                        {
                            CodeContract.Required<ArgumentException>(pOrderRow["PlantCode"].ToString().IsNotNullOrWhiteSpace(), "Site code is mandatory.");
                            Site site = Site.GetSiteBySiteCode(pOrderRow["PlantCode"].ToString());
                            CodeContract.Required<BCILException>(site.IsNotNull() && site.SiteId > 0, "Plant not found");

                            Line line = Line.GetLineByCode(pOrderRow["PPLine"].ToString());
                            CodeContract.Required<BCILException>(line.IsNotNull() && line.LineId > 0, "PPLine not found");

                            Material material = Material.GetMaterialByCode(pOrderRow["MaterialCode"].ToString());
                            CodeContract.Required<BCILException>(material.IsNotNull() && material.MaterialId > 0, "Material not found");

                            Location location = Location.GetLocationByCode(pOrderRow["SLoc"].ToString());
                            CodeContract.Required<BCILException>(location.IsNotNull() && location.LocationId > 0, "SLoc not found");

                            var POrderObj = BL.ProductionOrder.NewProductionOrder();
                            POrderObj.POrderNo = pOrderRow["PONo"].ToString();
                            POrderObj.Status = ProductionOrderStatus.New;
                            POrderObj.SiteId = site.SiteId;
                            POrderObj.MovementType = pOrderRow["MovementType"].ToString();
                            POrderObj.POrderDate = Convert.ToDateTime(pOrderRow["PODate"].ToString());
                            POrderObj.CreatedOn = DateTime.Now;
                            POrderObj.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                            POrderObj.UpdatedOn = DateTime.Now;
                            POrderObj.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                            POrderObj.POLineItems = new POLineItemList();

                            ProductionOrderLineItem lineItem = ProductionOrderLineItem.NewProductionOrderLineItem();
                            lineItem.Material = new Utility.KeyValue<long, string>(material.MaterialId, material.MaterialCode);
                            lineItem.Location = new Utility.KeyValue<long, string>(location.LocationId, location.LocationCode);
                            lineItem.ChangeOn = Convert.ToDateTime(pOrderRow["ChangeDate"].ToString());
                            lineItem.UOM = pOrderRow["UoM"].ToString();
                            lineItem.Length = Convert.ToInt32(pOrderRow["Length"].ToString());
                            lineItem.BundleQty = Convert.ToInt32(pOrderRow["BundleQty"].ToString());
                            lineItem.PPLine = line.LineId;
                            POrderObj.POLineItems.Add(lineItem);
                            POrderObj.IsImported = true;
                            POrderObj.ImportedOn = DateTime.Now;
                            if (POrderObj.IsValid)
                            {
                                POrderObj.Save();
                            }
                            else
                            {
                                throw new Exception(string.Join(Environment.NewLine, POrderObj.BrokenRulesCollection.Select(x => x.Description)));
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("MaterialCode='{0}'", pOrderRow["MaterialCode"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };

            view.ShowDialog(App.Shell);
            return true;
        }

        #endregion Private Method

        #region Private Events

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.CreatedFrom = DateTime.Today.Date;
                View.Model.SearchCriteria.CreatedTo = DateTime.Today.Date;
                View.Model.SearchCriteria.LineId = App.WorkStation.WSLine.LineId;
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshGrid();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshGrid();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_AddProductionOrderRequested(object sender, EventArgs e)
        {
            try
            {
                ProductionOrderView view = new ProductionOrderView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditProductionOrderRequested(object sender, ProductionOrder po)
        {
            try
            {
                ProductionOrderView view = new ProductionOrderView(po);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var IsProcessDone = ImportProductionOrder();
                if (IsProcessDone)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private string GetPrn(PrnType prnType, string lableValue)
        {
            if (!_prns.Keys.Contains(prnType))
            {
                var prn = Prn.GetPrn(prnType);
                _prns.Add(prnType, prn.PrnTemplate);
            }
            string prnValue = _prns[prnType];
            //here replace placement char by values
            prnValue = lableValue; //value replace by prn field
            return prnValue;
        }

        private void View_PrintRequested(object sender, ProductionOrder po)
        {
            try
            {
                if (po != null && po.POLineItems.Count > 0)
                {
                    m_Materials = MaterialDVL.GetMaterialDVLByIds(po.POLineItems.Select(x => x.Material.Key).ToList()).ToDictionary(z => z.MaterialId);
                    var materialList = m_Materials.Values.ToList();
                    if (materialList.Any(x => x.IsBrown == true))
                    {
                        if (po.Status == ProductionOrderStatus.New)
                        {
                            // ItemLabelPrint(po);
                            ItemLabelPrintView view = new ItemLabelPrintView(po);
                            if (view.ShowDialog(App.Shell) == DialogResult.OK)
                            {
                                DoRefresh();
                            }
                        }
                    }
                    else
                    {
                        if (po.Status == ProductionOrderStatus.New)
                        {
                            // BundleLabelPrint(po);
                            BundleLabelPrintView view = new BundleLabelPrintView(po);
                            if (view.ShowDialog(App.Shell) == DialogResult.OK)
                            {
                                DoRefresh();
                            }
                        }
                    }
                }
                else
                {
                    View.ShowException("PO have no item");
                }
            }
            catch (TargetInvocationException ex)
            {
                View.ShowException(ex.InnerException);
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void BundleLabelPrint(ProductionOrder po)
        {
            Bundles bundles = null;
            ProgressView pview = new ProgressView(App.Shell);

            pview.DoWork = (backgroudEvent) =>
            {
                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();

                    bundles = Bundles.GetBundleById(new BundleSearchCriteriaByPo() { POrderId = po.POrderId, SiteId = App.Login.LoginSite.SiteId });
                    var bundlesInPo = po.POLineItems.Sum(x => x.BundleQty);
                    pview.TotalRecords = bundlesInPo;

                    int totalbundlePrinted = 0;

                    m_Materials = MaterialDVL.GetMaterialDVLByIds(po.POLineItems.Select(x => x.Material.Key).ToList()).ToDictionary(z => z.MaterialId);
                    foreach (var poItem in po.POLineItems)
                    {
                        var bundlesToPrint = poItem.BundleQty;
                        var printedBundles = 0;

                        if (printedBundles <= bundlesToPrint)
                        {
                            bundles.IsLabelPrinted = true;
                            for (int i = 0; i < bundlesToPrint; i++)
                            {
                                var bundle = Bundle.NewBundle();
                                bundle.BundleSrNo = i + 1;
                                bundle.BundleCode = CodeCommand.GetNextCode(ObjectType.Bundle, App.Login.LoginSite.SiteId);
                                bundle.Po = new KeyValue<long, string>(po.POrderId, "");
                                bundle.Material = new KeyValue<long, string>(poItem.Material.Key, "");
                                bundle.Qty = m_Materials[poItem.Material.Key].PackSize;
                                bundle.Location = new KeyValue<long, string>(App.WorkStation.WMaterialBination.LocationId, "");
                                bundle.Tooling = new KeyValue<long, string>(App.WorkStation.WSLine.Tooling.Key, App.WorkStation.WSLine.Tooling.Value);
                                bundle.CreatedOn = DateTime.Now;
                                bundle.CreatedBy = App.Login.Employee.EmployeeId;
                                bundle.UpdatedOn = DateTime.Now;
                                bundle.UpdatedBy = App.Login.Employee.EmployeeId;
                                bundles.Add(bundle);
                                ++printedBundles;

                                var prn = Prn.GetPrn(PrnType.Bundle);
                                var _material = Material.GetMaterial(bundle.Material.Key);

                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Date}", bundle.CreatedOn.ToString("dd-MM-yyyy"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{LineNo}", App.WorkStation.WSLine.Code);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PackNo}", string.Format("{0}/{1}", bundle.BundleSrNo, po.POLineItems.FirstOrDefault(x => x.Material.Key == bundle.Material.Key).BundleQty));
                                //Below {PackSize} value for Pcs/Mr
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PcsMtr}", string.Format("{0}/{1:0.00}", _material.PackSize, _material.StdBarLength * _material.PackSize));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{TotalWeight}", string.Format("{0:0.00} {1}", _material.BundleTotalWeight, "Kg"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{BundleCode}", bundle.BundleCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", bundle.Material.Value);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Tooling}", bundle.Tooling.Value);

                                string dataToPrint = prn.PrnTemplate;
                                if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                                backgroudEvent.DoWorkEventArgs.Result = string.Format("Total printed labels: {0}.", ++totalbundlePrinted);
                                backgroudEvent.ReportProgress(0);
                            }
                        }
                    }
                }
            };

            pview.OnProgressChanged = (o) =>
            {
                if (o.UserState != null)
                    return Convert.ToString(((DoWorkEventArgs)o.UserState).Result);
                else return "Printing is in progress";
            };

            pview.RunWorkerCompleted = (o) =>
            {
                try
                {
                    if (o.IsNotNull() && o.Error.IsNotNull()) throw o.Error;

                    if (!bundles.IsValid) throw new BCILException(string.Join(Environment.NewLine, bundles.SelectMany(x => x.BrokenRulesCollection.Select(y => y.Description))));

                    bundles.Save();
                    po.Status = ProductionOrderStatus.BundlePrinted;
                    po.ConfirmedOn = SqlDateTime.MinValue.Value;
                    po.Save();
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                }
            };

            pview.Run(null);
        }

        private void ItemLabelPrint(ProductionOrder po)
        {
            try
            {
                Items items = new Items();
                ProgressView pview = new ProgressView(App.Shell);

                pview.DoWork = (backgroudEvent) =>
                {
                    using (var printingManager = PrintFactory.GetManager())
                    {
                        var printer = printingManager.GetProvider<IPrinterFactory>();
                        int totalbundlePrinted = 0;
                        int totalRecord = 0;
                        m_Materials = MaterialDVL.GetMaterialDVLByIds(po.POLineItems.Select(x => x.Material.Key).ToList()).ToDictionary(z => z.MaterialId);
                        var Materials = m_Materials.Values.ToList();
                        foreach (var item in po.POLineItems)
                        {
                            totalRecord += Materials.FirstOrDefault(x => x.MaterialId == item.Material.Key).PackSize * item.BundleQty;
                        }
                        pview.TotalRecords = totalRecord;

                        foreach (var poItem in po.POLineItems)
                        {
                            var materialPackSize = Materials.FirstOrDefault(x => x.MaterialId == poItem.Material.Key).PackSize;
                            var itemsToPrint = poItem.BundleQty * materialPackSize;
                            var printedItems = 0;

                            if (printedItems <= itemsToPrint)
                            {
                                items.IsLabelPrinted = true;
                                for (int i = 0; i < itemsToPrint; i++)
                                {
                                    var item = Item.NewItem();
                                    item.ItemCode = CodeCommand.GetNextCode(ObjectType.Item, App.Login.LoginSite.SiteId);
                                    item.Bundle = new KeyValue<long, string>(0, "");
                                    item.POrder = new KeyValue<long, string>(poItem.PO.Key, "");
                                    item.Material = new KeyValue<long, string>(poItem.Material.Key, poItem.Material.Value);
                                    item.ItemStatus = ItemStatus.Printed;
                                    item.Location = new KeyValue<long, string>(App.WorkStation.WMaterialBination.LocationId, "");
                                    item.Tooling = m_Materials[poItem.Material.Key].Tooling;
                                    item.CreatedOn = DateTime.Now;
                                    item.CreatedBy = App.Login.Employee.EmployeeId;
                                    item.UpdatedOn = DateTime.Now;
                                    item.UpdatedBy = App.Login.Employee.EmployeeId;
                                    item.PrintedOn = DateTime.Now;
                                    items.Add(item);
                                    ++printedItems;

                                    //{BundleItemCode}
                                    var prn = Prn.GetPrn(PrnType.Item);
                                    prn.PrnTemplate = prn.PrnTemplate.Replace("{ItemCode}", item.ItemCode);
                                    prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", item.Material.Value);
                                    prn.PrnTemplate = prn.PrnTemplate.Replace("{CreatedOn}", item.CreatedOn.ToString("dd-MM-yyyy"));

                                    string dataToPrint = prn.PrnTemplate;
                                    if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                                    backgroudEvent.DoWorkEventArgs.Result = string.Format("Total printed labels: {0}.", ++totalbundlePrinted);
                                    backgroudEvent.ReportProgress(0);
                                }
                            }
                        }
                    }
                };

                pview.OnProgressChanged = (o) =>
                {
                    if (o.UserState != null)
                        return Convert.ToString(((DoWorkEventArgs)o.UserState).Result);
                    else return "Printing is in progress";
                };

                pview.RunWorkerCompleted = (o) =>
                {
                    try
                    {
                        if (o.Error.IsNotNull()) throw o.Error;
                        if (!items.IsValid) throw new BCILException(string.Join(Environment.NewLine, items.SelectMany(x => x.BrokenRulesCollection.Select(y => y.Description))));
                        items.Save();
                        po.Status = ProductionOrderStatus.ItemPrinted;
                        po.ConfirmedOn = SqlDateTime.MinValue.Value;
                        po.Save();
                    }
                    catch (Exception ex)
                    {
                        View.ShowException(ex);
                    }
                };

                pview.Run(null);
            }
            catch (TargetInvocationException ex)
            {
                View.ShowException(ex.InnerException);
            }
        }

        #endregion Private Events
    }
}