﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ItemLabelPrintPresenter : Presenter<IItemLabelPrintView>
    {
        #region Constructor

        private Dictionary<Int64, Material> m_Materials = null;

        public ItemLabelPrintPresenter(IItemLabelPrintView view) : base(view)
        {
            if (view.Model == null)
                view.Model = new Models.ItemLabelPrintModel();
            view.Load += View_Load;
            view.SavePrintRequested += View_SavePrintRequested;
            view.CancelRequested += View_CancelRequested;
        }

        #endregion Constructor

        #region Methods

        private bool BundleLabelPrint()
        {
            ProductionOrder po = View.Model.POrder;
            Bundles bundles = null;
            ProgressView pview = new ProgressView(App.Shell);
            pview.DoWork = (backgroudEvent) =>
            {
                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();

                    bundles = Bundles.GetBundleById(new BundleSearchCriteriaByPo() { POrderId = po.POrderId, SiteId = App.Login.LoginSite.SiteId });

                    pview.TotalRecords = View.Model.TotalItemQty - View.Model.TotalPrintedItemQty;

                    int totalbundlePrinted = 0;

                    foreach (var poItem in po.POLineItems)
                    {
                        var bundlesToPrint = View.Model.QtyToPrint;
                        var printedBundles = 0;

                        if (printedBundles <= bundlesToPrint)
                        {
                            bundles.IsLabelPrinted = true;
                            for (int i = 0; i < bundlesToPrint; i++)
                            {
                                View.Model.TotalPrintedItemQty = View.Model.TotalPrintedItemQty + 1;

                                var bundle = Bundle.NewBundle();

                                bundle.BundleCode = CodeCommand.GetNextCode(ObjectType.Bundle, App.Login.LoginSite.SiteId);
                                bundle.Po = new KeyValue<long, string>(po.POrderId, "");
                                bundle.Material = new KeyValue<long, string>(poItem.Material.Key, "");
                                bundle.Qty = m_Materials[poItem.Material.Key].PackSize;
                                bundle.Location = poItem.Location;
                                bundle.Tooling = m_Materials[poItem.Material.Key].Tooling;
                                bundle.CreatedOn = DateTime.Now;
                                bundle.CreatedBy = App.Login.Employee.EmployeeId;
                                bundle.UpdatedOn = DateTime.Now;
                                bundle.UpdatedBy = App.Login.Employee.EmployeeId;
                                bundles.Add(bundle);
                                ++printedBundles;

                                var prn = Prn.GetPrn(PrnType.Bundle);
                                var _material = Material.GetMaterial(bundle.Material.Key);

                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Date}", bundle.CreatedOn.ToString("dd-MM-yyyy"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{LineNo}", App.WorkStation.WSLine.Code);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PackNo}", string.Format("{0}/{1}", bundle.BundleSrNo, po.POLineItems.FirstOrDefault(x => x.Material.Key == bundle.Material.Key).BundleQty));
                                //Below {PackSize} value for Pcs/Mr
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{PcsMtr}", string.Format("{0}/{1:0.00}", _material.PackSize, _material.StdBarLength * _material.PackSize));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{TotalWeight}", string.Format("{0:0.00} {1}", _material.BundleTotalWeight, "Kg"));
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{BundleCode}", bundle.BundleCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", _material.MaterialCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Tooling}", bundle.Tooling.Value);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{MaterialImagePrn}", _material.MaterialImagePrn);

                                string dataToPrint = prn.PrnTemplate;
                                if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                                backgroudEvent.DoWorkEventArgs.Result = string.Format("Total printed labels: {0}.", ++totalbundlePrinted);
                                backgroudEvent.ReportProgress(0);
                            }
                        }
                    }
                }
            };

            pview.OnProgressChanged = (o) =>
            {
                if (o.UserState != null)
                    return Convert.ToString(((DoWorkEventArgs)o.UserState).Result);
                else return "Printing is in progress";
            };

            pview.RunWorkerCompleted = (o) =>
            {
                try
                {
                    if (o.IsNotNull() && o.Error.IsNotNull()) throw o.Error;

                    if (!bundles.IsValid) throw new BCILException(string.Join(Environment.NewLine, bundles.SelectMany(x => x.BrokenRulesCollection.Select(y => y.Description))));

                    bundles.Save();
                    if (View.Model.TotalItemQty == View.Model.TotalPrintedItemQty)
                    {
                        po.Status = ProductionOrderStatus.BundlePrinted;
                        po.ConfirmedOn = SqlDateTime.MinValue.Value;
                        po.Save();
                    }
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                }
            };

            pview.Run(null);

            return true;
        }

        private bool ItemLabelPrint()
        {
            ProductionOrder po = View.Model.POrder;
            Items items = new Items();
            ProgressView pview = new ProgressView(App.Shell);

            pview.DoWork = (backgroudEvent) =>
            {
                using (var printingManager = PrintFactory.GetManager())
                {
                    var printer = printingManager.GetProvider<IPrinterFactory>();
                    int totalbundleItemPrinted = 0;

                    pview.TotalRecords = View.Model.MaterialPackSize * View.Model.QtyToPrint;

                    foreach (var poItem in po.POLineItems)
                    {
                        var itemsToPrint = View.Model.CalculatedItemQty;
                        var printedItems = 0;

                        if (printedItems <= itemsToPrint)
                        {
                            items.IsLabelPrinted = true;
                            for (int i = 0; i < itemsToPrint; i++)
                            {
                                var item = Item.NewItem();
                                item.ItemCode = CodeCommand.GetNextCode(ObjectType.Item, App.Login.LoginSite.SiteId);
                                item.Bundle = new KeyValue<long, string>(0, "");
                                item.POrder = new KeyValue<long, string>(poItem.PO.Key, "");
                                item.Material = new KeyValue<long, string>(poItem.Material.Key, poItem.Material.Value);
                                item.ItemStatus = ItemStatus.Printed;
                                item.Location = new KeyValue<long, string>(App.WorkStation.WMaterialBination.LocationId, "");
                                item.Tooling = m_Materials[poItem.Material.Key].Tooling;
                                item.CreatedOn = DateTime.Now;
                                item.CreatedBy = App.Login.Employee.EmployeeId;
                                item.UpdatedOn = DateTime.Now;
                                item.UpdatedBy = App.Login.Employee.EmployeeId;
                                item.PrintedOn = DateTime.Now;
                                items.Add(item);
                                ++printedItems;

                                    //{BundleItemCode}
                                    var prn = Prn.GetPrn(PrnType.Item);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{ItemCode}", item.ItemCode);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{Material}", item.Material.Value);
                                prn.PrnTemplate = prn.PrnTemplate.Replace("{CreatedOn}", item.CreatedOn.ToString("dd-MM-yyyy"));

                                string dataToPrint = prn.PrnTemplate;
                                if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                                backgroudEvent.DoWorkEventArgs.Result = string.Format("Total printed labels: {0}.", ++totalbundleItemPrinted);
                                backgroudEvent.ReportProgress(0);
                            }
                        }
                    }
                }
            };

            pview.OnProgressChanged = (o) =>
            {
                if (o.UserState != null)
                    return Convert.ToString(((DoWorkEventArgs)o.UserState).Result);
                else return "Printing is in progress";
            };

            pview.RunWorkerCompleted = (o) =>
            {
                try
                {
                    if (o.Error.IsNotNull()) throw o.Error;
                    if (!items.IsValid) throw new BCILException(string.Join(Environment.NewLine, items.SelectMany(x => x.BrokenRulesCollection.Select(y => y.Description))));
                    items.Save();
                    var PrintedItems = Items.GetItems(new ItemSearchCriteriaByPOrderId() { POrderId = View.Model.POrder.POrderId, SiteId = App.Login.LoginSite.SiteId });
                    if (PrintedItems.HaveItems())
                    {
                        if (PrintedItems.Count == View.Model.TotalItemQty)
                        {
                            po.Status = ProductionOrderStatus.ItemPrinted;
                            po.ConfirmedOn = SqlDateTime.MinValue.Value;
                            po.Save();
                        }
                    }
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                }
            };

            pview.Run(null);
            return true;
        }

        #endregion Methods

        #region Event's Methods

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                View.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                View.ShowException(ex.Message);
            }
        }

        private void View_SavePrintRequested(object sender, EventArgs e)
        {
            try
            {
                if (View.Model.CalculatedItemQty == 0)
                {
                    View.ShowException("Print quantity should be greater than zero");
                    return;
                }
                if (View.Model.CalculatedItemQty > (View.Model.TotalItemQty - View.Model.TotalPrintedItemQty))
                {
                    View.ShowException("Print quantity should not be greater than " + (View.Model.TotalItemQty - View.Model.TotalPrintedItemQty) + "");
                    return;
                }

                if (ItemLabelPrint()) { View.DialogResult = DialogResult.OK; };
            }
            catch (TargetInvocationException ex)
            {
                View.ShowException(ex.InnerException);
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.TotalBundleQty = View.Model.POrder.POLineItems.Sum(x => x.BundleQty);

                m_Materials = MaterialDVL.GetMaterialDVLByIds(View.Model.POrder.POLineItems.Select(x => x.Material.Key).ToList()).ToDictionary(z => z.MaterialId);
                var Materials = m_Materials.Values.ToList();
                foreach (var item in View.Model.POrder.POLineItems)
                {
                    View.Model.TotalItemQty += Materials.FirstOrDefault(x => x.MaterialId == item.Material.Key).PackSize * item.BundleQty;
                }
                View.Model.MaterialPackSize = Materials[0].PackSize;
                var bundleItems = Items.GetItems(new ItemSearchCriteriaByPOrderId() { POrderId = View.Model.POrder.POrderId, SiteId = App.Login.LoginSite.SiteId });
                View.Model.TotalPrintedItemQty = bundleItems.Count;

                View.BindHeader();
            }
            catch (Exception ex)
            {
                View.ShowException(ex.Message);
            }
        }

        #endregion Event's Methods
    }
}