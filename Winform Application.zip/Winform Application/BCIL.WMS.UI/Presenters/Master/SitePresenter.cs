﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class SitePresenter : Presenter<ISiteView>
    {
        public SitePresenter(ISiteView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.SiteModel();
            view.Load += View_Load;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        private bool Save()
        {
            if (View.Model.Site.IsValid)
            {
                View.Model.Site.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Site.ApplyEdits();
                View.Model.Site = View.Model.Site.Save();
                View.RefreshBinding();
                //BcilLogger.WriteMessage(LogLevel.Info, "Site data :" + Serializer.Json.Serialize(View.Model.Site).ToString() + " saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.Site.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Site saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.Site == null || View.Model.Site.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.Site.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Site saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }
    }
}