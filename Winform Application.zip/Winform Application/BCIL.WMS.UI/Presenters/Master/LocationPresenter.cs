﻿using BCIL.Administration.BL;
using BCIL.Utility;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class LocationPresenter : Presenter<ILocationView>
    {
        public LocationPresenter(ILocationView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.LocationModel();
            view.Load += View_Load;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        private bool Save()
        {
            if (View.Model.Location.IsValid)
            {
                View.Model.Location.IsImported = false;
                View.Model.Location.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Location.ApplyEdits();
                View.Model.Location = View.Model.Location.Save();
                View.RefreshBinding();
                //BcilLogger.WriteMessage(LogLevel.Info, "Location data :" + Serializer.Json.Serialize(View.Model.Location).ToString()+" saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.Location.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.Location == null || View.Model.Location.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.Location.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Location saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Location saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.SiteList.Add(new KeyValue<int, string>(0, "None"));
                if (App.Login.User.IsSupperUser)
                {
                    var sites = SiteList.GetSites();
                    if (sites.HaveItems())
                    {
                        foreach (var item in sites)
                        {
                            View.Model.SiteList.Add(new KeyValue<int, string>(item.SiteId, item.SiteName));
                        }
                    }
                }
                else
                {
                    View.Model.SiteList.Add(new KeyValue<int, string>(App.Login.LoginSite.SiteId, App.Login.LoginSite.SiteName));
                    View.Model.Location.Site = new KeyValue<int, string>(App.Login.LoginSite.SiteId, App.Login.LoginSite.SiteName);
                }
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}