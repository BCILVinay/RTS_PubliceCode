﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialListPresenter : Presenter<IMaterialListView>
    {
        #region Constructor

        public MaterialListPresenter(IMaterialListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialListModel();
            view.Load += View_Load;
            view.AddMaterialRequested += View_AddMaterialRequested;
            view.EditMaterialRequested += View_EditMaterialRequested;
            view.ImportDataRequested += View_ImportDataRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.SearchRequested += View_SearchRequested;
            view.ReadOnlyViewMaterialRequested += View_ReadOnlyViewMaterialRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_AddMaterialRequested(object sender, EventArgs e)
        {
            try
            {
                MaterialView view = new MaterialView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            View.Model.Materials = MaterialDVL.GetMaterialDVL(View.Model.SearchCriteria);
            View.RefreshBinding();
        }

        private void View_EditMaterialRequested(object sender, Material material)
        {
            try
            {
                MaterialView view = new MaterialView(material);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ReadOnlyViewMaterialRequested(object sender, Material material)
        {
            try
            {
                MaterialView view = new MaterialView(material, "ReadOnly");
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.BindingHeader();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var IsProcessDone = ImportMaterial();
                if (IsProcessDone)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool ImportMaterial()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                  { "MaterialCode", true }, { "MaterialDescription", true }, { "ToolingCode", true },  { "UOM", true },  { "SectionalWeight", true }
                ,  { "StdBarLength", true },  { "PackSize", true },  { "Breath", true }, { "Height", true }, {"Weight",true }, {"IsBrown",true }
            };
            ImportView view = new ImportView();
            view.Text = "Import Material";
            view.TemplateDataSet = new Template().GetImportMaterialTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "MaterialCode", "MaterialDescription", "ToolingCode", "UOM", "SectionalWeight", "StdBarLength", "PackSize", "Breath", "Height", "Weight", "IsBrown");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable materialTable = dtToImport.DefaultView.ToTable(true);

                    foreach (DataRow materialRow in materialTable.Rows)
                    {
                        try
                        {
                            var toolingData = Tooling.GetToolingByCode(materialRow["ToolingCode"].ToString());
                            if (toolingData != null && toolingData.ToolingId > 0)
                            {
                                var MaterialObj = BL.Material.NewMaterial();
                                MaterialObj.MaterialCode = materialRow["MaterialCode"].ToString();
                                MaterialObj.MaterialDescription = materialRow["MaterialDescription"].ToString();
                                MaterialObj.Tooling = new KeyValue<Int64, string>(toolingData.ToolingId, toolingData.ToolingName);
                                MaterialObj.UOM = materialRow["UOM"].ToString();
                                MaterialObj.SectionalWeight = Convert.ToDecimal(materialRow["SectionalWeight"].ToString());
                                MaterialObj.StdBarLength = Convert.ToDecimal(materialRow["StdBarLength"].ToString());
                                MaterialObj.PackSize = Convert.ToInt32(materialRow["PackSize"].ToString());
                                MaterialObj.BundleBreath = Convert.ToDecimal(materialRow["Breath"].ToString());
                                MaterialObj.BundleHeight = Convert.ToDecimal(materialRow["Height"].ToString());
                                MaterialObj.BundleWeight = Convert.ToDecimal(materialRow["Weight"].ToString());
                                MaterialObj.IsBrown = Convert.ToBoolean(materialRow["IsBrown"].ToString());
                                MaterialObj.CreatedOn = DateTime.Now;
                                MaterialObj.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                MaterialObj.UpdatedOn = DateTime.Now;
                                MaterialObj.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                MaterialObj.IsActive = true;
                                if (MaterialObj.IsValid)
                                {
                                    MaterialObj.Save();
                                }
                                else
                                {
                                    throw new Exception(string.Join("\n", MaterialObj.BrokenRulesCollection.Select(x => x.Description)));
                                }
                            }
                            else
                            {
                                throw new Exception("Tooling is required");
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("MaterialCode='{0}'", materialRow["MaterialCode"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };

            view.ShowDialog(App.Shell);
            return true;
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}