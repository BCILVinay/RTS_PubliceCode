﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.WMS.UI.Views;
using System;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class SiteListPresenter : Presenter<ISiteListView>
    {
        #region Constructor

        public SiteListPresenter(ISiteListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.SiteListModel();
            view.Load += View_Load;
            view.AddSiteRequested += View_AddSiteRequested;
            view.EditSiteRequested += View_EditSiteRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            View.Model.Sites = SiteList.GetSites();
            View.RefreshBinding();
        }

        private void View_AddSiteRequested(object sender, EventArgs e)
        {
            try
            {
                SiteView view = new SiteView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditSiteRequested(object sender, Site site)
        {
            try
            {
                SiteView view = new SiteView(site);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}