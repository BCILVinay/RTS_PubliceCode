﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ToolingPresenter : Presenter<IToolingView>
    {
        public ToolingPresenter(IToolingView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ToolingModel();
            view.Load += View_Load;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        private bool Save()
        {
            if (View.Model.Tooling.IsValid)
            {
                View.Model.Tooling.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Tooling.ApplyEdits();
                View.Model.Tooling = View.Model.Tooling.Save();
                View.RefreshBinding();
                //BcilLogger.WriteMessage(LogLevel.Info, "Tooling data :" + Serializer.Json.Serialize(View.Model.Tooling).ToString() + " saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.Tooling.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.Tooling == null || View.Model.Tooling.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.Tooling.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Tooling saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Tooling saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.LocationList.Add(new KeyValue<Int64, string>(0, "None"));
                if (App.Login.LoginSite != null && App.Login.LoginSite.SiteId > 0)
                {
                    var locations = LocationDVL.GetLocationDVL(new LocationDVLSearchCriteria() { SiteId = App.Login.LoginSite.SiteId });
                    if (locations.HaveItems())
                    {
                        foreach (var item in locations)
                        {
                            View.Model.LocationList.Add(new KeyValue<Int64, string>(item.LocationId, item.LocationCode));
                        }
                    }

                    var criteria = new LinesSearchCriteria() { SiteId = App.Login.LoginSite.SiteId };
                    Lines lines = Lines.GetLines(criteria);

                    View.Model.Lines = new List<Line>();
                    View.Model.Lines.Add(new Line() { LineId = 0, Code = "None" });
                    View.Model.Lines.AddRange(lines.ToList());

                    View.Model.LinePrefences = new List<Line>();
                    View.Model.LinePrefences.Add(new Line() { LineId = 0, Code = "None" });
                    View.Model.LinePrefences.AddRange(lines.ToList());

                }

                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}