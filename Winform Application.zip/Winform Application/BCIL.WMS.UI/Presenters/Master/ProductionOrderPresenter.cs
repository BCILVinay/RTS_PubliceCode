﻿using BCIL.Utility;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ProductionOrderPresenter : Presenter<IProductionOrderView>
    {
        public ProductionOrderPresenter(IProductionOrderView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ProductionOrderModel();
            view.Load += View_Load;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        private bool Save()
        {
            if (View.Model.ProductionOrder.IsValid)
            {
                View.Model.ProductionOrder.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.ProductionOrder.ApplyEdits();
                View.Model.ProductionOrder = View.Model.ProductionOrder.Save();
                View.RefreshBinding();
                //BcilLogger.WriteMessage(LogLevel.Info, "Production order data :" + Serializer.Json.Serialize(View.Model.ProductionOrder).ToString() + " saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.ProductionOrder.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.ProductionOrder == null || View.Model.ProductionOrder.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.ProductionOrder.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Production order saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Production order saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }
    }
}