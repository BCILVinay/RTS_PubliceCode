﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using BCIL.WMS.BL;
using BCIL.WMS.Printing;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class LocationListPresenter : Presenter<ILocationListView>
    {
        #region Constructor

        public LocationListPresenter(ILocationListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.LocationListModel();
            view.Load += View_Load;
            view.AddLocationRequested += View_AddLocationRequested;
            view.EditLocationRequested += View_EditLocationRequested;
            view.ImportDataRequested += View_ImportDataRequested;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
            view.PrintRequested += View_PrintRequested;
        }

        #endregion Constructor

        #region Private Events

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                Items items = Items.GetItems(new ItemsByCodeSearchCriteria() { ItemCode = new List<string>() });
                Bundles.GetBundles(new BundleSearchCriteria());
                // DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void DoRefresh()
        {
            if (App.Login.LoginSite.IsNotNull())
            {
                View.Model.SearchCriteria.SiteId = App.Login.LoginSite.SiteId;
            }
            View.Model.Locations = LocationDVL.GetLocationDVL(View.Model.SearchCriteria);
            View.RefreshGrid();
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_AddLocationRequested(object sender, EventArgs e)
        {
            try
            {
                LocationView view = new LocationView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditLocationRequested(object sender, Location location)
        {
            try
            {
                LocationView view = new LocationView(location);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var IsProcessDone = ImportLocation();
                if (IsProcessDone)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool ImportLocation()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                  { "LocationCode", true }, { "LocationType", true },  { "Mode", true },  { "DimensionLength", true }
                ,  { "DimensionWidth", true },  { "DimensionHeight", true }
            };
            ImportView view = new ImportView();
            view.Text = "Import Location";
            view.TemplateDataSet = new Template().GetImportLocationTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "LocationCode", "LocationType", "Mode", "DimensionLength", "DimensionWidth", "DimensionHeight");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable locationTable = dtToImport.DefaultView.ToTable(true);

                    foreach (DataRow locationRow in locationTable.Rows)
                    {
                        try
                        {
                            var LocationObj = BL.Location.NewLocation();
                            LocationObj.LocationName = locationRow["LocationCode"].ToString();
                            LocationObj.LocationCode = locationRow["LocationCode"].ToString();
                            LocationObj.Description = locationRow["LocationCode"].ToString();
                            LocationObj.Type = (LocationType)System.Enum.Parse(typeof(LocationType), locationRow["LocationType"].ToString());
                            LocationObj.Mode = (Mode)System.Enum.Parse(typeof(Mode), locationRow["Mode"].ToString());
                            LocationObj.DimensionHeight = Convert.ToDecimal(locationRow["DimensionHeight"]);
                            LocationObj.DimensionLength = Convert.ToDecimal(locationRow["DimensionLength"]);
                            LocationObj.DimensionWidth = Convert.ToDecimal(locationRow["DimensionWidth"]);
                            LocationObj.CreatedOn = DateTime.Now;
                            LocationObj.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                            LocationObj.UpdatedOn = DateTime.Now;
                            LocationObj.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                            LocationObj.IsActive = true;
                            LocationObj.IsImported = true;
                            LocationObj.Site = new KeyValue<int, string>(App.Login.LoginSite.SiteId, App.Login.LoginSite.SiteCode);

                            if (LocationObj.IsValid)
                            {
                                LocationObj.Save();
                            }
                            else
                            {
                                throw new Exception(string.Join("\n", LocationObj.BrokenRulesCollection.Select(x => x.Description)));
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("LocationCode='{0}'", locationRow["LocationCode"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };

            view.ShowDialog(App.Shell);
            return true;
        }

        private void View_PrintRequested(object sender, List<Location> locationList)
        {
            try
            {
                foreach (var location in locationList)
                {
                    var prn = Prn.GetPrn(PrnType.Location);
                    using (var printingManager = PrintFactory.GetManager())
                    {
                        var printer = printingManager.GetProvider<IPrinterFactory>();

                        prn.PrnTemplate = prn.PrnTemplate.Replace("{LocationCode}", location.LocationCode);
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{PlantCode}", location.Site.Value);
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{Type}", location.Type.DisplayName());
                        prn.PrnTemplate = prn.PrnTemplate.Replace("{Mode}", location.Mode.DisplayName());
                        string dataToPrint = prn.PrnTemplate;

                        //replace values here
                        if (printer.Print(dataToPrint) == PrintStatus.Error) throw new BCILException(printer.Message);

                        var label = BL.Label.NewLabel();
                        label.LabelCode = location.LocationCode;
                        label.LabelObjType = BL.Enums.LabelType.Location;
                        label.LableObjTypeId = location.LocationId;
                        label.SiteId = App.Login.LoginSite.SiteId;
                        label.LocationId = location.LocationId;
                        label.CreatedBy = App.Login.Employee.EmployeeId;
                        label.CreatedOn = DateTime.Now;
                        label.Save();
                    }
                }
                View.ShowMessage("Label is printed");
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Events
    }
}