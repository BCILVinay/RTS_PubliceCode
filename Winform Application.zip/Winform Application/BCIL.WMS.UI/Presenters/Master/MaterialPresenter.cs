﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class MaterialPresenter : Presenter<IMaterialView>
    {
        public MaterialPresenter(IMaterialView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.MaterialModel();
            view.Load += View_Load;
            view.SaveRequested += View_SaveRequested;
            view.CancelRequested += View_CancelRequested;
        }

        #region Private Methods

        private bool Save()
        {
            if (View.Model.Material.IsValid)
            {
                View.Model.Material.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Material.ApplyEdits();
                View.Model.Material = View.Model.Material.Save();
                View.RefreshBinding();
                //BcilLogger.WriteMessage(LogLevel.Info, "Material data :" + Serializer.Json.Serialize(View.Model.Material).ToString() + " saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.Material.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                //Changes for Read only view
                View.DialogResult = DialogResult.OK;
                return;

                if (View.Model.Material == null || View.Model.Material.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.AddEditPermision.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.Material.CancelEdit();
                    return;
                }

                if (Save())
                {
                    View.ShowMessage("Material saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_SaveRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.AddEditPermision.HasPermission()) return;
                if (Save())
                {
                    View.ShowMessage("Material saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.ToolingList.Add(new KeyValue<long, string>(0, "None"));
                var toolingList = ToolingDVL.GetToolingDVL();
                if (toolingList.HaveItems())
                {
                    foreach (var item in toolingList)
                    {
                        View.Model.ToolingList.Add(new KeyValue<long, string>(item.ToolingId, item.ToolingCode));
                    }
                }
                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}