﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using BCIL.WMS.BL;
using BCIL.WMS.UI.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.WMS.UI.Presenters
{
    public class ToolingListPresenter : Presenter<IToolingListView>
    {
        #region Constructor

        public ToolingListPresenter(IToolingListView view) : base(view)
        {
            if (view.Model == null) view.Model = new Models.ToolingListModel();
            view.Load += View_Load;
            view.AddToolingRequested += View_AddToolingRequested;
            view.EditToolingRequested += View_EditToolingRequested;
            view.ImportDataRequested += View_ImportDataRequested;
            view.SearchRequested += View_SearchRequested;
            view.NextPageResultsRequested += View_NextPageResultsRequested;
            view.PrevPageResultsRequested += View_PrevPageResultsRequested;
        }

        #endregion Constructor

        #region Private Events

        private void DoRefresh()
        {
            View.Model.Toolings = ToolingDVL.GetToolingDVL(View.Model.SearchCriteria);
            View.RefreshGridView();
        }

        private void View_SearchRequested(object sender, EventArgs e)
        {
            try
            {
                DoRefresh();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_PrevPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                DoRefresh();
                View.RefreshGridView();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber += 1;
                View.ShowException(ex);
            }
        }

        private void View_NextPageResultsRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.SearchCriteria.PageNumber += 1;
                DoRefresh();
                View.RefreshGridView();
            }
            catch (Exception ex)
            {
                View.Model.SearchCriteria.PageNumber -= 1;
                View.ShowException(ex);
            }
        }

        private void View_AddToolingRequested(object sender, EventArgs e)
        {
            try
            {
                ToolingView view = new ToolingView();
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditToolingRequested(object sender, Tooling tooling)
        {
            try
            {
                ToolingView view = new ToolingView(tooling);
                if (view.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                var criteria = new LinesSearchCriteria() { SiteId = App.Login.LoginSite.SiteId };
                Lines lines = Lines.GetLines(criteria);
                View.Model.Lines = new List<Line>();
                View.Model.Lines.Add(new Line() { LineId = 0, Code = "None" });
                View.Model.Lines.AddRange(lines.ToList());

                View.RefreshBinding();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var IsProcessDone = ImportTooling();
                if (IsProcessDone)
                {
                    DoRefresh();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool ImportTooling()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                  { "ToolingCode", true },{ "ToolingSpeed", true },{ "LineCode", true },  { "PrefencesLineCode", true },  { "LocationCode", true }, { "OtherInfo",true }
            };
            ImportView view = new ImportView();
            view.Text = "Import Tooling";
            view.TemplateDataSet = new Template().GetImportToolingTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "ToolingCode", "ToolingSpeed", "LineCode", "PrefencesLineCode", "LocationCode", "OtherInfo");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable materialTable = dtToImport.DefaultView.ToTable(true);

                    foreach (DataRow toolingRow in materialTable.Rows)
                    {
                        try
                        {
                            //toolingRow["LineCode"].ToString()

                            var _location = Location.GetLocationByCode(toolingRow["LocationCode"].ToString());
                            CodeContract.Required<BCILException>(_location.IsNotNull() && _location.LocationId > 0, "Location is invalid");
                            var _line = Line.GetLineByCode(toolingRow["LineCode"].ToString());
                            CodeContract.Required<BCILException>(_line.IsNotNull() && _line.LineId > 0, "Line code is invalid");
                            var _linePrefences = Line.GetLineByCode(toolingRow["PrefencesLineCode"].ToString());
                            CodeContract.Required<BCILException>(_linePrefences.IsNotNull() && _linePrefences.LineId > 0, "Prefences line code is invalid");
                            if (_location != null)
                            {
                                var ToolingObj = BL.Tooling.NewTooling();
                                ToolingObj.ToolingCode = toolingRow["ToolingCode"].ToString();
                                ToolingObj.ToolingName = toolingRow["ToolingCode"].ToString();
                                ToolingObj.ToolingSpeed = Convert.ToDecimal(toolingRow["ToolingSpeed"].ToString());
                                ToolingObj.OtherInfo = toolingRow["OtherInfo"].ToString();
                                ToolingObj.LineId = _line.LineId;
                                ToolingObj.LinePrefences = _linePrefences.LineId;
                                ToolingObj.Location = new KeyValue<Int64, string>(_location.LocationId, _location.LocationCode);
                                ToolingObj.CreatedOn = DateTime.Now;
                                ToolingObj.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                ToolingObj.UpdatedOn = DateTime.Now;
                                ToolingObj.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                ToolingObj.IsActive = true;
                                ToolingObj.IsImported = true;
                                if (ToolingObj.IsValid)
                                {
                                    ToolingObj.Save();
                                }
                                else
                                {
                                    throw new Exception(string.Join("\n", ToolingObj.BrokenRulesCollection.Select(x => x.Description)));
                                }
                            }
                            else
                            {
                                throw new Exception(string.Format("Location is invalid {0}", Convert.ToInt64(toolingRow["LocationCode"].ToString())));
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("ToolingCode='{0}'", toolingRow["ToolingCode"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };

            view.ShowDialog(App.Shell);
            return true;
        }

        #endregion Private Events
    }
}