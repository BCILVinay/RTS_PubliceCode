﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class MaterialBinListModel
    {
        public MaterialBinListModel()
        {
            SearchCriteria = new MaterialBinDVLSearchCriteria() { PageNumber = 1, PageSize = 50, LocationCode = "", MaterialBinName = "" };
        }

        public MaterialBinDVLSearchCriteria SearchCriteria { get; set; }
        public MaterialBinDVL MaterialBins { get; set; }
    }
}