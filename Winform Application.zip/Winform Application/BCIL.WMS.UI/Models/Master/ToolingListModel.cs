﻿using BCIL.WMS.BL;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class ToolingListModel
    {
        public ToolingListModel()
        {
            SearchCriteria = new ToolingDVLSearchCriteria() { PageNumber = 1, PageSize = 50, ToolingCode = "", ToolingId = 0 };
        }

        public ToolingDVLSearchCriteria SearchCriteria { get; set; }
        public ToolingDVL Toolings { get; set; }

        public List<Line> Lines { get; set; }
    }
}