﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class ProductionOrderModel
    {
        public ProductionOrderModel()
        {
            ProductionOrder = ProductionOrder.NewProductionOrder();
        }
        public ProductionOrder ProductionOrder { get; set; }

        public List<KeyValuePair<MovementType, string>> MovementTypes { get; set; } = Enum<MovementType>.GetItems();
        public List<KeyValuePair<ProductionOrderStatus, string>> Status { get; set; } = Enum<ProductionOrderStatus>.GetItems();
    }
}
