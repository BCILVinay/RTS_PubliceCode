﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class LocationModel
    {
        public LocationModel()
        {
            LocationTypes = Enum<LocationType>.GetItems();
            Modes = Enum<Mode>.GetItems();
            Location = Location.NewLocation();
            Location.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Location.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            SiteList = new List<KeyValue<int, string>>();
        }
        public List<KeyValue<int, string>> SiteList { get; set; }
        public Location Location { get; set; }
        public List<KeyValuePair<LocationType, string>> LocationTypes { get; set; }
        public List<KeyValuePair<Mode, string>> Modes { get; set; }
    }
}