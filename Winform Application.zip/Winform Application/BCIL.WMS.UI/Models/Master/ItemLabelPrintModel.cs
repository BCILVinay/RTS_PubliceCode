﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class ItemLabelPrintModel
    {
        public ItemLabelPrintModel()
        {
            POrder = ProductionOrder.NewProductionOrder();
            QtyToPrint = 1;
        }

        public ProductionOrder POrder { get; set; }
        public int MaterialPackSize { get; set; }
        public int QtyToPrint { get; set; }
        public int CalculatedItemQty { get { return QtyToPrint * MaterialPackSize; } }
        public int TotalItemQty { get; set; }
        public int TotalBundleQty { get; set; }
        public int TotalPendingBundleQty { get { return TotalBundleQty - (TotalPrintedItemQty / MaterialPackSize); } }
        public int TotalPrintedItemQty { get; set; }
    }
}