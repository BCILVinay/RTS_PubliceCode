﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class SiteModel
    {
        public SiteModel()
        {
            Site = Site.NewSite();
            Site.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Site.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
        }
        public Site Site { get; set; }
    }
}
