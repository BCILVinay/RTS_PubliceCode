﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class MaterialModel
    {
        public MaterialModel()
        {
            Material = Material.NewMaterial();
            Material.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Material.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);

            ToolingList = new List<KeyValue<Int64, string>>();
        }
        public UserFile ItemImage { get; set; }
        public Material Material { get; set; }

        public bool IsReadOnlyView { get; set; }

        public List<KeyValue<Int64, string>> ToolingList { get; set; }
    }
}