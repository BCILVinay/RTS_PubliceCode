﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class ToolingModel
    {
        public ToolingModel()
        {
            Tooling = Tooling.NewTooling();
            Tooling.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Tooling.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);

            LocationList = new List<KeyValue<long, string>>();
        }

        public List<KeyValue<Int64, string>> LocationList { get; set; }

        public List<Line> Lines { get; set; }

        public List<Line> LinePrefences { get; set; }

        public Tooling Tooling { get; set; }
    }
}