﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class LocationListModel
    {
        public  LocationListModel()
        {
            Type = new List<KeyValue<int, string>>();
            Type.Add(new KeyValue<int, string>(-1, "All"));
            Type.AddRange(Enum<LocationType>.GetItemsWitIntKey());

            Mode = new List<KeyValue<int, string>>();
            Mode.Add(new KeyValue<int, string>(-1, "All"));
            Mode.AddRange(Enum<Mode>.GetItemsWitIntKey());

            State = new List<KeyValue<int, string>>();
            State.Add(new KeyValue<int, string>(-1, "All"));
            State.Add(new KeyValue<int, string>(0, "No"));
            State.Add(new KeyValue<int, string>(1, "Yes"));

            SearchCriteria = new LocationDVLSearchCriteria() {  PageNumber =1, PageSize =50, Mode =-1, State =-1, Type =-1};

        }

        public LocationDVL Locations { get; set; }

        public LocationDVLSearchCriteria SearchCriteria { get; set; } 

        public List<KeyValue<int, string>> Type { get; set; }

        public List<KeyValue<int, string>> Mode { get; set; }

        public List<KeyValue<int, string>> State { get; set; }
    }
}
