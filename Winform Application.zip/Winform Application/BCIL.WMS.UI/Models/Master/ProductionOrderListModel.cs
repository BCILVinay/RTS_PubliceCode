﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class ProductionOrderListModel
    {
        public ProductionOrderListModel()
        {
            ProductionOrders = new ProductionOrderDVL();
            SearchCriteria = new ProductionOrderSearchCriteria() { PageNumber = 1, PageSize = 50, POrderNo = "" };
        }

        public ProductionOrderSearchCriteria SearchCriteria { get; set; }

        public ProductionOrderDVL ProductionOrders { get; set; }
    }
}