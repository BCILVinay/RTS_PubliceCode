﻿using BCIL.Administration.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class SiteListModel
    {
       
        public SiteList Sites { get; set; }
    }
}
