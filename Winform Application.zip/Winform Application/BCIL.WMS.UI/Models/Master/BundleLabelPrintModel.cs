﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class BundleLabelPrintModel
    {
        public BundleLabelPrintModel()
        {
            POrder = ProductionOrder.NewProductionOrder();
            QtyToPrint = 1;
        }

        public ProductionOrder POrder { get; set; }

        public int QtyToPrint { get; set; }

        public int TotalBundleQty { get; set; }

        public int TotalPrintedBundleQty { get; set; }

        public int LastPrintedSrNo { get; set; }
    }
}