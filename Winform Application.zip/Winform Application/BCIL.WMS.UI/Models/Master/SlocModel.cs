﻿using BCIL.UIHelper;
using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class MaterialBinModel
    {
        public MaterialBinModel()
        {
            MaterialBin = MaterialBin.NewMaterialBin();
            MaterialBin.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            MaterialBin.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);

            Materials = new List<KeyValue<long, string>>();
        }

        public MaterialBin MaterialBin { get; set; }

        public List<KeyValue<Int64,string>> Materials { get; set; }
    }
}
