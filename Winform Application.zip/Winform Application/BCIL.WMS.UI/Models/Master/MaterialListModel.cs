﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class MaterialListModel
    {
        public MaterialListModel()
        {
            SearchCriteria = new MaterialGenericSearchCriteria() { PageNumber = 1, PageSize = 50, MeterialCode = "", MeterialDesc = "" };
        }

        public MaterialGenericSearchCriteria SearchCriteria { get; set; }
        public MaterialDVL Materials { get; set; }
    }
}
