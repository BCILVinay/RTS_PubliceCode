﻿using BCIL.Utility;
using BCIL.WMS.BL;
using BCIL.WMS.BL.Enums;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class ProductionOrderSearchModel
    {
        public ProductionOrderSearchModel()
        {
            MovementType = new List<KeyValue<int, string>>();
            MovementType.Add(new KeyValue<int, string>(-1, "All"));
            MovementType.AddRange(Enum<MovementType>.GetItemsWitIntKey());

            ProductionOrders = new List<ProductionOrder>();
            SearchCriteria = new ProductionOrderSearchCriteria() { PageNumber = 1, PageSize = 50, POrderNo = "", LineId = (App.WorkStation.WSLine.IsNotNull()) ? App.WorkStation.WSLine.LineId : 0 };
        }

        public List<KeyValue<int, string>> MovementType { get; set; }

        public ProductionOrderSearchCriteria SearchCriteria { get; set; }

        public List<ProductionOrder> ProductionOrders { get; set; }
    }
}