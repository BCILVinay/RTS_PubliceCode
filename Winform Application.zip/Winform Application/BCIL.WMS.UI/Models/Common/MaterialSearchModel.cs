﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class MaterialSearchModel
    {
        public MaterialSearchModel()
        {
            SearchedMaterials = new MaterialDVL();
            SearchCriteria = new MaterialGenericSearchCriteria() { MeterialCode = "", MeterialDesc = "", PageNumber = 1, PageSize = 50 };
        }
        public MaterialDVL SelectedMaterial  { get; set; }

        public MaterialDVL SearchedMaterials { get; set; }
        public MaterialGenericSearchCriteria SearchCriteria { get; set; }
        public int PageSize { get; set; } = 50;
        public int PageIndex { get; set; } = 1;
    }
}
