﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models.Common
{
    public class WorkstationSetupModel
    {
        public List<Location> Locations { get; set; }

        public List<Line> Lines { get; set; }
    }
}
