﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class LocationSearchModel
    {

        public LocationSearchModel()
        {
            Type = new List<KeyValue<int, string>>();
            Type.Add(new KeyValue<int, string>(-1, "All"));
            Type.AddRange(Enum<LocationType>.GetItemsWitIntKey());

            Mode = new List<KeyValue<int, string>>();
            Mode.Add(new KeyValue<int, string>(-1, "All"));
            Mode.AddRange(Enum<Mode>.GetItemsWitIntKey());

            State = new List<KeyValue<int, string>>();
            State.Add(new KeyValue<int, string>(-1, "All"));
            State.Add(new KeyValue<int, string>(0, "No"));
            State.Add(new KeyValue<int, string>(1, "Yes"));

            SearchedLocations = new LocationDVL();
            SearchCriteria = new LocationDVLSearchCriteria()
            {
                PageNumber = 1, PageSize = 50, LocationCode = "", Name = "", Mode = -1, State = -1, Type = -1
            };
        }
        public List<KeyValue<int, string>> Type { get; set; }

        public List<KeyValue<int, string>> Mode { get; set; }

        public List<KeyValue<int, string>> State { get; set; }
        public LocationDVL SelectedLocations { get; set; }

        public LocationDVL SearchedLocations { get; set; }
        public LocationDVLSearchCriteria SearchCriteria { get; set; }
        public int PageSize { get; set; } = 50;
        public int PageIndex { get; set; } = 1;
    }
}