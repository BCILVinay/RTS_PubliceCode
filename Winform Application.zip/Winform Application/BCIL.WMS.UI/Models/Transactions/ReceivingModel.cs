﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class ReceivingModel
    {
        public ReceivingModel()
        {
            Receiving = Receiving.NewReceiving();
        }
        public Receiving Receiving { get; set; }
    }
}
