﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class PickListDetailModel
    {
        public Picklist Picklist { get; set; }

        public Pickings Pickings { get; set; }
    }
}