﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class PickingListModel
    {
        public PickingListModel()
        {
            SearchCriteria = new PicklistGenericSearchCriteria() { PageNumber = 1, PageSize = 50 };
        }
        public Picklists PickingList { get; set; }

        public PicklistGenericSearchCriteria SearchCriteria { get; set; }
    }
}
