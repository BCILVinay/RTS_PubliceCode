﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class InvoiceListModel
    {
        public InvoiceListModel()
        {
            SearchCriteria = new InvoiceGenericSearchCriteria() { PageNumber = 1, PageSize = 50 };
        }
        public Invoices InvoiceList { get; set; }

        public InvoiceGenericSearchCriteria SearchCriteria { get; set; }
    }
}
