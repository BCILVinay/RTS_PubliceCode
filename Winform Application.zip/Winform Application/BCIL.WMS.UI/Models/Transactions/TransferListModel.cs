﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class TransferListModel
    {
        public TransferListModel()
        {
            SearchCriteria = new TransferGenericSearchCriteria() { PageNumber = 1, PageSize = 50 };
        }

        public Transfers Transfers { get; set; }

        public TransferGenericSearchCriteria SearchCriteria { get; set; }
    }
}