﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class BundleItemDetailsModel
    {
        public BundleItemDetailsModel()
        {
            Bundle = Bundle.NewBundle();
            Items = new Items();
        }

        public Bundle Bundle { get; set; }
        public Items Items { get; set; }
    }
}
