﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class TransferDetailModel
    {
        public TransferDetailModel()
        {
            Transfer = Transfer.NewTransfer();
        }
        public Transfer Transfer { get; set; }
    }
}
