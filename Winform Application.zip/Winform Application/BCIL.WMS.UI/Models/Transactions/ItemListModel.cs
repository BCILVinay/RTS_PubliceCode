﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class ItemListModel
    {
        public ItemListModel()
        {
            SearchCriteria = new ItemGenericSearchCriteria() { PageNumber = 1, PageSize = 50, BundleCode = "", ItemCode = "" };
        }

        public Items Items { get; set; }

        public ItemGenericSearchCriteria SearchCriteria { get; set; }
    }
}