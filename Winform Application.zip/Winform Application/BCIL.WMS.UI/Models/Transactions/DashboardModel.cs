﻿using System;
using BCIL.WMS.BL;
using System.Data;

namespace BCIL.WMS.UI.Models
{
    public class DashboardModel
    {
        public DashboardModel()
        {
            SearchCriteria = new DashboardSearchCriteria { FromDate = DateTime.Today.Date, ToDate = DateTime.Today.Date };
        }
        public DashboardSearchCriteria SearchCriteria { get; set; }
        public DataTable BundlePutawayData { get; set; }
        public DataTable BundlePickedData { get; set; }
        public DataTable ProductionData { get; set; }
    }
}