﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class ProductionPlanningListModel
    {
        public ProductionPlanningListModel()
        {
            SearchCriteria = new PoPlanningReadOnlySearchCriteria() { PageNumber = 1, PageSize = 50, PlanningNo = "" };
        }

        public PoPlanningReadOnlyList ProductionPlannings { get; set; }

        public PoPlanningReadOnlySearchCriteria SearchCriteria { get; set; }
    }
}