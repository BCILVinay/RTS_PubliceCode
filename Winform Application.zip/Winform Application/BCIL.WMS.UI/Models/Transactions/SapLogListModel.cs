﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BCIL.WMS.BL.SapPostingLogs;

namespace BCIL.WMS.UI.Models
{
    public class SapLogListModel
    {
        public SapLogListModel ()
        {
            SapProcesses = new List<KeyValue<int, string>>();
            SapProcesses.Add(new KeyValue<int, string>(-1, "All"));
            SapProcesses.AddRange(Enum<SapProcess>.GetItemsWitIntKey());
            SapPostingLogs = new SapPostingLogs();
            SearchCriteria = new SapPostingLogCriteria1();
        }

        public SapPostingLogCriteria1 SearchCriteria { get; set; }

        public List<KeyValue<int, string>> SapProcesses { get; set; } 

        public SapPostingLogs SapPostingLogs { get; set; }
    }
}
