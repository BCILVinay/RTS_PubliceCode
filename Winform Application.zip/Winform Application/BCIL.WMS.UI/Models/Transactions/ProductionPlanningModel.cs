﻿using BCIL.Utility;
using BCIL.WMS.BL;
using System;
using System.Collections.Generic;

namespace BCIL.WMS.UI.Models
{
    public class ProductionPlanningModel
    {
        public ProductionPlanningModel()
        {
            ProductionPlanning = ProductionPlanning.NewProductionPlanning();
            SelectedPOrders = new List<ProductionOrder>();

            Toolings = new List<KeyValue<long, string>>();
            Toolings.Add(new KeyValue<long, string>(0, "None"));

            MaterialBins = new List<KeyValue<long, string>>();
            MaterialBins.Add(new KeyValue<long, string>(0, "None"));

            LinePrefences = new List<KeyValue<int, string>>();
            LinePrefences.Add(new KeyValue<int, string>(0, "None"));
            Lines = new Lines();
            Lines.Add(new Line { LineId = 0, Code="", Speed = 1 });

        }

        public ProductionPlanning ProductionPlanning { get; set; }
        public List<KeyValue<Int64, string>> Toolings { get; set; }
        public List<KeyValue<Int64, string>> MaterialBins { get; set; }

        public List<KeyValue<int, string>> LinePrefences { get; set; }
        public List<ProductionOrder> SelectedPOrders { get; set; } = new List<ProductionOrder>();

        public Lines Lines { get; set; }
    }
}