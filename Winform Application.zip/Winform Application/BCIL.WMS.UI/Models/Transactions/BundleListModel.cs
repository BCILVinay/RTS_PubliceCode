﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class BundleListModel
    {
        public BundleListModel()
        {
            SearchCriteria = new BundleGenericSearchCriteria() { PageNumber = 1, PageSize = 50, POCode = "", BundleCode = "" , LocationCode=""};
        }
        public Bundles Bundles { get; set; }

        public BundleGenericSearchCriteria SearchCriteria { get; set; }
    }
}
