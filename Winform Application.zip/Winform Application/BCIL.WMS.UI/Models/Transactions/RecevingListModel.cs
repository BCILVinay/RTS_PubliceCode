﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class RecevingListModel
    {
        public RecevingListModel()
        {
            Receivings = new Receivings();
            SearchCriteria = new ReceivingGenericSearchCriteria() { PageNumber = 1, PageSize = 50, DeliveryNo = "" };
        } 

        public Receivings Receivings { get; set; }
        public ReceivingGenericSearchCriteria SearchCriteria { get; set; }
    }
}
