﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class MaterialBundleReadOnlyModel
    {
        public MaterialBundleReadOnlyModel()
        {
            SearchCriteria = new MaterialBundleSearchCriteria() { PageNumber = 1, PageSize = 1000, MaterialCode = "", LocationCode = "" };
        }

        public Bundles Bundles { get; set; }

        public MaterialBundleSearchCriteria SearchCriteria { get; set; }
    }
}