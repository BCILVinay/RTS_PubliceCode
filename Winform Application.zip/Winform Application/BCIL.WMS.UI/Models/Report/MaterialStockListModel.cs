﻿using BCIL.WMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.UI.Models
{
    public class MaterialStockListModel
    {
        public MaterialStockListModel()
        {
            SearchCriteria = new MaterialStockSearchCriteria() { PageNumber = 1, PageSize = 50, MaterialCode = "", LocationCode = "" };
        }
        public MaterialStocks MaterialStocks { get; set; }

        public MaterialStockSearchCriteria SearchCriteria { get; set; }
    }
}
