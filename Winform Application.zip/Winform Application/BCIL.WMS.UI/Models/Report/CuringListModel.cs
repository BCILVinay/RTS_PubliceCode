﻿using BCIL.WMS.BL;

namespace BCIL.WMS.UI.Models
{
    public class CuringListModel
    {
        public CuringListModel()
        {
            SearchCriteria = new CuringReadOnlySearchCriteria() { PageNumber = 1, PageSize = 50, MaterialCode = ""};
        }

        public CuringReadOnlyList Curings { get; set; }

        public CuringReadOnlySearchCriteria SearchCriteria { get; set; }
    }
}