﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.Printing
{
    public interface IPrinterFactory
    {
        PrintStatus Print(string dataToPrint);
        string Message { get; }
    }

    public enum PrintStatus
    {
        None = 0,
        Success = 1,
        Error = 2
    }
}
