﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.Printing
{
    public interface IPrintingManager : IDisposable
    {
        string Data { get; set; }
        T GetProvider<T>() where T : class;
    }

}
