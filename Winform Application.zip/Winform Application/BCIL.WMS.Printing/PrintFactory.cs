﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.Printing
{
    public class PrintFactory
    {
        private static Type _printingType;

        private static string GetTypeName(string factoryName)
        {
            var nameSpace = ConfigurationManager.AppSettings["BarcodePrinterFactory"];
            return String.Format("{0}.{1}, {0}", nameSpace, factoryName);
        }

        public static IPrintingManager GetManager()
        {
            if (_printingType == null)
            {
                var printingTypeName = GetTypeName("PrintManager");
                if (!string.IsNullOrEmpty(printingTypeName))
                    _printingType = Type.GetType(printingTypeName);
                else
                    throw new NullReferenceException("PrintingManagerType");
                if (_printingType == null)
                    throw new ArgumentException(string.Format("Type {0} could not be found", printingTypeName));
            }
            return (IPrintingManager)Activator.CreateInstance(_printingType);
        }
    }
}
