﻿using System;
using System.Net;

namespace BCIL.WMS.Printing.Network
{
    public class PrinterFactory : IPrinterFactory, IDisposable
    {
        private string _errorMessage = "";

        private PrintStatus _printStatus = PrintStatus.None;

        private Printer _printer;

        private void InitializePrinter()
        {
            try {
                _errorMessage = "";
                _printStatus = PrintStatus.None;
                _printer = new Printer(new IPEndPoint(IPAddress.Parse("192.168.100.81"), 233));
                _printer.Connect();
            }
            catch (System.Exception ex) {
                _printStatus = PrintStatus.Error;
                _errorMessage = ex.Message;
            }
        }

        public string Message
        {
            get { return _errorMessage; }
        }

        public PrintStatus Print(string printData)
        {
            try {
                if (_printStatus != PrintStatus.Success) {
                    InitializePrinter();
                }

                if (_printStatus != PrintStatus.Error) {
                    _printer.Print(printData);
                    return PrintStatus.Success;
                }
                return PrintStatus.Success;
            }
            catch (System.Exception ex) {
                _errorMessage = ex.Message;
            }
            return PrintStatus.Error;
        }

        public void Dispose()
        {
            if (_printer != null)
                _printer.Dispose();
            _printer = null;
        }
    }
}