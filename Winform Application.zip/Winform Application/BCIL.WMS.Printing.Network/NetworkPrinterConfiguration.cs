﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.Printing.Network
{
    public class NetworkPrinterConfiguration
    {
        public string IPAddress { get; set; }

        public int Port { get; set; }
    }
}
