﻿using BCIL;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace BCIL.WMS.Printing.Network
{
    public class Printer : IDisposable
    {
        #region Private Fields

        private Socket _socket = null;

        #endregion Private Fields

        #region Public Constructors

        public Printer(IPEndPoint printerAddress)
        {
            PrinterAddress = printerAddress;
        }

        #endregion Public Constructors

        #region Properties

        public IPEndPoint PrinterAddress { get; set; }

        private bool IsConnected
        {
            get
            {
                return _socket != null && _socket.Connected;
            }
        }
        #endregion Properties

        #region Public Methods

        public void Connect()
        {
            if (!IsConnected)
            {
                if (PrinterAddress == null) throw new BCILException("Invalid printer");
                _socket = new Socket(PrinterAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                _socket.Connect(PrinterAddress);
            }
            IsReadyToPrint();
        }

        public void Dispose()
        {
            if (IsConnected)
            {
                _socket.Close();
            }
            _socket = null;
        }

        public void Print(string value)
        {
            if (!IsConnected) Connect();

            Byte[] dataToSend = System.Text.Encoding.ASCII.GetBytes(value);
            _socket.Send(dataToSend);
        }

        #endregion Public Methods

        #region Private Methods

        private string GetResponse(Socket client)
        {
            Byte[] _data = new Byte[8025];
            Int32 byteCount = client.Receive(_data);
            return System.Text.Encoding.ASCII.GetString(_data, 0, byteCount);
        }

        private bool IsReadyToPrint()
        {
            byte[] dataToSend = System.Text.Encoding.ASCII.GetBytes("~HS");
            _socket.Send(dataToSend);

            string response = GetResponse(_socket);
            string[] data = response.Split(',');

            if (data.Length <= 14) throw new BCILException("Unknown Error");
            if (data[1].Trim() == "1") throw new BCILException("Printer paper out");
            if (data[2].Trim() == "1") throw new BCILException("Printer in pause status");
            if (data[5].Trim() == "1") throw new BCILException("Printer buffer full");
            if (Convert.ToInt64(data[4].Trim()) > 50) throw new BCILException("Unused bit greater than 50");
            if (data[14].Trim() == "1") throw new BCILException("Printer ribbon out");

            return true;
        }

        #endregion Private Methods

    }
}