﻿using BCIL.WMS.SAPService.FGToTrolly;
using BCIL.WMS.SAPService.ProductionOrderConfGetData;
using BCIL.WMS.SAPService.SAP_PI;
using BCIL.WMS.SAPService.SI_Picking;
using BCIL.WMS.SAPService.PGI;
using BCIL.WMS.SAPService.GR;
using BCIL.WMS.SAPService.TrolleyToWM;
using BCIL.WMS.SAPService.Putaway;

namespace BCIL.WMS
{
    public class SAP
    {
        public static SI_POPostData_OAClient PI => new SI_POPostData_OAClient();
        public static SI_POConfGetData_OSClient POConfGetData=> new SI_POConfGetData_OSClient();
        public static SI_FGToTrolleyGetData_OSClient FGToTrolley => new SI_FGToTrolleyGetData_OSClient();
        public static SI_PickingGetData_OSClient Picking => new SI_PickingGetData_OSClient();
        public static SI_PGIGetData_OSClient PGI => new SI_PGIGetData_OSClient();
        public static SI_GRGetData_OSClient GR => new SI_GRGetData_OSClient();
        public static SI_TrolleyToWMGetData_OSClient TrolleyToWM => new SI_TrolleyToWMGetData_OSClient();
        public static SI_PutwayGetData_OSClient Putaway => new SI_PutwayGetData_OSClient();
    }

    public class MyClass
    {
        public void aaa()
        { 
            BCIL.WMS.SAPService.ProductionOrderConfGetData.SI_POConfGetData_OSClient clnt = new SAPService.ProductionOrderConfGetData.SI_POConfGetData_OSClient();
            clnt.SI_POConfGetData_OS(new SAPService.ProductionOrderConfGetData.DT_POConfGetDataReq());

            var aa = new SAPService.ProductionOrderConfGetData.DT_POConfGetDataReq();
            aa.HEADER = new SAPService.ProductionOrderConfGetData.DT_POConfGetDataReqHEADER() {
                PLANTCODE = "",
                PO_DATE = "",
                PO_NO = ""
            };
            aa.ITEM = new SAPService.ProductionOrderConfGetData.DT_POConfGetDataReqITEM[10];
            aa.ITEM[0] = new SAPService.ProductionOrderConfGetData.DT_POConfGetDataReqITEM() {
                BARCODE_NO = "",
                MATERIALCODE = "",
                QUANTITY = "",
                SLOC = ""
            };
        }
    }
}
