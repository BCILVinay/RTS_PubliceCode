﻿using BCIL.WMS.Printing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.WMS.Printing.File
{
    public class PrinterFactory : IPrinterFactory, IDisposable
    {
        private string _errorMessage = "";

        private PrintStatus _printStatus = PrintStatus.None;
        private string folder = "PrintedPrn";

        private void InitializePrinter()
        {
            try
            {
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            }
            catch (System.Exception ex)
            {
                _printStatus = PrintStatus.Error;
                _errorMessage = ex.Message;
            }
        }

        public string Message
        {
            get { return _errorMessage; }
        }

        public PrintStatus Print(string printData)
        {
            try
            {
                if (_printStatus != PrintStatus.Success)
                {
                    InitializePrinter();
                }

                if (_printStatus != PrintStatus.Error)
                {
                    using (TextWriter txt = new StreamWriter(String.Format("{0}\\prn_{1}.txt", folder, DateTime.Now.ToString("yyyyMMdd_hh_mm_ss"))))
                    {
                        txt.Write(printData);
                    }
                    System.Threading.Thread.Sleep(1000);
                    return PrintStatus.Success;
                }
                return PrintStatus.Success;
            }
            catch (System.Exception ex)
            {
                _errorMessage = ex.Message;
            }
            return PrintStatus.Error;
        }

        public void Dispose()
        {
        }
    }
}
