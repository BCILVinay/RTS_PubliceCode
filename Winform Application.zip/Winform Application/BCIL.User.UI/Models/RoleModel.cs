﻿using BCIL.User.BL;
using BCIL.Utility;
using System;

namespace BCIL.User.UI.Models
{
    public class RoleModel
    {
        public RoleModel()
        {
            Role = Role.NewRole();
            Role.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Role.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
            Role.CreatedDate = DateTime.Now;
            Role.UpdatedDate = DateTime.Now;
        }
        #region Public Properties

        public Role Role { get; set; }

        #endregion Public Properties
    }
}