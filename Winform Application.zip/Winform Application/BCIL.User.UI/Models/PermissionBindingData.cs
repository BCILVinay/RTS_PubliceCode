﻿using BCIL.User.BL.Enums;
using BCIL.User.BL.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.UI.Models
{
    public class PermissionBindingData
    {
        #region Private Fields

        private RolePermission _nodePermission;

        #endregion Private Fields

        #region Public Constructors

        public PermissionBindingData(RolePermission permission)
        {
            _nodePermission = permission;
        }

        #endregion Public Constructors

        #region Public Properties

        public bool IsReadAndWrite
        {
            get { return _nodePermission.Rights == PermissionType.All; }
            set
            {
                _nodePermission.Rights = value == true ? PermissionType.All : PermissionType.None;
            }
        }

        public bool IsReadOnly
        {
            get { return _nodePermission.Rights == PermissionType.ReadOnly || _nodePermission.Rights == PermissionType.All; }
            set
            {
                if (_nodePermission.Rights != PermissionType.All)
                {
                    _nodePermission.Rights = value == true ? PermissionType.ReadOnly : PermissionType.None;
                }
            }
        }

        public string NodeCode
        {
            get { return _nodePermission.Node.Code; }
            set { _nodePermission.Node.Code = value; }
        }

        public string NodeName
        {
            get { return _nodePermission.Node.Name; }
            set { _nodePermission.Node.Name = value; }
        }

        public RolePermission NodePermissions
        {
            get { return _nodePermission; }
        }
        public string ParentNode
        {
            get { return _nodePermission.Node.ParentCode; }
            set { _nodePermission.Node.ParentCode = value; }
        }
        public string PermissionFromRole { get; set; }

        #endregion Public Properties
    }
}
