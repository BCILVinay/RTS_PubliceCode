﻿using BCIL.User.BL;
using System.Collections.Generic;

namespace BCIL.User.UI.Models
{
    public class UserListModel
    {
        #region Public Properties

        public EmployeeDVL Employees { get; set; }
        public int PageSize { get; set; } = 50;
        public int PageIndex { get; set; } = 1;

        #endregion Public Properties
    }
}