﻿using BCIL.Administration.BL;
using BCIL.User.BL;
using BCIL.User.UI.Models;
using System.Collections.Generic;

namespace BCIL.User.UI.Models
{
    public class RolePermissionModel
    {
        #region Public Fields

        public Dictionary<int, List<PermissionBindingData>> SitePermissions = new Dictionary<int, List<PermissionBindingData>>();

        #endregion Public Fields

        #region Public Properties

        public List<PermissionBindingData> BindablePermissions { get; set; }
        public Role Role { get; set; }
        public int SelectedSiteId { get; set; }
        public SiteList Sites { get; set; }

        #endregion Public Properties
    }
}