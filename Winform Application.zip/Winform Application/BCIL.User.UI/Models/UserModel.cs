﻿using BCIL.User.BL;

namespace BCIL.User.UI.Models
{
    public class UserModel
    {
        #region Public Properties

        public Employee Employee { get; set; }

        #endregion Public Properties
    }
}