﻿using BCIL.User.BL;
using System.Collections.Generic;

namespace BCIL.User.UI.Models
{
    public class RoleListModel
    {
        #region Public Properties

        public RoleDVL Roles { get; set; }

        #endregion Public Properties
    }
}