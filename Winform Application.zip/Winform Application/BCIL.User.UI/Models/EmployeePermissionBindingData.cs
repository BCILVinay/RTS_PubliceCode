﻿using BCIL.User.BL.Enums;
using BCIL.User.BL.Permission;

namespace BCIL.User.UI.Models
{
    public class EmployeePermissionBindingData
    {
        #region Private Fields

        private EmployeePermission _nodePermission;

        #endregion Private Fields

        #region Public Constructors

        public EmployeePermissionBindingData(EmployeePermission permission)
        {
            _nodePermission = permission;
        }

        #endregion Public Constructors

        #region Public Properties

        public bool IsReadAndWrite
        {
            get { return _nodePermission.Rights == PermissionType.All; }
            set
            {
                _nodePermission.Rights = value == true ? PermissionType.All : PermissionType.None;
                _nodePermission.IsRestricted = false;
            }
        }

        public bool IsReadOnly
        {
            get { return _nodePermission.Rights == PermissionType.ReadOnly || _nodePermission.Rights == PermissionType.All; }
            set
            {
                if (_nodePermission.Rights != PermissionType.All)
                {
                    _nodePermission.Rights = value == true ? PermissionType.ReadOnly : PermissionType.None;
                    _nodePermission.IsRestricted = false;
                }
            }
        }

        public bool IsRestricted
        {
            get
            {
                return _nodePermission.IsRestricted;
            }
            set
            {
                _nodePermission.IsRestricted = value;
                if (value == true)
                {
                    _nodePermission.Rights = PermissionType.None;
                }
            }
        }

        public string NodeCode
        {
            get { return _nodePermission.Node.Code; }
            set { _nodePermission.Node.Code = value; }
        }

        public string NodeName
        {
            get { return _nodePermission.Node.Name; }
            set { _nodePermission.Node.Name = value; }
        }

        public EmployeePermission NodePermissions
        {
            get { return _nodePermission; }
        }

        public string ParentNode
        {
            get { return _nodePermission.Node.ParentCode; }
            set { _nodePermission.Node.ParentCode = value; }
        }

        public string PermissionFromRole { get; set; }

        #endregion Public Properties
    }
}