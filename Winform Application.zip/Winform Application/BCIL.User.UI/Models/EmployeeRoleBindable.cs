﻿using BCIL.User.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCIL.User.UI.Models
{
    public class EmployeeRoleBindable
    {
        #region Private Fields

        private int _employeeIdToAssign;

        #endregion Private Fields

        #region Public Constructors

        public EmployeeRoleBindable(EmployeeRole employeeRole, int employeeToAssign)
        {
            EmployeeRole = employeeRole;
            EmployeeRole.BeginEdit();
            EmployeeIdToAssign = employeeToAssign;
        }

        #endregion Public Constructors

        #region Public Properties

        public bool Assigned
        {
            get
            {
                return (EmployeeRole.IsNew && EmployeeRole.EmployeeID > 0) || (!EmployeeRole.IsDeleted && EmployeeRole.EmployeeID > 0);
            }
            set
            {
                if (EmployeeRole.IsNew)
                {
                    if (value == true)
                    {
                        EmployeeRole.EmployeeID = _employeeIdToAssign;
                    }
                    else
                    {
                        EmployeeRole.EmployeeID = 0;
                        EmployeeRole.MarkAsClean();
                        EmployeeRole.MarkAsNew();
                    }
                }
                else
                {
                    if (value == true)
                    {
                        EmployeeRole.CancelEdit();
                        EmployeeRole.BeginEdit();
                    }
                    else
                        EmployeeRole.Delete();
                }
            }
        }

        public int EmployeeIdToAssign
        {
            get { return _employeeIdToAssign; }
            set { _employeeIdToAssign = value; }
        }

        public EmployeeRole EmployeeRole { get; private set; }

        public string RoleName
        {
            get { return EmployeeRole.RoleName; }
            set { EmployeeRole.RoleName = value; }
        }

        #endregion Public Properties
    }
}
