﻿using BCIL.Administration.BL;
using BCIL.User.BL;
using BCIL.User.BL.Permission;
using System.Collections.Generic;

namespace BCIL.User.UI.Models
{
    public class EmployeePermissionModel
    {
        #region Public Properties

        public Employee Employee { get; set; }
        public Dictionary<int, List<RolePermission>> RolePermissions { get; set; }
        public int SelectedSiteId { get; set; }
        public SiteList Sites { get; set; }

        #endregion Public Properties


        #region EmployeeRoles

        public Dictionary<int, List<EmployeeRoleBindable>> SiteEmployeeRoles = new Dictionary<int, List<EmployeeRoleBindable>>();
        public List<EmployeeRoleBindable> BindableRoles { get; set; }
        public List<Role> Roles { get; set; }
        #endregion EmployeeRoles

        #region EmployeePermission

        public Dictionary<int, List<EmployeePermissionBindingData>> SiteEmployeePermissions = new Dictionary<int, List<EmployeePermissionBindingData>>();
        private EmployeePermissionList _employeePermission;

        public List<EmployeePermissionBindingData> BindablePermissions { get; set; }

        public EmployeePermissionList EmployeePermissions
        {
            get
            {
                return _employeePermission;
            }
            set
            {
                _employeePermission = value;
            }
        }

        #endregion EmployeePermission
    }
}