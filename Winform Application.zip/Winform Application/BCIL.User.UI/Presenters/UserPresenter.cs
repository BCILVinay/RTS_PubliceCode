﻿using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.UI.Models;
using BCIL.User.UI.Views;
using BCIL.Utility;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class UserPresenter : Presenter<IUserView>
    {
        public UserPresenter(IUserView view)
            : base(view)
        {
            view.Model = new UserModel();
            view.Load += View_Load;
            view.SaveUserRequested += View_SaveUserRequested;
            view.CancelRequested += View_CancelRequested;
            view.ChangeCredentialRequested += View_ChangeCredentialRequested;
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.Employee.IsSelfDirty && View.AddEditPermision.HasPermission())
                {
                    if (View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (SaveUser())
                        {
                            View.ShowMessage("User saved.");
                            View.DialogResult = DialogResult.OK;
                            return;
                        }
                    }
                }
                View.DialogResult = DialogResult.Cancel;
                View.Model.Employee.CancelEdit();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_ChangeCredentialRequested(object sender, EventArgs e)
        {
            try
            {
                if (!View.ChangeCredentialPermission.HasPermission()) return;

                if (!string.IsNullOrWhiteSpace(View.Model.Employee.LoginId))
                {
                    CredentialView credView = new CredentialView(true, true);
                    credView.LoginId = View.Model.Employee.LoginId;
                    if (credView.ShowDialog(App.Shell) == DialogResult.OK)
                    {
                        var User = BL.User.GetUser(View.Model.Employee.EmployeeId);
                        User.Password = credView.NewPassword;
                        if (User.IsValid)
                        {
                            User.Save();
                            View.ShowMessage("Password changed successfully");
                        }
                        else
                        {
                            View.ShowException(string.Join(Environment.NewLine, User.BrokenRulesCollection.Select(x => x.Description)));
                        }
                    }
                }
                else
                {
                    CredentialView credView = new CredentialView(false, true);
                    if (credView.ShowDialog(App.Shell) == DialogResult.OK)
                    {
                        var User = BL.User.NewUser();
                        User.EmployeeId = View.Model.Employee.EmployeeId;
                        User.EmployeeName = View.Model.Employee.Name;
                        User.LoginId = credView.LoginId;
                        User.Password = credView.NewPassword;
                        User.CreatedBy = App.Login.Employee.EmployeeId;
                        User.UpdatedBy = App.Login.Employee.EmployeeId;

                        if (User.IsValid)
                        {
                            User.Save();
                            View.ShowMessage("Credentials generated successfully");
                        }
                        else
                        {
                            View.ShowException(string.Join(Environment.NewLine, User.BrokenRulesCollection.Select(x => x.Description)));
                        }
                        View.Model.Employee.LoginId = credView.LoginId;
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SaveUserRequested(object sender, EventArgs e)
        {
            try
            {
                if (SaveUser())
                {
                    View.ShowMessage("User saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                if (View.Model.Employee == null)
                    View.Model.Employee = Employee.NewEmployee();
                View.RefreshBinfing();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool SaveUser()
        {
            if (View.Model.Employee.IsValid)
            {
                View.Model.Employee.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Employee.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Employee.CreatedDate = DateTime.Now;

                View.Model.Employee.ApplyEdits();

                try
                {
                    View.Model.Employee = View.Model.Employee.Save();
                    View.RefreshBinfing();
                    //BcilLogger.WriteMessage(LogLevel.Info, "User data :" + Serializer.Json.Serialize(View.Model.Employee).ToString() + " saved.");
                    return true;
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                    return false;
                }
            }
            else
            {
                View.ShowException(new BCILException(String.Join("\n", View.Model.Employee.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }
    }
}