﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Permission;
using BCIL.User.UI.Models;
using BCIL.User.UI.Views;
using BCIL.Utility;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class EmployeePermissionPresenter : Presenter<IEmployeePermissionView>
    {
        #region Public Constructors

        public EmployeePermissionPresenter(IEmployeePermissionView view) :
            base(view)
        {
            view.Load += View_Load;
            view.SiteChanged += View_SiteChanged;
            view.SaveDataRequested += View_SaveDataRequested;
            view.CancelRequested += View_CancelRequested;
            view.ShowPermissionViewRequested += View_ShowPermissionViewRequested;
            if (view.Model == null)
                view.Model = new BCIL.User.UI.Models.EmployeePermissionModel();
            if (view.Model.RolePermissions == null) view.Model.RolePermissions = new Dictionary<int, List<RolePermission>>();
        }

        #endregion Public Constructors

        #region Private Methods

        private void GetRolePermissions(List<EmployeeRole> employeeRoles)
        {
            try
            {
                if (employeeRoles.Count == 0)
                {
                    return;
                }
                List<int> roles = new List<int>();
                if (!View.Model.RolePermissions.ContainsKey(View.Model.SelectedSiteId))
                {
                    View.Model.RolePermissions.Add(View.Model.SelectedSiteId, new List<RolePermission>());
                    roles = employeeRoles.Select(x => x.RoleId).ToList();
                }
                else
                {
                    var alreadyExistRoles = View.Model.RolePermissions[View.Model.SelectedSiteId];
                    roles = employeeRoles.Where(r => !alreadyExistRoles.Any(y => r.RoleId == y.RoleId)).Select(x => x.RoleId).ToList();
                }

                if (roles.Count > 0)
                {
                    var rolePermissions = RolePermissionList.GetRolePermissionList(roles, View.Model.SelectedSiteId);
                    //var rolePermissions = HttpHelper.Post<BusinessListBase<RolePermission>, List<int>>(string.Format(ServiceUriHelper.UserManagerment.GetRolesPermissions, View.Model.SelectedSiteId), roles);
                    var siteRolePermission = View.Model.RolePermissions[View.Model.SelectedSiteId];
                    siteRolePermission.AddRange(rolePermissions);
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool Save()
        {
            if (View.Model.BindableRoles != null && View.Model.BindableRoles.Any(x => x.EmployeeRole.IsDirty))
            {
                List<EmployeeRole> employeeRoles = new List<EmployeeRole>();
                employeeRoles.AddRange(View.Model.BindableRoles.Where(c => c.EmployeeRole.IsDirty && c.EmployeeRole.EmployeeID > 0).Select(x => x.EmployeeRole));

                if (employeeRoles.Count == 0)
                    return true;

                if (employeeRoles.Any(x => !x.IsValid))
                {
                    View.ShowException(new BCILException(String.Join("\n", employeeRoles.Where(x => x.IsValid == false).SelectMany(y => y.BrokenRulesCollection.Select(z => z.Description)))));
                    return false;
                }

                employeeRoles.ForEach(x => x.ApplyEdit());
                var employeeSiteRoles = SaveBizObjCommand<EmployeeRole>.Save(employeeRoles);
                //BcilLogger.WriteMessage(LogLevel.Info, "Employee role permission data :" + Serializer.Json.Serialize(employeeRoles).ToString() + " saved.");

                View.Model.SiteEmployeeRoles[View.Model.SelectedSiteId].RemoveAll(x => x.EmployeeRole.IsDirty);
                View.Model.SiteEmployeeRoles[View.Model.SelectedSiteId].AddRange(employeeSiteRoles.Select(x => new EmployeeRoleBindable(x, x.EmployeeID)).ToList());
            }

            if (View.Model.BindablePermissions != null && View.Model.BindablePermissions.Any(x => x.NodePermissions.IsDirty))
            {
                List<EmployeePermission> employeePermissions = new List<EmployeePermission>();
                employeePermissions.AddRange(View.Model.BindablePermissions.Where(c => c.NodePermissions.IsDirty).Select(x => x.NodePermissions));

                if (employeePermissions.Any(x => !x.IsValid))
                {
                    View.ShowException(new BCILException(String.Join("\n", employeePermissions.Where(x => x.IsValid == false).SelectMany(y => y.BrokenRulesCollection.Select(z => z.Description)))));
                    return false;
                }

                var employeeSitePermisions = SaveBizObjCommand<EmployeePermission>.Save(employeePermissions);
                //var employeeSitePermisions = HttpHelper.Post<BusinessListBase<EmployeePermission>, BusinessListBase<EmployeePermission>>(ServiceUriHelper.UserManagerment.SaveEmployeePermissions, employeePermissions);

                View.Model.SiteEmployeePermissions[View.Model.SelectedSiteId].RemoveAll(x => x.NodePermissions.IsDirty);
                View.Model.SiteEmployeePermissions[View.Model.SelectedSiteId].AddRange(employeeSitePermisions.Select(x => new EmployeePermissionBindingData(x)).ToList());
            }

            return true;
        }

        private void View_CancelRequested(object sender, EventArgs e)
        {
            try
            {
                if (View.AddEditPermission.HasPermission())
                {
                    if ((View.Model.BindableRoles != null && View.Model.BindableRoles.Any(x => x.EmployeeRole.IsDirty)) || (View.Model.BindablePermissions != null && View.Model.BindablePermissions.Any(x => x.NodePermissions.IsDirty)))
                    {
                        if (View.UserInput("Do you want to save changes?", System.Windows.Forms.MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                        {
                            if (!Save())
                            {
                                return;
                            }
                        }
                    }
                }
                View.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.Sites = SiteList.GetSites();
                var RolesList = RoleDVL.GetRoles();
                if (RolesList != null)
                {
                    View.Model.Roles = RolesList.Where(x => x.IsActive == true).ToList();
                }

                View.Model.SiteEmployeePermissions = new Dictionary<int, List<EmployeePermissionBindingData>>();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SaveDataRequested(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    if (View.UserInput("User information are saved.\nDo you want to modify on other site?", System.Windows.Forms.MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No)
                    {
                        View.DialogResult = System.Windows.Forms.DialogResult.OK;
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ShowPermissionViewRequested(object sender, EventArgs e)
        {
            try
            {
                var employeeRoles = View.Model.SiteEmployeeRoles[View.Model.SelectedSiteId].Where(x => x.Assigned == true).Select(y => y.EmployeeRole).ToList();
                GetRolePermissions(employeeRoles);

                View.RefreshBindingPermission();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SiteChanged(object sender, int siteId)
        {
            if (siteId != View.Model.SelectedSiteId)
            {
                try
                {
                    View.Model.SelectedSiteId = siteId;
                    if (!View.Model.SiteEmployeeRoles.ContainsKey(View.Model.SelectedSiteId))
                    {
                        #region EmployeeRoles

                        var employeeRoles = EmployeeRoleList.GetEmployeeRoles(View.Model.Employee.EmployeeId, View.Model.SelectedSiteId);

                        List<EmployeeRoleBindable> bindableRoles = new List<EmployeeRoleBindable>();
                        foreach (Role role in View.Model.Roles)
                        {
                            if (!employeeRoles.Any(x => x.RoleId == role.RoleId))
                            {
                                EmployeeRole emplRole = new EmployeeRole();
                                emplRole.RoleId = role.RoleId;
                                emplRole.RoleName = role.Name;
                                emplRole.CreatedBy = role.CreatedBy;
                                emplRole.CreatedDate = role.CreatedDate;
                                emplRole.SiteId = View.Model.SelectedSiteId;
                                emplRole.MarkAsNew();
                                emplRole.MarkAsClean();
                                bindableRoles.Add(new EmployeeRoleBindable(emplRole, View.Model.Employee.EmployeeId));
                            }
                        }

                        GetRolePermissions(employeeRoles.ToList());

                        bindableRoles.AddRange(employeeRoles.Select(x => new EmployeeRoleBindable(x, x.EmployeeID)).ToList());
                        View.Model.SiteEmployeeRoles.Add(View.Model.SelectedSiteId, bindableRoles);

                        #endregion EmployeeRoles

                        #region EmployeePermission

                        var employeePermisions = EmployeePermissionList.GetEmployeePermissions(View.Model.Employee.EmployeeId, View.Model.SelectedSiteId);

                        var newNodes = employeePermisions.Where(x => x.PermissionId == 0);
                        foreach (var node in newNodes)
                        {
                            node.EmployeeId = View.Model.Employee.EmployeeId;
                            node.SiteId = View.Model.SelectedSiteId;
                            node.CreatedBy = App.Login.Employee.EmployeeId;
                            node.CreatedDate = DateTime.SpecifyKind(DateTime.Today, DateTimeKind.Unspecified);
                            node.MarkAsNew();
                            node.MarkAsClean();
                        }
                        View.Model.SiteEmployeePermissions.Add(View.Model.SelectedSiteId, employeePermisions.Select(x => new EmployeePermissionBindingData(x)).ToList());

                        #endregion EmployeePermission
                    }

                    View.Model.BindablePermissions = View.Model.SiteEmployeePermissions[View.Model.SelectedSiteId];
                    View.Model.BindableRoles = View.Model.SiteEmployeeRoles[View.Model.SelectedSiteId];

                    View.RefreshBinding();
                }
                catch (Exception ex)
                {
                    View.ShowException(ex);
                }
            }
        }

        #endregion Private Methods
    }
}