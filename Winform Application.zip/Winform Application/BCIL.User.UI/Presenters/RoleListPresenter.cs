﻿using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.UI.Views;
using System;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class RoleListPresenter : Presenter<IRoleListView>
    {
        #region Public Constructors

        public RoleListPresenter(IRoleListView view) : base(view)
        {
            view.AddRoleRequested += View_AddRoleRequested;
            view.EditRoleRequested += View_EditRoleRequested;
            view.ChangePermissionRequested += View_ChangePermissionRequested;
            view.Load += View_Load;
        }

        #endregion Public Constructors

        #region Private Methods

        private void View_AddRoleRequested(object sender, EventArgs e)
        {
            try
            {
                RoleView roleView = new RoleView();
                if (roleView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    View.Model.Roles.AddRole(roleView.Role);
                    View.RefreshBinfing();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ChangePermissionRequested(object sender, Role e)
        {
            try
            {
                RolePermissionView rolePermissionView = new RolePermissionView(e);
                rolePermissionView.ShowDialog(App.Shell);
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditRoleRequested(object sender, Role e)
        {
            try
            {
                RoleView roleView = new RoleView(e);

                if (roleView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    View.RefreshBinfing();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model = new Models.RoleListModel();
                View.Model.Roles = RoleDVL.GetRoles();
                View.RefreshBinfing();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}