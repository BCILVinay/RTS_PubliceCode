﻿using BCIL.UIHelper;
using BCIL.UIHelper.Controls;
using BCIL.User.BL;
using BCIL.User.UI.Views;
using BCIL.Utility;
using BCIL.Utility.FileHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class UserListPresenter : Presenter<IUserListView>
    {
        #region Public Constructors

        public UserListPresenter(IUserListView view) : base(view)
        {
            view.AddUserRequested += View_AddUserRequested;
            view.EditUserRequested += View_EditUserRequested;
            view.ChangePermissionRequested += View_ChangePermissionRequested;
            view.Load += View_Load;
            view.ImportDataRequested += View_ImportDataRequested;
            view.PreviousPageResultRequested += View_PreviousPageResultRequested;
            view.NextPageResultRequested += View_NextPageResultRequested;
        }

        private void View_NextPageResultRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.PageIndex = View.Model.PageIndex + 1;
                Search();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_PreviousPageResultRequested(object sender, EventArgs e)
        {
            try
            {
                View.Model.PageIndex = View.Model.PageIndex - 1;
                Search();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Public Constructors

        #region Private Methods

        private void View_ImportDataRequested(object sender, EventArgs e)
        {
            try
            {
                var completeProcess = ImportUser();
                if (completeProcess)
                {
                    Search();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private bool ImportUser()
        {
            Dictionary<string, bool> columns = new Dictionary<string, bool>() {
                    { "Name", true },{ "Email", true },{ "Address", false },{ "Phone1", false }
            };

            ImportView view = new ImportView();
            view.Text = "Import User";
            view.TemplateDataSet = new Template().GetImportUserTemplate();
            view.OnImportRequested = (fileName) =>
            {
                try
                {
                    FileReader reader = new FileReader(fileName);
                    var importedData = reader.Read();
                    CodeContract.Required<BCILException>(importedData.Tables.Count > 0 && importedData.Tables[0].Rows.Count > 0, "There is no records to import");
                    if (!columns.Where(c => c.Value == true).All(y => importedData.Tables[0].Columns.Contains(y.Key)))
                    {
                        throw new BCILException("File don't have required columns");
                    }

                    DataTable itemTable = importedData.Tables[0].DefaultView.ToTable(true, "Name", "Email");
                    view.TotalRecords = itemTable.Rows.Count;
                    view.Run(importedData.Tables[0]);
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.DoWork = (dataToImport) =>
            {
                try
                {
                    if (dataToImport.IsNull() || dataToImport.DoWorkEventArgs.Argument.IsNull()) return;
                    DataTable dtToImport = dataToImport.DoWorkEventArgs.Argument as DataTable;

                    int index = 0;
                    int failedResult = 0;

                    DataTable errorTable = dtToImport.Clone();
                    if (!errorTable.Columns.Contains("Error"))
                        errorTable.Columns.Add("Error");

                    DataTable userTable = dtToImport.DefaultView.ToTable(true, "Name", "Email");
                    int count = 0;
                    foreach (DataRow dr in userTable.Rows)
                    {
                        try
                        {
                            var employee = Employee.NewEmployee();
                            employee.Name = dr["Name"].ToString();
                            employee.Email = dr["Email"].ToString();
                            employee.Address = dtToImport.Columns.Contains("Address") ? dtToImport.Rows[count]["Address"].ToString() : "";
                            employee.Phone1 = dtToImport.Columns.Contains("Phone1") ? dtToImport.Rows[count]["Phone1"].ToString() : "";
                            employee.IsActive = true;

                            if (employee.IsValid)
                            {
                                employee.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                employee.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                                employee.Save();
                                ++count;
                            }
                            else
                            {
                                throw new Exception(string.Join(Environment.NewLine, employee.BrokenRulesCollection.Select(x => x.Description)));
                            }
                        }
                        catch (Exception ex)
                        {
                            var lineItems = dtToImport.Select(string.Format("Name='{0}'", dr["Name"]));
                            for (int i = 0; i <= lineItems.Count() - 1; i++)
                            {
                                var data = lineItems[i].ItemArray;
                                object[] newData = new object[dtToImport.Columns.Contains("Error") == false ? data.Length + 1 : data.Length];
                                data.CopyTo(newData, 0);
                                if (i == 0)
                                {
                                    newData[newData.Length - 1] = ex.Message;
                                }
                                errorTable.Rows.Add(newData);
                            }
                            failedResult++;
                            dataToImport.DoWorkEventArgs.Result = "Failed to import: " + failedResult;
                        }
                        dataToImport.ReportProgress(index++ * 100 / dtToImport.Rows.Count);
                    }

                    if (errorTable.Rows.Count > 0)
                    {
                        var dataSource = new DataSet();
                        dataSource.Tables.Add(errorTable);
                        view.ErrorDataSet = dataSource;
                    }
                }
                catch (Exception ex)
                {
                    BcilMessageBox.ShowException(view, ex);
                }
            };

            view.RunWorkerCompleted = (o) => { BcilMessageBox.ShowMessage(view, "Import process completed"); };
            view.ShowDialog(App.Shell);
            return true;
        }

        private void Search()
        {
            View.Model.Employees = EmployeeDVL.GetEmployees(View.Model.PageIndex, View.Model.PageSize);
            View.RefreshBinfing();
        }

        private void View_AddUserRequested(object sender, EventArgs e)
        {
            try
            {
                UserView userView = new UserView();
                if (userView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    View.Model.Employees.AddEmployee(userView.Employee);
                    View.RefreshBinfing();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_ChangePermissionRequested(object sender, Employee e)
        {
            try
            {
                EmployeePermissionView employeePermissionView = new EmployeePermissionView(e);
                employeePermissionView.ShowDialog(App.Shell);
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_EditUserRequested(object sender, Employee e)
        {
            try
            {
                UserView userView = new UserView(e);

                if (userView.ShowDialog(App.Shell) == DialogResult.OK)
                {
                    View.RefreshBinfing();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model = new Models.UserListModel();
                Search();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}