﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.User.BL.Permission;
using BCIL.User.UI.Models;
using BCIL.User.UI.Views;
using BCIL.Utility;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class RolePermissionPresenter : Presenter<IRolePermissionView>
    {
        #region Public Constructors

        public RolePermissionPresenter(IRolePermissionView view) :
            base(view)
        {
            view.Load += View_Load;
            view.SiteChanged += View_SiteChanged;
            view.CancelRequested += View_CancelRequested;
            view.SaveDataRequested += View_SaveDataRequested;
            if (view.Model == null) view.Model = new Models.RolePermissionModel();
        }

        #endregion Public Constructors

        #region Private Methods

        private bool Save()
        {
            if (View.Model.BindablePermissions == null || !View.Model.BindablePermissions.Any(x => x.NodePermissions.IsDirty))
            {
                return true;
            }

            var items = View.Model.BindablePermissions.Where(c => c.NodePermissions.IsDirty).Select(x => x.NodePermissions).ToList();

            if (items.Any(x => !x.IsValid))
            {
                View.ShowException(new BCILException(String.Join("\n", items.Where(x => x.IsValid == false).SelectMany(y => y.BrokenRulesCollection.Select(z => z.Description)))));
                return false;
            }

            var sitePermisions = SaveBizObjCommand<RolePermission>.Save(items);
            //BcilLogger.WriteMessage(LogLevel.Info, "Role permission data :" + Serializer.Json.Serialize(items).ToString() + " saved.");
            View.Model.SitePermissions[View.Model.SelectedSiteId].RemoveAll(x => x.NodePermissions.IsDirty);
            View.Model.SitePermissions[View.Model.SelectedSiteId].AddRange(sitePermisions.Select(x => new PermissionBindingData(x)).ToList());

            return true;
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.BindablePermissions!=null && View.Model.BindablePermissions.Any(x => x.NodePermissions.IsDirty) && View.Permission.HasPermission())
                {
                    if (View.UserInput("Do you want to save changes?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (!Save())
                        {
                            e.Cancel = true;
                            return;
                        }
                    }
                }
                View.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                View.Model.Sites = SiteList.GetSites();
                if (View.Model.Sites == null || View.Model.Sites.Count == 0)
                {
                    View.ShowException("Please add site first");
                    View.DialogResult = DialogResult.OK;
                }
                View.Model.SitePermissions = new Dictionary<int, List<PermissionBindingData>>();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SaveDataRequested(object sender, EventArgs e)
        {
            try
            {
                if (Save())
                {
                    if (View.UserInput("Role Permissions are saved.\nDo you want to modify permissions on other site?", MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        View.DialogResult = DialogResult.OK;
                    }
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SiteChanged(object sender, int e)
        {
            try
            {
                if (e != View.Model.SelectedSiteId)
                {
                    if (View.Model.BindablePermissions != null && View.Model.BindablePermissions.Any(x => x.NodePermissions.IsDirty))
                    {
                        if (View.UserInput("Do you want to save changes?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            if (!Save())
                            {
                                View.SelectSite(View.Model.SelectedSiteId);
                                return;
                            }
                        }
                    }

                    View.Model.SelectedSiteId = e;
                    if (!View.Model.SitePermissions.ContainsKey(View.Model.SelectedSiteId))
                    {
                        var sitePermisions = RolePermissionList.GetRolePermissionList(View.Model.Role.RoleId, View.Model.SelectedSiteId);
                        var newNodes = sitePermisions.Where(x => x.PermissionId == 0);
                        foreach (var node in newNodes)
                        {
                            node.RoleId = View.Model.Role.RoleId;
                            node.SiteId = View.Model.SelectedSiteId;
                            node.CreatedBy = App.Login.Employee.EmployeeId;
                            node.CreatedDate = DateTime.SpecifyKind(DateTime.Today, DateTimeKind.Unspecified);
                            node.MarkAsNew();
                            node.MarkAsClean();
                        }
                        View.Model.SitePermissions.Add(View.Model.SelectedSiteId, sitePermisions.Select(x => new PermissionBindingData(x)).ToList());
                    }

                    View.Model.BindablePermissions = View.Model.SitePermissions[View.Model.SelectedSiteId];
                    View.RefreshBinding();
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}