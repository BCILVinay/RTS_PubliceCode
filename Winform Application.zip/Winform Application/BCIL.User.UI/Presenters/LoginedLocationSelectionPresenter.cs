﻿using BCIL.Administration.BL;
using BCIL.User.BL.Permission;
using BCIL.User.UI.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class LoginedLocationSelectionPresenter : Presenter<ILoginedLocationSelectionView>
    {
        public LoginedLocationSelectionPresenter(ILoginedLocationSelectionView view) : base(view)
        {
            view.Load += View_Load;
            view.SiteSelectionChanged += View_SiteSelectionChanged;
        }

        private void View_SiteSelectionChanged(object sender, Site site)
        {
            try {
                App.Login.LoginSite = site;
                View.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try {

                SiteList sites = SiteList.GetSites();
                View.FillSites(sites);
            }
            catch (Exception ex) {
                View.ShowException(ex);
            }
        }
    }
}
