﻿using System;
using System.Collections.Generic;
using System.Linq;
using WinFormsMvp;
using BCIL.Utility;
using BCIL.Administration.BL;
using BCIL.User.BL;
using BCIL.User.BL.Permission;
using BCIL.User.BL.Enums;
using BCIL.User.UI.Views;
using BCIL.User.UI.Models;

namespace BCIL.User.UI.Presenters
{
    public class LoginPresenter : Presenter<ILoginView>
    {
        public LoginPresenter(ILoginView view) : base(view)
        {
            view.Model = new LoginModel();
            view.AuthenticateCredentials += View_AuthenticateCredentials;
            view.AuthorizeUser += View_AuthorizeUser;
        }

        private void View_AuthorizeUser(object sender, KeyValuePair<int, string> site)
        {
            try
            {

                // If authorized the save user preferences

                Authorize(site.Key);

                View.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void Authorize(int siteid)
        {
            var permissions = UserPermissionDvl.GetUserPermissions(App.Login.Employee.EmployeeId, siteid, AppType.Desktop);

            if (!permissions.HaveItems() || permissions.All(x => x.Permission == PermissionType.None))
            {
                throw new BCILException("You don't permission");
            }

            App.Login.LoginSite = Site.GetSite(siteid);

            App.Login.User.Permissions = permissions.ToList().ToDictionary(x => x.NodeCode);
        }

        private void View_AuthenticateCredentials(object sender, KeyValue<string, string> e)
        {
            try
            {
                UserAuthenticateCommand userAuth = UserAuthenticateCommand.Authenticate(e.Key, e.Value);
                CodeContract.Required<BCILException>(userAuth.IsAuthenticated, "Invalid user id or password");

                App.Login.User.LogInUser = e.Key;
                App.Login.User.LogInPassword = e.Value;
                App.Login.Employee = userAuth.LoginEmployee;
                App.Login.User.IsSupperUser = userAuth.IsSupperUser;

                if(System.Configuration.ConfigurationManager.AppSettings["WMaterialBination"].IsNotNullOrWhiteSpace()) {
                    App.SetWorkstationLocation(Convert.ToInt64(System.Configuration.ConfigurationManager.AppSettings["WMaterialBination"]));
                }

                if (System.Configuration.ConfigurationManager.AppSettings["WSLine"].IsNotNullOrWhiteSpace()) {
                    App.SetWorkstationLocation(Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["WSLine"]));
                }

                if (App.Login.User.IsSupperUser)
                {
                    View.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                else
                {
                    View.Model.Sites = KeyValueCollection.GetSitesHavePermission(App.Login.Employee.EmployeeId,1);
                    CodeContract.Required<BCILException>(View.Model.Sites.HaveItems(), "You don't have any permission");
                    if (View.Model.Sites.Count == 1)
                    {
                        Authorize( Convert.ToInt32( View.Model.Sites[0].Key));
                        View.DialogResult = System.Windows.Forms.DialogResult.OK;
                    }
                    else
                        View.GetAuthorizationDetails(View.Model.Sites);
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex.GetBaseException());
            }
        }
    }
}