﻿using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.UI.Views;
using BCIL.Utility;
using NLog;
using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Presenters
{
    public class RolePresenter : Presenter<IRoleView>
    {
        #region Public Constructors

        public RolePresenter(IRoleView view)
            : base(view)
        {
            View.Model = new Models.RoleModel();
            view.Load += View_Load;
            view.SaveRole += View_SaveRole;
            view.CancelRequested += View_CancelRequested;
        }

        #endregion Public Constructors

        #region Private Methods

        private bool SaveRole()
        {
            if (View.Model.Role.IsValid)
            {
                View.Model.Role.CreatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Role.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                View.Model.Role.ApplyEdits();
                View.Model.Role = View.Model.Role.Save();
                View.RefreshBinfing();
                //BcilLogger.WriteMessage(LogLevel.Info, "Role data :" + Serializer.Json.Serialize(View.Model.Role).ToString() + " saved.");
                return true;
            }
            else
            {
                View.ShowException(new BCILException(string.Join("\n", View.Model.Role.BrokenRulesCollection.Select(x => x.Description))));
                return false;
            }
        }

        private void View_CancelRequested(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (View.Model.Role == null || View.Model.Role.IsSelfDirty == false)
                {
                    View.DialogResult = DialogResult.Cancel;
                    return;
                }

                if (!View.Permission.HasPermission() || View.UserInput("Do you want to save?", MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    View.DialogResult = DialogResult.Cancel;
                    View.Model.Role.CancelEdit();
                    return;
                }

                if (SaveRole())
                {
                    View.ShowMessage("Role saved.");
                    View.DialogResult = DialogResult.OK;
                    return;
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
                e.Cancel = true;
            }
        }

        private void View_Load(object sender, EventArgs e)
        {
            try
            {
                if (View.Model.Role == null)
                {
                    View.Model.Role = Role.NewRole();
                    View.Model.Role.CreatedBy = new KeyValue<int, string> (  App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                    View.Model.Role.UpdatedBy = new KeyValue<int, string>(App.Login.Employee.EmployeeId, App.Login.Employee.Name);
                }
                View.RefreshBinfing();
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        private void View_SaveRole(object sender, EventArgs e)
        {
            try
            {
                if (!View.Permission.HasPermission()) return;

                if (SaveRole())
                {
                    View.ShowMessage("Role saved.");
                    View.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                View.ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}