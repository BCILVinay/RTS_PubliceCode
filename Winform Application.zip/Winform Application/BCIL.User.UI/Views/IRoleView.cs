﻿using MetroFramework;
using BCIL.UIHelper;
using BCIL.User.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsMvp;
using BCIL;

namespace BCIL.User.UI.Views
{
    public interface IRoleView : IBaseView<RoleModel>
    {
        event EventHandler SaveRole;
        event EventHandler<FormClosingEventArgs> CancelRequested;

        Permission Permission { get; set; }

        DialogResult DialogResult { get; set; }

        void RefreshBinfing();
    }
}
