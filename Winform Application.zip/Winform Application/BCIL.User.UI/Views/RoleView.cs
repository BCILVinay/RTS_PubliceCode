﻿using BCIL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using MetroFramework;
using BCIL.User.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class RoleView : FormBase, IRoleView
    {
        #region Public Constructors

        public RoleView()
        {
            InitializeComponent();
            this.Text = "Add Role";
            //Permission = new Permission(() => { return App.Login.User.HasPermission(PermissionCode.Roles, PermissionType.All); });
            //btnSave.Permission = new ControlPermission(Permission, NoPermissionAction.Disable);
        }

        public RoleView(Role role)
            : this()
        {
            Model.Role = role;
            Model.Role.BeginEdit();
            this.Text = "Edit Role";
            if (!Permission.HasPermission())
            {
                this.Text = "Role";
            }
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler<FormClosingEventArgs> CancelRequested;
        public event EventHandler SaveRole;

        #endregion Public Events

        #region Public Properties

        public RoleModel Model { get; set; }
        public MetroFramework.Permission Permission { get; set; }
        public Role Role => Model.Role;

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinfing()
        {
            roleBindingSource.DataSource = Model.Role;
        }

        #endregion Public Methods

        #region Private Methods

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                btnCancel.Focus();
                SaveRole?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void RoleView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (this.DialogResult != DialogResult.OK)
                {
                    CancelRequested?.Invoke(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        #endregion Private Methods
    }
}