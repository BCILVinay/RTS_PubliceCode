﻿using BCIL.User.BL;
using BCIL.User.UI.Models;
using System;

namespace BCIL.User.UI.Views
{
    public interface IUserListView : IBaseView<UserListModel>
    {
        event EventHandler ImportDataRequested;

        event EventHandler AddUserRequested;

        event EventHandler<Employee> EditUserRequested;

        event EventHandler<Employee> ChangePermissionRequested;

        void RefreshBinfing();

        event EventHandler NextPageResultRequested;

        event EventHandler PreviousPageResultRequested;
    }
}