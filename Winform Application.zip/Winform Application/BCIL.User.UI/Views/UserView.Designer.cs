﻿using BCIL.User.BL;

namespace BCIL.User.UI.Views
{
    partial class UserView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserView));
            this.txtAddress = new MetroFramework.Controls.MetroTextBox();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblAdress = new MetroFramework.Controls.MetroLabel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.cboIsActive = new BCIL.UIHelper.YesNoComboBox();
            this.lblIsActive = new MetroFramework.Controls.MetroLabel();
            this.lblEmail = new MetroFramework.Controls.MetroLabel();
            this.txtContact1 = new MetroFramework.Controls.MetroTextBox();
            this.lblContact1 = new MetroFramework.Controls.MetroLabel();
            this.txtContact2 = new MetroFramework.Controls.MetroTextBox();
            this.lblContact2 = new MetroFramework.Controls.MetroLabel();
            this.requiredPanel1 = new BCIL.UIHelper.RequiredPanel();
            this.txtEmail = new MetroFramework.Controls.MetroTextBox();
            this.btnCredential = new MetroFramework.Controls.MyMetroButton();
            this.btnCancel = new BCIL.UIHelper.ButtonCancel();
            this.btnSave = new BCIL.UIHelper.ButtonSave();
            this.requiredPanel2 = new BCIL.UIHelper.RequiredPanel();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            this.requiredPanel1.SuspendLayout();
            this.requiredPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            // 
            // 
            // 
            this.txtAddress.CustomButton.Image = null;
            this.txtAddress.CustomButton.Location = new System.Drawing.Point(213, 2);
            this.txtAddress.CustomButton.Name = "";
            this.txtAddress.CustomButton.Size = new System.Drawing.Size(69, 69);
            this.txtAddress.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddress.CustomButton.TabIndex = 1;
            this.txtAddress.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddress.CustomButton.UseSelectable = true;
            this.txtAddress.CustomButton.Visible = false;
            this.txtAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Address", true));
            this.txtAddress.Lines = new string[0];
            this.txtAddress.Location = new System.Drawing.Point(113, 199);
            this.txtAddress.MaxLength = 255;
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.PasswordChar = '\0';
            this.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddress.SelectedText = "";
            this.txtAddress.SelectionLength = 0;
            this.txtAddress.SelectionStart = 0;
            this.txtAddress.ShortcutsEnabled = true;
            this.txtAddress.Size = new System.Drawing.Size(285, 74);
            this.txtAddress.TabIndex = 5;
            this.txtAddress.UseSelectable = true;
            this.txtAddress.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddress.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataSource = typeof(BCIL.User.BL.Employee);
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(23, 199);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(59, 19);
            this.lblAdress.TabIndex = 10;
            this.lblAdress.Text = "Address:";
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(261, 2);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Name", true));
            this.txtName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(0, 0);
            this.txtName.MaxLength = 50;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(285, 26);
            this.txtName.TabIndex = 0;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(23, 71);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(48, 19);
            this.lblName.TabIndex = 8;
            this.lblName.Text = "Name:";
            // 
            // cboIsActive
            // 
            this.cboIsActive.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.userBindingSource, "IsActive", true));
            this.cboIsActive.DataSource = ((object)(resources.GetObject("cboIsActive.DataSource")));
            this.cboIsActive.DisplayMember = "Value";
            this.cboIsActive.FormattingEnabled = true;
            this.cboIsActive.ItemHeight = 19;
            this.cboIsActive.Location = new System.Drawing.Point(533, 68);
            this.cboIsActive.Name = "cboIsActive";
            this.cboIsActive.PromptItemIndex = -1;
            this.cboIsActive.Size = new System.Drawing.Size(102, 25);
            this.cboIsActive.TabIndex = 6;
            this.cboIsActive.UseSelectable = true;
            this.cboIsActive.ValueMember = "Key";
            // 
            // lblIsActive
            // 
            this.lblIsActive.AutoSize = true;
            this.lblIsActive.Location = new System.Drawing.Point(461, 71);
            this.lblIsActive.Name = "lblIsActive";
            this.lblIsActive.Size = new System.Drawing.Size(47, 19);
            this.lblIsActive.TabIndex = 14;
            this.lblIsActive.Text = "Active:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(23, 99);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(44, 19);
            this.lblEmail.TabIndex = 16;
            this.lblEmail.Text = "Email:";
            // 
            // txtContact1
            // 
            // 
            // 
            // 
            this.txtContact1.CustomButton.Image = null;
            this.txtContact1.CustomButton.Location = new System.Drawing.Point(261, 2);
            this.txtContact1.CustomButton.Name = "";
            this.txtContact1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtContact1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtContact1.CustomButton.TabIndex = 1;
            this.txtContact1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtContact1.CustomButton.UseSelectable = true;
            this.txtContact1.CustomButton.Visible = false;
            this.txtContact1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Phone1", true));
            this.txtContact1.Lines = new string[0];
            this.txtContact1.Location = new System.Drawing.Point(113, 132);
            this.txtContact1.MaxLength = 15;
            this.txtContact1.Name = "txtContact1";
            this.txtContact1.PasswordChar = '\0';
            this.txtContact1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContact1.SelectedText = "";
            this.txtContact1.SelectionLength = 0;
            this.txtContact1.SelectionStart = 0;
            this.txtContact1.ShortcutsEnabled = true;
            this.txtContact1.Size = new System.Drawing.Size(285, 26);
            this.txtContact1.TabIndex = 3;
            this.txtContact1.UseSelectable = true;
            this.txtContact1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtContact1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtContact1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
           
            // 
            // lblContact1
            // 
            this.lblContact1.AutoSize = true;
            this.lblContact1.Location = new System.Drawing.Point(23, 132);
            this.lblContact1.Name = "lblContact1";
            this.lblContact1.Size = new System.Drawing.Size(90, 19);
            this.lblContact1.TabIndex = 18;
            this.lblContact1.Text = "Contact No 1:";
            // 
            // txtContact2
            // 
            // 
            // 
            // 
            this.txtContact2.CustomButton.Image = null;
            this.txtContact2.CustomButton.Location = new System.Drawing.Point(261, 2);
            this.txtContact2.CustomButton.Name = "";
            this.txtContact2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtContact2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtContact2.CustomButton.TabIndex = 1;
            this.txtContact2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtContact2.CustomButton.UseSelectable = true;
            this.txtContact2.CustomButton.Visible = false;
            this.txtContact2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Phone2", true));
            this.txtContact2.Lines = new string[0];
            this.txtContact2.Location = new System.Drawing.Point(113, 165);
            this.txtContact2.MaxLength = 15;
            this.txtContact2.Name = "txtContact2";
            this.txtContact2.PasswordChar = '\0';
            this.txtContact2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContact2.SelectedText = "";
            this.txtContact2.SelectionLength = 0;
            this.txtContact2.SelectionStart = 0;
            this.txtContact2.ShortcutsEnabled = true;
            this.txtContact2.Size = new System.Drawing.Size(285, 26);
            this.txtContact2.TabIndex = 4;
            this.txtContact2.UseSelectable = true;
            this.txtContact2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtContact2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtContact2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // lblContact2
            // 
            this.lblContact2.AutoSize = true;
            this.lblContact2.Location = new System.Drawing.Point(23, 165);
            this.lblContact2.Name = "lblContact2";
            this.lblContact2.Size = new System.Drawing.Size(90, 19);
            this.lblContact2.TabIndex = 20;
            this.lblContact2.Text = "Contact No 2:";
            // 
            // requiredPanel1
            // 
            this.requiredPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel1.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel1.Controls.Add(this.txtName);
            this.requiredPanel1.IsRequired = true;
            this.requiredPanel1.Location = new System.Drawing.Point(113, 67);
            this.requiredPanel1.Name = "requiredPanel1";
            this.requiredPanel1.Size = new System.Drawing.Size(305, 26);
            this.requiredPanel1.TabIndex = 1;
            // 
            // txtEmail
            // 
            // 
            // 
            // 
            this.txtEmail.CustomButton.Image = null;
            this.txtEmail.CustomButton.Location = new System.Drawing.Point(261, 2);
            this.txtEmail.CustomButton.Name = "";
            this.txtEmail.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtEmail.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtEmail.CustomButton.TabIndex = 1;
            this.txtEmail.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtEmail.CustomButton.UseSelectable = true;
            this.txtEmail.CustomButton.Visible = false;
            this.txtEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.userBindingSource, "Email", true));
            this.txtEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEmail.Lines = new string[0];
            this.txtEmail.Location = new System.Drawing.Point(0, 0);
            this.txtEmail.MaxLength = 50;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PasswordChar = '\0';
            this.txtEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEmail.SelectedText = "";
            this.txtEmail.SelectionLength = 0;
            this.txtEmail.SelectionStart = 0;
            this.txtEmail.ShortcutsEnabled = true;
            this.txtEmail.Size = new System.Drawing.Size(285, 26);
            this.txtEmail.TabIndex = 0;
            this.txtEmail.UseSelectable = true;
            this.txtEmail.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtEmail.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnCredential
            // 
            this.btnCredential.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCredential.ButtonImage")));
            this.btnCredential.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCredential.Enabled = false;
            this.btnCredential.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCredential.ImageSize = 50;
            this.btnCredential.Location = new System.Drawing.Point(23, 320);
            this.btnCredential.Name = "btnCredential";
            this.btnCredential.Size = new System.Drawing.Size(122, 56);
            this.btnCredential.TabIndex = 8;
            this.btnCredential.Text = "Create Credentials";
            this.btnCredential.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCredential.UseSelectable = true;
            this.btnCredential.Click += new System.EventHandler(this.btnCredential_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.ButtonImage")));
            this.btnCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnCancel.ImageSize = 50;
            this.btnCancel.Location = new System.Drawing.Point(556, 320);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 56);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("btnSave.ButtonImage")));
            this.btnSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.btnSave.ImageSize = 50;
            this.btnSave.Location = new System.Drawing.Point(465, 320);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 56);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseSelectable = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // requiredPanel2
            // 
            this.requiredPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.requiredPanel2.BackColor = System.Drawing.Color.Transparent;
            this.requiredPanel2.Controls.Add(this.txtEmail);
            this.requiredPanel2.IsRequired = true;
            this.requiredPanel2.Location = new System.Drawing.Point(113, 99);
            this.requiredPanel2.Name = "requiredPanel2";
            this.requiredPanel2.Size = new System.Drawing.Size(305, 26);
            this.requiredPanel2.TabIndex = 2;
            // 
            // UserView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 385);
            this.Controls.Add(this.requiredPanel2);
            this.Controls.Add(this.btnCredential);
            this.Controls.Add(this.requiredPanel1);
            this.Controls.Add(this.txtContact2);
            this.Controls.Add(this.lblContact2);
            this.Controls.Add(this.txtContact1);
            this.Controls.Add(this.lblContact1);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.cboIsActive);
            this.Controls.Add(this.lblIsActive);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblAdress);
            this.Controls.Add(this.lblName);
            this.Name = "UserView";
            this.Text = "AddEditUser";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UserView_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            this.requiredPanel1.ResumeLayout(false);
            this.requiredPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BCIL.UIHelper.ButtonCancel btnCancel;
        private BCIL.UIHelper.ButtonSave btnSave;
        private MetroFramework.Controls.MetroTextBox txtAddress;
        private MetroFramework.Controls.MetroLabel lblAdress;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel lblName;
        private BCIL.UIHelper.YesNoComboBox cboIsActive;
        private MetroFramework.Controls.MetroLabel lblIsActive;
        private MetroFramework.Controls.MetroLabel lblEmail;
        private MetroFramework.Controls.MetroTextBox txtContact1;
        private MetroFramework.Controls.MetroLabel lblContact1;
        private MetroFramework.Controls.MetroTextBox txtContact2;
        private MetroFramework.Controls.MetroLabel lblContact2;
        private System.Windows.Forms.BindingSource userBindingSource;
        private BCIL.UIHelper.RequiredPanel requiredPanel1;
        private MetroFramework.Controls.MetroTextBox txtEmail;
        private MetroFramework.Controls.MyMetroButton btnCredential;
        private BCIL.UIHelper.RequiredPanel requiredPanel2;
    }
}