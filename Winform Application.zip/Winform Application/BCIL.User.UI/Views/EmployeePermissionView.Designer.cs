﻿using BCIL.UIHelper;

namespace BCIL.User.UI.Views
{
    partial class EmployeePermissionView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeePermissionView));
            this.cboSites = new MetroFramework.Controls.MetroComboBox();
            this.lblSite = new MetroFramework.Controls.MetroLabel();
            this.lblUser = new MetroFramework.Controls.MetroLabel();
            this.buttonCancel = new BCIL.UIHelper.ButtonCancel();
            this.buttonSave = new BCIL.UIHelper.ButtonSave();
            this.metroTabControlUser = new MetroFramework.Controls.MetroTabControl();
            this.tabUserRole = new System.Windows.Forms.TabPage();
            this.dataListViewRoles = new BCIL.UIHelper.DataListView();
            this.olvColumnRoles = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnAssign = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.tabUserPermission = new System.Windows.Forms.TabPage();
            this.employeePermissionTree = new BCIL.UIHelper.DataTreeListView();
            this.olvColumnNode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnPermissionFromRole = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnReadPermission = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnEditPermission = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnRestriction = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.metroTabControlUser.SuspendLayout();
            this.tabUserRole.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataListViewRoles)).BeginInit();
            this.tabUserPermission.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeePermissionTree)).BeginInit();
            this.SuspendLayout();
            // 
            // cboSites
            // 
            this.cboSites.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboSites.FormattingEnabled = true;
            this.cboSites.ItemHeight = 19;
            this.cboSites.Location = new System.Drawing.Point(538, 65);
            this.cboSites.Name = "cboSites";
            this.cboSites.PromptItemIndex = -1;
            this.cboSites.Size = new System.Drawing.Size(152, 25);
            this.cboSites.TabIndex = 0;
            this.cboSites.UseSelectable = true;
            this.cboSites.SelectedIndexChanged += new System.EventHandler(this.cboSites_SelectedIndexChanged);
            // 
            // lblSite
            // 
            this.lblSite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSite.AutoSize = true;
            this.lblSite.Location = new System.Drawing.Point(499, 70);
            this.lblSite.Name = "lblSite";
            this.lblSite.Size = new System.Drawing.Size(41, 19);
            this.lblSite.TabIndex = 4;
            this.lblSite.Text = "Plant:";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(23, 70);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(57, 19);
            this.lblUser.TabIndex = 3;
            this.lblUser.Text = "User: {0}";
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonCancel.ButtonImage")));
            this.buttonCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonCancel.ImageSize = 50;
            this.buttonCancel.Location = new System.Drawing.Point(605, 437);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(85, 56);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCancel.UseSelectable = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSave.ButtonImage")));
            this.buttonSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSave.ImageSize = 50;
            this.buttonSave.Location = new System.Drawing.Point(514, 437);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(85, 56);
            this.buttonSave.TabIndex = 1;
            this.buttonSave.Text = "Save";
            this.buttonSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSave.UseSelectable = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // metroTabControlUser
            // 
            this.metroTabControlUser.Controls.Add(this.tabUserRole);
            this.metroTabControlUser.Controls.Add(this.tabUserPermission);
            this.metroTabControlUser.Location = new System.Drawing.Point(23, 124);
            this.metroTabControlUser.Name = "metroTabControlUser";
            this.metroTabControlUser.SelectedIndex = 1;
            this.metroTabControlUser.Size = new System.Drawing.Size(667, 307);
            this.metroTabControlUser.TabIndex = 9;
            this.metroTabControlUser.UseSelectable = true;
            this.metroTabControlUser.SelectedIndexChanged += new System.EventHandler(this.metroTabControlUser_SelectedIndexChanged);
            // 
            // tabUserRole
            // 
            this.tabUserRole.Controls.Add(this.dataListViewRoles);
            this.tabUserRole.Location = new System.Drawing.Point(4, 38);
            this.tabUserRole.Name = "tabUserRole";
            this.tabUserRole.Size = new System.Drawing.Size(659, 265);
            this.tabUserRole.TabIndex = 0;
            this.tabUserRole.Text = "Roles";
            // 
            // dataListViewRoles
            // 
            this.dataListViewRoles.AllColumns.Add(this.olvColumnRoles);
            this.dataListViewRoles.AllColumns.Add(this.olvColumnAssign);
            this.dataListViewRoles.CellEditUseWholeCell = false;
            this.dataListViewRoles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnRoles,
            this.olvColumnAssign});
            this.dataListViewRoles.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataListViewRoles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataListViewRoles.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dataListViewRoles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.dataListViewRoles.FullRowSelect = true;
            this.dataListViewRoles.HeaderMinimumHeight = 30;
            this.dataListViewRoles.HideSelection = false;
            this.dataListViewRoles.IncludeColumnHeadersInCopy = true;
            this.dataListViewRoles.Location = new System.Drawing.Point(0, 0);
            this.dataListViewRoles.Name = "dataListViewRoles";
            this.dataListViewRoles.RowHeight = 25;
            this.dataListViewRoles.ShowGroups = false;
            this.dataListViewRoles.Size = new System.Drawing.Size(659, 265);
            this.dataListViewRoles.TabIndex = 11;
            this.dataListViewRoles.UseCompatibleStateImageBehavior = false;
            this.dataListViewRoles.View = System.Windows.Forms.View.Details;
            this.dataListViewRoles.VirtualMode = true;
            // 
            // olvColumnRoles
            // 
            this.olvColumnRoles.AspectName = "RoleName";
            this.olvColumnRoles.FillsFreeSpace = true;
            this.olvColumnRoles.Text = "Roles";
            // 
            // olvColumnAssign
            // 
            this.olvColumnAssign.AspectName = "Assigned";
            this.olvColumnAssign.CheckBoxes = true;
            this.olvColumnAssign.Text = "Assign";
            this.olvColumnAssign.Width = 200;
            // 
            // tabUserPermission
            // 
            this.tabUserPermission.Controls.Add(this.employeePermissionTree);
            this.tabUserPermission.Location = new System.Drawing.Point(4, 38);
            this.tabUserPermission.Name = "tabUserPermission";
            this.tabUserPermission.Size = new System.Drawing.Size(659, 265);
            this.tabUserPermission.TabIndex = 1;
            this.tabUserPermission.Text = "Override Permissions";
            // 
            // employeePermissionTree
            // 
            this.employeePermissionTree.AllColumns.Add(this.olvColumnNode);
            this.employeePermissionTree.AllColumns.Add(this.olvColumnPermissionFromRole);
            this.employeePermissionTree.AllColumns.Add(this.olvColumnReadPermission);
            this.employeePermissionTree.AllColumns.Add(this.olvColumnEditPermission);
            this.employeePermissionTree.AllColumns.Add(this.olvColumnRestriction);
            this.employeePermissionTree.AllColumns.Add(this.olvColumn1);
            this.employeePermissionTree.CellEditUseWholeCell = false;
            this.employeePermissionTree.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnNode,
            this.olvColumnPermissionFromRole,
            this.olvColumnReadPermission,
            this.olvColumnEditPermission,
            this.olvColumnRestriction,
            this.olvColumn1});
            this.employeePermissionTree.Cursor = System.Windows.Forms.Cursors.Default;
            this.employeePermissionTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.employeePermissionTree.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.employeePermissionTree.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.employeePermissionTree.FullRowSelect = true;
            this.employeePermissionTree.HeaderMinimumHeight = 30;
            this.employeePermissionTree.IncludeColumnHeadersInCopy = true;
            this.employeePermissionTree.Location = new System.Drawing.Point(0, 0);
            this.employeePermissionTree.Name = "employeePermissionTree";
            this.employeePermissionTree.RowHeight = 25;
            this.employeePermissionTree.ShowGroups = false;
            this.employeePermissionTree.Size = new System.Drawing.Size(659, 265);
            this.employeePermissionTree.TabIndex = 8;
            this.employeePermissionTree.UseCompatibleStateImageBehavior = false;
            this.employeePermissionTree.View = System.Windows.Forms.View.Details;
            this.employeePermissionTree.VirtualMode = true;
            this.employeePermissionTree.SubItemChecking += new System.EventHandler<BrightIdeasSoftware.SubItemCheckingEventArgs>(this.permissionTree_SubItemChecking);
            // 
            // olvColumnNode
            // 
            this.olvColumnNode.AspectName = "NodeName";
            this.olvColumnNode.Text = "Action";
            this.olvColumnNode.Width = 210;
            // 
            // olvColumnPermissionFromRole
            // 
            this.olvColumnPermissionFromRole.AspectName = "PermissionFromRole";
            this.olvColumnPermissionFromRole.Text = "Role Permission";
            this.olvColumnPermissionFromRole.Width = 113;
            // 
            // olvColumnReadPermission
            // 
            this.olvColumnReadPermission.AspectName = "IsReadOnly";
            this.olvColumnReadPermission.CheckBoxes = true;
            this.olvColumnReadPermission.Text = "Can View";
            this.olvColumnReadPermission.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumnReadPermission.Width = 100;
            // 
            // olvColumnEditPermission
            // 
            this.olvColumnEditPermission.AspectName = "IsReadAndWrite";
            this.olvColumnEditPermission.CheckBoxes = true;
            this.olvColumnEditPermission.Text = "Can Change";
            this.olvColumnEditPermission.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumnEditPermission.Width = 100;
            // 
            // olvColumnRestriction
            // 
            this.olvColumnRestriction.AspectName = "IsRestricted";
            this.olvColumnRestriction.CheckBoxes = true;
            this.olvColumnRestriction.Text = "Is Restricted";
            this.olvColumnRestriction.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olvColumnRestriction.Width = 100;
            // 
            // olvColumn1
            // 
            this.olvColumn1.FillsFreeSpace = true;
            this.olvColumn1.Text = "";
            // 
            // EmployeePermissionView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 504);
            this.Controls.Add(this.metroTabControlUser);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.cboSites);
            this.Controls.Add(this.lblSite);
            this.Controls.Add(this.lblUser);
            this.Name = "EmployeePermissionView";
            this.Text = "User Permission";
            this.Load += new System.EventHandler(this.EmployeePermissionView_Load);
            this.metroTabControlUser.ResumeLayout(false);
            this.tabUserRole.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataListViewRoles)).EndInit();
            this.tabUserPermission.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.employeePermissionTree)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroComboBox cboSites;
        private MetroFramework.Controls.MetroLabel lblSite;
        private MetroFramework.Controls.MetroLabel lblUser;
        private UIHelper.ButtonCancel buttonCancel;
        private UIHelper.ButtonSave buttonSave;
        private MetroFramework.Controls.MetroTabControl metroTabControlUser;
        private System.Windows.Forms.TabPage tabUserRole;
        private System.Windows.Forms.TabPage tabUserPermission;
        private BrightIdeasSoftware.OLVColumn olvColumnEditPermission;
        private BrightIdeasSoftware.OLVColumn olvColumnReadPermission;
        private BrightIdeasSoftware.OLVColumn olvColumnNode;
        private UIHelper.DataTreeListView employeePermissionTree;
        private UIHelper.DataListView dataListViewRoles;
        private BrightIdeasSoftware.OLVColumn olvColumnRoles;
        private BrightIdeasSoftware.OLVColumn olvColumnAssign;
        private BrightIdeasSoftware.OLVColumn olvColumnPermissionFromRole;
        private BrightIdeasSoftware.OLVColumn olvColumnRestriction;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
    }
}