﻿using BCIL;
using BCIL.User.BL;
using BCIL.User.UI.Models;
using System;

namespace BCIL.User.UI.Views
{
    public interface IRoleListView : IBaseView<RoleListModel>
    {
        event EventHandler AddRoleRequested;

        event EventHandler<Role> EditRoleRequested;

        event EventHandler<Role> ChangePermissionRequested;

        void RefreshBinfing();
    }
}