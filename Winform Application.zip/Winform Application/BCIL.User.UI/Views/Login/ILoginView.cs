﻿using BCIL.User.BL.Permission;
using BCIL.User.UI.Models;
using BCIL.Utility;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public interface ILoginView : IBaseView<LoginModel>
    {
        event EventHandler<KeyValue<string,string>> AuthenticateCredentials;

        event EventHandler<KeyValuePair<int, string>> AuthorizeUser;

        DialogResult DialogResult { get; set; }
        void GetAuthorizationDetails(KeyValueCollection sites);

    }
}