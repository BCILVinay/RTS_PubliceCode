﻿namespace BCIL.User.UI.Views
{
    partial class LoginView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginView));
            this.pnlDetail = new MetroFramework.Controls.MetroPanel();
            this.SuspendLayout();
            // 
            // pnlDetail
            // 
            this.pnlDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDetail.BackgroundGradientColor = System.Drawing.Color.Transparent;
            this.pnlDetail.HorizontalScrollbarBarColor = true;
            this.pnlDetail.HorizontalScrollbarHighlightOnWheel = false;
            this.pnlDetail.HorizontalScrollbarSize = 10;
            this.pnlDetail.Location = new System.Drawing.Point(16, 68);
            this.pnlDetail.Name = "pnlDetail";
            this.pnlDetail.Size = new System.Drawing.Size(392, 176);
            this.pnlDetail.TabIndex = 8;
            this.pnlDetail.VerticalScrollbarBarColor = true;
            this.pnlDetail.VerticalScrollbarHighlightOnWheel = false;
            this.pnlDetail.VerticalScrollbarSize = 10;
            // 
            // LoginView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(426, 260);
            this.ControlBox = false;
            this.Controls.Add(this.pnlDetail);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoginView";
            this.Text = "WMS Login";
            this.Load += new System.EventHandler(this.LoginView_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel pnlDetail;
    }
}