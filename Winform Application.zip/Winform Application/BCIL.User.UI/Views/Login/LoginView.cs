﻿using BCIL.UIHelper;
using BCIL.User.BL.Permission;
using BCIL.User.UI.Models;
using BCIL.Utility;
using System;
using System.Collections.Generic;

namespace BCIL.User.UI.Views
{
    public partial class LoginView : FormBase, ILoginView
    {
        public LoginView()
        {
            InitializeComponent();
            this.ShowInTaskbar = true;
        }

        public event EventHandler<KeyValue<string, string>> AuthenticateCredentials;
        public event EventHandler<KeyValuePair<int, string>> AuthorizeUser;

        public LoginModel Model { get; set; }

        private void LoginView_Load(object sender, EventArgs e)
        {
            FocusMe();
            UserCredentialView view = new UserCredentialView(pnlDetail);
            view.OnLogginAction = (userName, pwd) => {
                AuthenticateCredentials?.Invoke(sender, new KeyValue<string, string>() { Key = userName, Value = pwd });
            };
            view.OnCancel = () => {
                Close();
            };
            view.swipe(true);
        }

        public void GetAuthorizationDetails(KeyValueCollection sites)
        {
            LocationSelectionView view = new LocationSelectionView(pnlDetail);
            view.AllowedSitesGetter = () => {
                return sites;
            };

            view.OnOkClicked = (o) => {
                AuthorizeUser?.Invoke(this, o);
            };

            view.OnCanceledClicked = () => { Close(); };
            view.swipe(true);
        }
    }
}