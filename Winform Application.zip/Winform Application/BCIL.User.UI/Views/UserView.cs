﻿using BCIL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using MetroFramework;
using BCIL.User.UI.Models;
using System;
using System.Windows.Forms;
using System.ComponentModel;

namespace BCIL.User.UI.Views
{
    public partial class UserView : FormBase, IUserView
    {
        #region Public Constructors

        public UserView()
        {
            InitializeComponent();
            this.Text = "Add User";
            ChangeCredentialPermission = new Permission(() => { return App.Login.User.HasAnyPermission(PermissionCode.ChangeCredentials); });
            btnCredential.Permission = new ControlPermission(ChangeCredentialPermission, NoPermissionAction.Disable);

            AddEditPermision = new Permission(() => { return App.Login.User.HasPermission(PermissionCode.Users, PermissionType.All); });
            btnSave.Permission = new ControlPermission(AddEditPermision, NoPermissionAction.Disable);
        }

        public UserView(Employee employee)
            : this()
        {
            Model.Employee = employee;
            Model.Employee.BeginEdit();
            this.Text = "Edit User";
            btnCredential.Enabled = true;
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler ChangeCredentialRequested;

        public event EventHandler SaveUserRequested;

        #endregion Public Events

        #region Public Properties

        public Permission AddEditPermision { get; set; }
        public Permission ChangeCredentialPermission { get; set; }
        public Employee Employee => Model.Employee;
        public UserModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinfing()
        {
            userBindingSource.DataSource = Model.Employee;
            if (!string.IsNullOrWhiteSpace(Model.Employee.LoginId))
            {
                btnCredential.Text = "Change password";
            }
        }

        #endregion Public Methods

        #region Private Methods

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnCredential_Click(object sender, EventArgs e)
        {
            try
            {
                ChangeCredentialRequested?.Invoke(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                btnSave.Focus();
                SaveUserRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void UserView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (DialogResult != DialogResult.OK)
                {
                    CancelRequested?.Invoke(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
        private void txtNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e.AllowNumbericValueOnly();
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

       
        #endregion Private Methods
    }
}