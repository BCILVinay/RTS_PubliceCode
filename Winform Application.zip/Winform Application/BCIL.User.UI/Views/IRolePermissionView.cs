﻿using BCIL;
using MetroFramework;
using BCIL.User.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsMvp;

namespace BCIL.User.UI.Views
{
    public interface IRolePermissionView : IBaseView<RolePermissionModel>
    {
        event EventHandler<int> SiteChanged;
        event EventHandler SaveDataRequested;
        event EventHandler<FormClosingEventArgs> CancelRequested;

        Permission Permission { get; set; }
        void RefreshBinding();
        DialogResult DialogResult { get; set; }
        void SelectSite(int siteID);
    }
}
