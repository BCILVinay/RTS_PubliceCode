﻿using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using BCIL.User.UI.Models;
using BCIL.Utility;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class UserListView : ControlSliderBase, IUserListView
    {
        #region Public Events
        public event EventHandler AddUserRequested;
        public event EventHandler<Employee> ChangePermissionRequested;
        public event EventHandler<Employee> EditUserRequested;
        public event EventHandler ImportDataRequested;
        public event EventHandler NextPageResultRequested;
        public event EventHandler PreviousPageResultRequested;
        #endregion

        #region Public Constructors
        public UserListView(Control owner): base(owner)
        {
            InitializeComponent();
            this.Closing += UserListView_Closing;
            this.Title = "Users";

            olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };

            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var user = o as Employee;
                return user.CreatedDate.ToString(App.DateFormat);
            };
            this.olvUser.HeaderFormatStyle = new BrightIdeasSoftware.HeaderFormatStyle()
            {
                Normal = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightBlue },
                Hot = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightGray },
                Pressed = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightBlue }
            };
            olvUser.Font = new Font("Segoe UI", 11f, FontStyle.Regular, GraphicsUnit.Pixel);
            this.olvUser.HeaderMinimumHeight = 30;

            btnAdd.Permission = new MetroFramework.ControlPermission(() => { return App.Login.User.HasPermission(PermissionCode.Users, PermissionType.All); }, MetroFramework.NoPermissionAction.Disable);
            if (!App.Login.User.HasPermission(PermissionCode.Users, PermissionType.All))
            {
                btnEdit.Text = "View";
            }
            if (App.Login.User.HasPermission(PermissionCode.Users, PermissionType.All)) { btnImport.Enabled = true; }
            btnAdd.Permission = new MetroFramework.ControlPermission(() => { return App.Login.User.HasPermission(PermissionCode.AssignRoleAndPermission, PermissionType.Any); }, MetroFramework.NoPermissionAction.Disable);
        }
        #endregion

        #region Public Properties
        public UserListModel Model { get; set; }
        #endregion

        #region Public Methods
        public void RefreshBinfing()
        {
            olvUser.SetObjects(Model.Employees);
            lblRecords.Text = "Total records: " + Model.Employees.Count.ToString();
        }
        #endregion

        #region Private Methods
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddUserRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvUser.SelectedObject != null)
                {
                    EditUserRequested?.Invoke(this, (Employee)olvUser.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                ImportDataRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NextPageResultRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }


        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                PreviousPageResultRequested?.Invoke(sender, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvUser.SelectedObjects.Count > 0)
                {
                    tsUserPermissions.Enabled = true;
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnEdit.Enabled = false;
                    tsUserPermissions.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void tsUserPermissions_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvUser.SelectedObject != null)
                {
                    ChangePermissionRequested?.Invoke(this, (Employee)olvUser.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void UserListView_Closing(object sender, ActionArg e)
        {
            //Prevent to close
            //e.Handled = true;
        }

        private void UserListView_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvUser.Width - 20;

                olvColumnEmail.Width = withToDistribute.GetPercentValue(30);
                olvColumnName.Width = withToDistribute.GetPercentValue(20);
                olvColumnCreatedBy.Width = withToDistribute.GetPercentValue(20);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(15);
                olvColumnActive.Width = withToDistribute.GetPercentValue(15);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }
        #endregion
    }
}