﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using BCIL.User.UI.Models;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class RolePermissionView : FormBase, IRolePermissionView
    {
        #region Public Constructors

        public RolePermissionView(Role role)
        {
            InitializeComponent();
            if (Model == null) Model = new RolePermissionModel();
            Model.Role = role;
            lblRole.Text = String.Format(lblRole.Text, role.Name);

            permissionTree.HeaderUsesThemes = false;
            permissionTree.HeaderFormatStyle = new BrightIdeasSoftware.HeaderFormatStyle()
            {
                Normal = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightBlue },
                Hot = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightGray },
                Pressed = new BrightIdeasSoftware.HeaderStateStyle() { BackColor = Color.LightBlue }
            };
            permissionTree.Font = new Font("Segoe UI", 11f, FontStyle.Regular, GraphicsUnit.Pixel);
            permissionTree.HeaderMinimumHeight = 30;
            permissionTree.ShowGroups = false;
            permissionTree.FullRowSelect = true;
            permissionTree.RowHeight = 25;

            Permission = new Permission(() => { return App.Login.User.HasPermission(PermissionCode.RolePermission, PermissionType.All); });
            buttonSave.Permission = new ControlPermission(Permission, NoPermissionAction.Disable);
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler<FormClosingEventArgs> CancelRequested;

        public event EventHandler SaveDataRequested;

        public event EventHandler<int> SiteChanged;

        #endregion Public Events

        #region Public Properties

        public RolePermissionModel Model { get; set; }

        public Permission Permission { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinding()
        {
            permissionTree.Roots = Model.BindablePermissions.Where(x => String.IsNullOrWhiteSpace(x.ParentNode) || x.ParentNode == x.NodeCode);

            permissionTree.CanExpandGetter = delegate (object x)
            {
                var obj = (PermissionBindingData)x;

                return Model.BindablePermissions.Any(y => y.ParentNode == obj.NodeCode && y.NodeCode != obj.NodeCode);
            };

            permissionTree.TreeColumnRenderer.IsShowLines = false;
            permissionTree.TreeColumnRenderer.UseTriangles = true;
            permissionTree.ChildrenGetter = delegate (object x)
            {
                try
                {
                    return Model.BindablePermissions.Where(y => y.ParentNode == ((PermissionBindingData)x).NodeCode).ToList();
                }
                catch (UnauthorizedAccessException ex)
                {
                    BeginInvoke((MethodInvoker)delegate ()
                    {
                        permissionTree.Collapse(x);
                        ShowException(ex);
                    });
                    return new System.Collections.ArrayList();
                }
            };
            permissionTree.ExpandAll();
        }

        public void SelectSite(int siteID)
        {
            cboSites.SelectedValue = siteID;
        }

        #endregion Public Methods

        #region Private Methods

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveDataRequested?.Invoke(sender, null);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void cboSites_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (SiteChanged != null && cboSites.SelectedValue != null) SiteChanged(sender, ((Site)cboSites.SelectedItem).SiteId);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void permissionTree_SubItemChecking(object sender, BrightIdeasSoftware.SubItemCheckingEventArgs e)
        {
            try
            {
                var bindedItem = (PermissionBindingData)e.RowObject;
                if (Model.BindablePermissions.Any(y => y.ParentNode == bindedItem.NodeCode && y.NodeCode != bindedItem.NodeCode))
                {
                    if (e.Column.AspectName == "IsReadOnly")
                    {
                        if (e.NewValue == CheckState.Checked)
                        {
                            GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadOnly = true);
                        }
                        else
                        {
                            GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadOnly = false);
                        }
                    }

                    if (e.Column.AspectName == "IsReadAndWrite")
                    {
                        if (e.NewValue == CheckState.Checked)
                        {
                            GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadAndWrite = true);
                        }
                        else
                        {
                            GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadAndWrite = false);
                        }
                    }
                }
                if (!string.IsNullOrWhiteSpace(bindedItem.ParentNode) && e.NewValue == CheckState.Checked)
                {
                    GetParentsNode(bindedItem.ParentNode).ForEach(y => y.IsReadOnly = true);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void RolePermissionView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (DialogResult != DialogResult.OK)
                {
                    CancelRequested?.Invoke(sender, e);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void RolePermissionView_Load(object sender, EventArgs e)
        {
            try
            {
                cboSites.DataSource = Model.Sites;
                cboSites.DisplayMember = "SiteName";
                cboSites.ValueMember = "SiteId";
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        public List<PermissionBindingData> GetAllChildNode(string nodeCode)
        {
            List<PermissionBindingData> childs = new List<PermissionBindingData>();
            foreach (var node in Model.BindablePermissions)
            {
                if (node.ParentNode == nodeCode)
                {
                    childs.Add(node);
                    childs.AddRange(GetAllChildNode(node.NodeCode));
                }
            }

            return childs;
        }

        public List<PermissionBindingData> GetParentsNode(string parentCode)
        {
            List<PermissionBindingData> parentNodes = new List<PermissionBindingData>();
            var parents = Model.BindablePermissions.Where(x => x.NodeCode == parentCode).ToList();
            parentNodes.AddRange(parents);
            foreach (var node in parents)
            {
                if (!string.IsNullOrWhiteSpace(node.ParentNode))
                {
                    parentNodes.AddRange(GetParentsNode(node.ParentNode));
                }
            }

            return parentNodes;
        }
        #endregion Private Methods
    }
}