﻿using BCIL.User.UI.Models;
using MetroFramework;
using System;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public interface IEmployeePermissionView : IBaseView<EmployeePermissionModel>
    {
        event EventHandler<int> SiteChanged;

        event EventHandler SaveDataRequested;

        event EventHandler CancelRequested;

        event EventHandler ShowPermissionViewRequested;

        Permission AddEditPermission { get; set; }

        void RefreshBinding();

        void RefreshBindingPermission();

        DialogResult DialogResult { get; set; }

        void SelectSite(int siteID);
    }
}