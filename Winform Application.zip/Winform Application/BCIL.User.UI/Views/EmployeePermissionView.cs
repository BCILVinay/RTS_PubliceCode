﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using BCIL.User.UI.Models;
using MetroFramework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class EmployeePermissionView : FormBase, IEmployeePermissionView
    {
        #region Public Constructors

        public EmployeePermissionView(Employee employee)
        {
            InitializeComponent();

            if (Model == null)
                Model = new EmployeePermissionModel();
            Model.Employee = employee;
            lblUser.Text = String.Format(lblUser.Text, employee.Name);
            metroTabControlUser.SelectedIndex = 0;

            AddEditPermission = new Permission(() => { return App.Login.User.HasPermission(PermissionCode.AssignRoleAndPermission, PermissionType.All); });
            buttonSave.Permission = new ControlPermission(AddEditPermission, NoPermissionAction.Disable);
        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler CancelRequested;

        public event EventHandler SaveDataRequested;

        public event EventHandler ShowPermissionViewRequested;

        public event EventHandler<int> SiteChanged;

        #endregion Public Events

        #region Public Properties

        public EmployeePermissionModel Model { get; set; }

        public Permission AddEditPermission { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinding()
        {
            dataListViewRoles.SetObjects(Model.BindableRoles);

            employeePermissionTree.Roots = Model.BindablePermissions.Where(x => String.IsNullOrWhiteSpace(x.ParentNode) || x.ParentNode == x.NodeCode);
            employeePermissionTree.CanExpandGetter = delegate (object x)
            {
                var obj = (EmployeePermissionBindingData)x;
                return Model.BindablePermissions.Any(y => y.ParentNode == obj.NodeCode && y.NodeCode != obj.NodeCode);
                // return String.IsNullOrWhiteSpace(obj.ParentNode) || obj.ParentNode == obj.NodeCode;
            };

            employeePermissionTree.TreeColumnRenderer.IsShowLines = false;
            employeePermissionTree.TreeColumnRenderer.UseTriangles = true;
            employeePermissionTree.ChildrenGetter = delegate (object x)
            {
                try
                {
                    return Model.BindablePermissions.Where(y => y.ParentNode == ((EmployeePermissionBindingData)x).NodeCode).ToList();
                }
                catch (UnauthorizedAccessException ex)
                {
                    this.BeginInvoke((MethodInvoker)delegate ()
                    {
                        this.employeePermissionTree.Collapse(x);
                        ShowException(ex);
                    });
                    return new System.Collections.ArrayList();
                }
            };
            employeePermissionTree.ExpandAll();
        }

        public void RefreshBindingPermission()
        {
            var assignedRoles = Model.BindableRoles.Where(z => z.Assigned == true).Select(y => y.EmployeeRole.RoleId).ToList();

            if (Model.RolePermissions.ContainsKey(Model.SelectedSiteId))
            {
                var max = Model.RolePermissions[Model.SelectedSiteId]
                .Where(c => assignedRoles.Contains(c.RoleId))
                 .GroupBy(a => a.Node.NodeId)
                 .Select(g => new { g.Key, right = g.Max(z => (int)z.Rights) });

                Model.BindablePermissions.ForEach(x =>
               {
                   var nodepermission = max.FirstOrDefault(c => c.Key == x.NodePermissions.Node.NodeId);
                   x.PermissionFromRole = "";
                   if (nodepermission != null)
                   {
                       if (nodepermission.right == 2)
                       {
                           x.PermissionFromRole = "Write";
                       }
                       else if (nodepermission.right == 1)
                       {
                           x.PermissionFromRole = "Read";
                       }
                   }
               });
            }
            dataListViewRoles.SetObjects(Model.BindableRoles);
        }

        public void SelectSite(int siteID)
        {
            cboSites.SelectedValue = siteID;
        }

        #endregion Public Methods

        #region Private Methods

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            if (CancelRequested != null)
                CancelRequested(sender, null);
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (SaveDataRequested != null)
                SaveDataRequested(sender, null);
        }

        private void cboSites_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SiteChanged != null && cboSites.SelectedValue != null)
                SiteChanged(sender, ((Site)cboSites.SelectedItem).SiteId);
        }

        private void EmployeePermissionView_Load(object sender, EventArgs e)
        {
            cboSites.DataSource = Model.Sites;
            cboSites.DisplayMember = "SiteName";
            cboSites.ValueMember = "SiteId";
        }

        private void metroTabControlUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (metroTabControlUser.SelectedTab.Name == "tabUserPermission")
            {
                if (ShowPermissionViewRequested != null) ShowPermissionViewRequested(sender, null);
            }
        }

        private void permissionTree_SubItemChecking(object sender, BrightIdeasSoftware.SubItemCheckingEventArgs e)
        {
            var bindedItem = (EmployeePermissionBindingData)e.RowObject;

            if (Model.BindablePermissions.Any(y => y.ParentNode == bindedItem.NodeCode && y.NodeCode != bindedItem.NodeCode))
            {
                if (e.Column.AspectName == "IsReadOnly")
                {
                    if (e.NewValue == CheckState.Checked)
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadOnly = true);
                    }
                    else
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadOnly = false);
                    }
                }

                if (e.Column.AspectName == "IsReadAndWrite")
                {
                    if (e.NewValue == CheckState.Checked)
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadAndWrite = true);
                    }
                    else
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsReadAndWrite = false);
                    }
                }
                if (e.Column.AspectName == "IsRestricted")
                {
                    if (e.NewValue == CheckState.Checked)
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsRestricted = true);
                    }
                    else
                    {
                        GetAllChildNode(bindedItem.NodeCode).ForEach(y => y.IsRestricted = false);
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(bindedItem.ParentNode) && e.NewValue == CheckState.Checked)
            {
                GetParentsNode(bindedItem.ParentNode).ForEach(y => y.IsReadOnly = true);
            }

        }

        public List<EmployeePermissionBindingData> GetAllChildNode(string nodeCode)
        {
            List<EmployeePermissionBindingData> childs = new List<EmployeePermissionBindingData>();
            foreach (var node in Model.BindablePermissions)
            {
                if (node.ParentNode == nodeCode)
                {
                    childs.Add(node);
                    childs.AddRange(GetAllChildNode(node.NodeCode));
                }
            }

            return childs;
        }

        public List<EmployeePermissionBindingData> GetParentsNode(string parentCode)
        {
            List<EmployeePermissionBindingData> parentNodes = new List<EmployeePermissionBindingData>();
            var parents = Model.BindablePermissions.Where(x => x.NodeCode == parentCode).ToList();
            parentNodes.AddRange(parents);
            foreach (var node in parents)
            {
                if (!string.IsNullOrWhiteSpace (node.ParentNode))
                {
                    parentNodes.AddRange(GetParentsNode(node.ParentNode));
                }
            }

            return parentNodes;
        }
        #endregion Private Methods
    }
}