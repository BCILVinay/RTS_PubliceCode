﻿using BCIL;
using BCIL.UIHelper;
using BCIL.User.BL;
using BCIL.User.BL.Enums;
using BCIL.Utility;
using BCIL.User.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class RoleListView : ControlSliderBase, IRoleListView
    {
        #region Public Constructors

        public RoleListView(Control owner) : base(owner)
        {
            InitializeComponent();
            this.Title = "Roles";
            olvColumnCreatedDate.AspectGetter = (o) =>
            {
                var role = o as Role;
                return role.CreatedDate.ToString(App.DateFormat);
            };


            olvColumnActive.AspectToStringConverter = (object o) => { return ((bool)o == true) ? "Yes" : "No"; };
            btnAdd1.Permission = new MetroFramework.ControlPermission(() => { return App.Login.User.HasPermission(PermissionCode.Roles, PermissionType.All); }, MetroFramework.NoPermissionAction.Disable);
            if (!App.Login.User.HasPermission(PermissionCode.Roles, PermissionType.All))
            {
                btnEdit1.Text = "View";
            }

            btnAssign.Permission = new MetroFramework.ControlPermission(() => { return App.Login.User.HasPermission(PermissionCode.RolePermission, PermissionType.Any); }, MetroFramework.NoPermissionAction.Disable);

        }

        #endregion Public Constructors

        #region Public Events

        public event EventHandler AddRoleRequested;
        public event EventHandler<Role> ChangePermissionRequested;
        public event EventHandler<Role> EditRoleRequested;

        #endregion Public Events

        #region Public Properties

        public RoleListModel Model { get; set; }

        #endregion Public Properties

        #region Public Methods

        public void RefreshBinfing()
        {
            olvRoles.SetObjects(Model.Roles);
            lblRecords.Text = "Total records: " + Model.Roles.Count.ToString();
        }
        public void ShowErrorMessage(string message)
        {
            MessageBox.Show(message);
        }

        #endregion Public Methods

        #region Private Methods

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddRoleRequested?.Invoke(this, e);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvRoles.SelectedObject != null)
                {
                    EditRoleRequested?.Invoke(this, (Role)olvRoles.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvRoles_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (olvRoles.SelectedObjects.Count > 0)
                {
                    btnEdit1.Enabled = true;
                    if (App.Login.User.HasAnyPermission(PermissionCode.RolePermission))
                    {
                        btnAssign.Enabled = true;
                    }
                }
                else
                {
                    btnEdit1.Enabled = false;
                    btnAssign.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void tsPermissions_Click(object sender, EventArgs e)
        {
            try
            {
                if (olvRoles.SelectedObject != null)
                {
                    ChangePermissionRequested?.Invoke(this, (Role)olvRoles.SelectedObject);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void olvRoles_Resize(object sender, EventArgs e)
        {
            try
            {
                int withToDistribute = olvRoles.Width - 20;

                olvColumnDescription.Width = withToDistribute.GetPercentValue(30);
                olvColumnName.Width = withToDistribute.GetPercentValue(20);
                olvColumnCreatedBy.Width = withToDistribute.GetPercentValue(20);
                olvColumnCreatedDate.Width = withToDistribute.GetPercentValue(15);
                olvColumnActive.Width = withToDistribute.GetPercentValue(15);
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
            
        }

        #endregion Private Methods
    }
}