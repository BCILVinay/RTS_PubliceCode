﻿using BCIL.Administration.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public interface ILoginedLocationSelectionView : IBaseView
    {
        event EventHandler<Site> SiteSelectionChanged;
        void FillSites(SiteList sites);
        DialogResult DialogResult { get; set; }
    }
}
