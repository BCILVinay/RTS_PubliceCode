﻿using BCIL.Administration.BL;
using BCIL.UIHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public partial class LoginedLocationSelectionView : FormBase, ILoginedLocationSelectionView
    {
        public event EventHandler<Site> SiteSelectionChanged;

        public LoginedLocationSelectionView()
        {
            InitializeComponent();
        }

        public void FillSites(SiteList sites)
        {
            cboSites.DisplayMember = "SiteName";
            cboSites.ValueMember = "SiteId";
            cboSites.DataSource = sites;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try {
                SiteSelectionChanged?.Invoke(this, (Site)cboSites.SelectedItem);
            }
            catch (Exception ex) {
                ShowException(ex);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try {
                DialogResult = DialogResult.Cancel;
            }
            catch (Exception ex) {
                ShowException(ex);
            }
        }

        public static void SelectLocationIfNot(IWin32Window parent)
        {
            if (App.Login.LoginSite.IsNull()) {
                if (new LoginedLocationSelectionView().ShowDialog(parent) == DialogResult.Cancel) {
                    throw new BCILException("Location is not selected");
                }
            }
        }
    }
}
