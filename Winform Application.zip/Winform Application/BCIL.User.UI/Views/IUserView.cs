﻿using BCIL;
using MetroFramework;
using BCIL.User.UI.Models;
using System;
using System.Windows.Forms;

namespace BCIL.User.UI.Views
{
    public interface IUserView : IBaseView<UserModel>
    {
        event EventHandler ChangeCredentialRequested;
        event EventHandler SaveUserRequested;
        event EventHandler<FormClosingEventArgs> CancelRequested;

        Permission AddEditPermision { get; set; }
        Permission ChangeCredentialPermission { get; set; }
        DialogResult DialogResult { get; set; }
        void RefreshBinfing();
    }
}