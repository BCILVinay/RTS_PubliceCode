﻿using BCIL.UIHelper;

namespace BCIL.User.UI.Views
{
    partial class RolePermissionView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RolePermissionView));
            this.lblRole = new MetroFramework.Controls.MetroLabel();
            this.lblSite = new MetroFramework.Controls.MetroLabel();
            this.cboSites = new MetroFramework.Controls.MetroComboBox();
            this.permissionTree = new BCIL.UIHelper.DataTreeListView();
            this.olvColumnNode = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnReadPermission = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumnEditPermission = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.buttonSave = new BCIL.UIHelper.ButtonSave();
            this.buttonCancel = new BCIL.UIHelper.ButtonCancel();
            ((System.ComponentModel.ISupportInitialize)(this.permissionTree)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(24, 76);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(57, 19);
            this.lblRole.TabIndex = 0;
            this.lblRole.Text = "Role: {0}";
            // 
            // lblSite
            // 
            this.lblSite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSite.AutoSize = true;
            this.lblSite.Location = new System.Drawing.Point(502, 76);
            this.lblSite.Name = "lblSite";
            this.lblSite.Size = new System.Drawing.Size(41, 19);
            this.lblSite.TabIndex = 1;
            this.lblSite.Text = "Plant:";
            // 
            // cboSites
            // 
            this.cboSites.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboSites.FormattingEnabled = true;
            this.cboSites.ItemHeight = 19;
            this.cboSites.Location = new System.Drawing.Point(541, 71);
            this.cboSites.Name = "cboSites";
            this.cboSites.PromptItemIndex = -1;
            this.cboSites.Size = new System.Drawing.Size(166, 25);
            this.cboSites.TabIndex = 0;
            this.cboSites.UseSelectable = true;
            this.cboSites.SelectedIndexChanged += new System.EventHandler(this.cboSites_SelectedIndexChanged);
            // 
            // permissionTree
            // 
            this.permissionTree.AllColumns.Add(this.olvColumnNode);
            this.permissionTree.AllColumns.Add(this.olvColumnReadPermission);
            this.permissionTree.AllColumns.Add(this.olvColumnEditPermission);
            this.permissionTree.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.permissionTree.CellEditUseWholeCell = false;
            this.permissionTree.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumnNode,
            this.olvColumnReadPermission,
            this.olvColumnEditPermission});
            this.permissionTree.Cursor = System.Windows.Forms.Cursors.Default;
            this.permissionTree.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.permissionTree.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.permissionTree.FullRowSelect = true;
            this.permissionTree.HeaderMinimumHeight = 30;
            this.permissionTree.IncludeColumnHeadersInCopy = true;
            this.permissionTree.Location = new System.Drawing.Point(23, 118);
            this.permissionTree.Name = "permissionTree";
            this.permissionTree.RowHeight = 25;
            this.permissionTree.ShowGroups = false;
            this.permissionTree.Size = new System.Drawing.Size(684, 320);
            this.permissionTree.TabIndex = 3;
            this.permissionTree.UseCompatibleStateImageBehavior = false;
            this.permissionTree.View = System.Windows.Forms.View.Details;
            this.permissionTree.VirtualMode = true;
            this.permissionTree.SubItemChecking += new System.EventHandler<BrightIdeasSoftware.SubItemCheckingEventArgs>(this.permissionTree_SubItemChecking);
            // 
            // olvColumnNode
            // 
            this.olvColumnNode.AspectName = "NodeName";
            this.olvColumnNode.FillsFreeSpace = true;
            this.olvColumnNode.Text = "Action";
            // 
            // olvColumnReadPermission
            // 
            this.olvColumnReadPermission.AspectName = "IsReadOnly";
            this.olvColumnReadPermission.CheckBoxes = true;
            this.olvColumnReadPermission.Text = "Read Permission";
            this.olvColumnReadPermission.Width = 150;
            // 
            // olvColumnEditPermission
            // 
            this.olvColumnEditPermission.AspectName = "IsReadAndWrite";
            this.olvColumnEditPermission.CheckBoxes = true;
            this.olvColumnEditPermission.Text = "Edit Permission";
            this.olvColumnEditPermission.Width = 150;
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSave.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonSave.ButtonImage")));
            this.buttonSave.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSave.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonSave.ImageSize = 50;
            this.buttonSave.Location = new System.Drawing.Point(531, 444);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(85, 56);
            this.buttonSave.TabIndex = 1;
            this.buttonSave.Text = "Save";
            this.buttonSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonSave.UseSelectable = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.ButtonImage = ((System.Drawing.Image)(resources.GetObject("buttonCancel.ButtonImage")));
            this.buttonCancel.ButtonImageAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.FontWeight = MetroFramework.MetroButtonWeight.Bold;
            this.buttonCancel.ImageSize = 50;
            this.buttonCancel.Location = new System.Drawing.Point(622, 444);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(85, 56);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonCancel.UseSelectable = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // RolePermissionView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(730, 512);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.permissionTree);
            this.Controls.Add(this.cboSites);
            this.Controls.Add(this.lblSite);
            this.Controls.Add(this.lblRole);
            this.Name = "RolePermissionView";
            this.Text = "Role Permissions";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RolePermissionView_FormClosing);
            this.Load += new System.EventHandler(this.RolePermissionView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.permissionTree)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRole;
        private MetroFramework.Controls.MetroLabel lblSite;
        private MetroFramework.Controls.MetroComboBox cboSites;
        private DataTreeListView permissionTree;
        private BrightIdeasSoftware.OLVColumn olvColumnNode;
        private BrightIdeasSoftware.OLVColumn olvColumnReadPermission;
        private BrightIdeasSoftware.OLVColumn olvColumnEditPermission;
        private ButtonSave buttonSave;
        private ButtonCancel buttonCancel;
    }
}