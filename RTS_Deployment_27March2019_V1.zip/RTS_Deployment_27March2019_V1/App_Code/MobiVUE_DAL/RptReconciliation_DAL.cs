﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for RptReconciliation_DAL
    /// </summary>
    public class RptReconciliation_DAL
    {
        //clsDb oDb;
        //StringBuilder sbQuery;
        public RptReconciliation_DAL()
        {
            //oDb = new clsDb();
            //oDb.Connect();
        }
        ~RptReconciliation_DAL()
        {
            //oDb.Disconnect();
            //oDb = null;
            //sbQuery = null;
        }
    }
}