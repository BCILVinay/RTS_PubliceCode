﻿using MobiVUE_ATS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for AssetRquestDAL
/// </summary>
public class AssetRquestDAL
{
    private static clsDb oDb;
    StringBuilder sbQuery;
    private readonly string _DataBaseType = string.Empty;

    public AssetRquestDAL(string DatabaseType)
    {
        if (oDb == null)
        {
            oDb = new clsDb();
        }

        if (DatabaseType != "")
        {
            oDb.Connect(DatabaseType);
            _DataBaseType = DatabaseType;
        }

    }

    ~AssetRquestDAL()
    {
        if (oDb != null)
        {
            oDb.Disconnect();
        }

        oDb = null;
        sbQuery = null;
    }

    #region Asset Request Function
    public List<string> GetAssetTempRequest(string requestType)
    {
        try
        {
            List<string> _requestTypes = new List<string>();
            string sqlQuery = "select CODE  from CODE_MASTER where lower(TYPE) =lower(@Type)";
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = sqlQuery;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Parameters.AddWithValue("@Type", requestType);
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _requestTypes.Add(reader["CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CODE"]));
            }
            return _requestTypes;
        }
        catch (Exception)
        {

            throw;
        }
    }

    public DataTable GetStoregLocation(string loggedInLocation, string company)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_StorageLocationMaster @TYPE='GETSTOREGELOCATION_NOTLOGGEDIN', @COMP_CODE='" + company + "' , @STORAGE_LOC_CODE= '" + loggedInLocation.Trim() + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            return dt;
        }
        catch (Exception)
        {

            throw;
        }
    }

    public string SaveAssetRequest(AssetRequest Request)
    {
        string _assetRequestId = string.Empty;
        try
        {
            if (Request != null)
            {
                oDb.Connect(_DataBaseType);
                oDb.BeginTrans();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_AssetRequest";
                cmd.Parameters.AddWithValue("@LocationCode", Request.LocationCode);
                cmd.Parameters.AddWithValue("@IsPermanent", Request.IsPermanent);
                cmd.Parameters.AddWithValue("@TransferTo", Request.TransferTo);
                cmd.Parameters.AddWithValue("@IsInterUnit", Request.IsInterUnit);
                cmd.Parameters.AddWithValue("@LocationTo", Request.LocationTo);
                cmd.Parameters.AddWithValue("@ProjectCode", Request.ProjectCode);
                cmd.Parameters.AddWithValue("@ReceiverEmail", Request.ReceiverEmail);
                cmd.Parameters.AddWithValue("@GST_NO", Request.GstNo);
                cmd.Parameters.AddWithValue("@ProjectCostCenter", Request.ProjectCostCentre);
                cmd.Parameters.AddWithValue("@Stage", Request.Stage);
                cmd.Parameters.AddWithValue("@ActionBy", Request.CreatedBY);
                SqlParameter RequestId = new SqlParameter("@RequestId", SqlDbType.VarChar, 20);
                RequestId.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(RequestId);
                oDb.ExecuteQueryWithTransation(cmd);

                Request.RequestId = Convert.ToString(RequestId.Value);
                SaveUploadData(Request.RequestId, Request.LocationCode, Request.Documents);
                SaveAssetDetails(Request.RequestId, Request.LocationCode, Request.AssetDetails);
                _assetRequestId = Request.RequestId;

                FinalUploadFile(Request.Documents, Request.LocationCode);

                oDb.CommitTrans();
                oDb.Disconnect();



            }
        }
        catch (Exception ex)
        {
            oDb.RollBack();
            throw ex;
        }
        finally
        {
            oDb.Disconnect();
        }

        return _assetRequestId;


    }

    private int SaveUploadData(string AssetRequestId, string LocationCode, List<UploadDocument> Documents)
    {
        int ctr = default(int);
        int _SerialNumber = default(int);
        try
        {
            if (Documents != null && Documents.Count > 0)
            {
                foreach (var document in Documents)
                {
                    _SerialNumber = GetRunningSerialNumber(LocationCode, 1, "MOVEMENT_REQUEST_DOC", "0", false);
                    document.DocumentDetailId = _SerialNumber;
                    document.UploadDBFilePath = Path.GetFileNameWithoutExtension(document.FileName) + "_" + LocationCode + "_" + document.DocumentDetailId + Path.GetExtension(document.FileName);
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "USP_AssetRequestLineItem";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Type", "SAVE_UPLOAD_DOCUMENT");
                    cmd.Parameters.AddWithValue("@LineItemId", document.DocumentDetailId);
                    cmd.Parameters.AddWithValue("@AssetHeaderRequestId", AssetRequestId);
                    cmd.Parameters.AddWithValue("@DocumentType", document.DocumentType);
                    cmd.Parameters.AddWithValue("@DocumentName", document.UploadDBFilePath);
                    cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
                    cmd.Parameters.AddWithValue("@Remark", document.Remark);

                    //SqlParameter FileName = new SqlParameter("@FileName", SqlDbType.VarChar, 20);
                    //FileName.Direction = System.Data.ParameterDirection.Output;
                    //cmd.Parameters.Add(FileName);
                    ctr = ctr + oDb.ExecuteQueryWithTransation(cmd);

                }
            }
            return ctr;
        }
        catch (Exception)
        {

            throw;
        }
    }

    private int SaveAssetDetails(string AssetRequestId, string LocationCode, List<AssetDetails> AssetDetails)
    {
        int ctr = default(int);
        int _SerialNumber = default(int);
        try
        {
            foreach (var asset in AssetDetails)
            {
                _SerialNumber = GetRunningSerialNumber(LocationCode, 1, "MOVEMENT_REQUEST_DTL", "0", false);
                asset.AssetDetailId = _SerialNumber;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "USP_AssetRequestLineItem";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Type", "SAVE_REQUEST_DETAIL");
                cmd.Parameters.AddWithValue("@LineItemId", asset.AssetDetailId);
                cmd.Parameters.AddWithValue("@AssetHeaderRequestId", AssetRequestId);
                cmd.Parameters.AddWithValue("@AssetCode", asset.AssetCode);
                cmd.Parameters.AddWithValue("@LocationCode", LocationCode);

                //SqlParameter FileName = new SqlParameter("@FileName", SqlDbType.VarChar, 20);
                //FileName.Direction = System.Data.ParameterDirection.Output;
                //cmd.Parameters.Add(FileName);
                var x = oDb.ExecuteQueryWithTransation(cmd);
                if (x > 0)
                {
                    asset.IsUploaded = true;
                }
                ctr = ctr + x;

                //asset.AssetDBFileName = Convert.ToString(FileName.Value);

            }
            return ctr;
        }
        catch (Exception)
        {

            throw;
        }
    }


    private void FinalUploadFile(List<UploadDocument> documents, string locationCode)
    {
        try
        {


            if (documents != null && documents.Count > 0)
            {
                foreach (var document in documents)
                {
                    var documentName = Path.GetFileNameWithoutExtension(document.FileName);
                    var finalUploadPath = Path.GetDirectoryName(document.UploadFilePath);
                    var ext = Path.GetExtension(document.UploadFilePath);
                    if (!string.IsNullOrEmpty(finalUploadPath))
                    {
                        finalUploadPath = finalUploadPath.Replace("\\TempDocument", "");
                    }
                    finalUploadPath = finalUploadPath + "\\" + document.UploadDBFilePath;

                    File.Copy(document.UploadFilePath, finalUploadPath);

                    if (File.Exists(document.UploadFilePath))
                    {
                        File.Delete(document.UploadFilePath);
                    }

                }
            }
        }

        catch (Exception)
        {


        }
    }


    private int GetRunningSerialNumber(string LocationCode, int PrintQty, string TransactionType, string LineNumber, bool MonthWise)
    {
        int _serialNumber = default(int);
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "ud_mRunningSerialNo";
            cmd.Parameters.AddWithValue("@SiteID", LocationCode);
            cmd.Parameters.AddWithValue("@PrintQty", PrintQty);
            cmd.Parameters.AddWithValue("@TransType", TransactionType);
            cmd.Parameters.AddWithValue("@LineNo", LineNumber);
            cmd.Parameters.AddWithValue("@MonthWise", MonthWise);
            SqlParameter SerialNumber = new SqlParameter("@Output", SqlDbType.VarChar, 20);
            SerialNumber.Direction = System.Data.ParameterDirection.Output;
            cmd.Parameters.Add(SerialNumber);
            oDb.ExecuteQueryWithTransation(cmd);
            _serialNumber = Convert.ToInt16(SerialNumber.Value);
            return _serialNumber;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public List<AssetDetails> ValidateAssetDetails(DataTable assetDetails, string LocationCode)
    {
        List<AssetDetails> assetType = new List<AssetDetails>();
        try
        {

            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_ValidateAsset";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            SqlParameter Parameter = new SqlParameter();
            Parameter.ParameterName = "@UploadAsset";
            Parameter.SqlDbType = SqlDbType.Structured;
            Parameter.Value = assetDetails;
            cmd.Parameters.Add(Parameter);

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                assetType.Add(new AssetDetails { AssetCode = reader["ASSETCODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSETCODE"]) });
            }
            return assetType;
        }
        catch (Exception)
        {
            oDb.Disconnect();
        }
        return assetType;
    }

    #endregion


    #region Asset Approved function

    public List<string> GetRequest(string LocationCode, AssetRequestStage RequestStage)
    {
        List<string> _requests = new List<string>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@Stage", RequestStage);
            cmd.Parameters.AddWithValue("@Type", "GetRequest");
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _requests.Add(reader["RequestId"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestId"]));
            }
            oDb.Disconnect();
            return _requests;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }

    public AssetRequest GetAssetRequest(AssetSearchCriteria Criteria)
    {
        AssetRequest _request = new AssetRequest();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", Criteria.LocationCode);
            cmd.Parameters.AddWithValue("@Stage", Criteria.RequestStage);
            cmd.Parameters.AddWithValue("@RequestID", Criteria.RequestId);
            cmd.Parameters.AddWithValue("@DocType", Criteria.DocumentType);
            cmd.Parameters.AddWithValue("@Type", "GETASSETREQUEST");

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);

            while (reader.Read())
            {
                _request.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                _request.IsPermanent = reader["IS_PERMANENT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_PERMANENT"]);
                _request.TransferTo = reader["TRANSFER_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["TRANSFER_TO"]);
                _request.IsInterUnit = reader["IS_INTERUNIT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_INTERUNIT"]);
                _request.LocationTo = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                _request.ProjectCode = reader["PROJECT_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_CODE"]);
                _request.ReceiverEmail = reader["RECEIVER_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVER_EMAIL"]);
                _request.GstNo = reader["GST_NO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GST_NO"]);
                _request.ProjectCostCentre = reader["PROJECT_COST_CENTRE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_COST_CENTRE"]);
                _request.PMApprove = reader["PM_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["PM_APPROVE"]);
                _request.PMRemark = reader["PM_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_REMARKS"]);
                _request.CMFApprove = reader["CMF_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["CMF_APPROVE"]);
                _request.CMFRemark = reader["CMF_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_REMARKS"]);
                _request.IsClerance = reader["IS_CLEARANCE"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_CLEARANCE"]);
                _request.Stage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CREATED_ON"]);
                _request.CreatedBY = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                _request.PMApprovedOn = reader["PM_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["PM_APPROVED_ON"]);
                _request.PMApprovedBy = reader["PM_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_BY"]);
                _request.CMFApprovedOn = reader["CMF_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CMF_APPROVED_ON"]);
                _request.CMFApprovedBy = reader["CMF_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_BY"]);
                _request.ClearanceOn = reader["CLEARANCE_ON"] == DBNull.Value ? null : (DateTime?)(reader["CLEARANCE_ON"]);
                _request.ClearanceBy = reader["CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_BY"]);

                _request.ReceivedOn = reader["RECEIVED_ON"] == DBNull.Value ? default(DateTime?) : (DateTime?)(reader["RECEIVED_ON"]);
                _request.ReceivedBy = reader["RECEIVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_BY"]);

                _request.RequestedLocName = reader["RequestedLocName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestedLocName"]);
                _request.RequestedToLocName = reader["RequestedToLocName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestedToLocName"]);

                _request.AssetDetails.Add(GetAsset(reader));
                // _request.Documents.Add(this.GetAssetUploadDocument(reader));

            }
            _request.Documents = GetUploadedDocument(Criteria);

            oDb.Disconnect();
            return _request;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }


    private List<UploadDocument> GetUploadedDocument(AssetSearchCriteria Criteria)
    {
        List<UploadDocument> _uploadedDocuments = new List<UploadDocument>();
        try
        {
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", Criteria.LocationCode);
            cmd.Parameters.AddWithValue("@Stage", Criteria.RequestStage);
            cmd.Parameters.AddWithValue("@RequestID", Criteria.RequestId);
            cmd.Parameters.AddWithValue("@DocType", Criteria.DocumentType);
            cmd.Parameters.AddWithValue("@Type", "GETUPLOADDOCUMENT");
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _uploadedDocuments.Add(GetAssetUploadDocument(reader));
            }
            return _uploadedDocuments;
        }
        catch (Exception)
        {
            throw;
        }
    }

    private AssetDetails GetAsset(SqlDataReader reader)
    {
        try
        {
            var _assetDetails = new AssetDetails();
            _assetDetails.AssetDetailId = reader["REQUEST_DTL_ID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["REQUEST_DTL_ID"]);
            _assetDetails.AssetCode = reader["ASSET_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_CODE"]);
            _assetDetails.FamsID = reader["ASSET_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_ID"]);
            _assetDetails.CategoryCode = reader["CATEGORY_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CATEGORY_NAME"]);
            return _assetDetails;
        }
        catch (Exception)
        {

            throw;
        }
    }
    private UploadDocument GetAssetUploadDocument(SqlDataReader reader)
    {
        try
        {
            var _uploadDocument = new UploadDocument();
            _uploadDocument.DocumentDetailId = reader["REQUEST_DOC_ID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["REQUEST_DOC_ID"]);
            _uploadDocument.DocumentType = reader["DOC_TYPE"] == DBNull.Value ? UploadDocType.None : (UploadDocType)(reader["DOC_TYPE"]);
            _uploadDocument.UploadDBFilePath = reader["DOC_NAME"] == DBNull.Value ? string.Empty : Convert.ToString(reader["DOC_NAME"]);
            _uploadDocument.Remark = reader["Remark"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Remark"]);

            return _uploadDocument;
        }
        catch (Exception)
        {

            throw;
        }
    }


    public int ApprovedRequest(AssetApprove approvedRequest)
    {

        try
        {
            int ctr = default(Int32);

            if (approvedRequest != null)
            {

                DateTime? ActionOn = default(DateTime?);
                string ActionBy = string.Empty;
                oDb.Connect(_DataBaseType);
                oDb.BeginTrans();
                if ((approvedRequest.AssetRequest.Stage == AssetRequestStage.CMFApproved || approvedRequest.AssetRequest.Stage == AssetRequestStage.CMFReject))
                {
                    ctr = ApprovedByCMF(approvedRequest);
                    ActionOn = approvedRequest.AssetRequest.CMFApprovedOn;
                    ActionBy = approvedRequest.AssetRequest.CMFApprovedBy;

                }
                else if ((approvedRequest.AssetRequest.Stage == AssetRequestStage.PMApproved || approvedRequest.AssetRequest.Stage == AssetRequestStage.PMReject))
                {
                    ctr = ApprovedbyPM(approvedRequest);
                    ActionOn = approvedRequest.AssetRequest.PMApprovedOn;
                    ActionBy = approvedRequest.AssetRequest.PMApprovedBy;
                }
                RejectRequest(approvedRequest.AssetRequest, ActionOn, ActionBy);

                oDb.CommitTrans();
            }
            return ctr;
        }
        catch (Exception)
        {
            oDb.RollBack();
            throw;
        }
        finally
        {
            oDb.Disconnect();
        }
    }

    private int ApprovedbyPM(AssetApprove approvedRequest)
    {
        int ctr = default(Int32);
        try
        {
            if (approvedRequest != null)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_ApprovedAssetRequest";

                cmd.Parameters.AddWithValue("@Type", "PMAPPROVED");
                cmd.Parameters.AddWithValue("@PM_APPROVE", approvedRequest.AssetRequest.PMApprove);
                cmd.Parameters.AddWithValue("@PM_REMARKS", approvedRequest.AssetRequest.PMRemark);
                cmd.Parameters.AddWithValue("@STAGE", approvedRequest.AssetRequest.Stage);
                cmd.Parameters.AddWithValue("@ActionON", approvedRequest.AssetRequest.PMApprovedOn);
                cmd.Parameters.AddWithValue("@ActionBY", approvedRequest.AssetRequest.PMApprovedBy);
                cmd.Parameters.AddWithValue("@LOCATION_CODE", approvedRequest.AssetRequest.LocationCode);
                cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", approvedRequest.AssetRequest.RequestId);
                ctr = ctr + oDb.ExecuteQueryWithTransation(cmd);
                SaveUploadData(approvedRequest.AssetRequest.RequestId, approvedRequest.AssetRequest.LocationCode, approvedRequest.Documents);

                FinalUploadFile(approvedRequest.Documents, approvedRequest.AssetRequest.LocationCode);



            }
            return ctr;
        }
        catch (Exception)
        {

            throw;
        }

    }

    private int ApprovedByCMF(AssetApprove approvedRequest)
    {
        int ctr = default(Int32);
        try
        {
            if (approvedRequest != null)
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_ApprovedAssetRequest";
                cmd.Parameters.AddWithValue("@Type", "CMFAPPROVED");
                cmd.Parameters.AddWithValue("@CMF_APPROVE", approvedRequest.AssetRequest.CMFApprove);
                cmd.Parameters.AddWithValue("@CMF_REMARKS", approvedRequest.AssetRequest.CMFRemark);
                cmd.Parameters.AddWithValue("@STAGE", approvedRequest.AssetRequest.Stage);
                cmd.Parameters.AddWithValue("@ActionON", approvedRequest.AssetRequest.CMFApprovedOn);
                cmd.Parameters.AddWithValue("@ActionBY", approvedRequest.AssetRequest.CMFApprovedBy);
                cmd.Parameters.AddWithValue("@LOCATION_CODE", approvedRequest.AssetRequest.LocationCode);
                cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", approvedRequest.AssetRequest.RequestId);
                ctr = ctr + oDb.ExecuteQueryWithTransation(cmd);
                SaveUploadData(approvedRequest.AssetRequest.RequestId, approvedRequest.AssetRequest.LocationCode, approvedRequest.Documents);
                FinalUploadFile(approvedRequest.Documents, approvedRequest.AssetRequest.LocationCode);
            }
            return ctr;
        }
        catch (Exception)
        {
            throw;
        }
    }

    public Clearance GetClearanceRequest(AssetSearchCriteria Criteria, string ClearanceSource)
    {
        Clearance _clearanceRequest = default(Clearance);
        try
        {
            _clearanceRequest = new Clearance();
            _clearanceRequest.AssetRequest = this.GetAssetRequest(Criteria);
            _clearanceRequest.AssetClerance = this.GetAssetClearance(_clearanceRequest.AssetRequest, ClearanceSource);
            return _clearanceRequest;
        }
        catch (Exception)
        {
            throw;
        }
    }


    public Clearance GetReceivingClearanceRequest(AssetSearchCriteria Criteria, string ClearanceSource)
    {
        Clearance _clearanceRequest = default(Clearance);
        try
        {
            _clearanceRequest = new Clearance();
            _clearanceRequest.AssetRequest = this.GetReceivingRequest(Criteria);
            _clearanceRequest.AssetClerance = this.GetAssetClearance(_clearanceRequest.AssetRequest, ClearanceSource);
            return _clearanceRequest;
        }
        catch (Exception)
        {
            throw;
        }
    }

    public List<AssetClearance> GetAssetClearance(AssetRequest request, string Source)
    {
        List<AssetClearance> _Clearance = new List<AssetClearance>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", request.LocationCode);
            cmd.Parameters.AddWithValue("@Stage", request.Stage);
            cmd.Parameters.AddWithValue("@RequestID", request.RequestId);
            cmd.Parameters.AddWithValue("@Source", Source);
            cmd.Parameters.AddWithValue("@Type", "GETASSETCLEARANCE");

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);

            while (reader.Read())
            {
                var clearance = new AssetClearance()
                {
                    ClearanceCode = Convert.ToInt32(reader["clearance_code"] == DBNull.Value ? default(Int32) : reader["clearance_code"]),
                    Description = Convert.ToString(reader["description"] == DBNull.Value ? string.Empty : reader["description"]),
                    Type = Convert.ToString(reader["type"] == DBNull.Value ? string.Empty : reader["type"]),
                    CreatedBY = Convert.ToString(reader["created_by"] == DBNull.Value ? string.Empty : reader["created_by"]),
                    CreatedOn = Convert.ToDateTime(reader["created_on"] == DBNull.Value ? default(DateTime?) : reader["created_on"]),
                    ClearanceOn = Convert.ToDateTime(reader["ClearanceOn"] == DBNull.Value ? default(DateTime?) : reader["ClearanceOn"]),
                    ClearanceBy = Convert.ToString(reader["ClearanceBy"] == DBNull.Value ? string.Empty : reader["ClearanceBy"]),
                    IsClearanced = Convert.ToBoolean(reader["IsAssetClearanced"] == DBNull.Value ? default(bool) : reader["IsAssetClearanced"]),
                    Remarks = Convert.ToString(reader["Remarks"] == DBNull.Value ? string.Empty : reader["Remarks"]),
                };
                _Clearance.Add(clearance);
            }
            return _Clearance;
        }
        catch (Exception)
        {

            throw;
        }
    }

    public int SaveAssetClearance(Clearance clearance)
    {
        var _affectedRows = default(Int32);
        try
        {
            if (clearance.AssetClerance.FindAll(p => p.IsClearanced).Count > 0)
            {
                oDb.Connect(_DataBaseType);
                oDb.BeginTrans();
                foreach (var item in clearance.AssetClerance)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_ApprovedAssetRequest";

                    cmd.Parameters.AddWithValue("@Type", "CLEARANCE");

                    cmd.Parameters.AddWithValue("@Clearance_Code", item.ClearanceCode);

                    cmd.Parameters.AddWithValue("@ClearanceRemarks", item.Remarks);

                    cmd.Parameters.AddWithValue("@ActionON", item.ClearanceOn);
                    cmd.Parameters.AddWithValue("@ActionBY", item.ClearanceBy);

                    cmd.Parameters.AddWithValue("@STAGE", clearance.AssetRequest.Stage);
                    cmd.Parameters.AddWithValue("@IS_CLEARANCE", clearance.AssetRequest.IsClerance);
                    cmd.Parameters.AddWithValue("@LOCATION_CODE", clearance.AssetRequest.LocationCode);
                    cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", clearance.AssetRequest.RequestId);
                    var x = oDb.ExecuteQueryWithTransation(cmd);
                    if (x > 0)
                    {
                        _affectedRows = _affectedRows + x;
                    }

                }

                if (clearance.AssetRequest.Stage == AssetRequestStage.ClearanceApproved || clearance.AssetRequest.Stage == AssetRequestStage.ClearanceReject)
                {

                    var ClearanceOn = clearance.AssetRequest.ClearanceOn;
                    var ClearanceBy = clearance.AssetRequest.ClearanceBy;
                    var x = ClearancRequestAction(clearance.AssetRequest);
                    RejectRequest(clearance.AssetRequest, ClearanceOn, ClearanceBy);
                    _affectedRows = x > 0 ? x : _affectedRows;

                }

                if (clearance.Documents != null)
                {
                    SaveUploadData(clearance.AssetRequest.RequestId, clearance.AssetRequest.LocationCode, clearance.Documents);
                    FinalUploadFile(clearance.Documents, clearance.AssetRequest.LocationCode);
                }

                oDb.CommitTrans();
            }

            return _affectedRows;
        }
        catch (Exception)
        {
            oDb.RollBack();
            throw;
        }
        finally
        {
            oDb.Disconnect();
        }
    }

    private int ClearancRequestAction(AssetRequest request)
    {
        int _affectedRows = default(int);
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_ApprovedAssetRequest";
            cmd.Parameters.AddWithValue("@Type", "CLEARANEREQUEST");
            cmd.Parameters.AddWithValue("@ActionON", request.ClearanceOn);
            cmd.Parameters.AddWithValue("@ActionBY", request.ClearanceBy);
            cmd.Parameters.AddWithValue("@STAGE", request.Stage);
            cmd.Parameters.AddWithValue("@IS_CLEARANCE", request.IsClerance);
            cmd.Parameters.AddWithValue("@LOCATION_CODE", request.LocationCode);
            cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", request.RequestId);
            _affectedRows = _affectedRows + oDb.ExecuteQueryWithTransation(cmd);
            return _affectedRows;
        }
        catch (Exception)
        {

            throw;
        }
    }



    #endregion

    #region Asset Receiving
    // GETREQUESTFORCLRRECEIVING
    public List<string> GetReceiveingRequest(string LocationCode, AssetRequestStage RequestStage)
    {
        List<string> _requests = new List<string>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LOcationCode", LocationCode);
            cmd.Parameters.AddWithValue("@Stage", RequestStage);
            cmd.Parameters.AddWithValue("@Type", "GETREQUESTFORRECEIVING");
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _requests.Add(reader["RequestId"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestId"]));
            }
            oDb.Disconnect();
            return _requests;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }

    public List<string> GetClearanceReceiveingRequest(string LocationCode, AssetRequestStage RequestStage)
    {
        List<string> _requests = new List<string>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LOcationCode", LocationCode);
            cmd.Parameters.AddWithValue("@Stage", RequestStage);
            cmd.Parameters.AddWithValue("@Type", "GETREQUESTFORCLRRECEIVING");
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _requests.Add(reader["RequestId"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestId"]));
            }
            oDb.Disconnect();
            return _requests;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }

    public List<string> GetRGPRequest(string LocationCode, AssetRequestStage RequestStage)
    {
        List<string> _requests = new List<string>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@Stage", RequestStage);
            cmd.Parameters.AddWithValue("@Type", "GetRGPRequest");
            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
            while (reader.Read())
            {
                _requests.Add(reader["RequestId"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestId"]));
            }
            oDb.Disconnect();
            return _requests;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }

    public AssetRequest GetReceivingRequest(AssetSearchCriteria Criteria)
    {
        AssetRequest _request = new AssetRequest();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", Criteria.LocationCode);
            cmd.Parameters.AddWithValue("@Stage", Criteria.RequestStage);
            cmd.Parameters.AddWithValue("@RequestID", Criteria.RequestId);
            cmd.Parameters.AddWithValue("@DocType", Criteria.DocumentType);
            cmd.Parameters.AddWithValue("@Type", "GETASSETFORRECEIVING");

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);

            while (reader.Read())
            {

                _request.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                _request.IsPermanent = reader["IS_PERMANENT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_PERMANENT"]);
                _request.TransferTo = reader["TRANSFER_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["TRANSFER_TO"]);
                _request.IsInterUnit = reader["IS_INTERUNIT"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_INTERUNIT"]);
                _request.LocationTo = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                _request.ProjectCode = reader["PROJECT_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_CODE"]);
                _request.ReceiverEmail = reader["RECEIVER_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVER_EMAIL"]);
                _request.GstNo = reader["GST_NO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GST_NO"]);
                _request.ProjectCostCentre = reader["PROJECT_COST_CENTRE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_COST_CENTRE"]);
                _request.PMApprove = reader["PM_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["PM_APPROVE"]);
                _request.PMRemark = reader["PM_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_REMARKS"]);
                _request.CMFApprove = reader["CMF_APPROVE"] == DBNull.Value ? false : Convert.ToBoolean(reader["CMF_APPROVE"]);
                _request.CMFRemark = reader["CMF_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_REMARKS"]);
                _request.IsClerance = reader["IS_CLEARANCE"] == DBNull.Value ? false : Convert.ToBoolean(reader["IS_CLEARANCE"]);
                _request.Stage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CREATED_ON"]);
                _request.CreatedBY = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                _request.PMApprovedOn = reader["PM_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["PM_APPROVED_ON"]);
                _request.PMApprovedBy = reader["PM_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_BY"]);
                _request.CMFApprovedOn = reader["CMF_APPROVED_ON"] == DBNull.Value ? null : (DateTime?)(reader["CMF_APPROVED_ON"]);
                _request.CMFApprovedBy = reader["CMF_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_BY"]);
                _request.ClearanceOn = reader["CLEARANCE_ON"] == DBNull.Value ? null : (DateTime?)(reader["CLEARANCE_ON"]);
                _request.ClearanceBy = reader["CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_BY"]);
                _request.ReceivedOn = reader["RECEIVED_ON"] == DBNull.Value ? default(DateTime?) : (DateTime?)(reader["RECEIVED_ON"]);
                _request.ReceivedBy = reader["RECEIVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_BY"]);
                _request.RequestedLocName = reader["RequestedLocName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestedLocName"]);
                _request.RequestedToLocName = reader["RequestedToLocName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestedToLocName"]);

               // added new feild  : on 11 JAN 2018 

               
                _request.AssetDetails.Add(GetAsset(reader));

                // _request.Documents.Add(this.GetAssetUploadDocument(reader));

            }
            _request.Documents = GetUploadedDocument(Criteria);
            oDb.Disconnect();
            return _request;
        }
        catch (Exception)
        {
            oDb.Disconnect();
            throw;
        }
    }

    public int ReceivedAssetRequest(AssetRequest request)
    {
        int _affectedRows = default(int);
        try
        {
            // string _assetCode = GetCommaSeparatedAssetCategory(request.AssetDetails);
            oDb.Connect(_DataBaseType);
            oDb.BeginTrans();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_ApprovedAssetRequest";

            cmd.Parameters.AddWithValue("@Type", "RECEIVEDREQUEST");
            cmd.Parameters.AddWithValue("@STAGE", request.Stage);
            cmd.Parameters.AddWithValue("@ActionON", request.ReceivedOn);
            cmd.Parameters.AddWithValue("@ActionBY", request.ReceivedBy);
            cmd.Parameters.AddWithValue("@LOCATION_CODE", request.LocationCode);
            cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", request.RequestId);
            cmd.Parameters.AddWithValue("@IS_Received", request.IsReceived);


            _affectedRows = oDb.ExecuteQueryWithTransation(cmd);

            RejectRequest(request, request.ReceivedOn, request.ReceivedBy);
            //if (_affectedRows > 0)
            //{
            //    ReleaseAsset(_assetCode, request.LocationCode);
            //  var x =  GenerateAssetHistory(request.ReceivedBy, request.ReceivedOn, _assetCode);
            //}

            if (request.Documents != null && request.Documents.Count > 0)
            {
                SaveUploadData(request.RequestId, request.LocationCode, request.Documents);
                FinalUploadFile(request.Documents, request.LocationCode);
            }

            if (request.Stage == AssetRequestStage.Received)
            {
                try
                {
                    SendMailOnReceivedAsset(request.RequestId);
                }
                catch (Exception) { throw; }
            }

            oDb.CommitTrans();


            return _affectedRows;
        }
        catch (Exception)
        {
            oDb.RollBack();
            oDb.Disconnect();
            throw;
        }
        finally
        {
            oDb.Disconnect();
        }
    }

    public void SendMailOnReceivedAsset(string RequestId)
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_ReceivedAssetMail";
            cmd.Parameters.AddWithValue("@MovementId", RequestId);
            oDb.ExecuteQueryWithTransation(cmd);
        }
        catch (Exception)
        {
        }
    }


    //    private int ReleaseAsset(string AssetCode, string LocationCode)
    //    {
    //        string sqlQuery = @"UPDATE  ASSET_ACQUISITION 
    //SET 
    //	 Status =null ,
    //	 LOCATION = '" + LocationCode + "' WHERE  ASSET_CODE in (" + AssetCode + ")";


    //        var x = oDb.ExecuteSQLQuery(sqlQuery);

    //        return x;


    //    }

    private int GenerateAssetHistory(string ActionBy, DateTime? ActionOn, string AssetCode)
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = SqlQueryForAssetHistory(AssetCode);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@ActionON", ActionOn);
            cmd.Parameters.AddWithValue("@ActionBy", ActionBy);
            var x = oDb.ExecuteQueryWithTransation(cmd);
            return x;
        }
        catch (Exception)
        {

            throw;
        }
    }

    // for Comma separated Category Used is in condition

    private string SqlQueryForAssetHistory(string AssetCode)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("INSERT INTO [ASSET_ACQUISITION_HISTORY] \n");
        sb.Append("           ([RUNNING_SERIAL_NO] \n");
        sb.Append("           ,[ASSET_CODE] \n");
        sb.Append("           ,[TAG_ID] \n");
        sb.Append("           ,[ASSET_ID] \n");
        sb.Append("           ,[SERIAL_CODE] \n");
        sb.Append("           ,[CATEGORY_CODE] \n");
        sb.Append("           ,[ASSET_LOCATION] \n");
        sb.Append("           ,[PLANT] \n");
        sb.Append("           ,[LOCATION] \n");
        sb.Append("           ,[CUSTOMER_ORDER_NO] \n");
        sb.Append("           ,[PROJECT_NAME] \n");
        sb.Append("           ,[SUB_PROJECT_NAME] \n");
        sb.Append("           ,[PROJECT_MANAGER] \n");
        sb.Append("           ,[ASSIGN_PRO_TO_EMP] \n");
        sb.Append("           ,[COMP_CODE] \n");
        sb.Append("           ,[VENDOR_CODE] \n");
        sb.Append("           ,[INSTALLED_DATE] \n");
        sb.Append("           ,[PURCHASED_DATE] \n");
        sb.Append("           ,[PURCHASED_AMT] \n");
        sb.Append("           ,[CURRENCY] \n");
        sb.Append("           ,[TRANSFER_PRICE] \n");
        sb.Append("           ,[LOCAL_CURRENCY] \n");
        sb.Append("           ,[PO_NUMBER] \n");
        sb.Append("           ,[PO_DATE] \n");
        sb.Append("           ,[INVOICE_NO] \n");
        sb.Append("           ,[SALE_DATE] \n");
        sb.Append("           ,[SALE_AMT] \n");
        sb.Append("           ,[CREATED_BY] \n");
        sb.Append("           ,[CREATED_ON] \n");
        sb.Append("           ,[ASSET_MAKE] \n");
        sb.Append("           ,[MODEL_NAME] \n");
        sb.Append("           ,[ASSET_PROCESS] \n");
        sb.Append("           ,[SECURITY_CLASSIFICATION] \n");
        sb.Append("           ,[ASSET_SIZE] \n");
        sb.Append("           ,[ASSET_VLAN] \n");
        sb.Append("           ,[ASSET_HDD] \n");
        sb.Append("           ,[ASSET_PROCESSOR] \n");
        sb.Append("           ,[ASSET_RAM] \n");
        sb.Append("           ,[ASSET_IMEI_NO] \n");
        sb.Append("           ,[ASSET_PHONE_MEMORY] \n");
        sb.Append("           ,[ASSET_SERVICE_PROVIDER] \n");
        sb.Append("           ,[ASSET_TYPE] \n");
        sb.Append("           ,[ASSET_BOE] \n");
        sb.Append("           ,[ASSET_REGISTER_NO] \n");
        sb.Append("           ,[BONDED_TYPE] \n");
        sb.Append("           ,[BOND_NO] \n");
        sb.Append("           ,[CAPITALISED_STATUS] \n");
        sb.Append("           ,[VERIFIABLE_STATUS] \n");
        sb.Append("           ,[PORT_NO] \n");
        sb.Append("           ,[ASSET_ALLOCATED] \n");
        sb.Append("           ,[SOLD_SCRAPPED_STATUS] \n");
        sb.Append("           ,[SECURITY_GATE_ENTRY_NO] \n");
        sb.Append("           ,[SECURITY_GATE_ENTRY_DATE] \n");
        sb.Append("           ,[AMC_WARRANTY_START_DATE] \n");
        sb.Append("           ,[AMC_WARRANTY_END_DATE] \n");
        sb.Append("           ,[REMARKS] \n");
        sb.Append("           ,[ASSET_APPROVED] \n");
        sb.Append("           ,[AMC_WARRANTY] \n");
        sb.Append("           ,[WORKSTATION_NO] \n");
        sb.Append("           ,[COST_CENTER_NO] \n");
        sb.Append("           ,[COMPANY_NAME] \n");
        sb.Append("           ,[DEPARTMENT] \n");
        sb.Append("           ,[INVENTORY_NOTE] \n");
        sb.Append("           ,[ASSET_DESCRIPTION] \n");
        sb.Append("           ,[ASSET_MAIN_TEXT] \n");
        sb.Append("           ,[ASSET_DESCRIPTION_1] \n");
        sb.Append("           ,[ACCT_DE] \n");
        sb.Append("           ,[ROOM] \n");
        sb.Append("           ,[BA] \n");
        sb.Append("           ,[UPDATED_ON] \n");
        sb.Append("           ,[UPDATED_BY] \n");
        sb.Append("           ,[EX_FIELD1] \n");
        sb.Append("           ,[EX_FIELD2] \n");
        sb.Append("           ,[EX_FIELD3] \n");
        sb.Append("           ,[EX_FIELD4] \n");
        sb.Append("           ,[EX_FIELD5] \n");
        sb.Append("           ,[Status] \n");
        sb.Append("           ,[MOVED_ON] \n");
        sb.Append("           ,[MOVED_BY]) \n");
        sb.Append("   \n");
        sb.Append("  SELECT \n");
        sb.Append("  [RUNNING_SERIAL_NO] \n");
        sb.Append(",[ASSET_CODE],[TAG_ID],[ASSET_ID],[SERIAL_CODE] ,[CATEGORY_CODE] ,[ASSET_LOCATION] ,[PLANT] \n");
        sb.Append(",[LOCATION],[CUSTOMER_ORDER_NO],[PROJECT_NAME],[SUB_PROJECT_NAME],[PROJECT_MANAGER] ,[ASSIGN_PRO_TO_EMP],[COMP_CODE] \n");
        sb.Append(",[VENDOR_CODE] ,[INSTALLED_DATE] ,[PURCHASED_DATE],[PURCHASED_AMT] ,[CURRENCY] ,[TRANSFER_PRICE] ,[LOCAL_CURRENCY],[PO_NUMBER] \n");
        sb.Append(",[PO_DATE] ,[INVOICE_NO],[SALE_DATE] ,[SALE_AMT],[CREATED_BY],[CREATED_ON] ,[ASSET_MAKE] ,[MODEL_NAME] ,[ASSET_PROCESS] ,[SECURITY_CLASSIFICATION] ,[ASSET_SIZE] \n");
        sb.Append(",[ASSET_VLAN],[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO] ,[ASSET_PHONE_MEMORY] ,[ASSET_SERVICE_PROVIDER] ,[ASSET_TYPE] \n");
        sb.Append(",[ASSET_BOE],[ASSET_REGISTER_NO] \n");
        sb.Append("           ,[BONDED_TYPE] \n");
        sb.Append("           ,[BOND_NO] \n");
        sb.Append("           ,[CAPITALISED_STATUS] \n");
        sb.Append("           ,[VERIFIABLE_STATUS] \n");
        sb.Append("           ,[PORT_NO] \n");
        sb.Append("           ,[ASSET_ALLOCATED] \n");
        sb.Append("           ,[SOLD_SCRAPPED_STATUS] \n");
        sb.Append("           ,[SECURITY_GATE_ENTRY_NO] \n");
        sb.Append("           ,[SECURITY_GATE_ENTRY_DATE] \n");
        sb.Append("           ,[AMC_WARRANTY_START_DATE] \n");
        sb.Append("           ,[AMC_WARRANTY_END_DATE] \n");
        sb.Append("           ,[REMARKS] \n");
        sb.Append("           ,[ASSET_APPROVED] \n");
        sb.Append("           ,[AMC_WARRANTY] \n");
        sb.Append("           ,[WORKSTATION_NO] \n");
        sb.Append("           ,[COST_CENTER_NO] \n");
        sb.Append("           ,[COMPANY_NAME] \n");
        sb.Append("           ,[DEPARTMENT] \n");
        sb.Append("           ,[INVENTORY_NOTE] \n");
        sb.Append("           ,[ASSET_DESCRIPTION] \n");
        sb.Append("           ,[ASSET_MAIN_TEXT] \n");
        sb.Append("           ,[ASSET_DESCRIPTION_1] \n");
        sb.Append("           ,[ACCT_DE] \n");
        sb.Append("           ,[ROOM] \n");
        sb.Append("           ,[BA] \n");
        sb.Append("           ,[UPDATED_ON] \n");
        sb.Append("           ,[UPDATED_BY] \n");
        sb.Append("           ,[EX_FIELD1] \n");
        sb.Append("           ,[EX_FIELD2] \n");
        sb.Append("           ,[EX_FIELD3] \n");
        sb.Append("           ,[EX_FIELD4] \n");
        sb.Append("           ,[EX_FIELD5] \n");
        sb.Append("           ,[Status] \n");
        sb.Append("          , @ActionON \n");
        sb.Append("		  , @ActionBy \n");
        sb.Append("		   from ASSET_ACQUISITION \n");
        sb.Append("		   WHERE  ASSET_CODE in (" + AssetCode + ")");

        return sb.ToString();

    }

    private string GetCommaSeparatedAssetCategory(List<AssetDetails> AssetDetails)
    {
        string _CommaSeparated = " ' ' ";
        try
        {
            if (AssetDetails.Count > 0)
            {
                var _assetCode = AssetDetails.Select(p => p.AssetCode).ToArray();
                _CommaSeparated = string.Join("','", _assetCode);
                _CommaSeparated = "'" + _CommaSeparated + "'";
            }
        }
        catch (Exception)
        {
        }
        return _CommaSeparated;
    }


    #endregion

    #region Asset Clearance Receiving

    public int SaveReceivedClearance(List<AssetClearance> ClearanceRequest, AssetRequest request, List<UploadDocument> documents)
    {
        var _affectedRows = default(Int32);
        try
        {
            if (ClearanceRequest.FindAll(p => p.IsClearanced).Count > 0)
            {
                oDb.Connect(_DataBaseType);
                oDb.BeginTrans();
                foreach (var item in ClearanceRequest)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_ApprovedAssetRequest";

                    cmd.Parameters.AddWithValue("@Type", "CLEARANCE");

                    cmd.Parameters.AddWithValue("@Clearance_Code", item.ClearanceCode);

                    cmd.Parameters.AddWithValue("@ClearanceRemarks", item.Remarks);

                    cmd.Parameters.AddWithValue("@ActionON", item.ClearanceOn);
                    cmd.Parameters.AddWithValue("@ActionBY", item.ClearanceBy);

                    cmd.Parameters.AddWithValue("@STAGE", request.Stage);
                    cmd.Parameters.AddWithValue("@IS_CLEARANCE", request.IsClerance);
                    cmd.Parameters.AddWithValue("@LOCATION_CODE", request.LocationCode);
                    cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", request.RequestId);
                    var x = oDb.ExecuteQueryWithTransation(cmd);

                    if (x > 0)
                    {
                        _affectedRows = _affectedRows + x;
                    }

                }

                if (request.Stage == AssetRequestStage.ClearanceReceived || request.Stage == AssetRequestStage.ClearanceRecReject)
                {

                    var ClearanceOn = ClearanceRequest.FirstOrDefault().ClearanceOn;
                    var ClearanceBy = ClearanceRequest.FirstOrDefault().ClearanceBy;
                    var x = ClearancReceivedAction(request);
                    RejectRequest(request, ClearanceOn, ClearanceBy);

                    _affectedRows = x > 0 ? x : _affectedRows;

                }

                if (documents != null)
                {
                    SaveUploadData(request.RequestId, request.LocationCode, documents);
                    FinalUploadFile(documents, request.LocationCode);
                }


                oDb.CommitTrans();
            }

            return _affectedRows;
        }
        catch (Exception)
        {
            oDb.RollBack();
            throw;
        }
        finally
        {
            oDb.Disconnect();
        }
    }



    private int ClearancReceivedAction(AssetRequest request)
    {
        int _affectedRows = default(int);
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_ApprovedAssetRequest";
            cmd.Parameters.AddWithValue("@Type", "CLEARANCERECEIVED");
            cmd.Parameters.AddWithValue("@ActionON", request.ReceivedClearanceOn);
            cmd.Parameters.AddWithValue("@ActionBY", request.ReceivedClearanceBy);
            cmd.Parameters.AddWithValue("@STAGE", request.Stage);
            cmd.Parameters.AddWithValue("@IS_CLEARANCE", request.IsClerance);
            cmd.Parameters.AddWithValue("@LOCATION_CODE", request.LocationCode);
            cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", request.RequestId);
            _affectedRows = _affectedRows + oDb.ExecuteQueryWithTransation(cmd);
            return _affectedRows;
        }
        catch (Exception)
        {

            throw;
        }
    }




    #endregion

    private int RejectRequest(AssetRequest request, DateTime? ActionOn, string ActionBy)
    {
        int _affectedRecord = default(Int32);


        try
        {
            if (AssetRequestStage.PMReject == request.Stage || AssetRequestStage.CMFReject == request.Stage || AssetRequestStage.ClearanceReject == request.Stage || AssetRequestStage.ClearanceRecReject == request.Stage)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_ApprovedAssetRequest";
                cmd.Parameters.AddWithValue("@Type", "CANCELREQUEST");
                cmd.Parameters.AddWithValue("@ActionON", ActionOn);
                cmd.Parameters.AddWithValue("@ActionBY", ActionBy);
                cmd.Parameters.AddWithValue("@LOCATION_CODE", request.LocationCode);
                cmd.Parameters.AddWithValue("@REQUEST_HDR_ID", request.RequestId);
                _affectedRecord = oDb.ExecuteQueryWithTransation(cmd);
            }
            return _affectedRecord;
        }
        catch (Exception)
        {

            throw;
        }
    }

    #region GatePass


    public DataTable GetGatePassSlipForAsset(string RequestId, string LocationCode)
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.Parameters.AddWithValue("@Type", "GATEPASSSLIP");
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@RequestID", RequestId);
            cmd.Parameters.AddWithValue("@Stage", 1);
            DataTable tbl = oDb.GetDataTable(cmd);
            return tbl;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public DataTable GetGatePassSlipForDescription(string RequestId, string LocationCode)
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_GetAssetRequests";
            cmd.Parameters.AddWithValue("@Type", "GTRequestDesc");
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@RequestID", RequestId);
            cmd.Parameters.AddWithValue("@Stage", 1);
            DataTable tbl = oDb.GetDataTable(cmd);
            return tbl;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion

    public List<MovementConfig> GetMovementSetting()
    {
        try
        {
            List<MovementConfig> config = new List<MovementConfig>();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT RequestStage ,RequestOrder , IsActive from MovementRequestConfig ";
            SqlDataReader reader = oDb.GetRecord(cmd);
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    MovementConfig obj = new MovementConfig();
                    obj.RequestStage = reader["RequestStage"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestStage"]);
                    obj.RequestOrder = reader["RequestOrder"] == DBNull.Value ? default(int) : Convert.ToInt32(reader["RequestOrder"]);
                    obj.IsActive = reader["IsActive"] == DBNull.Value ? default(bool) : Convert.ToBoolean(reader["IsActive"]);
                    config.Add(obj);
                }
            }
            return config;
        }
        catch (Exception)
        {

            throw;
        }
    }



    #region ViewAssetRequest

    public List<AssetRequestDTO> GetViewAssetRequest(AssetSearchCriteria Criteria)
    {
        AssetRequestDTO _request = default(AssetRequestDTO);
        List<AssetRequestDTO> _requests = new List<AssetRequestDTO>();

        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_SearchMovementRequest";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LocationCode", Criteria.LocationCode);
            cmd.Parameters.AddWithValue("@ReqStatus", Criteria.RequestStage);
            cmd.Parameters.AddWithValue("@RequestNo", Criteria.RequestId);
            //cmd.Parameters.AddWithValue("@DocType", Criteria.DocumentType);
            cmd.Parameters.AddWithValue("@ReqFromDate", Criteria.RequestFrom);
            cmd.Parameters.AddWithValue("@ReqToDate", Criteria.RequestTo);
            cmd.Parameters.AddWithValue("@AssetNo", Criteria.AssetCode);

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);

            while (reader.Read())
            {
                _request = new AssetRequestDTO();

                _request.LocationCode = reader["LOCATION_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_CODE"]);
                _request.RequestId = reader["REQUEST_HDR_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REQUEST_HDR_ID"]);
                _request.IsPermanent = reader["IS_PERMANENT"] == DBNull.Value ? "NO" : Convert.ToBoolean(reader["IS_PERMANENT"]) == true ? "YES" : "NO";
                _request.TransferTo = reader["TRANSFER_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["TRANSFER_TO"]);
                _request.IsInterUnit = reader["IS_INTERUNIT"] == DBNull.Value ? "NO" : Convert.ToBoolean(reader["IS_INTERUNIT"]) == true ? "YES" : "NO";
                _request.LocationTo = reader["LOCATION_TO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION_TO"]);
                _request.ProjectCode = reader["PROJECT_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_CODE"]);
                _request.ReceiverEmail = reader["RECEIVER_EMAIL"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVER_EMAIL"]);
                _request.GstNo = reader["GST_NO"] == DBNull.Value ? string.Empty : Convert.ToString(reader["GST_NO"]);
                _request.ProjectCostCentre = reader["PROJECT_COST_CENTRE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PROJECT_COST_CENTRE"]);
                _request.PMApprove = reader["PM_APPROVE"] == DBNull.Value ? "NO" : Convert.ToBoolean(reader["PM_APPROVE"]) == true ? "YES" : "NO";
                _request.PMRemark = reader["PM_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_REMARKS"]);
                _request.CMFApprove = reader["CMF_APPROVE"] == DBNull.Value ? "NO" : Convert.ToBoolean(reader["CMF_APPROVE"]) == true ? "YES" : "NO";
                _request.CMFRemark = reader["CMF_REMARKS"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_REMARKS"]);
                _request.IsClerance = reader["IS_CLEARANCE"] == DBNull.Value ? "NO" : Convert.ToBoolean(reader["IS_CLEARANCE"]) == true ? "YES" : "NO";
                _request.Stage = reader["STAGE"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["STAGE"]);
                _request.CreatedOn = reader["CREATED_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_ON"]);

                _request.CreatedBY = reader["CREATED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CREATED_BY"]);
                _request.PMApprovedOn = reader["PM_APPROVED_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_ON"]);

                _request.PMApprovedBy = reader["PM_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["PM_APPROVED_BY"]);

                _request.CMFApprovedOn = reader["CMF_APPROVED_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_ON"]);
                _request.CMFApprovedBy = reader["CMF_APPROVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CMF_APPROVED_BY"]);
                _request.ClearanceOn = reader["CLEARANCE_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_ON"]);
                _request.ClearanceBy = reader["CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CLEARANCE_BY"]);
                _request.ReceivedOn = reader["RECEIVED_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_ON"]);
                _request.ReceivedBy = reader["RECEIVED_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RECEIVED_BY"]);

                _request.ReceivedClearanceOn = reader["REC_CLEARANCE_ON"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REC_CLEARANCE_ON"]);
                _request.ReceivedClearanceBy = reader["REC_CLEARANCE_BY"] == DBNull.Value ? string.Empty : Convert.ToString(reader["REC_CLEARANCE_BY"]);


                _request.AssetDetailId = reader["REQUEST_DTL_ID"] == DBNull.Value ? 0 : Convert.ToInt32(reader["REQUEST_DTL_ID"]);
                _request.AssetCode = reader["ASSET_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_CODE"]);
                //_request.FamsID = reader["ASSET_ID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_ID"]);

                _request.RequestToLocationName = reader["RequestToLocationName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestToLocationName"]);
                _request.RequestedLocationName = reader["RequestedLocationName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestedLocationName"]);

                //RequestedLocationName
                //RequestToLocationName
                _requests.Add(_request);

                // _request.Documents.Add(this.GetAssetUploadDocument(reader));

            }
            //_request.Documents = GetUploadedDocument(Criteria);

            return _requests;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            oDb.Disconnect();
        }
    }

    public List<ViewAssetLocation> GetViewAssetLocation(AssetSearchCriteria Criteria)
    {
        ViewAssetLocation _request = default(ViewAssetLocation);
        List<ViewAssetLocation> _requests = new List<ViewAssetLocation>();
        try
        {
            oDb.Connect(_DataBaseType);
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandText = "USP_SearchAsset";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AssetCode", Criteria.AssetCode);

            System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);

            while (reader.Read())
            {
                _request = new ViewAssetLocation();

                _request.AssetCode = reader["ASSET_CODE"] == DBNull.Value ? string.Empty : Convert.ToString(reader["ASSET_CODE"]);
                _request.RequestId = reader["RequestID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["RequestID"]);
                _request.Location = reader["LOCATION"] == DBNull.Value ? string.Empty : Convert.ToString(reader["LOCATION"]);
                _request.Stage = reader["RequestStage"] == DBNull.Value ? AssetRequestStage.None : (AssetRequestStage)(reader["RequestStage"]);
                _requests.Add(_request);
            }
            return _requests;
        }
        catch (Exception)
        {

            throw;
        }

    }





    #endregion



    #region  Movement Report
    public DataTable GetSummaryReport(DateTime? RequestFrom, DateTime? RequestTo, string LocationCode, string UserId, int ReportType , string FromLocation , string ToLocation)
    {
        DataTable tbl = new DataTable();
        try
        {
            switch (ReportType)
            {
                case 0:
                    tbl = GetMovementCategoryReport(RequestFrom, RequestTo, LocationCode, UserId);
                    break;
                case 1:
                    tbl = GetMonthlyReport(RequestFrom, RequestTo, LocationCode, UserId , FromLocation , ToLocation);
                    break;
                case 2:
                    tbl = GetRequestStatusReport(RequestFrom, RequestTo, LocationCode, UserId, FromLocation, ToLocation);
                    break;
            }
            return tbl;
        }
        catch (Exception)
        {

            throw;
        }
    }

    private DataTable GetMovementCategoryReport(DateTime? RequestFrom, DateTime? RequestTo, string LocationCode, string UserId)
    {

        DataTable tbl = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_GetSummaryReportUnAuthrizeMovement";
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@UserId", UserId);
            cmd.Parameters.AddWithValue("@FromDate", RequestFrom);
            cmd.Parameters.AddWithValue("@ToDate", RequestTo);
            tbl = oDb.GetDataTable(cmd);
            return tbl;
        }
        catch (Exception)
        {

            throw;
        }
    }


    private DataTable GetRequestStatusReport(DateTime? RequestFrom, DateTime? RequestTo, string LocationCode, string UserId , string FromLocation , string ToLocation)
    {
        DataTable tbl = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_MovementOpenCloseReport";
            cmd.Parameters.AddWithValue("@LOcationCode", LocationCode);
            cmd.Parameters.AddWithValue("@UserId", UserId);
            cmd.Parameters.AddWithValue("@FromDate", RequestFrom);
            cmd.Parameters.AddWithValue("@ToDate", RequestTo);

            cmd.Parameters.AddWithValue("@FromLocation", FromLocation);
            cmd.Parameters.AddWithValue("@ToLocation", ToLocation);

            tbl = oDb.GetDataTable(cmd);
            return tbl;
        }
        catch (Exception)
        {

            throw;
        }
    }

    private DataTable GetMonthlyReport(DateTime? RequestFrom, DateTime? RequestTo, string LocationCode, string UserId , string FromLocation , string ToLocation)
    {
        DataTable tbl = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "USP_UnAuthrizeWeeklyReport";
            cmd.Parameters.AddWithValue("@LocationCode", LocationCode);
            cmd.Parameters.AddWithValue("@UserId", UserId);
            cmd.Parameters.AddWithValue("@FromDate", RequestFrom);
            cmd.Parameters.AddWithValue("@ToDate", RequestTo);
            cmd.Parameters.AddWithValue("@FromLocation", FromLocation);
            cmd.Parameters.AddWithValue("@ToLocation", ToLocation);

            tbl = oDb.GetDataTable(cmd);

            return tbl;
        }
        catch (Exception)
        {

            throw;
        }
    }


    #endregion

    #region Common Date Function

    public static int GetMonth(string month)
    {
        Dictionary<string, int> dictmonth = new Dictionary<string, int>();
        dictmonth.Add("JAN", 1);
        dictmonth.Add("FEB", 2);
        dictmonth.Add("MAR", 3);
        dictmonth.Add("APR", 4);
        dictmonth.Add("MAY", 5);
        dictmonth.Add("JUN", 6);
        dictmonth.Add("JUL", 7);
        dictmonth.Add("AUG", 8);
        dictmonth.Add("SEP", 9);
        dictmonth.Add("OCT", 10);
        dictmonth.Add("NOV", 11);
        dictmonth.Add("DEC", 12);

        if (dictmonth.ContainsKey(month.ToUpper()))
        {
            return dictmonth.FirstOrDefault(p => p.Key == month.ToUpper()).Value;
        }
        return 0;

    }


    #endregion




}


