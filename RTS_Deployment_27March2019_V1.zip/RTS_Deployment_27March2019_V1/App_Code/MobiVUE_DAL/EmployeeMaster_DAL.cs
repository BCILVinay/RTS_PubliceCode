﻿//************************************************************************************************************************************************
//  Data Access Layer Class For Add/Edit/Update/Delete Employee Master Details
//  Created By : Neeraj Saxena
//  Created On : April 27, 2012
//  Modified By : Neeraj Saxena 
//  Modified On : Sept 11, 2012
//************************************************************************************************************************************************
using System;
using System.Data;
using System.Text;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for EmployeeMaster_DAL
    /// </summary>
    public class EmployeeMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public EmployeeMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~EmployeeMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Save/Update Employee Master
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns>bResult</returns>
        //public bool SaveUpdateEmployee(string OpType, EmployeeMaster_PRP oPRP)
        //{
        //    try
        //    {
        //        bool bResult = false;
        //        if (OpType == "SAVE")
        //        {
        //            if (!CheckDuplicateEmployee(oPRP.EmpCode,oPRP.LocCode))
        //            {
        //                //Add new Employee...
        //                sbQuery = new StringBuilder();
        //                sbQuery.Append("INSERT INTO [EMPLOYEE_MASTER] ([EMPLOYEE_CODE],[EMPLOYEE_NAME],[EMP_COMP_CODE],[EMP_PROCESS_CODE],[EMP_REPORTING_TO]");
        //                sbQuery.Append(",[EMP_EMAIL],[EMP_DOJ],[EMP_PHONE],[ACTIVE],[REMARKS],[COMP_CODE],[CREATED_BY],[CREATED_ON])");
        //                sbQuery.Append("VALUES ('" + oPRP.EmpCode + "','" + oPRP.EmpName + "','" + oPRP.EmpLocCode + "','" + oPRP.EmpProjCode + "','" + oPRP.EmpReprotTo + "','" + oPRP.EmpEmail + "'");
        //                sbQuery.Append(",'" + oPRP.EmpDOJ + "','" + oPRP.EmpPhone + "','" + oPRP.Active + "','" + oPRP.EmpRemarks + "','" + oPRP.LocCode + "','" + oPRP.CreatedBy + "',GETDATE())");
        //                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //                if (iRes > 0)
        //                    bResult = true;
        //            }
        //        }
        //        else if (OpType == "UPDATE")
        //        {
        //            //Update Employee Information...
        //            sbQuery = new StringBuilder();
        //            sbQuery.Append("UPDATE [EMPLOYEE_MASTER] SET [EMPLOYEE_NAME]='" + oPRP.EmpName + "',[EMP_COMP_CODE]='" + oPRP.EmpLocCode + "'");
        //            sbQuery.Append(",[EMP_PROCESS_CODE]='" + oPRP.EmpProjCode + "',[EMP_REPORTING_TO]='" + oPRP.EmpReprotTo + "',[EMP_EMAIL]='" + oPRP.EmpEmail + "'");
        //            sbQuery.Append(",[EMP_PHONE]='" + oPRP.EmpPhone + "',[ACTIVE] = '" + oPRP.Active + "',[REMARKS] = '" + oPRP.EmpRemarks + "',[MODIFIED_BY]='" + oPRP.ModifiedBy + "',[MODIFIED_ON]=GETDATE()");
        //            sbQuery.Append(" WHERE [EMPLOYEE_CODE]='" + oPRP.EmpCode + "' AND [COMP_CODE]='" + oPRP.LocCode + "'");
        //            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //            if (iRes > 0)
        //                bResult = true;
        //        }
        //        return bResult;
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //}

        public bool SaveEmployee(EmployeeMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicateEmployee(oPRP.EmpCode, oPRP.LocCode))
                {
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='SAVEEMPLOYEE', @Comp_Code ='"+oPRP.CompCode+"' ,  @EMP_CODE='" + oPRP.EmpCode.Trim().Replace("'", "''") + "',@EMP_NAME='" + oPRP.EmpName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @PROJECT_CODE='" + oPRP.EmpProjCode.Trim().Replace("'", "''") + "', @REPORTING_MNGR='" + oPRP.EmpReprotTo.Trim().Replace("'", "''") + "',@EMP_LOC_CODE='" + oPRP.EmpLocCode + "',");
                    sbQuery.Append(" @DEPT_CODE='" + oPRP.EmpDOL.Trim().Replace("'", "''") + "', @EMP_EMAIL='" + oPRP.EmpEmail.Trim().Replace("'", "''") + "',@EMP_PHONE='" + oPRP.EmpPhone.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @EMP_DOJ='" + oPRP.EmpDOJ + "', @STORAGE_LOC_CODE='" + oPRP.LocCode + "', @REMARKS='" + oPRP.EmpRemarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");                  
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateEmployee(EmployeeMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='UPDATEEMPLOYEE',@EMP_CODE='" + oPRP.EmpCode.Trim().Replace("'", "''") + "',@EMP_NAME='" + oPRP.EmpName.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @PROJECT_CODE='" + oPRP.EmpProjCode.Trim().Replace("'", "''") + "', @REPORTING_MNGR='" + oPRP.EmpReprotTo.Trim().Replace("'", "''") + "',@EMP_LOC_CODE='" + oPRP.EmpLocCode + "',");
                sbQuery.Append(" @DEPT_CODE='" + oPRP.EmpDOL.Trim().Replace("'", "''") + "', @EMP_EMAIL='" + oPRP.EmpEmail.Trim().Replace("'", "''") + "',@EMP_PHONE='" + oPRP.EmpPhone.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @EMP_DOJ='" + oPRP.EmpDOJ + "', @STORAGE_LOC_CODE='" + oPRP.LocCode + "', @REMARKS='" + oPRP.EmpRemarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "'"); 
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Upload employee details from excel file.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public void UploadEmployeeDetails(EmployeeMaster_PRP oPRP)
        {
            try
            {
                //sbQuery = new StringBuilder();
                //sbQuery.Append("INSERT INTO [EMPLOYEE_MASTER] ([EMPLOYEE_CODE],[EMPLOYEE_NAME],[EMP_COMP_CODE],[EMP_PROCESS_CODE],[EMP_REPORTING_TO]");
                //sbQuery.Append(",[EMP_EMAIL],[EMP_DOJ],[EMP_PHONE],[ACTIVE],[REMARKS],[COMP_CODE],[CREATED_BY],[CREATED_ON])");
                //sbQuery.Append("VALUES ('" + oPRP.EmpCode + "','" + oPRP.EmpName + "','" + oPRP.EmpLocCode + "','" + oPRP.EmpProjCode + "','" + oPRP.EmpReprotTo + "','" + oPRP.EmpEmail + "'");
                //sbQuery.Append(",'" + oPRP.EmpDOJ + "','" + oPRP.EmpPhone + "','" + oPRP.Active + "','" + oPRP.EmpRemarks + "','" + oPRP.LocCode + "','" + oPRP.CreatedBy + "',GETDATE())");
                //oDb.ExecuteQuery(sbQuery.ToString());
                
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='UPLOADEMPLOYEEDETAILS', @Comp_Code ='"+oPRP.CompCode+"' , @EMP_CODE='" + oPRP.EmpCode.Trim().Replace("'", "''") + "',@EMP_NAME='" + oPRP.EmpName.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @PROJECT_CODE='" + oPRP.EmpProjCode.Trim().Replace("'", "''") + "', @REPORTING_MNGR='" + oPRP.EmpReprotTo.Trim().Replace("'", "''") + "',@EMP_LOC_CODE='" + oPRP.EmpLocCode + "',");
                    sbQuery.Append(" @EMP_EMAIL='" + oPRP.EmpEmail.Trim().Replace("'", "''") + "',@EMP_PHONE='" + oPRP.EmpPhone.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @EMP_DOJ='" + oPRP.EmpDOJ + "', @STORAGE_LOC_CODE='" + oPRP.LocCode + "', @REMARKS='" + oPRP.EmpRemarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");
                    oDb.ExecuteQuery(sbQuery.ToString());
               
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Checks Duplicate Employee Code
        /// </summary>
        /// <param name="_EmpCode"></param>
        /// <returns>bDup</returns>
        public bool CheckDuplicateEmployee(string _EmpCode, string _LocCode)
        {
            bool bDup = false;
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='CHECKDUPLICATEEMPLOYEE', @EMP_CODE='" + _EmpCode + "', @STORAGE_LOC_CODE='" + _LocCode + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows.Count > 0)
                bDup = true;
            return bDup;
        }

        /// <summary>
        /// Checks Duplicate Email ID on update. 
        /// </summary>
        /// <param name="_EmpCode"></param>
        /// <returns>bDup</returns>
        public bool CheckDuplicateEmailID(string EmailID, string EmpCode, string LocCode)
        {
            bool bDup = false;
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='CHECKDUPLICATEEMAILID',@EMP_EMAIL='" + EmailID + "', @EMP_CODE='" + EmpCode + "', @STORAGE_LOC_CODE='" + LocCode + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows.Count > 0)
                bDup = true;
            return bDup;
        }

        /// <summary>
        /// Fetches Company Details For DropDownList Population
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetCompany()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='GETCOMPANY'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches Department Details For DropDownList Population
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetProject(string LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='GETPROJECT',@STORAGE_LOC_CODE='" + LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches Empoyee Details For DropDownList (Reporting To) Population
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetEmpoyee(string LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='GETRMEMPLOYEE',@STORAGE_LOC_CODE='" + LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches Empoyee Records For GridView Population
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetEmpoyeeDetails(string _LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='GETEMPLOYEEDETAILS',@STORAGE_LOC_CODE='" + _LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Delete An Employee From Employee Master.
        /// </summary>
        /// <param name="_EmpCode"></param>
        /// <returns>bResult</returns>
    //    public string DeleteEmployee(string _EmpCode, string _LocCode)
    //    {
    //        try
    //        {
    //            string DelRslt = "";
    //            sbQuery = new StringBuilder();
    //            sbQuery.Append("SELECT COUNT(*) AS CNTEMP FROM EMPLOYEE_MASTER");
    //            sbQuery.Append(" WHERE EMP_REPORTING_TO='" + _EmpCode.Trim() + "'");
    //            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
    //            if (dt.Rows.Count > 0)
    //            {
    //                int iChild = 0;
    //                int.TryParse(dt.Rows[0]["CNTEMP"].ToString(), out iChild);
    //                if (iChild > 0)
    //                {
    //                    DelRslt = "CHILD_FOUND";
    //                    return DelRslt;
    //                }
    //            }
    //            sbQuery = new StringBuilder();
    //            sbQuery.Append("SELECT COUNT(*) AS EMPALLOC FROM ASSET_ALLOCATION AL INNER JOIN ASSET_ACQUISITION AA");
    //            sbQuery.Append(" ON AL.ASSET_CODE = AA.ASSET_CODE WHERE AL.ALLOCATED_EMP_ID='" + _EmpCode + "' AND AA.ASSET_ALLOCATED='1'");
    //            sbQuery.Append(" AND AL.ACTUAL_RTN_DATE IS NULL AND AL.COMP_CODE='" + _LocCode + "'");
    //            DataTable dtALL = oDb.GetDataTable(sbQuery.ToString());
    //            if (dt.Rows.Count > 0)
    //            {
    //                int iAll = 0;
    //                int.TryParse(dtALL.Rows[0]["EMPALLOC"].ToString(), out iAll);
    //                if (iAll > 0)
    //                {
    //                    DelRslt = "ASSET_ALLOCATED";
    //                    return DelRslt;
    //                }
    //            }
    //            sbQuery = new StringBuilder();
    //            sbQuery.Append("DELETE FROM EMPLOYEE_MASTER WHERE EMPLOYEE_CODE = '" + _EmpCode + "' AND COMP_CODE='" + _LocCode + "'");
    //            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
    //            if (iRes > 0)
    //                DelRslt = "SUCCESS";
    //            return DelRslt;
    //        }
    //        catch (Exception ex)
    //        { throw ex; }
    //    }

        public bool DeleteEmployee(string _EmpCode, string _LocCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_EmployeeMaster @TYPE='DELETEEMPLOYEE', @EMP_CODE='" + _EmpCode + "',@STORAGE_LOC_CODE='" + _LocCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}