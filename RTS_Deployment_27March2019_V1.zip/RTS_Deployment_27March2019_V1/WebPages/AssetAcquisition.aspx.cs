﻿using System;
using System.IO;
using System.Web;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Net.Mail;
using System.Configuration;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class AssetAcquisition : System.Web.UI.Page
{
    private bool IsViewRight { get; set; }
    private bool IsSaveRight { get; set; }
    private bool IsEditRight { get; set; }
    private bool IsDeleteRight { get; set; }
    private bool IsExportRight { get; set; }

    string _CompCode = "";
    string _StorageLocCode = "";
    string strDupFilePath = @"C:\ATS\";
    AssetAcquisition_DAL oDAL;
    AssetAcquisition_PRP oPRP;
    public AssetAcquisition()
    {
        oPRP = new AssetAcquisition_PRP();
    }
    ~AssetAcquisition()
    {
        oPRP = null; oDAL = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new AssetAcquisition_DAL(Session["DATABASE"].ToString());
        _CompCode = Session["COMPANY"].ToString();
        _StorageLocCode = Session["COMPLOCATION"].ToString();
    }

    /// <summary>
    /// Check user rights for asset acquisition save/update operation.
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            ViewState["ASSET_CODE"] = "";
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("ASSET_ACQUISITION", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');

                this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
                this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
                this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
                this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
                this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ACQUISITION");
                if (!this.IsViewRight)
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                    return;
                }
                ddlCompany.SelectedValue = Session["COMPANY"].ToString();
                clsGeneral.OpType = "SAVE";
                ddlAssetType.SelectedValue = clsGeneral.gStrAssetType;
                lblAssetType.Text = clsGeneral.gStrAssetType;
                PopulateCategory(lblAssetType.Text);
                if (clsGeneral.gStrAssetType == "IT")
                    CollapsiblePanelExtender1.Collapsed = false;
                else
                    CollapsiblePanelExtender1.Collapsed = true;
                PopulateLocation();
                PopulateDepartment();
                PopulateCompany();
                PopulateVendor();

                PopulatePlant();
                PopulateCurrency();
                PopulateBondedType();
                PopulateProject();

                string strPRN = oDAL.GetPRNFile();
                HiddenField1.Value = strPRN;
                ddlAssetType.Attributes.Add("onChange", "onselectionChange();");
                //chkPrintBarcode.Attributes.Add("onClick", "OpenActiveX();");
                if (!Directory.Exists(strDupFilePath))
                {
                    Directory.CreateDirectory(strDupFilePath);
                }
                if (Request.QueryString["AssetCode"] != null)
                {
                    clsGeneral.OpType = "UPDATE";
                    PopulateProcess();
                    string AssetCode = Request.QueryString["AssetCode"].ToString();
                    PopulateAssetDetails(AssetCode);
                    ddlAssetCategory.Enabled = false;
                    btnRefreshCategory.Enabled = false;
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Populate company code/name.
    /// </summary>
    //private void PopulateCompany()
    //{
    //    ddlCompany.DataSource = null;
    //    DataTable dt = new DataTable();
    //    dt = oDAL.PopulateCompany(Session["COMPANY"].ToString());
    //    ddlCompany.DataSource = dt;
    //    ddlCompany.DataTextField = "COMP_NAME";
    //    ddlCompany.DataValueField = "COMP_CODE";
    //    ddlCompany.DataBind();
    //    ddlCompany.Items.Insert(0, "-- Select Company --");
    //}

    private void PopulateCompany()
    {
        ddlCompany.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCompany(Session["COMPANY"].ToString());
        ddlCompany.DataSource = dt;
        ddlCompany.DataTextField = "COMP_NAME";
        ddlCompany.DataValueField = "COMP_CODE";
        ddlCompany.DataBind();
        ddlCompany.Items.Insert(0, "-- Select Company --");
    }

    /// <summary>
    /// Populate department code/name.
    /// </summary>
    private void PopulateDepartment()
    {
        ddlDepartment.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateDepartment(Session["COMPANY"].ToString());
        ddlDepartment.DataSource = dt;
        ddlDepartment.DataTextField = "DEPT_NAME";
        ddlDepartment.DataValueField = "DEPT_CODE";
        ddlDepartment.DataBind();
        ddlDepartment.Items.Insert(0, "-- Select Department --");
    }

    /// <summary>
    /// Populate process code/name.
    /// </summary>
    private void PopulateProcess()
    {
        //ddlProcessName.DataSource = null;
        //DataTable dt = new DataTable();
        //dt = oDAL.PopulateProcess(Session["COMPLOCATION"].ToString());
        //ddlProcessName.DataSource = dt;
        //ddlProcessName.DataTextField = "PROCESS_NAME";
        //ddlProcessName.DataValueField = "PROCESS_CODE";
        //ddlProcessName.DataBind();
        //ddlProcessName.Items.Insert(0, "-- Select Process --");
    }

    /// <summary>
    /// Populate process code/name as the department name selected.
    /// </summary>
    private void PopulateProcess(string DeptCode)
    {
        //ddlProcessName.DataSource = null;
        //DataTable dt = new DataTable();
        //dt = oDAL.PopulateProcess(DeptCode, Session["COMPANY"].ToString());
        //ddlProcessName.DataSource = dt;
        //ddlProcessName.DataTextField = "PROCESS_NAME";
        //ddlProcessName.DataValueField = "PROCESS_CODE";
        //ddlProcessName.DataBind();
        //ddlProcessName.Items.Insert(0, "-- Select Process --");
    }

    /// <summary>
    /// Cathes exception for the entier page operations.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Acquisition");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx", false);
        }
    }

    /// <summary>
    /// Fetch vendor details to be populated in dropdownlist.
    /// </summary>
    private void PopulateVendor()
    {
        ddlVendor.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateVendor(_CompCode);
        ddlVendor.DataSource = dt;
        ddlVendor.DataTextField = "VENDOR_NAME";
        ddlVendor.DataValueField = "VENDOR_CODE";
        ddlVendor.DataBind();
        ddlVendor.Items.Insert(0, "-- Select Vendor --");
    }

    /// <summary>
    /// Fetch category details to be populated in dropdownlist.
    /// </summary>
    private void PopulateCategory(string AssetType)
    {
        lblCatCode.Text = "0";
        lblCatLevel.Text = "1";
        ddlAssetCategory.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCategory(AssetType.Trim(), "", 1);
        ddlAssetCategory.DataSource = dt;
        ddlAssetCategory.DataTextField = "CATEGORY_NAME";
        ddlAssetCategory.DataValueField = "CATEGORY_CODE";
        ddlAssetCategory.DataBind();
        ddlAssetCategory.Items.Insert(0, "-- Select Category --");
    }

    /// <summary>
    /// Fetch location details to be populated in dropdownlist.
    /// </summary>
    private void PopulateLocation()
    {
        lblLocCode.Text = "0";
        lblLocLevel.Text = "1";
        ddlAssetLocation.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetLocation(_StorageLocCode, "", 1);
        ddlAssetLocation.DataSource = dt;
        ddlAssetLocation.DataTextField = "LOC_NAME";
        ddlAssetLocation.DataValueField = "LOC_CODE";
        ddlAssetLocation.DataBind();
        ddlAssetLocation.Items.Insert(0, "-- Select Location --");
    }

    private void PopulatePlant()
    {
        ddlPlant.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulatePlant();
        ddlPlant.DataSource = dt;
        ddlPlant.DataTextField = "PLANT_NAME";
        ddlPlant.DataValueField = "PLANT_CODE";
        ddlPlant.DataBind();
        ddlPlant.Items.Insert(0, "-- Select Plant --");
    }

    private void PopulateCurrency()
    {
        ddlCurrency.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCurrencyType();
        ddlCurrency.DataSource = dt;
        ddlCurrency.DataTextField = "CODE";
        ddlCurrency.DataValueField = "CODE";
        ddlCurrency.DataBind();
        ddlCurrency.Items.Insert(0, "-- Select Currency --");
    }

    private void PopulateBondedType()
    {
        ddlBondedType.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateBondedType();
        ddlBondedType.DataSource = dt;
        ddlBondedType.DataTextField = "CODE";
        ddlBondedType.DataValueField = "CODE";
        ddlBondedType.DataBind();
        ddlBondedType.Items.Insert(0, "-- Select Bond Type --");
    }

    private void PopulateProject()
    {
        ddlProjectCode.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateProject(_StorageLocCode);
        ddlProjectCode.DataSource = dt;
        ddlProjectCode.DataTextField = "PROJECT_NAME";
        ddlProjectCode.DataValueField = "PROJECT_CODE";
        ddlProjectCode.DataBind();
        ddlProjectCode.Items.Insert(0, "-- Select Project --");
    }

    private void PopulateSubProject(string _ProjectName)
    {
        ddlSubProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateSubProject(_ProjectName, _StorageLocCode);
        ddlSubProject.DataSource = dt;
        ddlSubProject.DataTextField = "SUB_PROJECT_NAME";
        ddlSubProject.DataValueField = "SUB_PROJECT_CODE";
        ddlSubProject.DataBind();
        ddlSubProject.Items.Insert(0, "-- Select Sub Project --");
    }

    private void PopulateProjectManager(string _SubProjectName)
    {
        txtProjectMngr.Text = "";
        DataTable dt = new DataTable();
        dt = oDAL.GetProjectManager(_SubProjectName, _StorageLocCode);
        if (dt.Rows.Count > 0)
        {
            txtProjectMngr.Text = dt.Rows[0][0].ToString();
            txtProjectMngr.Enabled = false;
        }
    }


    /// <summary>
    /// Populate asset acquisition fields for update operation.
    /// </summary>
    /// <param name="AssetCode"></param>
    private void PopulateAssetDetails(string AssetCode)
    {
        if (Session["GROUP"].ToString() == "SYSADMIN")
        {
            txtSerialCode.Enabled = true;
            txtAssetId.Enabled = true;
        }
        else
        {
            txtSerialCode.Enabled = false;
            txtAssetId.Enabled = false;
        }
        //ddlAssetCategory.Enabled = false;
        //btnRefreshCategory.Enabled = false;
        oPRP.AssetCode = AssetCode;
        txtAssetCode.Text = oPRP.AssetCode;
        DataTable dt = oDAL.GetAssetDetailsForUpdate(oPRP.AssetCode);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["ASSET_TYPE"].ToString() == "ADMIN")
            {
                CollapsiblePanelExtender1.Collapsed = true;
                CollapsiblePanelExtender1.ClientState = "true";
                ddlAssetType.SelectedValue = "AD";
                lblAssetType.Text = "ADMIN";
                PopulateCategory("ADMIN");
            }
            else if (dt.Rows[0]["ASSET_TYPE"].ToString() == "IT")
            {
                CollapsiblePanelExtender1.Collapsed = false;
                CollapsiblePanelExtender1.ClientState = "false";
                ddlAssetType.SelectedValue = "IT";
                lblAssetType.Text = "IT";
                PopulateCategory("IT");

                var CategoryName = dt.Rows[0]["CATEGORY_CODE"].ToString().Trim();
                ddlAssetCategory.SelectedValue = CategoryName;
                lblCatCode.Text = CategoryName;
                ddlAssetCategory.Items.Insert(0, dt.Rows[0]["CATEGORY_NAME"].ToString().Trim());
                txtSecurityClass.Text = dt.Rows[0]["SECURITY_CLASSIFICATION"].ToString().Trim();
                txtSize.Text = dt.Rows[0]["ASSET_SIZE"].ToString().Trim();
                txtVlan.Text = dt.Rows[0]["ASSET_VLAN"].ToString().Trim();
                txtHDD.Text = dt.Rows[0]["ASSET_HDD"].ToString().Trim();
                txtProcessor.Text = dt.Rows[0]["ASSET_PROCESSOR"].ToString().Trim();
                txtRAM.Text = dt.Rows[0]["ASSET_RAM"].ToString().Trim();
                txtIMEINo.Text = dt.Rows[0]["ASSET_IMEI_NO"].ToString().Trim();
                txtMemory.Text = dt.Rows[0]["ASSET_PHONE_MEMORY"].ToString().Trim();
                txtServProvider.Text = dt.Rows[0]["ASSET_SERVICE_PROVIDER"].ToString().Trim();
            }
            txtAssetId.Text = dt.Rows[0]["ASSET_ID"].ToString().Trim();
            txtSerialCode.Text = dt.Rows[0]["SERIAL_CODE"].ToString().Trim();
            txtAssetMake.Text = dt.Rows[0]["ASSET_MAKE"].ToString().Trim();
            txtAssetModel.Text = dt.Rows[0]["MODEL_NAME"].ToString().Trim();
            lblCatCode.Text = dt.Rows[0]["CATEGORY_CODE"].ToString().Trim();
            txtInvoiceNo.Text = dt.Rows[0]["INVOICE_NO"].ToString().Trim();
            lblLocCode.Text = dt.Rows[0]["ASSET_LOCATION"].ToString().Trim();
            //ddlProjectCode.SelectedValue = dt.Rows[0]["PROJECT_NAME"].ToString().Trim();
            //ddlSubProject.SelectedValue = dt.Rows[0]["SUB_PROJECT_NAME"].ToString().Trim();
            txtProjectMngr.Text = dt.Rows[0]["PROJECT_MANAGER"].ToString().Trim();
            txtProAssignEmp.Text = dt.Rows[0]["ASSIGN_PRO_TO_EMP"].ToString().Trim();

            if (dt.Rows[0]["INSTALLED_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["INSTALLED_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtInstallDate.Text = Convert.ToDateTime(dt.Rows[0]["INSTALLED_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtInstallDate.Text = "";

            if (dt.Rows[0]["PO_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["PO_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtPODate.Text = Convert.ToDateTime(dt.Rows[0]["PO_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtPODate.Text = "";

            if (Convert.ToDateTime(dt.Rows[0]["PURCHASED_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                txtPurchasedDate.Text = Convert.ToDateTime(dt.Rows[0]["PURCHASED_DATE"].ToString()).ToString("dd/MMM/yyyy");
            else
                txtPurchasedDate.Text = "";

            txtPONo.Text = dt.Rows[0]["PO_NUMBER"].ToString().Trim();
            ddlVendor.SelectedValue = dt.Rows[0]["VENDOR_CODE"].ToString().Trim();
            txtPurchaseValue.Text = dt.Rows[0]["PURCHASED_AMT"].ToString().Trim();
            ddlCurrency.SelectedValue = dt.Rows[0]["CURRENCY"].ToString().Trim();
            txtTransferPrice.Text = dt.Rows[0]["TRANSFER_PRICE"].ToString().Trim();
            txtLocalCurrency.Text = dt.Rows[0]["LOCAL_CURRENCY"].ToString().Trim();
            txtSaleValue.Text = dt.Rows[0]["SALE_AMT"].ToString().Trim();

            if (dt.Rows[0]["SALE_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["SALE_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtSaleDate.Text = Convert.ToDateTime(dt.Rows[0]["SALE_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtSaleDate.Text = "";

            txtBOE.Text = dt.Rows[0]["ASSET_BOE"].ToString().Trim();
            txtRegisterNo.Text = dt.Rows[0]["ASSET_REGISTER_NO"].ToString().Trim();
            txtWorkStationNo.Text = dt.Rows[0]["WORKSTATION_NO"].ToString().Trim();
            ddlAMCWarranty.SelectedValue = dt.Rows[0]["AMC_WARRANTY"].ToString().Trim();

            if (dt.Rows[0]["AMC_WARRANTY_START_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["AMC_WARRANTY_START_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtAMCWrntyStartDate.Text = Convert.ToDateTime(dt.Rows[0]["AMC_WARRANTY_START_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtAMCWrntyStartDate.Text = "";

            if (dt.Rows[0]["AMC_WARRANTY_START_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["AMC_WARRANTY_START_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtAMCWrntyEndDate.Text = Convert.ToDateTime(dt.Rows[0]["AMC_WARRANTY_END_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtAMCWrntyEndDate.Text = "";

            if (ddlAMCWarranty.SelectedValue == "WARRANTY" || ddlAMCWarranty.SelectedValue == "AMC")
            {
                txtAMCWrntyStartDate.Enabled = true;
                txtAMCWrntyEndDate.Enabled = true;
            }

            txtPortNo.Text = dt.Rows[0]["PORT_NO"].ToString().Trim();
            txtSecGENo.Text = dt.Rows[0]["SECURITY_GATE_ENTRY_NO"].ToString().Trim();

            if (dt.Rows[0]["SECURITY_GATE_ENTRY_DATE"].ToString().Trim() != "")
            {
                if (Convert.ToDateTime(dt.Rows[0]["SECURITY_GATE_ENTRY_DATE"].ToString()).ToString("dd/MMM/yyyy") != "01/Jan/1900")
                    txtSecGEDate.Text = Convert.ToDateTime(dt.Rows[0]["SECURITY_GATE_ENTRY_DATE"].ToString()).ToString("dd/MMM/yyyy");
            }
            else
                txtSecGEDate.Text = "";
            txtRemarks.Text = dt.Rows[0]["REMARKS"].ToString().Trim();
            txtCostCenterNo.Text = dt.Rows[0]["COST_CENTER_NO"].ToString().Trim();
            ddlCompany.SelectedValue = dt.Rows[0]["COMP_CODE"].ToString().Trim();
            ddlDepartment.SelectedValue = dt.Rows[0]["DEPARTMENT"].ToString().Trim();
            // ddlProcessName.SelectedValue = dt.Rows[0]["ASSET_PROCESS"].ToString().Trim();

            ddlBondedType.SelectedValue = dt.Rows[0]["BONDED_TYPE"].ToString().Trim();
            ddlPlant.SelectedValue = dt.Rows[0]["PLANT"].ToString().Trim();
            ddlProjectCode.Text = dt.Rows[0]["PROJECT_NAME"].ToString().Trim();
            ddlSubProject.Text = dt.Rows[0]["SUB_PROJECT_NAME"].ToString().Trim();
            txtInventoryNote.Text = dt.Rows[0]["INVENTORY_NOTE"].ToString().Trim();
            txtRoom.Text = dt.Rows[0]["ROOM"].ToString().Trim();
            txtBA.Text = dt.Rows[0]["BA"].ToString().Trim();
            txtAssetDescription.Text = dt.Rows[0]["ASSET_DESCRIPTION"].ToString().Trim();
            txtAssetMainText.Text = dt.Rows[0]["ASSET_MAIN_TEXT"].ToString().Trim();
            ddlAcctDe.SelectedValue = dt.Rows[0]["ACCT_DE"].ToString().Trim();
            // ddlCurrency.Text = dt.Rows[0]["CURRENCY"].ToString().Trim();

            //if (dt.Rows[0]["BONDED_TYPE"].ToString().Trim() != "")
            //{
            //    ddlBondedType.SelectedValue = dt.Rows[0]["BONDED_TYPE"].ToString().Trim();
            //   // rdoCB.Checked = true; txtBOE.Enabled = true; rdoNCB.Checked = false;
            //}            
            if (dt.Rows[0]["CAPITALISED_STATUS"].ToString().Trim() == "CAP")
            {
                rdoCapitalised.Checked = true; rdoNonCapitalised.Checked = false;
            }
            else if (dt.Rows[0]["CAPITALISED_STATUS"].ToString().Trim() == "NCAP")
            {
                rdoCapitalised.Checked = false; rdoNonCapitalised.Checked = true;
            }
            if (dt.Rows[0]["VERIFIABLE_STATUS"].ToString().Trim() == "VER")
            {
                rdoVerifiable.Checked = true; rdoNonVerifiable.Checked = false;
            }
            else if (dt.Rows[0]["VERIFIABLE_STATUS"].ToString().Trim() == "NVER")
            {
                rdoVerifiable.Checked = false; rdoNonVerifiable.Checked = true;
            }
        }
    }

    /// <summary>
    /// Send approval mail message for new asset created/asset details updated.
    /// </summary>
    /// <param name="_AssetCode"></param>
    private void SendMailForApproval(string AssetCode, string LoginUser)
    {
        SmtpClient smtpClient = new SmtpClient();
        MailMessage message = new MailMessage();
        MailAddress fromAddress = new MailAddress(ConfigurationManager.AppSettings["SENDER"].ToString(), "ATS");
        smtpClient.Host = ConfigurationManager.AppSettings["SMTP_HOST"].ToString();
        smtpClient.Port = int.Parse(ConfigurationManager.AppSettings["SMTP_PORT"].ToString());
        message.From = fromAddress;
        message.To.Add(Session["EMAIL"].ToString());
        message.Subject = "WIPRO : RTS - New Asset For Approval";
        message.IsBodyHtml = false;
        StringBuilder sbMsg = new StringBuilder();
        sbMsg.AppendLine("Please Note,");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("An asset has been acquired/updated with asset code as : " + AssetCode + " by '" + LoginUser + "'.");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Company/Location : " + Session["COMP_NAME"] + ".");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("Kindly approve the same.");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("");
        sbMsg.AppendLine("http://10.164.91.191/FIS_ATS/WebPages/UserLogin.aspx");
        message.Body = sbMsg.ToString();
        smtpClient.Send(message);
    }


    private void EmptyToNA(System.Web.UI.WebControls.TextBox textbox)
    {
        if (string.IsNullOrEmpty(textbox.Text))
        {
           
        }
    }

    #endregion

    #region SELECTEDINDEXCHANGED EVENTS
    /// <summary>
    /// Get process code/name populated as the department name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlDepartment.SelectedIndex != 0)
                PopulateProcess(ddlDepartment.SelectedValue.ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get sub category populated as the parent category selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetCategory.SelectedIndex > 0)
            {
                int CatLevel = int.Parse(lblCatLevel.Text.Trim());
                lblCatLevel.Text = (CatLevel + 1).ToString();
                int iCatLevel = int.Parse(lblCatLevel.Text.Trim());
                string sCatCode = ddlAssetCategory.SelectedValue.ToString();
                lblCatCode.Text = sCatCode;
                lblCatName.Text = ddlAssetCategory.SelectedItem.Text;

                ddlAssetCategory.DataSource = null;
                DataTable dt = oDAL.PopulateCategory(lblAssetType.Text, sCatCode, iCatLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetCategory.DataSource = dt;
                    ddlAssetCategory.DataValueField = "CATEGORY_CODE";
                    ddlAssetCategory.DataTextField = "CATEGORY_NAME";
                    ddlAssetCategory.DataBind();
                    ddlAssetCategory.Items.Insert(0, "-- Select Category --");
                    ddlAssetCategory.Focus();
                     
                }
                else
                {
                    iCatLevel = iCatLevel - 1;
                    lblCatLevel.Text = iCatLevel.ToString();
                    ddlAssetLocation.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get location code/name to be populated into dropdownlist.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetLocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetLocation.SelectedIndex != 0)
            {
                int locLevel = int.Parse(lblLocLevel.Text.Trim());
                lblLocLevel.Text = (locLevel + 1).ToString();
                int iLocLevel = int.Parse(lblLocLevel.Text.Trim());
                string sLocCode = ddlAssetLocation.SelectedValue.ToString();
                lblLocCode.Text = sLocCode;

                ddlAssetLocation.DataSource = null;
                DataTable dt = oDAL.GetLocation(_StorageLocCode, sLocCode, iLocLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetLocation.DataSource = dt;
                    ddlAssetLocation.DataValueField = "LOC_CODE";
                    ddlAssetLocation.DataTextField = "LOC_NAME";
                    ddlAssetLocation.DataBind();
                    ddlAssetLocation.Items.Insert(0, "-- Select Location --");
                    ddlAssetLocation.Focus();
                }
                else
                {
                    iLocLevel = iLocLevel - 1;
                    lblLocLevel.Text = iLocLevel.ToString();
                    ddlAMCWarranty.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get category based on selection of asset type.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetType.SelectedValue.ToString() == "AD")
            {
                lblAssetType.Text = "ADMIN";
                PopulateCategory(lblAssetType.Text);
            }
            else if (ddlAssetType.SelectedValue.ToString() == "IT")
            {
                lblAssetType.Text = "IT";
                PopulateCategory(lblAssetType.Text);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    protected void ddlProjectCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlProjectCode.SelectedIndex != 0)
                PopulateSubProject(ddlProjectCode.SelectedValue.ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    protected void ddlSubProject_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlSubProject.SelectedIndex != 0)
                PopulateProjectManager(ddlSubProject.SelectedValue.ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }

    }
    #endregion

    #region BUTTON EVENTS
    /// <summary>
    /// Refresh category level to top (level 1).
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshCategory_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateCategory(lblAssetType.Text);
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Save/update asset acquisition details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            bool bResp = false;
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            //if (rdoCB.Checked)
            //{
            //    if (txtBOE.Text.Trim() == "")
            //    {
            //        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : BOE cannot be blank when custom bonded is checked!');", true);
            //        txtBOE.Enabled = true;
            //        txtBOE.Focus();
            //        return;
            //    }
            //}
            if (lblLocCode.Text == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset Location is mandatory.');", true);
                ddlAssetLocation.Focus();
                return;
            }
            if (lblCatCode.Text == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset Category is mandatory.');", true);
                ddlAssetCategory.Focus();
                return;
            }
            if (clsGeneral.OpType == "SAVE")
            {
                if (ddlAssetType.SelectedIndex == 2)
                {
                    oPRP.AssetType = "IT";
                    oPRP.SecurityClassification = txtSecurityClass.Text.Trim();
                    oPRP.ServiceProvider = txtServProvider.Text.Trim();
                    oPRP.AssetVlan = txtVlan.Text.Trim();
                    oPRP.AssetSize = txtSize.Text.Trim();
                    oPRP.AssetRAM = txtRAM.Text.Trim();
                    oPRP.AssetProcessor = txtProcessor.Text.Trim();
                    oPRP.AssetIMEINo = txtIMEINo.Text.Trim();
                    oPRP.AssetPhoneMemory = txtMemory.Text.Trim();
                    oPRP.AssetHDD = txtHDD.Text.Trim();
                }
                else if (ddlAssetType.SelectedIndex == 1)
                {
                    oPRP.AssetType = "ADMIN";
                }
                if (txtPODate.Text.Trim() != "" && txtInstallDate.Text.Trim() != "")
                {
                    int iDate = clsGeneral.CompareDate(txtPODate.Text.Trim(), txtInstallDate.Text.Trim());
                    if (iDate > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Purchase Order Date should be earlier than Installation Date!');", true);
                        return;
                    }
                }
                if (txtPurchasedDate.Text.Trim() != "" && txtInstallDate.Text.Trim() != "")
                {
                    int iDate = clsGeneral.CompareDate(txtPurchasedDate.Text.Trim(), txtInstallDate.Text.Trim());
                    if (iDate > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Purchased Date should be earlier than Installation Date!');", true);
                        return;
                    }
                }
                oPRP.CompCode = Session["COMPANY"].ToString();
                oPRP.CompanyName = (ddlCompany.SelectedIndex != 0) ? ddlCompany.SelectedItem.Text.Trim() : "";
                oPRP.Plant = (ddlPlant.SelectedIndex != 0) ? ddlPlant.SelectedItem.Text.Trim() : "";
                oPRP.DeptCode = (ddlDepartment.SelectedIndex != 0) ? ddlDepartment.SelectedValue.ToString() : "";
                oPRP.AssetProcess = "";// (ddlProcessName.SelectedIndex != -1 || ddlProcessName.SelectedIndex != 0) ? ddlProcessName.SelectedValue.ToString() : "";
                oPRP.Project_Name = (ddlProjectCode.SelectedIndex != 0) ? ddlProjectCode.SelectedValue.ToString() : "";
                oPRP.Sub_Project_Name = (ddlSubProject.SelectedIndex != 0) ? ddlSubProject.SelectedValue.ToString() : "";
                oPRP.Project_Manager = txtProjectMngr.Text.ToString();
                oPRP.Assign_Proj_To_Emp = txtProAssignEmp.Text.ToString();
                oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
                oPRP.SecurityGENo = txtSecGENo.Text.Trim();
                oPRP.SecurityGEDate = txtSecGEDate.Text.Trim();
                oPRP.AssetSerialCode = txtSerialCode.Text.Trim();
                oPRP.AssetMakeName = txtAssetMake.Text.Trim();
                oPRP.AssetModelName = txtAssetModel.Text.Trim();
                oPRP.AssetCategoryCode = lblCatCode.Text.Trim();
                oPRP.AssetLocation = lblLocCode.Text.Trim();
                oPRP.AMC_Warranty = (ddlAMCWarranty.SelectedValue.ToString() != "SELECT") ? ddlAMCWarranty.SelectedValue.ToString() : "";
                oPRP.AMC_Wrnty_Start_Date = txtAMCWrntyStartDate.Text.Trim();
                oPRP.AMC_Wrnty_End_Date = txtAMCWrntyEndDate.Text.Trim();
                if (oPRP.AMC_Warranty == "AMC" || oPRP.AMC_Warranty == "WARRANTY")
                {
                    if (oPRP.AMC_Wrnty_Start_Date == "" || oPRP.AMC_Wrnty_End_Date == "")
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : For AMC/WARRANTY, start date and end date are mandatory!');", true);
                        txtAMCWrntyStartDate.Enabled = true;
                        txtAMCWrntyEndDate.Enabled = true;
                        txtAMCWrntyStartDate.Focus();
                        return;
                    }
                }
                oPRP.AssetInstallDate = (txtInstallDate.Text.Trim() != "") ? txtInstallDate.Text.Trim() : "";
                oPRP.InvoiceNo = txtInvoiceNo.Text.Trim();
                oPRP.PurchasedDate = (txtPurchasedDate.Text.Trim() != "") ? txtPurchasedDate.Text.Trim() : "";
                oPRP.PODate = (txtPODate.Text.Trim() != "") ? txtPODate.Text.Trim() : "";
                oPRP.PurchaseOrderNo = txtPONo.Text.Trim();
                oPRP.RegisterNo = txtRegisterNo.Text.Trim();
                oPRP.CapitalisedType = rdoCapitalised.Checked ? "CAP" : "NCAP";
                oPRP.VerifiableType = rdoVerifiable.Checked ? "VER" : "NVER";
                //oPRP.BondedType = rdoCB.Checked ? "CBD" : "NCBD";
                oPRP.BondedType = (ddlBondedType.SelectedIndex != 0) ? ddlBondedType.SelectedValue.ToString() : "";
                oPRP.VendorCode = (ddlVendor.SelectedIndex != 0) ? ddlVendor.SelectedValue.ToString() : "";
                oPRP.AssetSaleDate = txtSaleDate.Text.Trim();
                oPRP.AssetPurchaseValue = (txtPurchaseValue.Text.Trim() != "") ? txtPurchaseValue.Text.Trim() : "0";
                oPRP.Transfer_Price = (txtTransferPrice.Text.Trim() != "") ? txtTransferPrice.Text.Trim() : "0";
                oPRP.Local_Currency = (txtLocalCurrency.Text.Trim() != "") ? txtLocalCurrency.Text.Trim() : "0";
                oPRP.AssetSaleValue = (txtSaleValue.Text.Trim() != "") ? txtSaleValue.Text.Trim() : "0";
                oPRP.AssetBOE = txtBOE.Text.Trim();
                oPRP.Bond_No = "";// txtInventoryNo.Text.Trim();
                oPRP.Inventory_Note = txtInventoryNote.Text.Trim();
                oPRP.AssetID = txtAssetId.Text.Trim();
                oPRP.CustomerOrderNo = txtCustOrderNo.Text.Trim();
                oPRP.PortNo = txtPortNo.Text.Trim();
                oPRP.AssetRemarks = txtRemarks.Text.Trim();
                oPRP.WorkStationNo = txtWorkStationNo.Text.Trim();
                oPRP.CostCenterNo = txtCostCenterNo.Text.Trim();
                oPRP.Asset_Desc = txtAssetDescription.Text.Trim();
                oPRP.Asset_Main_Text = txtAssetMainText.Text.Trim();
                oPRP.Room = txtRoom.Text.Trim();
                oPRP.BA = txtBA.Text.Trim();
                oPRP.Acct_De = (ddlAcctDe.SelectedIndex != 0) ? ddlAcctDe.SelectedValue.ToString() : "";
                oPRP.Currency = (ddlCurrency.SelectedIndex != 0) ? ddlCurrency.SelectedValue.ToString() : "";
                oPRP.Location = Session["COMPLOCATION"].ToString();
                oPRP.ExField1 = "";
                oPRP.ExField2 = "";
                oPRP.ExField3 = "";
                oPRP.ExField4 = "";
                oPRP.ExField5 = "";


                int _iMaxACQId = oDAL.GetMaxAcquisitionId(oPRP.AssetCategoryCode, oPRP.Location);
                oPRP.RunningSerialNo = _iMaxACQId;
                string s = oPRP.AssetCategoryCode.Trim().Replace("-00", "");
                string str = s.Substring(s.Length - 2, 2);
                oPRP.AssetCode = oPRP.Location + "-" + ddlAssetType.SelectedValue.ToString() + "-" + str + "-" + _iMaxACQId.ToString().PadLeft(6, '0');

                if (!oDAL.CheckDuplicateSerialNo(oPRP.AssetSerialCode, oPRP.Location) || !oDAL.CheckDuplicateIMEINo(oPRP.AssetIMEINo, oPRP.Location))
                {
                    bResp = oDAL.SaveAssetAcquisitionDetails(oPRP);
                    if (chkPrintBarcode.Checked)
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Print Barcode Sticker", "print();", true);
                }
                else
                {
                    StreamWriter sw;
                    if (File.Exists(strDupFilePath + DateTime.Today.ToString("dd_MMM_yyyy") + "_" + Session["COMPLOCATION"].ToString() + ".txt"))
                    {
                        sw = File.AppendText(strDupFilePath + DateTime.Today.ToString("dd_MMM_yyyy") + "_" + Session["COMPLOCATION"].ToString() + ".txt");
                        sw.WriteLine(oPRP.AssetSerialCode, oPRP.AssetIMEINo);
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset Serial No./IMEI No. found duplicate, hence asset details not saved.');", true);
                    }
                    else
                    {
                        sw = new StreamWriter(strDupFilePath + DateTime.Today.ToString("dd_MMM_yyyy") + "_" + Session["COMPLOCATION"].ToString() + ".txt");
                        sw.WriteLine(oPRP.AssetSerialCode, oPRP.AssetIMEINo);
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset Serial No./IMEI No. found duplicate, hence asset details not saved.');", true);
                    }
                    sw.Close();
                    sw = null;
                }
                if (bResp)
                {
                    txtAssetCode.Text = oPRP.AssetCode;
                    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ACQUISITION_SAVE");
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                    lblErrorMsg.Text = "Please Note : New Asset Acquired For Approval With Asset Code As : " + oPRP.AssetCode;
                    upSubmit.Update();
                    //try
                    //{ SendMailForApproval(oPRP.AssetCode, Session["CURRENTUSER"].ToString()); }
                    //catch (Exception ex) { }
                }
            }
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (clsGeneral.OpType == "UPDATE")
            {
                oPRP.AssetCode = txtAssetCode.Text.Trim();
                bool ChkAssetTransferred = oDAL.ChkAssetTransferred(oPRP.AssetCode, Session["COMPANY"].ToString());
                if (ChkAssetTransferred)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset is transferred to another location, so details cannot be updated.');", true);
                    return;
                }
                if (ddlAssetType.SelectedIndex == 2)
                {
                    oPRP.AssetType = "IT";
                    oPRP.SecurityClassification = txtSecurityClass.Text.Trim();
                    oPRP.ServiceProvider = txtServProvider.Text.Trim();
                    oPRP.AssetVlan = txtVlan.Text.Trim();
                    oPRP.AssetSize = txtSize.Text.Trim();
                    oPRP.AssetRAM = txtRAM.Text.Trim();
                    oPRP.AssetProcessor = txtProcessor.Text.Trim();
                    oPRP.AssetIMEINo = txtIMEINo.Text.Trim();
                    oPRP.AssetPhoneMemory = txtMemory.Text.Trim();
                    oPRP.AssetHDD = txtHDD.Text.Trim();
                }
                else if (ddlAssetType.SelectedIndex == 1)
                {
                    oPRP.AssetType = "ADMIN";
                }
                if (txtPODate.Text.Trim() != "" && txtInstallDate.Text.Trim() != "")
                {
                    int iDate = clsGeneral.CompareDate(txtPODate.Text.Trim(), txtInstallDate.Text.Trim());
                    if (iDate > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : PO Date cannot be later than installed date.');", true);
                        return;
                    }
                }
                oPRP.AssetID = txtAssetId.Text.Trim();
                oPRP.CompCode = ddlCompany.SelectedValue.ToString();
                oPRP.CompanyName = ddlCompany.SelectedItem.Text.Trim();
                oPRP.Plant = (ddlPlant.SelectedIndex != 0) ? ddlPlant.SelectedItem.Text.Trim() : "";
                oPRP.DeptCode = oPRP.DeptCode = (ddlDepartment.SelectedIndex != 0) ? ddlDepartment.SelectedValue.ToString() : "";
                oPRP.AssetProcess = "";// (ddlProcessName.SelectedIndex != -1 || ddlProcessName.SelectedIndex != 0) ? ddlProcessName.SelectedValue.ToString() : "";
                oPRP.Project_Name = (ddlProjectCode.SelectedIndex != 0) ? ddlProjectCode.SelectedValue.ToString() : "";
                oPRP.Sub_Project_Name = (ddlSubProject.SelectedIndex != 0) ? ddlSubProject.SelectedValue.ToString() : "";
                oPRP.Project_Manager = txtProjectMngr.Text.ToString();
                oPRP.Assign_Proj_To_Emp = txtProAssignEmp.Text.ToString();
                oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
                oPRP.AssetSerialCode = txtSerialCode.Text.Trim();
                oPRP.AssetMakeName = txtAssetMake.Text.Trim();
                oPRP.AssetModelName = txtAssetModel.Text.Trim();
                oPRP.AssetCategoryCode = lblCatCode.Text.Trim();
                oPRP.AssetLocation = lblLocCode.Text.Trim();
                oPRP.AMC_Warranty = (ddlAMCWarranty.SelectedValue.ToString() != "SELECT") ? ddlAMCWarranty.SelectedValue.ToString() : "";
                oPRP.AMC_Wrnty_Start_Date = (txtAMCWrntyStartDate.Text.Trim() != "") ? txtAMCWrntyStartDate.Text.Trim() : "";
                oPRP.AMC_Wrnty_End_Date = (txtAMCWrntyEndDate.Text.Trim() != "") ? txtAMCWrntyEndDate.Text.Trim() : "";
                if (oPRP.AMC_Warranty == "AMC" || oPRP.AMC_Warranty == "WARRANTY")
                {
                    if (oPRP.AMC_Wrnty_Start_Date == "" || oPRP.AMC_Wrnty_End_Date == "")
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : For AMC/WARRANTY, start date and end date are mandatory!');", true);
                        txtAMCWrntyStartDate.Enabled = true;
                        txtAMCWrntyEndDate.Enabled = true;
                        txtAMCWrntyStartDate.Focus();
                        return;
                    }
                }
                oPRP.AssetInstallDate = (txtInstallDate.Text.Trim() != "") ? txtInstallDate.Text.Trim() : "";
                oPRP.InvoiceNo = txtInvoiceNo.Text.Trim();
                oPRP.PurchasedDate = (txtPurchasedDate.Text.Trim() != "") ? txtPurchasedDate.Text.Trim() : "";
                oPRP.PODate = (txtPODate.Text.Trim() != "") ? txtPODate.Text.Trim() : "";
                oPRP.PurchaseOrderNo = txtPONo.Text.Trim();
                oPRP.RegisterNo = txtRegisterNo.Text.Trim();
                oPRP.CapitalisedType = rdoCapitalised.Checked ? "CAP" : "NCAP";
                oPRP.VerifiableType = rdoVerifiable.Checked ? "VER" : "NVER";
                //oPRP.BondedType = rdoCB.Checked ? "CBD" : "NCBD";
                oPRP.BondedType = (ddlBondedType.SelectedIndex != 0) ? ddlBondedType.SelectedValue.ToString() : "";
                oPRP.VendorCode = (ddlVendor.SelectedIndex != 0) ? ddlVendor.SelectedValue.ToString() : "";
                oPRP.AssetSaleDate = (txtSaleDate.Text.Trim() != "") ? txtSaleDate.Text.Trim() : "";
                oPRP.AssetPurchaseValue = txtPurchaseValue.Text.Trim();
                oPRP.Transfer_Price = (txtTransferPrice.Text.Trim() != "") ? txtTransferPrice.Text.Trim() : "0";
                oPRP.Local_Currency = (txtLocalCurrency.Text.Trim() != "") ? txtLocalCurrency.Text.Trim() : "0";
                oPRP.AssetSaleValue = txtSaleValue.Text.Trim();
                oPRP.AssetBOE = txtBOE.Text.Trim();
                oPRP.AssetRemarks = txtRemarks.Text.Trim();
                oPRP.CustomerOrderNo = txtCustOrderNo.Text.Trim();
                oPRP.PortNo = txtPortNo.Text.Trim();
                oPRP.WorkStationNo = txtWorkStationNo.Text.Trim();
                oPRP.CostCenterNo = txtCostCenterNo.Text.Trim();
                oPRP.SecurityGENo = txtSecGENo.Text.Trim();
                oPRP.SecurityGEDate = (txtSecGEDate.Text.Trim() != "") ? txtSecGEDate.Text.Trim() : "";
                oPRP.Bond_No = "";// txtInventoryNo.Text.Trim();
                oPRP.Inventory_Note = txtInventoryNote.Text.Trim();
                oPRP.Asset_Desc = txtAssetDescription.Text.Trim();
                oPRP.Asset_Main_Text = txtAssetMainText.Text.Trim();
                oPRP.Room = txtRoom.Text.Trim();
                oPRP.BA = txtBA.Text.Trim();
                oPRP.Acct_De = (ddlAcctDe.SelectedIndex != 0) ? ddlAcctDe.SelectedValue.ToString() : "";
                oPRP.Currency = (ddlCurrency.SelectedIndex != 0) ? ddlCurrency.SelectedValue.ToString() : "";
                oPRP.Location = Session["COMPLOCATION"].ToString();

                bResp = oDAL.UpdateAssetAcquisitionDetails(oPRP);
                if (bResp)
                {
                    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ACQUISITION_UPDATE");
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Asset details updated successfully.');", true);
                    if (chkPrintBarcode.Checked)
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Print Barcode Sticker", "print();", true);
                    //try
                    //{ SendMailForApproval(oPRP.AssetCode, Session["CURRENTUSER"].ToString()); }
                    //catch (Exception ex) { }
                    txtAssetCode.Focus();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert(Please Note : Asset details are not updated.);", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : An error has occured while saving asset details.');", true);
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Reset/Crear fields and set location/category details refreshed.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            txtAssetCode.Text = "";
            PopulateLocation();
            PopulateCategory(lblAssetType.Text);
            ddlAssetCategory.Enabled = true;
            btnRefreshCategory.Enabled = true;
            txtInvoiceNo.Focus();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Refresh/reset location/sub location/floor no. dropdowns.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ibtnRefreshLocation_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateLocation();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion




}