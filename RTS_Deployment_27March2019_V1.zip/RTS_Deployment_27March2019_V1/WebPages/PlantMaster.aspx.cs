﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class PlantMaster : System.Web.UI.Page
{
    PlantMaster_DAL oDAL;
    PlantMaster_PRP oPRP;
    public PlantMaster()
    {
        oPRP = new PlantMaster_PRP();
    }
    ~PlantMaster()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new PlantMaster_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Checking user group rights for company master details 
    /// save/edit/update/delete operations.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("COMPANY_MASTER", (DataTable)Session["USERRIGHTS"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "COMPANY_MASTER");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx");
                }
                PopulateCity();
                GetPlantDetails();
                txtPlantCode.Focus();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Country Master");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx", false);
        }
    }

    /// <summary>
    /// Populate city details into gridview for viewing.
    /// </summary>
    private void GetPlantDetails()
    {
        DataTable dt = new DataTable();
        dt = oDAL.GetPlantDetails();
        gvPlant.DataSource = dt;
        gvPlant.DataBind();
    }

    /// <summary>
    /// Populate city details into gridview for viewing.
    /// </summary>
    private void PopulateCity()
    {
        DataTable dt = new DataTable();
        dt = oDAL.GetCity();
        ddlCityCode.DataSource = dt;
        ddlCityCode.DataTextField = "CITY_NAME";
        ddlCityCode.DataValueField = "CITY_CODE";
        ddlCityCode.DataBind();
        ddlCityCode.Items.Insert(0, "-- Select City --");
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Company details deleting event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvPlant.Rows[e.RowIndex];
            oPRP.PlantCode = ((Label)gvRow.FindControl("lblPlantCode")).Text.Trim();
            //oPRP.CityCode = ((DropDownList)(gvRow.FindControl("ddlECityCode"))).SelectedValue.ToString();
            bool DelRslt = oDAL.DeletePlant(oPRP.PlantCode);
            if (DelRslt)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Entire details of the plant deleted successfully.');", true);
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details editing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvPlant.Rows[e.NewEditIndex];
            ViewState["CITY"] = ((Label)gvRow.FindControl("lblCityCode")).Text.Trim();
            gvPlant.EditIndex = e.NewEditIndex;
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlECityCode = (DropDownList)e.Row.FindControl("ddlECityCode");
                if (ddlECityCode != null)
                {
                    ddlECityCode.DataSource = oDAL.GetCity();
                    ddlECityCode.DataTextField = "CITY_NAME";
                    ddlECityCode.DataValueField = "CITY_CODE";
                    ddlECityCode.DataBind();
                    ddlECityCode.Items.Insert(0, "-- Select City --");
                    if (ViewState["CITY"].ToString() != "")
                        ddlECityCode.SelectedIndex = ddlECityCode.Items.IndexOf(ddlECityCode.Items.FindByText(ViewState["CITY"].ToString()));
                    else
                    {
                        ddlECityCode.SelectedIndex = ddlECityCode.Items.IndexOf(ddlECityCode.Items.FindByText("-- Select City --"));
                    }
                }



                ImageButton imagebuttonEdit = (ImageButton)e.Row.FindControl("imagebuttonEdit");
                ImageButton imagebuttonDelete = (ImageButton)e.Row.FindControl("imagebuttonDelete");
                if (imagebuttonEdit != null)
                {
                    if (clsGeneral._strRights[2] == "0")
                        imagebuttonEdit.Enabled = false;
                    else
                        imagebuttonEdit.Enabled = true;
                }
                if (imagebuttonDelete != null)
                {
                    if (clsGeneral._strRights[3] == "0")
                        imagebuttonDelete.Enabled = false;
                    else
                        imagebuttonDelete.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details updating event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvPlant.Rows[e.RowIndex];
            oPRP.CityCode = ((DropDownList)(gvRow.FindControl("ddlECityCode"))).SelectedValue.ToString();           
            oPRP.PlantCode = ((Label)gvRow.FindControl("lblEditPlantCode")).Text.Trim();
            oPRP.PlantName = ((Label)gvRow.FindControl("lblEditPlantName")).Text.Trim();            
            oPRP.Remarks = ((TextBox)gvRow.FindControl("txtERemarks")).Text.Trim();
            oPRP.Active = ((CheckBox)gvRow.FindControl("chkEditActive")).Checked;
            oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
            oDAL.UpdatePlant(oPRP);

            gvPlant.EditIndex = -1;
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company details edit/update cancelling event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvPlant.EditIndex = -1;
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Company master gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPlantMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvPlant.PageIndex = e.NewPageIndex;
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region SUBMIT EVENT
    /// <summary>
    /// Save new company details.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            oPRP.PlantCode = txtPlantCode.Text.Trim();
            oPRP.PlantName = txtPlantName.Text.Trim();
            if (ddlCityCode.SelectedIndex != 0)
                oPRP.CityCode = ddlCityCode.SelectedValue.ToString();
            oPRP.Remarks = txtRemarks.Text.Trim().Replace("'", "`");
            oPRP.Active = chkSetStatus.Checked;
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            bool bResp = oDAL.SavePlant(oPRP);
            if (!bResp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Plant Code already exist !');", true);
                txtPlantCode.Focus();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                upSubmit.Update();
            }
            GetPlantDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}