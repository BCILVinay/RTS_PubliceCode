﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebPages_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //List<TEST> lst = new List<TEST> { new TEST { DATEON = DateTime.Today} };
        //GridView1.DataSource = lst;
        //GridView1.DataBind();
        DropDownList1.Items.Add(new ListItem() {  Text="AAA", Value ="AAA"});
        DropDownList1.Items.Add(new ListItem() { Text = "BBB", Value = "BBB" });
        DropDownList1.Items.Add(new ListItem() { Text = "CCC", Value = "CCC" });
        DropDownList1.Items.Add(new ListItem() { Text = "DDD", Value = "DDD" });
        DropDownList1.Items.Add(new ListItem() { Text = "EEE", Value = "EEE" });
        DropDownList1.Items.Add(new ListItem() { Text = "FFF", Value = "FFF" });
        DropDownList1.Items.Add(new ListItem() { Text = "GGG", Value = "GGG" });
        DropDownList1.Items.Add(new ListItem() { Text = "HHH", Value = "HHH" });
        DropDownList1.Items.Add(new ListItem() { Text = "IIII", Value = "IIII" });
    }
}
//public class TEST
//{
//    public DateTime DATEON { get; set; }
//}
