﻿using MobiVUE_ATS.PRP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchAsset : System.Web.UI.Page
{
 AssetRquestDAL _assetRquestDAL = null;
    AssetReplacement_PRP oPRP;
    //List<ViewAssetLocation> _viewAssetRequest
    //{
    //    get
    //    {
    //        return ViewState["ViewSearch"] == null ? new List<ViewAssetLocation>() : (List<ViewAssetLocation>)ViewState["ViewSearch"];
    //    }
    //    set
    //    {
    //        ViewState["ViewSearch"] = value;
    //    }
     
        
    //}
    


    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }


    string strFilePath = string.Empty;
    private string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }
    private string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public string CurrentDBName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

   



    public SearchAsset()
    {
        oPRP = new AssetReplacement_PRP();
        _assetRquestDAL = default(AssetRquestDAL);
    }
    ~SearchAsset()
    {
         oPRP = null;
        _assetRquestDAL = null;
    }



    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        //if (Session["CURRENTUSER"] == null)
        //{
        //    Server.Transfer("SessionExpired.aspx");
        //}
        //oDAL = new AssetReplacement_DAL(Session["DATABASE"].ToString());
        //txtActiveInAssetCode.Focus();
    }

    /// <summary>
    /// Checking user group rights for Asset replacement operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                string _strRights = clsGeneral.GetRights("SearchAsset_Location", (System.Data.DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');

                this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
                this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
                this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
                this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
                this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
                if (!this.IsViewRight)
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }

            }

        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion
    #region Exception Handler
    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }
    #endregion


    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrEmpty(txtRequestNo.Text.Trim()))
            {


                _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
                var _searchCriteria = new AssetSearchCriteria()
                    {
                        AssetCode = txtRequestNo.Text.Trim()
                    };
                List<ViewAssetLocation> _viewAssetRequest = _assetRquestDAL.GetViewAssetLocation(
                   _searchCriteria
                    );

                var ctr = _viewAssetRequest.Count();

                if (_viewAssetRequest.Count() > 0)
                {
                    lblErrorMsg.Text = string.Format("Record found :{0} .", ctr);
                }
                else
                {
                    lblErrorMsg.Text = "No record found !!!";
                }
                gvMovementRequest.DataSource = _viewAssetRequest;
                gvMovementRequest.DataBind();
            }
            else
            {
                lblErrorMsg.Text = "Please enter asset code !!!";
                gvMovementRequest.DataSource = null;
                gvMovementRequest.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.HandleExceptions(ex);
        }
    }

   
   
}