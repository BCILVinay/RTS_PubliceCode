﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;

public partial class WebPages_rptGatePassSlip : System.Web.UI.Page
{

    public string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }

    public string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public AssetRequest GatePassRequest
    {
        get
        {
            return ViewState["AssetRequest"] == null ? default(AssetRequest) : (AssetRequest)ViewState["AssetRequest"];
        }
        set
        {
            ViewState["AssetRequest"] = value;
        }
    }

    private string LoggedInDataBaseName;
   

    protected void Page_Init(object sender, EventArgs e)
    {

        //if (Session["CURRENTUSER"] == null)
        //{
        //    Server.Transfer("SessionExpired.aspx");
        //}
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            
        if (!Page.IsPostBack && Request.QueryString["RequestId"] != null)
        {
            var AssetMovementRequesrId = UrlEncript.Decrypt(HttpUtility.UrlDecode(Request.QueryString["RequestId"]));
            var LocationCode = UrlEncript.Decrypt(HttpUtility.UrlDecode(Request.QueryString["Location"]));
            LoggedInDataBaseName = UrlEncript.Decrypt(HttpUtility.UrlDecode(Request.QueryString["GT"]));
            DataTable dt = GetAssetDescription(AssetMovementRequesrId, LocationCode);
            DataTable dtAsset = GetAssetDetails(AssetMovementRequesrId, LocationCode);
            GatePassData ds = new GatePassData();
            ds.Tables["tblGTDescription"].Merge(dt, true, MissingSchemaAction.Ignore);
            ds.Tables["tblGTAsset"].Merge(dtAsset, true, MissingSchemaAction.Ignore);
            rptGatePassViewer.ProcessingMode = ProcessingMode.Local;
            rptGatePassViewer.LocalReport.ReportPath = Server.MapPath("~/Reports/GatePassReport.rdlc");
            ReportDataSource DescriptionSource = new ReportDataSource("GTDescritopn", ds.Tables["tblGTDescription"]);
            ReportDataSource AssetSource = new ReportDataSource("GTAsset", ds.Tables["tblGTAsset"]);
            rptGatePassViewer.LocalReport.DataSources.Clear();
            rptGatePassViewer.LocalReport.DataSources.Add(DescriptionSource);
            rptGatePassViewer.LocalReport.DataSources.Add(AssetSource);
            rptGatePassViewer.Visible = true;
        }
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    private DataTable GetAssetDetails(string RequestId , string LocationCode)
    {
        try
        {
            var _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);
            DataTable tbl = _assetRquestDAL.GetGatePassSlipForAsset(RequestId,LocationCode);
            return tbl;
        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    private DataTable GetAssetDescription(string RequestId, string LocationCode)
    {
        try
        {
            var _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);
            DataTable tbl = _assetRquestDAL.GetGatePassSlipForDescription(RequestId, LocationCode);
            return tbl;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}