﻿using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CategorySummaryReport : System.Web.UI.Page
{
    private DateTime? RequestDateFrom = default(DateTime?);
    private DateTime? RequestDateTo = default(DateTime?);
    AssetReplacement_PRP oPRP = new AssetReplacement_PRP();
    AssetRquestDAL _assetRquestDAL = default(AssetRquestDAL);

    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }


    string strFilePath = string.Empty;
    private string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }
    private string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public string CurrentDBName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

    public CategorySummaryReport()
    {
        var oPRP = new AssetReplacement_PRP();
        var _assetRquestDAL = default(AssetRquestDAL);
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                string _strRights = clsGeneral.GetRights("ASSET_SUMMARY_REPORT", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');

                this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
                this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
                this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
                this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
                this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "Category Summary Report");
                if (!this.IsViewRight)
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                }
                if (this.LoggedInUser.ToUpper() != "SYSADMIN")
                {
                    TrLocationFilter.Style.Add("display", "none");
                }
               //  Session["COMPANY"]
                PopulateLocation(Convert.ToString(Session["COMPANY"]));
                btnClear_Click(null, null);

            }

        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }


    private void PopulateLocation(string Company)
    {
       var  oDAL = new UserMaster_DAL("IT");
        ddlFromLocation.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetCompLocation(Company);
        ddlFromLocation.DataSource = dt;
        ddlFromLocation.DataTextField = "STORAGE_LOC_NAME";
        ddlFromLocation.DataValueField = "STORAGE_LOC_CODE";
        ddlFromLocation.DataBind();
        ddlFromLocation.Items.Insert(0, new ListItem("-- Select From Location --","0"));

        ddlToLocation.DataSource = dt;
        ddlToLocation.DataTextField = "STORAGE_LOC_NAME";
        ddlToLocation.DataValueField = "STORAGE_LOC_CODE";
        ddlToLocation.DataBind();
        ddlToLocation.Items.Insert(0, new ListItem("-- Select To Location --","0"));

    }


    private bool ValidateSearchDate(string RequestFrom, string RequestTo)
    {
        try
        {

            if (!string.IsNullOrEmpty(RequestFrom))
            {
                var dt = RequestFrom.Trim().Split('/');
                RequestDateFrom = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(AssetRquestDAL.GetMonth(dt[1])), Convert.ToInt32(dt[0]));
            }

            if (!string.IsNullOrEmpty(RequestTo))
            {
                var dt = RequestTo.Trim().Split('/');
                RequestDateTo = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(AssetRquestDAL.GetMonth(dt[1])), Convert.ToInt32(dt[0]));
            }
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    private void SubmitRequest()
    {
        gvAssetDetails.Visible = false;
        if (!ValidateSearchDate(txtRequestFrom.Text, txtRequestTo.Text))
        {
            lblErrorMsg.Text = "Please enter valid date format dd/MMM/yyyy";
            return;
        }

        else if (ValidateSearchDate(txtRequestFrom.Text, txtRequestTo.Text) == true
            && (RequestDateFrom != default(DateTime?) && RequestDateTo == default(DateTime?))
            || (RequestDateFrom == default(DateTime?) && RequestDateTo != default(DateTime?))
            )
        {
            lblErrorMsg.Text = "Please select request From and To date";
            return;
        }
        else if (ValidateSearchDate(txtRequestFrom.Text, txtRequestTo.Text) == true && RequestDateFrom > RequestDateTo)
        {
            lblErrorMsg.Text = "Request From date should not be greater than To date";
            return;
        }
        else
        {
            int ReportType = Convert.ToInt32(drpReportType.SelectedValue);
            _assetRquestDAL = new AssetRquestDAL(this.CurrentDBName);
            var FromLocation = ddlFromLocation.SelectedValue;
            var Tolocation = ddlToLocation.SelectedValue;
            DataTable tbl = _assetRquestDAL.GetSummaryReport(RequestDateFrom, RequestDateTo, this.LoggedInLocation, this.LoggedInUser, ReportType, FromLocation, Tolocation);

            if (tbl.Rows.Count > 0)
            {
                if (ReportType == 0)
                {
                    var reportsData = RemoveEmptyColumns(tbl);
                    Session["CategoryReport"] = reportsData;
                    // pnlGrid
                    int cnt = reportsData.Count();
                    for (int i = 0; i < cnt; i++)
                    {
                        GridView grd = new GridView();
                        grd.ID = "grid_" + i;
                        grd.AutoGenerateColumns = true;
                        grd.Attributes.Add("Class", "mGrid");


                        grd.DataSource = reportsData[i];
                        grd.DataBind();
                        pnlGrid.Controls.Add(grd);
                    }

                    //gvAssetDetails.DataSource = tbl;
                    //gvAssetDetails.DataBind();
                    lblErrorMsg.Text = string.Empty;
                }

                else
                {
                    Session["CategoryReport"] = tbl;
                    gvAssetDetails.DataSource = tbl;
                    gvAssetDetails.DataBind();
                    gvAssetDetails.Visible = true;
                }
            }
            else
            {
                lblErrorMsg.Text = "No Data Found";
                Session["CategoryReport"] = null;
            }

            // _searchCriteria.RequestFrom = RequestDateFrom;
            // _searchCriteria.RequestFrom = RequestDateTo;
        }
    }

    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }
    protected void btnGetAssets_Click(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            SubmitRequest();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }

    }

    private DataTable[] RemoveEmptyColumns(DataTable tbl)
    {
        try
        {

            DataTable[] tbls = new DataTable[tbl.Rows.Count];

            for (int i = 0; i < tbl.Rows.Count; i++)
            {
                tbls[i] = new DataTable();
                for (int j = 0; j < tbl.Columns.Count; j++)
                {
                    if (tbl.Columns[j].ColumnName != "Location" && Convert.ToString(tbl.Rows[i][j]) != "")
                    {
                        tbls[i].Columns.Add(new DataColumn(tbl.Columns[j].ColumnName, typeof(string)));
                    }
                }
            }

            for (int i = 0; i < tbl.Rows.Count; i++)
            {
                DataRow row = tbls[i].NewRow();
                for (int j = 0; j < tbl.Columns.Count; j++)
                {
                    if (tbls[i].Columns.Contains(Convert.ToString(tbl.Columns[j].ColumnName)))
                    {
                        string colName = tbl.Columns[j].ColumnName;
                        row[colName] = Convert.ToString(tbl.Rows[i][j]);
                    }
                }
                tbls[i].Rows.Add(row);
            }
            return tbls;
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnExportDetails_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsViewRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (drpReportType.SelectedValue == "0")
            {
                if (Session["CategoryReport"] != null)
                {
                    DataTable[] tbls = (DataTable[])Session["CategoryReport"];
                    if (tbls != null && tbls.Length > 0)
                    {
                        StringBuilder builder = new StringBuilder();
                        builder.Append("<html>");
                        builder.Append("<head>");
                        builder.Append("<title>");
                        builder.Append("Page-");
                        builder.Append(Guid.NewGuid());
                        builder.Append("</title>");
                        builder.Append("</head>");
                        builder.Append("<body>");
                        string str = builder.ToString();
                        for (int i = 0; i < tbls.Length; i++)
                        {
                            str = str + toHTML_Table(tbls[i]);
                            str = str + "</table><br>";
                        }

                        str = str + "</body> </html>";

                        byte[] document = Encoding.ASCII.GetBytes(str);

                        Response.Clear();
                        Response.AddHeader("content-disposition", "attachment;filename=MovementCategorySummaryReport.xls");
                        Response.Charset = "";
                        Response.Cache.SetNoServerCaching();
                        Response.ContentType = "application/ms-excel";
                        Response.BinaryWrite(document);
                        // Response.End();

                    }
                }
            }
            else
            {
                if (Session["CategoryReport"] != null)
                {
                    DataTable tbl = (DataTable)Session["CategoryReport"];
                    if (tbl != null && tbl.Rows.Count > 0)
                    {
                        //  gvAssetDetails

                        System.IO.StringWriter tw = new System.IO.StringWriter();
                        System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);

                        DataGrid dgGrid = new DataGrid();
                        dgGrid.DataSource = tbl;
                        // hw.WriteLine("<b><u><font size='5'> " + Session["COMPANY"].ToString() + "</font></u></b>");
                        hw.WriteLine("<br>");
                        dgGrid.HeaderStyle.Font.Bold = true;
                        dgGrid.DataBind();
                        dgGrid.RenderControl(hw);
                        Response.ContentType = "application/vnd.ms-excel";
                        Response.AddHeader("Content-Disposition", "attachment;filename=MovementSummaryReport.xls");
                        this.EnableViewState = false;
                        Response.Write(tw.ToString());
                        Response.End();

                    }
                }


            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);

        }
    }


    public static string toHTML_Table(DataTable dt)
    {
        if (dt.Rows.Count == 0) return ""; // enter code here

        StringBuilder builder = new StringBuilder();

        builder.Append("<table border='1px' cellpadding='5' cellspacing='0' ");
        builder.Append("style='border: solid 1px Silver; font-size: x-small;'>");
        builder.Append("<tr align='left' valign='top'>");
        foreach (DataColumn c in dt.Columns)
        {
            builder.Append("<td align='left' valign='top'><b>");
            builder.Append(c.ColumnName);
            builder.Append("</b></td>");
        }
        builder.Append("</tr>");
        foreach (DataRow r in dt.Rows)
        {
            builder.Append("<tr align='left' valign='top'>");
            foreach (DataColumn c in dt.Columns)
            {
                builder.Append("<td align='left' valign='top'>");
                builder.Append(r[c.ColumnName]);
                builder.Append("</td>");
            }
            builder.Append("</tr>");
        }


        return builder.ToString();
    }
    protected void btnClear_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            Session["CategoryReport"] = null;
            txtRequestFrom.Text = string.Empty;
            txtRequestTo.Text = string.Empty;
            gvAssetDetails.DataSource = null;
            gvAssetDetails.DataBind();
            drpReportType.SelectedIndex = 0;
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void drpReportType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            Session["CategoryReport"] = null;
            gvAssetDetails.DataSource = null;
            gvAssetDetails.DataBind();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
}
