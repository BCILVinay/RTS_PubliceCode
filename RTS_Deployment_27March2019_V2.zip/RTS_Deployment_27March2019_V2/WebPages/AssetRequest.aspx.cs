﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeOpenXml;
using System.IO;
using MobiVUE_ATS.MyDLL;
using System.Data;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;
using MobiVUE_ATS.MyDLL;
using System.Web.Services;
using System.Text.RegularExpressions;

public partial class WebPages_AssetRequest : System.Web.UI.Page
{

    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }


    string strFilePath = string.Empty;

    private static DataTable dtAssetType = new DataTable();

    private List<AssetDetails> InvalidAssets
    {
        get;
        set;
    }



    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }



    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                SetPageRights();
                BindAssetType();
            }
        }
        catch (Exception ex)
        {
            Response.Redirect("UnauthorizedUser.aspx", false);
        }
    }

    private void SetPageRights()
    {
        try
        {
            string _strRights = clsGeneral.GetRights("MOVEMENT_REQUEST", (DataTable)Session["UserRights"]);
            clsGeneral._strRights = _strRights.Split('^');
            this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
            this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
            this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
            this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
            this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

            clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
            if (!this.IsViewRight)
            {
                Response.Redirect("UnauthorizedUser.aspx", false);
                return;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void btnUpload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (UploadAssetFile())
            {
                MyExcel oExcel = new MyExcel();
                DataTable dtFileData = oExcel.ReadExcel(strFilePath);
                if (!ValidateColumn(dtFileData))
                {
                    lblErrorMsg.Text = "Invalid Column Name";
                    return;
                }
                List<AssetDetails> lstAssetDetails = ConvertDataTableToList(dtFileData);
                if (ChkEmptyAsset(lstAssetDetails))
                {
                    lblErrorMsg.Text = "Please remove blank asset code";
                    return;
                }


                //   Session["AssetUpload"] = ValidAssets;
                ViewState["AssetDetailsTemp"] = lstAssetDetails;
                AssetDetailsAddGrid.DataSource = dtFileData;
                AssetDetailsAddGrid.DataBind();
                //UploadedAssetGrid.DataSource = lstAssetDetails;
                //UploadedAssetGrid.DataBind();
                // dvUploadedAssetGrid.Style.Add("display", "block");
                btnSearch.Attributes.Add("disabled", "disabled");
                AssetFilter.Style.Add("display", "none");
                dvAssetDetails.Style.Add("display", "none");


                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Enter Submit to save/update file data.');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Select Excel File ');", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }


    protected void btnDocumentUpload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<UploadDocument> UploadFiles = new List<UploadDocument>();
            List<string> ValidFile = new List<string>();
            var files = Request.Files;
            if (files.Count > 0)
            {
                string fileName = string.Empty;
                for (int i = 1; i < files.Count; i++)
                {
                    HttpPostedFile userPostedFile = files[i];
                    var fileExt = System.IO.Path.GetExtension(userPostedFile.FileName);
                    if (!string.IsNullOrEmpty(userPostedFile.FileName))
                    {

                        //if (fileExt.ToLower() != ".xls".ToLower() && fileExt.ToLower() != ".XLS".ToLower() && fileExt.ToLower() != ".xlsx".ToLower())
                        //{
                        var ext = Path.GetExtension(userPostedFile.FileName);
                        var fileNameWithoutExt = Path.GetFileName(userPostedFile.FileName).Replace(ext, "").Trim();
                        strFilePath = Request.PhysicalApplicationPath + "UploadedFiles\\TempDocument\\" + fileNameWithoutExt + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;


                        if (File.Exists(strFilePath))
                        {
                            File.Delete(strFilePath);
                        }

                        AssetDocumentUpload.SaveAs(strFilePath);


                        FileInfo info = new FileInfo(strFilePath);
                        var fileLength = info.Length;

                        if (fileLength > 0 && Decimal.Divide(fileLength, 1048576) <= 5)// TotalBytes = 1048576)
                        {
                            UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, UploadFilePath = strFilePath, DocumentType = UploadDocType.REQ, IsValid = "YES", Remark = txtUploadRemark.Text });
                        }
                        else
                        {
                            fileName = fileName + userPostedFile.FileName + ",";
                        }
                        //}
                        //else
                        //{
                        //    UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, IsValid = "NO" });
                        //}
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Seelct File !!!');", true);
                    }
                }
                if (!string.IsNullOrEmpty(fileName))
                {
                    lblErrorMsg.Text = "Invalid File : file size greather than 5 MB " + fileName;
                }
                if (UploadFiles.Count > 0)
                {
                    if (Session["UploadDocument"] != null)
                    {
                        var FilesUploaded = Session["UploadDocument"] as List<UploadDocument>;
                        UploadFiles.AddRange(FilesUploaded);
                    }
                    UploadedDocumentGrid.DataSource = UploadFiles;
                    UploadedDocumentGrid.DataBind();
                    Session["UploadDocument"] = UploadFiles;
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                    txtUploadRemark.Text = string.Empty;
                }

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }


    #region Private Function

    private bool UploadAssetFile()
    {
        String fileExt;
        bool bRes = false;

        fileExt = System.IO.Path.GetExtension(AssetUpload.FileName);
        if (AssetUpload.HasFile)
        {
            if (fileExt == ".xls" || fileExt == ".XLS" || fileExt == ".xlsx")
            {
                strFilePath = Request.PhysicalApplicationPath + "UploadedFiles\\" + AssetUpload.FileName;
                File.Delete(strFilePath);
                AssetUpload.SaveAs(strFilePath);
                bRes = true;
            }
        }
        return bRes;
    }


    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Movement Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }
    #endregion

    protected void UploadedDocumentGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridViewRow row = e.Row;
        if (row.RowType == DataControlRowType.DataRow)
        {
            Label lblIsValid = (Label)row.FindControl("lblIsValid");
            if (lblIsValid != null && lblIsValid.Text == "NO")
            {
                row.Style.Add("background-color", "#ff531a");
                row.Attributes.Add("tooltip", "Invalid File format");
            }
            else
            {
                row.Style.Add("background-color", "#59b300");
                row.Attributes.Add("tooltip", "Valid File format");
            }
        }
    }

    protected void ImgDelete_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsDeleteRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblFileName = (Label)row.FindControl("lblFileName");
            if (Session["UploadDocument"] != null)
            {
                List<UploadDocument> documents = Session["UploadDocument"] as List<UploadDocument>;
                var tempfilePath = documents.FindAll(p => p.FileName.Equals(lblFileName.Text)).Select(S => S.UploadFilePath).ToList<string>();
                documents.RemoveAll(p => p.FileName.Equals(lblFileName.Text));
                RemoveTempUploadFile(tempfilePath);
                Session["UploadDocument"] = documents;
                UploadedDocumentGrid.DataSource = documents;
                UploadedDocumentGrid.DataBind();
                UploadedAssetGrid.DataSource = (List<AssetDetails>)Session["AssetUpload"];
                UploadedAssetGrid.DataBind();
                if (documents.Count == 0)
                {
                    dvUploadedDocumentGrid.Style.Add("display", "none;");
                }
                else
                {
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (AssetType.SelectedIndex <= 0 || Category.SelectedIndex <= 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Select Asset Type And Asset Category');", true);
                return;
            }

            if (Session["AssetUpload"] == null)
            {
                lblTotalRecord.Text = string.Empty;
                List<AssetDetails> lstData = Search();
                AssetDetailGrid.EmptyDataText = lstData.Count > 0 ? "No data found  in given filter !!!" : string.Empty;
                AssetDetailsAddGrid.DataSource = null;
                AssetDetailsAddGrid.DataBind();
                btnADD.Style.Add("display", "none");

                if (lstData.Count == 0)
                {
                    AssetDetailGrid.DataSource = null;
                    AssetDetailGrid.DataBind();
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Assets are not found as per given filters.');", true);
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Note : Assets are not found as per given filters.');", true);
                    return;
                }
                lblTotalRecord.Text = lstData.Count > 1 ? "Total Record :" + lstData.Count : "Total Records :" + lstData.Count;
                Session["FilterAssetDetails"] = lstData;
                btnUpload.Attributes.Add("disabled", "disabled");
                btnADD.Style.Add("display", "block");
                TempGridBind(lstData);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Seach Is not allowed !!!');", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void imgDeleteAsset_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsDeleteRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblAssetCode = (Label)row.FindControl("lblAssetCode");


            if (ViewState["AssetDetailsTemp"] != null)
            {
                List<AssetDetails> lstData = (List<AssetDetails>)ViewState["AssetDetailsTemp"];
                if (lblAssetCode != null)
                {
                    var item = lstData.Find(p => p.AssetCode.Equals(lblAssetCode.Text));
                    lstData.Remove(item);
                    AssetDetailsAddGrid.DataSource = lstData;
                    AssetDetailsAddGrid.DataBind();
                    ViewState["AssetDetailsTemp"] = lstData;

                }

            }

        }
        catch (Exception ex)
        {

        }
    }


    protected void btnADD_Click(object sender, EventArgs e)
    {
        try
        {
            //if (!this.IsSaveRight)
            //{
            //   ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
            //    return;
            //}
            List<AssetDetails> lstData = new List<AssetDetails>();
            foreach (GridViewRow row in AssetDetailGrid.Rows)
            {
                CheckBox chk = (CheckBox)row.FindControl("chkAsset");
                if (chk != null && chk.Checked)
                {
                    Label lblAssetCode = (Label)row.FindControl("lblAssetCode");
                    Label lblFAMS_ID = (Label)row.FindControl("lblFAMS_ID");
                    AssetDetails obj = new AssetDetails() { AssetCode = lblAssetCode.Text, FamsID = lblFAMS_ID.Text };
                    lstData.Add(obj);

                }
            }
            List<AssetDetails> alreadyAddedItem = new List<AssetDetails>();

            foreach (GridViewRow item in AssetDetailsAddGrid.Rows)
            {
                Label lblAssetCode = (Label)item.FindControl("lblAssetCode");
                TextBox txtQuantity = (TextBox)item.FindControl("txtQuantity");
                alreadyAddedItem.Add(new AssetDetails { AssetCode = lblAssetCode.Text, Quantity = Convert.ToInt32(txtQuantity.Text) });
            }

            foreach (var item in lstData)
            {
                if (alreadyAddedItem.Find(p => p.AssetCode == item.AssetCode) == null)
                {
                    alreadyAddedItem.Add(item);
                }
            }



            ViewState["AssetDetailsTemp"] = alreadyAddedItem;
            AssetDetailsAddGrid.DataSource = null;
            AssetDetailsAddGrid.DataSource = alreadyAddedItem;
            AssetDetailsAddGrid.DataBind();
            //if (Session["FilterAssetDetails"] != null && Session["FilterAssetDetails"] is List<AssetDetails>)
            //{
            //    var lst = Session["FilterAssetDetails"] as List<AssetDetails>;
            //    foreach (AssetDetails item in lstData)
            //    {
            //        var x = lst.Find(p => p.AssetCode == item.AssetCode);
            //        lst.Remove(x);
            //    }
            if (lstData.Count > 0)
            {
                AssetDetailGrid.EmptyDataText = string.Empty;
                AssetDetailGrid.DataSource = null;
                AssetDetailGrid.DataBind();
                lblTotalRecord.Text = string.Empty;
                Session["FilterAssetDetails"] = null;
                //    if (lst.Count == 0)
                //    {
                btnADD.Style.Add("display", "none");
            }
            //    }
            //}

        }
        catch (Exception ex)
        {

        }
    }
    private void TempGridBind(List<AssetDetails> lstData)
    {
        if (lstData.Count == 0)
        {
            // AssetDetailGrid.EmptyDataText = "No Data Found in given filter !!!";
        }
        AssetDetailGrid.DataSource = lstData;
        AssetDetailGrid.DataBind();
        Session["FilterAssetDetails"] = lstData;
    }

    private void BindAssetType()
    {
        AssetType.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });
        AssetType.Items.Insert(1, new ListItem { Text = "ADMIN", Value = "AD" });
        AssetType.Items.Insert(2, new ListItem { Text = "IT", Value = "IT" });
    }

    private void PopulateCategory()
    {
        CategoryMaster_DAL oDAL = new CategoryMaster_DAL(Session["DATABASE"].ToString());
        Category.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetCategoryCode(AssetType.SelectedItem.Text);
        // dt = oDAL.PopulateCategory(AssetType.SelectedItem.Text, "", 1);
        Category.DataSource = dt;
        Category.DataTextField = "CATEGORY_NAME";
        Category.DataValueField = "CATEGORY_CODE";
        Category.DataBind();
        Category.Items.Insert(0, "-- Select Category --");
    }

    private void PopulateAssetMake(string CategoryCode)
    {
        ddlAssetMake.DataSource = null;
        DataTable dt = new DataTable();
        AssetAcquisition_DAL AssetAcquisitionDAL = new AssetAcquisition_DAL(Session["DATABASE"].ToString());
        dt = AssetAcquisitionDAL.PopulateAssetMake(CategoryCode, Session["COMPANY"].ToString());
        ddlAssetMake.DataSource = dt;
        ddlAssetMake.DataTextField = "ASSET_MAKE";
        ddlAssetMake.DataValueField = "ASSET_MAKE";
        ddlAssetMake.DataBind();
        ddlAssetMake.Items.Insert(0, "-- Select Make --");
    }

    private void PopulateModelName(string AssetMake, string CategoryCode)
    {
        lstModelName.DataSource = null;
        DataTable dt = new DataTable();
        AssetAcquisition_DAL AssetAcquisitionDAL = new AssetAcquisition_DAL(Session["DATABASE"].ToString());
        dt = AssetAcquisitionDAL.PopulateModelName(AssetMake, CategoryCode, Session["COMPANY"].ToString());
        lstModelName.DataSource = dt;
        lstModelName.DataTextField = "MODEL_NAME";
        lstModelName.DataValueField = "MODEL_NAME";
        lstModelName.DataBind();
        lstModelName.Items.Insert(0, "-- Select Model --");
    }


    private List<AssetDetails> Search()
    {
        List<AssetDetails> AssetDetails = new List<AssetDetails>();
        try
        {
            string AssetType = "", AssetCategoryCode = "", AssetMakeName = "", AssetModelName = null;
            AssetType = clsGeneral.gStrAssetType;
            if (Category.SelectedIndex != 0)
                AssetCategoryCode = Category.SelectedValue.ToString();
            else
                AssetCategoryCode = "";

            if (ddlAssetMake.SelectedIndex != 0)
                AssetMakeName = ddlAssetMake.SelectedValue.ToString();
            else
                AssetMakeName = "";

            for (int iCnt = 0; iCnt < lstModelName.Items.Count; iCnt++)
            {
                if (lstModelName.Items[iCnt].Selected)
                    AssetModelName += lstModelName.Items[iCnt].Value.ToString() + ",";
            }
            if (AssetModelName != null)
            {
                AssetModelName = AssetModelName.TrimEnd(',');
                AssetModelName = AssetModelName.Replace(",", "','");
                AssetModelName = "'" + AssetModelName + "'";
            }
            else
                AssetModelName = "";

            AssetAcquisition_DAL AssetAcquisitionDAL = new AssetAcquisition_DAL(Session["DATABASE"].ToString());
            AssetDetails = AssetAcquisitionDAL.GetAssetDetails(AssetType, AssetCategoryCode, AssetMakeName, AssetModelName, Session["COMPANY"].ToString(), Session["CurrentLocation"].ToString());

            return AssetDetails;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }


        return AssetDetails;
    }

    protected void AssetDetailsAddGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridViewRow row = e.Row;
        //int index = 1;
        if (row.RowType == DataControlRowType.DataRow)
        {
            Label lblAssetCode = (Label)row.FindControl("lblAssetCode");
            if (this.InvalidAssets != null && this.InvalidAssets.Exists(p => p.AssetCode == lblAssetCode.Text.Trim()))
            {
                row.Cells[0].Style.Add("background-color", "red");
            }
            //txtQuantity.Attributes.Add("tabindex", index.ToString());
            //index++;
        }
    }
    protected void AssetType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (AssetType.SelectedItem.Text != "SELECT")
            {
                PopulateCategory();
            }
            else
            {
                Category.Items.Clear();
            }
        }
        catch (Exception)
        {


        }
    }

    protected void Category_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (Category.SelectedIndex > 0)
            {
                PopulateAssetMake(Category.SelectedValue.ToString());
                //int CatLevel = int.Parse(lblCatLevel.Text.Trim());
                //lblCatLevel.Text = (CatLevel + 1).ToString();
                //int iCatLevel = int.Parse(lblCatLevel.Text.Trim());
                //string sCatCode = Category.SelectedValue.ToString();
                //ViewState["ParentCatCode"] = sCatCode;
                //lblCatCode.Text = sCatCode;

                //Category.DataSource = null;
                //CategoryMaster_DAL oDAL = new CategoryMaster_DAL(Session["DATABASE"].ToString());
                ////  DataTable dt = oDAL.GetCategoryCode(AssetType.SelectedItem.Text);
                //if (dt.Rows.Count > 0)
                //{
                //    Category.DataSource = dt;
                //    Category.DataValueField = "CATEGORY_CODE";
                //    Category.DataTextField = "CATEGORY_NAME";
                //    Category.DataBind();
                //    Category.Items.Insert(0, "Select");
                //    Category.Focus();
                //}
                //else
                //{
                //    iCatLevel = iCatLevel - 1;
                //    lblCatLevel.Text = iCatLevel.ToString();
                //}
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    protected void ddlAssetMake_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetMake.SelectedIndex != 0)
                PopulateModelName(ddlAssetMake.SelectedValue.ToString(), Category.SelectedValue.ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }


    protected void rdoTempoary_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rdoTempoary.Checked)
            {
                RefreshForm();
                SelectUnit.Style.Add("display", "none");
                TransferTo.Style.Remove("display");

                string _requestType = "Temp";
                AssetRquestDAL _assetRquestDAL = new AssetRquestDAL(Session["DATABASE"].ToString());
                var result = _assetRquestDAL.GetAssetTempRequest(_requestType);
                ddlTempAssetRequest.DataSource = null;
                ddlTempAssetRequest.DataBind();
                if (result.Count > 0)
                {
                    ddlTempAssetRequest.DataSource = result;
                    ddlTempAssetRequest.DataBind();
                }
                ddlTempAssetRequest.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });

                PopulateLocation();
                txtLocationTo.Style.Add("display", "none");
                LocationTo.Style.Add("display", "block");
                //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), " rdoOtherUnit", " rdoOtherUnit();", true);
            }
            else
            {
                SelectUnit.Style.Remove("display");
                TransferTo.Style.Add("display", "none");
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    protected void rdoPermanent_CheckedChanged(object sender, EventArgs e)
    {
        if (rdoPermanent.Checked)
        {
            SelectUnit.Style.Remove("display");
            TransferTo.Style.Add("display", "none");
            RefreshForm();
        }
        else
        {
            SelectUnit.Style.Add("display", "none");

            TransferTo.Style.Remove("display");
        }
    }

    private void PopulateLocation()
    {
        string Company = (string)Session["COMPANY"];


        var loggedInLocation = (string)Session["CurrentLocation"];
        AssetRquestDAL _assetRquestDAL = new AssetRquestDAL(Session["DATABASE"].ToString());
        DataTable location = _assetRquestDAL.GetStoregLocation(loggedInLocation, Company);
        LocationTo.DataSource = null;

        LocationTo.DataSource = location;
        LocationTo.DataTextField = "STORAGE_LOC_NAME";
        LocationTo.DataValueField = "STORAGE_LOC_CODE";
        LocationTo.DataBind();
        LocationTo.Items.Insert(0, "-- Select Location --");

    }
    protected void LocationTo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            Project.DataSource = null;
            Project.DataBind();
            if (rdoTempoary.Checked == false)
            {


                if (LocationTo.SelectedIndex > 0)
                {
                    SubProjectMaster_DAL _subProjectDAL = new SubProjectMaster_DAL(Session["DATABASE"].ToString());
                    DataTable tbl = _subProjectDAL.GetSubProjectDetails(LocationTo.SelectedValue);
                    Project.DataTextField = "SUB_PROJECT_CODE";
                    Project.DataValueField = "SUB_PROJECT_NAME";
                    Project.DataSource = tbl;
                    Project.DataBind();
                    Project.Items.Insert(0, "SELECT");
                }
            }

        }
        catch (Exception)
        {

            throw;
        }

    }
    protected void rdoInnerUnit_CheckedChanged(object sender, EventArgs e)
    {
        if (rdoInnerUnit.Checked)
        {
            Project.Enabled = true;
            PopulateLocation();
            txtLocationTo.Style.Add("display", "none");
            LocationTo.Style.Add("display", "block");
        }

    }
    protected void rdoOtherUnit_CheckedChanged(object sender, EventArgs e)
    {
        if (rdoOtherUnit.Checked)
        {
            txtLocationTo.Style.Add("display", "block");
            LocationTo.Style.Add("display", "none");

            Project.DataSource = null;
            Project.DataBind();
            Project.Items.Clear();
            Project.Enabled = false;
        }
        else
        {
            txtLocationTo.Style.Add("display", "none");
            LocationTo.Style.Add("display", "block");
        }
    }
    protected void btnSubmitRequest_Click(object sender, EventArgs e)
    {
        //if (!this.IsSaveRight)
        //{
        //   ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
        //    return;
        //}
        AssetRequest _request = new AssetRequest();
        AssetRquestDAL DAL = new AssetRquestDAL(Session["DATABASE"].ToString());
        try
        {
            if (!ValidateForm())
            {
                return;
            }
            if (Session["AssetUpload"] != null && Session["AssetUpload"] is List<AssetDetails>)
            {
                _request.AssetDetails = (List<AssetDetails>)Session["AssetUpload"];
            }
            else if (ViewState["AssetDetailsTemp"] != null)
            {
                List<AssetDetails> lstData = (List<AssetDetails>)ViewState["AssetDetailsTemp"];
                _request.AssetDetails = lstData;
            }

            if (_request.AssetDetails.Count == 0)
            {

                lblErrorMsg.Text = "Please upload or add  valid asset  !!!";
                return;
            }
            else if (_request.AssetDetails.Count > 0)
            {
                DataTable tbl = ConvertToDataTable(_request.AssetDetails);
                DAL = new AssetRquestDAL(Session["DATABASE"].ToString());
                List<AssetDetails> InvalidValidAssets = DAL.ValidateAssetDetails(tbl, Convert.ToString(Session["CurrentLocation"]));

                if (InvalidValidAssets.Count > 0)
                {
                    this.InvalidAssets = InvalidValidAssets;
                    AssetDetailsAddGrid.DataSource = null;
                    AssetDetailsAddGrid.DataSource = InvalidValidAssets;
                    AssetDetailsAddGrid.DataBind();
                    ViewState["AssetDetailsTemp"] = InvalidValidAssets;
                    //foreach (GridViewRow item in AssetDetailsAddGrid.Rows)
                    //{
                    //    Label lblAssetCode = (Label)item.FindControl("lblAssetCode");
                    //    if (!ValidAssets.Exists(p => p.AssetCode == lblAssetCode.Text.Trim()))
                    //    {
                    //        lblAssetCode.Style.Add("background-color", "red");
                    //    }
                    //}
                    lblErrorMsg.Text = "Invalid Asset Code " + InvalidValidAssets.Count + " Out of " + _request.AssetDetails.Count;
                    return;
                }
            }


            if (Session["UploadDocument"] != null)
            {
                List<UploadDocument> documents = Session["UploadDocument"] as List<UploadDocument>;
                _request.Documents = documents;
            }

            if (rdoTempoary.Checked)
            {
                _request.TransferTo = ddlTempAssetRequest.SelectedValue;
                _request.LocationTo = LocationTo.SelectedValue;
            }
            else if (rdoPermanent.Checked && rdoInnerUnit.Checked)
            {
                _request.LocationTo = LocationTo.SelectedValue;
                _request.ProjectCode = Project.SelectedValue;
            }
            else if (rdoPermanent.Checked && rdoOtherUnit.Checked)
            {
                _request.LocationTo = txtLocationTo.Text;
            }
            _request.IsPermanent = rdoPermanent.Checked ? true : false;
            _request.IsInterUnit = rdoInnerUnit.Checked ? true : false;
            _request.ReceiverEmail = txtReceiverEmailId.Text;
            _request.GstNo = txtGstNO.Text;
            _request.ProjectCostCentre = txtProjectCost.Text;
            _request.LocationCode = Convert.ToString(Session["CurrentLocation"]);
            _request.CreatedBY = Convert.ToString(Session["CURRENTUSER"]);

            _request.Stage = AssetRequestStage.Raised;


            var RequestConfig = DAL.GetMovementSetting();

            _request.Stage = AssetRequestStage.None;


            if (RequestConfig.Find(p => p.RequestStage == "PMApproval").IsActive == true)
            {
                _request.Stage = AssetRequestStage.Raised;
            }
            else if (RequestConfig.Find(p => p.RequestStage == "CMFApproval").IsActive == true)
            {
                _request.Stage = AssetRequestStage.PMApproved;
            }
            else
            {
                _request.Stage = AssetRequestStage.Raised;
            }



            string _AssetRquestId = DAL.SaveAssetRequest(_request);

            lblErrorMsg.Text = "Request Saved Successfully. Request Id:" + _AssetRquestId;

            RefreshForm();
            rdoTempoary.Checked = false;
            rdoPermanent.Checked = false;

        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }


    private void RefreshForm()
    {
        Session["UploadDocument"] = null;
        ViewState["AssetDetailsTemp"] = null;
        txtGstNO.Text = "";
        txtLocationTo.Text = "";
        txtProjectCost.Text = "";
        txtReceiverEmailId.Text = "";
        ddlTempAssetRequest.DataSource = null;
        ddlTempAssetRequest.DataBind();
        LocationTo.DataSource = null;
        LocationTo.DataBind();
        Project.DataSource = null;
        Project.DataBind();
        rdoInnerUnit.Checked = false;
        rdoOtherUnit.Checked = false;
        AssetType.DataSource = null;
        AssetType.DataBind();
        Category.DataSource = null;
        Category.DataBind();

        ddlAssetMake.DataSource = null;
        ddlAssetMake.DataBind();
        lstModelName.DataSource = null;
        lstModelName.DataBind();
        UploadedAssetGrid.DataSource = null;
        UploadedAssetGrid.DataBind();
        UploadedDocumentGrid.DataSource = null;
        UploadedDocumentGrid.DataBind();
        AssetDetailGrid.DataSource = null;
        AssetDetailGrid.DataBind();
        AssetDetailsAddGrid.DataSource = null;
        AssetDetailsAddGrid.DataBind();
        AssetDetailGrid.EmptyDataText = "";
        dvUploadedDocumentGrid.Style.Add("display", "none");
        dvUploadedAssetGrid.Style.Add("display", "none");
        AssetFilter.Style.Remove("display");
        dvAssetDetails.Style.Remove("display");
        btnSearch.Attributes.Remove("disabled");
        lblTotalRecord.Text = string.Empty;
        ClearAllDropDown();

    }

    private bool ValidateForm()
    {
        try
        {
            if (!rdoTempoary.Checked && !rdoPermanent.Checked)
            {
                lblErrorMsg.Text = "Please Seelct Request !!!";
                return false;
            }
            else if ((rdoTempoary.Checked && ddlTempAssetRequest.SelectedIndex == 0) || (!rdoTempoary.Checked && ddlTempAssetRequest.SelectedIndex > 0))
            {
                lblErrorMsg.Text = "Please Select Tempory Request and Transer To location !!!";
                return false;
            }
            else if (rdoTempoary.Checked && LocationTo.SelectedIndex == 0)
            {
                lblErrorMsg.Text = "Please Select Location To !!!";
                return false;
            }
            else if (rdoPermanent.Checked)
            {
                if (rdoPermanent.Checked && (!rdoInnerUnit.Checked && !rdoOtherUnit.Checked))
                {
                    lblErrorMsg.Text = "Please Select  Innter Unit Or Other Unit !!!";
                    return false;
                }
                else if (rdoInnerUnit.Checked && (LocationTo.SelectedIndex == 0 || Project.SelectedIndex == 0))
                {
                    lblErrorMsg.Text = "Please Select  Location To and  Project !!!";
                    return false;
                }
                else if (rdoOtherUnit.Checked && string.IsNullOrEmpty(txtLocationTo.Text))
                {
                    lblErrorMsg.Text = "Please enter valid To location !!!";
                    return false;
                }
            }

            if (Regex.IsMatch(txtReceiverEmailId.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$") == false)
            {
                lblErrorMsg.Text = "Please enter valid receiver email Id !!!";
                return false;
            }
            else if (string.IsNullOrEmpty(txtGstNO.Text))
            {
                lblErrorMsg.Text = "Please enter valid GST number!!!";
                return false;
            }
            else if (AssetDetailsAddGrid.Rows.Count == 0 && UploadedAssetGrid.Rows.Count == 0)
            {
                lblErrorMsg.Text = "Please upload or add asset details !!!";
                return false;
            }

            return true;
        }
        catch (Exception)
        {
            return false;

        }
    }

    // Clear all dorpdownlist of current form
    private void ClearAllDropDown()
    {
        if (Category.Items.Count > 0)
        {
            Category.Items.Clear();
        }
        if (AssetType.Items.Count > 0)
        {
            AssetType.SelectedIndex = 0;
        }
        if (ddlAssetMake.Items.Count > 0)
        {
            ddlAssetMake.Items.Clear();
        }
        if (LocationTo.Items.Count > 0)
        {
            LocationTo.Items.Clear();
        }

        if (Project.Items.Count > 0)
        {
            Project.Items.Clear();
        }

        if (ddlTempAssetRequest.Items.Count > 0)
        {
            ddlTempAssetRequest.Items.Clear();
        }
    }

    private void RemoveTempUploadFile(List<string> fileNames)
    {


        foreach (var fileName in fileNames)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
            }
            catch (Exception)
            {

            }

        }


    }

    private bool ValidateColumn(DataTable UploadAsset)
    {
        try
        {
            if (UploadAsset.Columns.Cast<DataColumn>().Count() == 1)
            {
                var ColumnName = UploadAsset.Columns.Cast<DataColumn>().FirstOrDefault().ColumnName.ToUpper().Trim();
                if (ColumnName == "ASSETCODE")
                {
                    return true;
                }
            }
            return false;
        }
        catch (Exception)
        {

            return false;
        }
    }

    private List<AssetDetails> ConvertDataTableToList(DataTable uploadAsset)
    {
        List<AssetDetails> _AssetDetials = new List<AssetDetails>();
        try
        {
            foreach (DataRow item in uploadAsset.Rows)
            {
                _AssetDetials.Add(new AssetDetails { AssetCode = Convert.ToString(item["ASSETCODE"]) });
            }
            return _AssetDetials;
        }
        catch (Exception)
        {
            return _AssetDetials;

        }
    }

    private bool ChkEmptyAsset(List<AssetDetails> AssetDetails)
    {
        try
        {
            if (AssetDetails.Count == 0 || AssetDetails.Find(p => string.IsNullOrEmpty(p.AssetCode) == true) == null)
            {
                return false;
            }
            return true;
        }
        catch (Exception)
        {

            throw;
        }
    }


    protected void UploadedAssetGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            GridViewRow row = e.Row;

            if (row.RowType == DataControlRowType.DataRow)
            {
                Label lblAssetCode = (Label)row.FindControl("lblAssetCode");
                if (lblAssetCode != null && Session["AssetUpload"] != null)
                {
                    List<AssetDetails> dtls = (List<AssetDetails>)Session["AssetUpload"];
                    if (dtls.Find(p => p.AssetCode == lblAssetCode.Text) == null)
                    {
                        row.Style.Add("background-color", "red");
                    }
                }

            }
        }
        catch (Exception)
        {


        }
    }


    private DataTable ConvertToDataTable(List<AssetDetails> details)
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn { ColumnName = "AssetCode", DataType = typeof(string) });
        if (details.Count > 0)
        {
            foreach (var item in details)
            {


                DataRow rw = tbl.NewRow();
                rw["AssetCode"] = item.AssetCode;
                tbl.Rows.Add(rw);
            }
        }
        return tbl;
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        try
        {
            AssetType.SelectedIndex = 0;
            Category.SelectedIndex = 0;
            ddlAssetMake.SelectedIndex = 0;
            lstModelName.Items.Clear();
        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message;
        }
    }
    protected void ImgDownload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            var _downloadFilePath = Server.MapPath("~/Templates/MovementReq.xlsx");

            if (File.Exists(_downloadFilePath))
            {
                Response.Redirect("Download.aspx?FileName=" + _downloadFilePath, false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Uploaded document is removed !!!');", true);
            }


        }
        catch (Exception)
        {

        }
    }
}



