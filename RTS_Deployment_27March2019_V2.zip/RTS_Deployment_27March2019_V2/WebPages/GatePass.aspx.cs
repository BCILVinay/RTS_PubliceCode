﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;


public partial class WebPages_GatePass : System.Web.UI.Page
{

    AssetRquestDAL _assetRquestDAL = null;
    string strFilePath = string.Empty;
    private string ClearanceSource = "SOURCE";
    //public string LoggedInLocation = string.Empty;
    //public string LoggedInUser = string.Empty;

    public string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }

    public string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public AssetRequest GatePassRequest
    {
        get
        {
            return ViewState["AssetRequest"] == null ? default(AssetRequest) : (AssetRequest)ViewState["AssetRequest"];
        }
        set
        {
            ViewState["AssetRequest"] = value;
        }
    }

    public string LoggedInDataBaseName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

    public List<UploadDocument> UploadDocuments
    {
        get
        {
            return Session["UploadDocument"] == null ? null : (List<UploadDocument>)Session["UploadDocument"];
        }
        set
        {
            Session["UploadDocument"] = value;
        }
    }
    public AssetRequestStage RequestStage = AssetRequestStage.None;

    protected void Page_Init(object sender, EventArgs e)
    {

        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                this.RequestStage = AssetRequestStage.ClearanceApproved;
                this.BindRequest(this.RequestStage, this.LoggedInLocation);
            }
        }
        catch (Exception ex)
        {

            this.HandleExceptions(ex);
        }
    }

    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetRequest.SelectedIndex > 0)
            {
                var url = "/WebPages/rptGatePassSlip.aspx?RequestId={0}&Location={1}&GT={2}";
                url = string.Format(url, HttpUtility.UrlEncode(UrlEncript.Encrypt(ddlAssetRequest.SelectedValue)), HttpUtility.UrlEncode(UrlEncript.Encrypt(this.LoggedInLocation)), HttpUtility.UrlEncode(UrlEncript.Encrypt(this.LoggedInDataBaseName)));
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "OpenReport", "OpenReport('" +url+ "');", true);
            }
        }
        catch (Exception ex)
        {
            this.HandleExceptions(ex);
        }
    }

    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Asset Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }

    protected void ddlAssetRequest_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            this.GatePassRequest = null;

            if (ddlAssetRequest.SelectedIndex > 0)
            {
                _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);

                var criteria = new AssetSearchCriteria()
                {
                    RequestId = ddlAssetRequest.SelectedValue,
                    DocumentType = UploadDocType.CMF,
                    LocationCode = this.LoggedInLocation,
                    RequestStage = AssetRequestStage.ClearanceApproved
                };

                 this.GatePassRequest = _assetRquestDAL.GetAssetRequest(criteria);

                if (this.GatePassRequest != null)
                {
                    lblStatus.Text = GatePassRequest.Stage.ToString();
                    lblRequestType.Text = GatePassRequest.IsPermanent == true ? "Permanent-" + (GatePassRequest.IsInterUnit ? " InterUnit" : " Wipro To Other") : "Temporary - " + GatePassRequest.TransferTo;
                    lblRequestedDate.Text = GatePassRequest.CreatedOn == null ? string.Empty : ((DateTime)GatePassRequest.CreatedOn).ToString("dd-MMM-yyyy");
                    lblRequestedBy.Text = GatePassRequest.CreatedBY.ToUpper();
                    lblRequestedLocation.Text = GatePassRequest.LocationCode;
                    TranLocation.InnerText = GatePassRequest.IsPermanent ? "Location To" : "Transfer To";
                    lblLocationTo.Text = GatePassRequest.IsPermanent ? GatePassRequest.LocationTo : GatePassRequest.TransferTo;
                    AssetGrid.DataSource = this.GatePassRequest.AssetDetails;
                    AssetGrid.DataBind();
                }
            }
            else
            {
                RefreshForm();
            }

        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }


    private void BindRequest(AssetRequestStage requestStage, string location)
    {
        try
        {
            _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);
            List<string> _requests = _assetRquestDAL.GetRequest(location, requestStage);
            ddlAssetRequest.DataSource = null;
            ddlAssetRequest.Items.Clear();
            ddlAssetRequest.DataSource = _requests;
            ddlAssetRequest.DataBind();
            ddlAssetRequest.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });
        }
        catch (Exception)
        {

            throw;
        }
    }



    private void RefreshForm()
    {
        //ddlAssetRequest.DataSource = null;
        //ddlAssetRequest.DataBind();
        //ddlAssetRequest.Items.Clear();

        lblLocationTo.Text = string.Empty;
        lblRequestedBy.Text = string.Empty;
        lblRequestedDate.Text = string.Empty;
        lblRequestedLocation.Text = string.Empty;
        lblRequestType.Text = string.Empty;
        lblStatus.Text = string.Empty;
        //ViewState["AssetRequest"] = null;
        this.GatePassRequest = null;
        totalClearanceItem.Value = "0";

        this.UploadDocuments = null;
        AssetGrid.DataSource = null;
        AssetGrid.DataBind();
       


    }
}