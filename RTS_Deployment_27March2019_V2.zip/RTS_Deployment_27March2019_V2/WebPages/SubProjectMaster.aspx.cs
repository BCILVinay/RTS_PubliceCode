﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class SubProjectMaster : System.Web.UI.Page
{
    SubProjectMaster_DAL oDAL;
    SubProjectMaster_PRP oPRP;
    public SubProjectMaster()
    {
        oPRP = new SubProjectMaster_PRP();
    }
    ~SubProjectMaster()
    {
        oDAL = null; oPRP = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new SubProjectMaster_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Check user rights for SubProject master operations.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["CURRENTUSER"].ToString() != "test")
                {
                    string _strRights = clsGeneral.GetRights("SUBPROJECTMASTER", (DataTable)Session["UserRights"]);
                    clsGeneral._strRights = _strRights.Split('^');
                    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "SUBPROJECTMASTER");
                    if (clsGeneral._strRights[0] == "0")
                    {
                        Response.Redirect("UnauthorizedUser.aspx", false);
                    }
                }
                PopulateProjectManager(Session["COMPLOCATION"].ToString());
                PopulateProject(Session["COMPLOCATION"].ToString());
                GetSubProjectDetails(Session["COMPLOCATION"].ToString());
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Populate employee code/name for SubProject owner selection.
    /// </summary>
    private void PopulateProjectManager(string LocCode)
    {
        //ddlProcOwner.DataSource = null;
        //DataTable dt = new DataTable();
        //dt = oDAL.GetEmployee(CompCode);
        //ddlProcOwner.DataSource = dt;
        //ddlProcOwner.DataValueField = "EMPLOYEE_CODE";
        //ddlProcOwner.DataTextField = "EMPLOYEE_NAME";
        //ddlProcOwner.DataBind();
        //ddlProcOwner.Items.Insert(0, "-- Select Owner --");
    }

    /// <summary>
    /// Populate department code/name from dropdown selection.
    /// </summary>
    private void PopulateProject(string LocCode)
    {
        ddlProject.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProject(LocCode);
        ddlProject.DataSource = dt;
        ddlProject.DataValueField = "PROJECT_CODE";
        ddlProject.DataTextField = "PROJECT_NAME";
        ddlProject.DataBind();
        ddlProject.Items.Insert(0, "-- Select Project --");
    }

    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "SubProject Master");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            //oBL_ClsLog.SaveLog(Convert.ToString(Session["CURRENTUSER"]).Trim(), "Exception", ex.Message.ToString(), "GROUP MASTER");
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Populate SubProject master details into gridview.
    /// </summary>
    private void GetSubProjectDetails(string LocCode)
    {
        gvSubProjectMaster.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetSubProjectDetails(LocCode);
        gvSubProjectMaster.DataSource = Session["SUBPROJECT"] = dt;
        gvSubProjectMaster.DataBind();
    }
    #endregion

    #region SUBMIT EVENT
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (ddlProject.SelectedIndex != 0)
                oPRP.ProjectCode = ddlProject.SelectedValue.ToString();
            //if (ddlPM.SelectedIndex != 0)
            //    oPRP.ProjectManager = ddlPM.SelectedValue.ToString();
            oPRP.SubProjectCode = txtSubProjectCode.Text.Trim().ToUpper();
            oPRP.SubProjectName = txtSubProjectName.Text.Trim();
            oPRP.ProjectManager = txtProjectManager.Text.Trim();
            oPRP.Remarks = "";
            oPRP.Active = chkSetStatus.Checked;
            oPRP.CreatedBy = Session["CURRENTUSER"].ToString();
            oPRP.LocCode = Session["COMPLOCATION"].ToString();
            bool bResp = oDAL.SaveSubProject(oPRP);
            if (!bResp)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Duplicate SubProject Code cannot be saved.');", true);
                txtSubProjectCode.Focus();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields", "ClearFields();", true);
                upSubmit.Update();
            }
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Export gridview data to excel sheet.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExport_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[4] == "0")
            {
                Response.Redirect("UnauthorizedUser.aspx");
            }
            if (gvSubProjectMaster.Rows.Count > 0)
            {
                Response.Clear();
                DataTable dt = (DataTable)Session["SUBPROJECT"];
                DataSet dsExport = new DataSet();
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                DataGrid dgGrid = new DataGrid();
                dgGrid.DataSource = dt;
                hw.WriteLine("<b><u><font size='5'> " + Session["COMPLOCATION"].ToString() + "</font></u></b>");
                hw.WriteLine("<br>");
                hw.WriteLine("<b><u><font size='4'> SubProject Master</font></u></b>");
                hw.WriteLine("<br>");
                dgGrid.HeaderStyle.Font.Bold = true;
                dgGrid.DataBind();
                dgGrid.RenderControl(hw);
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=SubProjectMaster.xls" );  
                this.EnableViewState = false;
                Response.Write(tw.ToString());
                Response.End();
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Gets SubProject details in delete mode
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = gvSubProjectMaster.Rows[e.RowIndex];
            oPRP.SubProjectCode = ((Label)(gvRow.FindControl("lblProcCode"))).Text.Trim();
            bool DelRslt = oDAL.DeleteSubProject(oPRP.SubProjectCode, Session["COMPLOCATION"].ToString());
            //if (DelRslt == "SubProject_MAPPED")
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
            //       "ShowErrMsg('Please Note : SubProject is mapped with employees, hence cannot be deleted.');", true);
            //    return;
            //}
            //if (DelRslt == "ASSET_MAPPED")
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
            //       "ShowErrMsg('Please Note : SubProject is mapped with assets, hence cannot be deleted.');", true);
            //    return;
            //}
            if (DelRslt)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg",
                       "ShowErrMsg('Please Note : SubProject deleted successfully.');", true);
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Gets SubProject details in edit mode
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = (GridViewRow)gvSubProjectMaster.Rows[e.NewEditIndex];
            ViewState["PROJCT"] = ((Label)gvRow.FindControl("lblProjectCode")).Text.Trim();
            //ViewState["PM"] = ((Label)gvRow.FindControl("lblPMCode")).Text.Trim();
            gvSubProjectMaster.EditIndex = e.NewEditIndex;
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    
    /// <summary>
    /// SubProject details can be updated
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[2] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            GridViewRow gvRow = gvSubProjectMaster.Rows[e.RowIndex];
            oPRP.ProjectCode = ((DropDownList)(gvRow.FindControl("ddlEProjectCode"))).SelectedValue.ToString();
            //oPRP.ProjectManager = ((DropDownList)(gvRow.FindControl("ddlEPMCode"))).SelectedValue.ToString();
            oPRP.SubProjectCode = ((Label)(gvRow.FindControl("lblEProcCode"))).Text.Trim();
            oPRP.SubProjectName = ((TextBox)(gvRow.FindControl("txtEProcName"))).Text.Trim();
            oPRP.ProjectManager = ((TextBox)(gvRow.FindControl("txtEPMCode"))).Text.Trim();
            oPRP.Remarks = "";
            oPRP.Active = ((CheckBox)(gvRow.FindControl("chkEditActive"))).Checked;
            oPRP.ModifiedBy = Session["CURRENTUSER"].ToString();
            oPRP.LocCode = Session["COMPLOCATION"].ToString();
            oDAL.UpdateSubProject(oPRP);

            gvSubProjectMaster.EditIndex = -1;
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// SubProject details are cancelled from edit/update/delete
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvSubProjectMaster.EditIndex = -1;
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    
    /// <summary>
    /// populate SubProject owner dropdownlist inside gridview for edit operation.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //DropDownList ddlEPMCode = (DropDownList)e.Row.FindControl("ddlEPMCode");
                //if (ddlEPMCode != null)
                //{
                //    ddlEPMCode.DataSource = oDAL.GetPRojectManager(Session["COMPLOCATION"].ToString());
                //    ddlEPMCode.DataTextField = "EMPLOYEE_NAME";
                //    ddlEPMCode.DataValueField = "EMPLOYEE_CODE";
                //    ddlEPMCode.DataBind();
                //    ddlEPMCode.Items.Insert(0, "-- Select Project Manager --");
                //    if (ViewState["PM"].ToString() != "")
                //        ddlEPMCode.SelectedIndex = ddlEPMCode.Items.IndexOf(ddlEPMCode.Items.FindByText(ViewState["PM"].ToString()));
                //    else
                //    {
                //        ddlEPMCode.SelectedIndex = ddlEPMCode.Items.IndexOf(ddlEPMCode.Items.FindByText("-- Select Projecty Manager --"));
                //    }
                //}

                DropDownList ddlEProjectCode = (DropDownList)e.Row.FindControl("ddlEProjectCode");
                if (ddlEProjectCode != null)
                {
                    ddlEProjectCode.DataSource = oDAL.GetProject(Session["COMPLOCATION"].ToString());
                    ddlEProjectCode.DataTextField = "PROJECT_NAME";
                    ddlEProjectCode.DataValueField = "PROJECT_CODE";
                    ddlEProjectCode.DataBind();
                    ddlEProjectCode.Items.Insert(0, "-- Select Project --");
                    if (ViewState["PROJCT"].ToString() != "")
                        ddlEProjectCode.SelectedIndex = ddlEProjectCode.Items.IndexOf(ddlEProjectCode.Items.FindByText(ViewState["PROJCT"].ToString()));
                    else
                    {
                        ddlEProjectCode.SelectedIndex = ddlEProjectCode.Items.IndexOf(ddlEProjectCode.Items.FindByText("-- Select Project --"));
                    }
                }

                ImageButton imagebuttonEdit = (ImageButton)e.Row.FindControl("imagebuttonEdit");
                ImageButton imagebuttonDelete = (ImageButton)e.Row.FindControl("imagebuttonDelete");
                if (imagebuttonEdit != null)
                {
                    if (clsGeneral._strRights[2] == "0")
                        imagebuttonEdit.Enabled = false;
                    else
                        imagebuttonEdit.Enabled = true;
                }
                if (imagebuttonDelete != null)
                {
                    if (clsGeneral._strRights[3] == "0")
                        imagebuttonDelete.Enabled = false;
                    else
                        imagebuttonDelete.Enabled = true;
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// SubProject master gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSubProjectMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvSubProjectMaster.PageIndex = e.NewPageIndex;
            GetSubProjectDetails(Session["COMPLOCATION"].ToString());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion
}