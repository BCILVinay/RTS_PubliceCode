﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebPages_AssetClearanceReq : System.Web.UI.Page
{

    private bool IsViewRight
    {
        get
        {
            return ViewState["IsViewRight"] == null ? false : (bool)ViewState["IsViewRight"];
        }
        set
        {
            ViewState["IsViewRight"] = value;
        }
    }
    private bool IsSaveRight
    {
        get
        {
            return ViewState["IsSaveRight"] == null ? false : (bool)ViewState["IsSaveRight"];
        }
        set
        {
            ViewState["IsSaveRight"] = value;
        }
    }
    private bool IsEditRight
    {
        get
        {
            return ViewState["IsEditRight"] == null ? false : (bool)ViewState["IsEditRight"];
        }
        set
        {
            ViewState["IsEditRight"] = value;
        }
    }
    private bool IsDeleteRight
    {

        get
        {
            return ViewState["IsDeleteRight"] == null ? false : (bool)ViewState["IsDeleteRight"];
        }
        set
        {
            ViewState["IsDeleteRight"] = value;
        }

    }
    private bool IsExportRight
    {
        get
        {
            return ViewState["IsExportRight"] == null ? false : (bool)ViewState["IsExportRight"];
        }
        set
        {
            ViewState["IsExportRight"] = value;
        }
    }


    AssetRquestDAL _assetRquestDAL = null;
    string strFilePath = string.Empty;
    private string ClearanceSource = "SOURCE";
    //public string LoggedInLocation = string.Empty;
    //public string LoggedInUser = string.Empty;

    public string LoggedInUser
    {
        get
        {
            return Session["CURRENTUSER"] == null ? string.Empty : Convert.ToString(Session["CURRENTUSER"]);
        }

    }

    public string LoggedInLocation
    {
        get
        {
            return Session["CurrentLocation"] == null ? string.Empty : Convert.ToString(Session["CurrentLocation"]);
        }
    }

    public AssetRequest ClearanceRequest
    {
        get
        {
            return ViewState["AssetRequest"] == null ? default(AssetRequest) : (AssetRequest)ViewState["AssetRequest"];
        }
        set
        {
            ViewState["AssetRequest"] = value;
        }
    }

    public string LoggedInDataBaseName
    {
        get
        {
            return Session["DATABASE"] == null ? string.Empty : Convert.ToString(Session["DATABASE"]);
        }
    }

    public List<UploadDocument> UploadDocuments
    {
        get
        {
            return Session["UploadDocument"] == null ? null : (List<UploadDocument>)Session["UploadDocument"];
        }
        set
        {
            Session["UploadDocument"] = value;
        }
    }

    private void SetPageRights()
    {
        try
        {
            string _strRights = clsGeneral.GetRights("MOVEMENT_CLEARANCE", (DataTable)Session["UserRights"]);
            clsGeneral._strRights = _strRights.Split('^');
            this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
            this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
            this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
            this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
            this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

            clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
            if (!this.IsViewRight)
            {
                Response.Redirect("UnauthorizedUser.aspx", false);
                return;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {

        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            //try
            //{
            //    string _strRights = clsGeneral.GetRights("ASSET_CLEARANCE", (DataTable)Session["UserRights"]);
            //    clsGeneral._strRights = _strRights.Split('^');

            //    this.IsViewRight = clsGeneral._strRights[0] == "0" ? false : true;
            //    this.IsSaveRight = clsGeneral._strRights[1] == "0" ? false : true;
            //    this.IsEditRight = clsGeneral._strRights[2] == "0" ? false : true;
            //    this.IsDeleteRight = clsGeneral._strRights[3] == "0" ? false : true;
            //    this.IsExportRight = clsGeneral._strRights[4] == "0" ? false : true;

            //    clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "ASSET_ALLOCATION");
            //    if (!this.IsViewRight)
            //    {
            //        Response.Redirect("UnauthorizedUser.aspx", false);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Response.Redirect("UnauthorizedUser.aspx", false);
            //}

            if (!Page.IsPostBack)
            {

                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);

                SetPageRights();

                this.UploadDocuments = null;
                this.ClearanceRequest = null;
                BindRequest();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void ddlAssetRequest_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            this.ClearanceRequest = null;
            if (ddlAssetRequest.SelectedIndex > 0)
            {
                var loggedInLocation = this.LoggedInLocation;
                _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);

                var criteria = new AssetSearchCriteria()
                {
                    RequestId = ddlAssetRequest.SelectedValue,
                    DocumentType = UploadDocType.CMF,
                    LocationCode = loggedInLocation,
                    RequestStage = AssetRequestStage.CMFApproved
                };
                //var _request = _assetRquestDAL.GetAssetRequest(criteria);
                //var _clearance = _assetRquestDAL.GetAssetClearance(_request, "Source");
                var _request = _assetRquestDAL.GetClearanceRequest(criteria, this.ClearanceSource);
                this.ClearanceRequest = _request.AssetRequest;
                if (this.ClearanceRequest != null)
                {
                    var totalClearanceCtr = _request.AssetClerance.FindAll(p => p.IsClearanced).Count;

                    totalClearanceItem.Value = Convert.ToString(totalClearanceCtr == _request.AssetClerance.Count ? 0 : totalClearanceCtr);  // loginc for if all select already then not check validation for

                    //  ViewState["AssetRequest"] = _request;
                    lblStatus.Text = ClearanceRequest.Stage.ToString();
                    lblRequestType.Text = ClearanceRequest.IsPermanent == true ? "Permanent-" + (ClearanceRequest.IsInterUnit ? " InterUnit" : " Wipro To Other") : "Temporary - " + ClearanceRequest.TransferTo;
                    lblRequestedDate.Text = ClearanceRequest.CreatedOn == null ? string.Empty : ((DateTime)ClearanceRequest.CreatedOn).ToString("dd-MMM-yyyy");
                    lblRequestedBy.Text = ClearanceRequest.CreatedBY.ToUpper();
                    lblRequestedLocation.Text = ClearanceRequest.RequestedLocName;

                    TranLocation.InnerText = ClearanceRequest.IsPermanent ? "Location To" : "Transfer To";
                    lblLocationTo.Text = ClearanceRequest.IsPermanent ? ClearanceRequest.RequestedToLocName : ClearanceRequest.RequestedToLocName;
                    AssetClearanceGrid.DataSource = _request.AssetClerance;
                    AssetClearanceGrid.DataBind();
                    ReuestDetails.Style.Remove("display");
                    CheckAlreadeyClearanceReceived(_request.AssetClerance);
                }
            }
            else
            {
                RefreshForm();
                //AssetClearanceGrid.DataSource = null;
                //AssetClearanceGrid.DataBind();
            }

        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void btnApprove_Click(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<AssetClearance> Clearance = GetAssetClearance(AssetClearanceGrid);
            AssetRequestStage stage = AssetRequestStage.ClearanceApproved;
            if (ValidateForm(Clearance, stage))
            {
                ClearanceAction(stage, Clearance);
                RefreshForm();
                BindRequest();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }
    protected void btnReject_Click(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<AssetClearance> Clearance = GetAssetClearance(AssetClearanceGrid);
            AssetRequestStage stage = AssetRequestStage.ClearanceReject;
            if (ValidateForm(Clearance, stage))
            {
                ClearanceAction(stage, Clearance);
                RefreshForm();
                BindRequest();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<AssetClearance> Clearance = GetAssetClearance(AssetClearanceGrid);
            AssetRequestStage stage = AssetRequestStage.None;
            if (ValidateForm(Clearance, stage))
            {
                ClearanceAction(stage, Clearance);
                RefreshForm();
                BindRequest();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void AssetClearanceGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            GridViewRow row = e.Row;
            if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkIsClearance = (CheckBox)row.FindControl("chkClearance");
                TextBox txtRemarks = (TextBox)row.FindControl("txtRemarks");
                TextBox CleranceOn = (TextBox)row.FindControl("txtClearanceDate");

                if (chkIsClearance.Checked)
                {
                    chkIsClearance.Attributes.Add("disabled", "disabled");
                    chkIsClearance.Enabled = false;
                    txtRemarks.Enabled = false;
                    CleranceOn.Enabled = false;

                    txtRemarks.Style.Add("width", "200px");
                    CleranceOn.Style.Add("width", "200px");
                    txtRemarks.Attributes.Add("disabled", "disabled");
                    CleranceOn.Attributes.Add("disabled", "disabled");
                }
                if (string.IsNullOrEmpty(CleranceOn.Text) || Convert.ToDateTime(CleranceOn.Text) == DateTime.MinValue)
                {
                    CleranceOn.Text = string.Empty;
                }
            }
        }
        catch (Exception)
        {


        }
    }


    private void BindRequest()
    {
        try
        {
            var LoggedInLocation = this.LoggedInLocation;
            _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);
            AssetRequestStage _stage = AssetRequestStage.CMFApproved;

            List<string> _requests = _assetRquestDAL.GetRequest(LoggedInLocation, _stage);
            ddlAssetRequest.DataSource = null;
            ddlAssetRequest.Items.Clear();
            ddlAssetRequest.DataSource = _requests;
            ddlAssetRequest.DataBind();
            ddlAssetRequest.Items.Insert(0, new ListItem { Text = "SELECT", Value = "SELECT" });
        }
        catch (Exception)
        {

            throw;
        }
    }


    private void CheckAlreadeyClearanceReceived(List<AssetClearance> clearance)
    {
        if (clearance.FindAll(p => p.IsClearanced).Count == clearance.Count)
        {
            CheckBox chkAll = (CheckBox)AssetClearanceGrid.HeaderRow.FindControl("chkAllClearance");

            if (chkAll != null)
            {
                chkAll.Checked = true;
                chkAll.Enabled = false;
                btnSave.Enabled = false;
            }
        }
    }

    private List<AssetClearance> GetAssetClearance(GridView AssetClearanceGrid)
    {
        List<AssetClearance> _clearance = new List<AssetClearance>();
        try
        {

            foreach (GridViewRow row in AssetClearanceGrid.Rows)
            {
                CheckBox chkClearance = (CheckBox)row.FindControl("chkClearance");
                if (chkClearance.Checked)
                {
                    Label lblDescription = (Label)row.FindControl("lblDescription");
                    TextBox txtRemarks = (TextBox)row.FindControl("txtRemarks");
                    TextBox lblClearanceOn = (TextBox)row.FindControl("txtClearanceDate");
                    Label lblClearanceBy = (Label)row.FindControl("lblClearanceBy");
                    Label lblClearanceCode = (Label)row.FindControl("lblClearanceCode");
                    Label lblType = (Label)row.FindControl("lblType");

                    DateTime? dtClearanceOn = default(DateTime?);
                    try
                    {


                        if (!string.IsNullOrEmpty(lblClearanceOn.Text))
                        {

                            if (lblClearanceOn.Text.Contains("-"))
                            {
                                var dt = lblClearanceOn.Text.Split('-');
                                dtClearanceOn = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(GetMonth(dt[1])), Convert.ToInt32(dt[0]));
                            }
                            else if (lblClearanceOn.Text.Contains('/'))
                            {
                                var dt = lblClearanceOn.Text.Split('/');
                                dtClearanceOn = new DateTime(Convert.ToInt32(dt[2]), Convert.ToInt32(GetMonth(dt[1])), Convert.ToInt32(dt[0]));
                            }
                            else
                            {

                            }


                        }
                    }
                    catch (Exception)
                    {

                    }

                    var clearanceItem = new AssetClearance()
                    {
                        ClearanceCode = Convert.ToInt32(lblClearanceCode.Text),
                        Description = lblDescription.Text,
                        Remarks = txtRemarks.Text.Trim(),
                        IsClearanced = true,
                        Type = lblType.Text,
                        ClearanceOn = dtClearanceOn,
                        ClearanceBy = Convert.ToString(lblClearanceBy.Text == string.Empty ? this.LoggedInUser : lblClearanceBy.Text)
                    };

                    _clearance.Add(clearanceItem);
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
        return _clearance;
    }

    private bool ValidateForm(List<AssetClearance> clearance, AssetRequestStage stage)
    {

        if (ddlAssetRequest.SelectedIndex == 0)
        {
            lblErrorMsg.Text = "Please Select Request";
            return false;
        }
        else if (clearance.Count == 0)
        {
            lblErrorMsg.Text = "Please Select  At Least one clearance for " + (stage == AssetRequestStage.None ? " Save" : stage == AssetRequestStage.ClearanceReject ? "Reject" : " Approve") + " Clearance";
            return false;
        }
        else if (Convert.ToInt32(totalClearanceItem.Value) == clearance.Count && stage == AssetRequestStage.None)
        {
            lblErrorMsg.Text = "Please Select Clearance for Approval";
            return false;
        }
        foreach (var item in clearance)
        {
            if (string.IsNullOrEmpty(item.Remarks))
            {
                lblErrorMsg.Text = "Please Enter Remarks.";
                return false;
            }
            else if (item.ClearanceOn == null)
            {
                lblErrorMsg.Text = "Please Enter valid  clearance date format dd/mmm/yyyy ";
                return false;
            }
        }

        return true;
    }

    private void ClearanceAction(AssetRequestStage stage, List<AssetClearance> Clearance)
    {
        _assetRquestDAL = new AssetRquestDAL(this.LoggedInDataBaseName);

        AssetRequest request = (AssetRequest)this.ClearanceRequest;

        //   if (AssetClearanceGrid.Rows.Count == Clearance.Count)
        if (stage == AssetRequestStage.ClearanceApproved || stage == AssetRequestStage.ClearanceReject)
        {

            request.IsClerance = (stage == AssetRequestStage.ClearanceApproved) ? true : false;
            request.ClearanceBy = this.LoggedInUser;
            request.ClearanceOn = DateTime.Now;
            request.Stage = stage;
        }
        Clearance _clearance = new Clearance();
        _clearance.AssetRequest = request;
        _clearance.AssetClerance = Clearance;
        _clearance.Documents = this.UploadDocuments;
        var affectedRecord = _assetRquestDAL.SaveAssetClearance(_clearance);
        if (affectedRecord > 0)
        {
            lblErrorMsg.Text = stage == AssetRequestStage.ClearanceApproved ? " Clearance Approced Successfully" : stage == AssetRequestStage.ClearanceReject ? " Clearance Rejected Successfully" : "Clearance Saved Successfully";
        }

    }



    private void RefreshForm()
    {
        //ddlAssetRequest.DataSource = null;
        //ddlAssetRequest.DataBind();
        //ddlAssetRequest.Items.Clear();
        AssetClearanceGrid.DataSource = null;
        AssetClearanceGrid.DataBind();
        ReuestDetails.Style.Add("display", "none");
        lblLocationTo.Text = string.Empty;
        lblRequestedBy.Text = string.Empty;
        lblRequestedDate.Text = string.Empty;
        lblRequestedLocation.Text = string.Empty;
        lblRequestType.Text = string.Empty;
        lblStatus.Text = string.Empty;
        //ViewState["AssetRequest"] = null;
        this.ClearanceRequest = null;
        totalClearanceItem.Value = "0";

        this.UploadDocuments = null;
        UploadedDocumentGrid.DataSource = null;
        UploadedDocumentGrid.DataBind();
        ViewDocumentGrid.DataSource = null;
        ViewDocumentGrid.DataBind();

    }
    private int GetMonth(string month)
    {
        Dictionary<string, int> dictmonth = new Dictionary<string, int>();
        dictmonth.Add("JAN", 1);
        dictmonth.Add("FEB", 2);
        dictmonth.Add("MAR", 3);
        dictmonth.Add("APR", 4);
        dictmonth.Add("MAY", 5);
        dictmonth.Add("JUN", 6);
        dictmonth.Add("JUL", 7);
        dictmonth.Add("AUG", 8);
        dictmonth.Add("SEP", 9);
        dictmonth.Add("OCT", 10);
        dictmonth.Add("NOV", 11);
        dictmonth.Add("DEC", 12);

        if (dictmonth.ContainsKey(month.ToUpper()))
        {
            return dictmonth.FirstOrDefault(p => p.Key == month.ToUpper()).Value;
        }
        return 0;

    }

    private void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Movement Clearance Request");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Response.Redirect("Error.aspx");
        }
    }


    #region Upload Docuent Code

    protected void btnDocumentUpload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            List<UploadDocument> UploadFiles = new List<UploadDocument>();
            List<string> ValidFile = new List<string>();
            var files = Request.Files;
            if (files.Count > 0)
            {
                string fileName = string.Empty;
                for (int i = 0; i < files.Count; i++)
                {
                    HttpPostedFile userPostedFile = files[i];
                    var fileExt = System.IO.Path.GetExtension(userPostedFile.FileName);
                    if (!string.IsNullOrEmpty(userPostedFile.FileName))
                    {

                        //if (fileExt.ToLower() != ".xls".ToLower() && fileExt.ToLower() != ".XLS".ToLower() && fileExt.ToLower() != ".xlsx".ToLower())
                        //{
                            var ext = Path.GetExtension(userPostedFile.FileName);
                            var fileNameWithoutExt = Path.GetFileName(userPostedFile.FileName).Replace(ext, "").Trim();
                            strFilePath = Request.PhysicalApplicationPath + "UploadedFiles\\TempDocument\\" + fileNameWithoutExt + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;


                            if (File.Exists(strFilePath))
                            {
                                File.Delete(strFilePath);
                            }

                            AssetDocumentUpload.SaveAs(strFilePath);


                            FileInfo info = new FileInfo(strFilePath);
                            var fileLength = info.Length;

                            if (fileLength > 0 && Decimal.Divide(fileLength, 1048576) <= 5)// TotalBytes = 1048576)
                            {
                                UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, UploadFilePath = strFilePath, DocumentType = UploadDocType.CLRREQ, IsValid = "YES", Remark = txtUploadRemarks.Text });
                            }
                            else
                            {
                                fileName = fileName + userPostedFile.FileName + ",";
                            }

                        //}

                        //else
                        //{
                        //    UploadFiles.Add(new UploadDocument { FileName = userPostedFile.FileName, IsValid = "NO" });
                        //}
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Please Seelct File !!!');", true);
                    }
                }

                if (!string.IsNullOrEmpty(fileName))
                {
                    lblErrorMsg.Text = "Invalid File : file size greather than 5 MB " + fileName;
                }

                if (UploadFiles.Count > 0)
                {
                    if (this.UploadDocuments != null && this.UploadDocuments.Count > 0)
                    {
                        var FilesUploaded = this.UploadDocuments;
                        UploadFiles.AddRange(FilesUploaded);
                    }
                    UploadedDocumentGrid.DataSource = UploadFiles;
                    UploadedDocumentGrid.DataBind();
                    this.UploadDocuments = UploadFiles;
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                    txtUploadRemarks.Text = string.Empty;
                }

            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    protected void UploadedDocumentGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        GridViewRow row = e.Row;
        if (row.RowType == DataControlRowType.DataRow)
        {
            Label lblIsValid = (Label)row.FindControl("lblIsValid");
            if (lblIsValid != null && lblIsValid.Text == "NO")
            {
                row.Style.Add("background-color", "#ff531a");
                row.Attributes.Add("tooltip", "Invalid File format");
            }
            else
            {
                row.Style.Add("background-color", "#59b300");
                row.Attributes.Add("tooltip", "Valid File format");
            }
        }
    }


    protected void ImgDelete_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsDeleteRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblFileName = (Label)row.FindControl("lblFileName");
            if (this.UploadDocuments != null && this.UploadDocuments.Count > 0)
            {
                List<UploadDocument> documents = this.UploadDocuments;
                var tempfilePath = documents.FindAll(p => p.FileName.Equals(lblFileName.Text)).Select(S => S.UploadFilePath).ToList<string>();
                documents.RemoveAll(p => p.FileName.Equals(lblFileName.Text));
                RemoveTempUploadFile(tempfilePath);
                this.UploadDocuments = documents;
                UploadedDocumentGrid.DataSource = documents;
                UploadedDocumentGrid.DataBind();

                if (documents.Count == 0)
                {
                    dvUploadedDocumentGrid.Style.Add("display", "none;");
                }
                else
                {
                    dvUploadedDocumentGrid.Style.Add("display", "block ;");
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }

    private void RemoveTempUploadFile(List<string> fileNames)
    {


        foreach (var fileName in fileNames)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
            }
            catch (Exception)
            {

            }

        }


    }

    #endregion
    protected void btnViewUploadDocument_Click(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsSaveRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            if (this.ClearanceRequest != null && (this.ClearanceRequest.Documents != null && this.ClearanceRequest.Documents.Count > 0))
            {
                ViewDocumentGrid.DataSource = this.ClearanceRequest.Documents;
                ViewDocumentGrid.DataBind();
                dvViewDocument.Style.Add("display", "block");
            }
            else
            {
                dvViewDocument.Style.Remove("display");
            }
        }
        catch (Exception ex)
        {

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('" + ex.Message + "');", true);
            HandleExceptions(ex);
        }
    }
    protected void ViewDocumentGrid_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            GridViewRow row = e.Row;
            if (row.RowType == DataControlRowType.DataRow)
            {
                Label lblFileName = (Label)row.FindControl("lblUploadFileName");
                if (lblFileName != null)
                {
                    var fileName = lblFileName.Text;
                    lblFileName.Text = lblFileName.Text.Split('_')[0] + Path.GetExtension(fileName);
                }
            }
        }
        catch (Exception)
        {


        }
    }
    protected void ImgDownload_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (!this.IsExportRight)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            ImageButton btn = (ImageButton)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Label lblDocumentId = (Label)row.FindControl("lblViewDocumentId");

            if (this.ClearanceRequest != null && this.ClearanceRequest.Documents != null && this.ClearanceRequest.Documents.Count > 0)
            {
                List<UploadDocument> documents = this.ClearanceRequest.Documents;
                var tempfilePath = documents.FindAll(p => p.DocumentDetailId == Convert.ToInt32(lblDocumentId.Text.Trim())).Select(S => S.UploadDBFilePath).FirstOrDefault().ToString();

                var _downloadFilePath = Server.MapPath("~/UploadedFiles/" + tempfilePath);
                if (File.Exists(_downloadFilePath))
                {
                    Response.Redirect("Download.aspx?FileName=" + _downloadFilePath, false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowAlert", "ShowAlert('Uploaded document is removed !!!');", true);
                }


            }
        }
        catch (Exception)
        {


        }
    }
}