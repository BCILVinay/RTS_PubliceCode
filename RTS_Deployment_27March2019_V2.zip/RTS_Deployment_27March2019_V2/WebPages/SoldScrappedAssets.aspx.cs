﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.DAL;
using MobiVUE_ATS.PRP;

public partial class SoldScrappedAssets : System.Web.UI.Page
{
    AssetAcquisition_DAL oDAL;
    AssetAcquisition_PRP oPRP;
    public SoldScrappedAssets()
    {
        oPRP = new AssetAcquisition_PRP();
    }
    ~SoldScrappedAssets()
    {
        oPRP = null;
        oDAL = null;
    }

    #region PAGE EVENTS
    /// <summary>
    /// Navigates to session expired page in case of user logs off/session expired.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Init(object sender, EventArgs e)
    {
        if (Session["CURRENTUSER"] == null)
        {
            Server.Transfer("SessionExpired.aspx");
        }
        oDAL = new AssetAcquisition_DAL(Session["DATABASE"].ToString());
    }

    /// <summary>
    /// Checking user group rights for update asset status as sold/scrapped.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
                string _strRights = clsGeneral.GetRights("SOLD_SCRAPPED_ASSET", (DataTable)Session["UserRights"]);
                clsGeneral._strRights = _strRights.Split('^');
                clsGeneral.LogUserOperationToLogFile(Session["CURRENTUSER"].ToString(), Session["COMP_NAME"].ToString(), "SOLD_SCRAPPED_ASSET");
                if (clsGeneral._strRights[0] == "0")
                {
                    Response.Redirect("UnauthorizedUser.aspx", false);
                } 
                ddlAssetType.SelectedValue = clsGeneral.gStrAssetType;
                lblAssetType.Text = clsGeneral.gStrAssetType;
                PopulateCategory(lblAssetType.Text.Trim());
                GetVendor();
                GetProcess();
                GetSoldScrappedDetails();
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion

    #region PRIVATE FUNCTIONS
    /// <summary>
    /// Fetch Vendor details to be populated in dropdownlist.
    /// </summary>
    private void GetVendor()
    {
        ddlVendor.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateVendor(Session["COMPANY"].ToString());
        ddlVendor.DataSource = dt;
        ddlVendor.DataTextField = "VENDOR_NAME";
        ddlVendor.DataValueField = "VENDOR_CODE";
        ddlVendor.DataBind();
        ddlVendor.Items.Insert(0, "-- Select Vendor --");
    }

    /// <summary>
    /// Fetch Process details to be populated in dropdownlist.
    /// </summary>
    private void GetProcess()
    {
        ddlProcess.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetProcess(Session["COMPANY"].ToString());
        ddlProcess.DataSource = dt;
        ddlProcess.DataTextField = "PROJECT_NAME";
        ddlProcess.DataValueField = "PROJECT_CODE";
        ddlProcess.DataBind();
        ddlProcess.Items.Insert(0, "-- Select Project --");
    }

    /// <summary>
    /// Fetch category details to be populated in dropdownlist.
    /// </summary>
    private void PopulateCategory(string AssetType)
    {
        lblCatCode.Text = "0";
        lblCatLevel.Text = "1";
        ddlAssetCategory.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateCategory(AssetType.Trim(), "", 1);
        ddlAssetCategory.DataSource = dt;
        ddlAssetCategory.DataTextField = "CATEGORY_NAME";
        ddlAssetCategory.DataValueField = "CATEGORY_CODE";
        ddlAssetCategory.DataBind();
        ddlAssetCategory.Items.Insert(0, "-- Select Category --");
    }

    /// <summary>
    /// Fetch asset make to be populated in dropdownlist.
    /// </summary>
    private void PopulateAssetMake(string CategoryCode)
    {
        ddlAssetMake.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateAssetMake(CategoryCode, Session["COMPANY"].ToString());
        ddlAssetMake.DataSource = dt;
        ddlAssetMake.DataTextField = "ASSET_MAKE";
        ddlAssetMake.DataValueField = "ASSET_MAKE";
        ddlAssetMake.DataBind();
        ddlAssetMake.Items.Insert(0, "-- Select Make --");
    }

    /// <summary>
    /// Fetch asset model name to be populated in dropdownlist.
    /// </summary>
    /// <param name="AssetMake"></param>
    private void PopulateModelName(string AssetMake, string CategoryCode)
    {
        lstModelName.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.PopulateModelName(AssetMake, CategoryCode, Session["COMPANY"].ToString());
        lstModelName.DataSource = dt;
        lstModelName.DataTextField = "MODEL_NAME";
        lstModelName.DataValueField = "MODEL_NAME";
        lstModelName.DataBind();
        lstModelName.Items.Insert(0, "-- Select Model --");
    }

    /// <summary>
    /// Catch unhandled exceptions.
    /// </summary>
    /// <param name="ex"></param>
    public void HandleExceptions(Exception ex)
    {
        clsGeneral.LogErrorToLogFile(ex, "Sold/Scrapped Assets");
        if (!ex.Message.ToString().Contains("Thread was being aborted."))
        {
            //oBL_ClsLog.SaveLog(Convert.ToString(Session["CURRENTUSER"]).Trim(), "Exception", ex.Message.ToString(), "GROUP MASTER");
            clsGeneral.ErrMsg = ex.Message.ToString(); try { string[] arrErr = ex.Message.ToString().Split('\n'); Session["ErrMsg"] = arrErr[0].ToString().Trim(); }
            catch { } Server.Transfer("Error.aspx");
        }
    }

    /// <summary>
    /// Get asset details for updating status as sold/scrapped.
    /// </summary>
    private void GetAssetDetailsForSoldScrapped()
    {
        oPRP.CompCode = Session["COMPANY"].ToString();
        oPRP.AssetCode = txtAssetCode.Text.Trim();
        oPRP.AssetSerialCode = txtSerialCode.Text.Trim();
        if (ddlAssetMake.SelectedIndex != 0)
            oPRP.AssetMakeName = ddlAssetMake.SelectedValue.ToString();
        else
            oPRP.AssetMakeName = "";
        for (int iCnt = 0; iCnt < lstModelName.Items.Count; iCnt++)
        {
            if (lstModelName.Items[iCnt].Selected)
                oPRP.AssetModelName += lstModelName.Items[iCnt].Text.ToString() + ",";
        }
        if (oPRP.AssetModelName != null)
        {
            oPRP.AssetModelName = oPRP.AssetModelName.TrimEnd(',');
            oPRP.AssetModelName = oPRP.AssetModelName.Replace(",", "','");
            oPRP.AssetModelName = "'" + oPRP.AssetModelName + "'";
        }
        else
            oPRP.AssetModelName = "";
        if (ddlAssetType.SelectedIndex != 0)
            oPRP.AssetType = ddlAssetType.SelectedValue.ToString();
        if (ddlAssetCategory.SelectedIndex != 0)
            oPRP.AssetCategoryCode = ddlAssetCategory.SelectedValue.ToString();
        else
            oPRP.AssetCategoryCode = "";
        if (ddlProcess.SelectedIndex != 0)
            oPRP.AssetProcess = ddlProcess.SelectedValue.ToString();
        else
            oPRP.AssetProcess = "";

        gvAssetSoldScrapped.DataSource = null;
        DataTable dt = new DataTable();
        if (rdoScrapped.Checked)
            dt = oDAL.GetAssetDetailsForSoldScrapped("SCRAPPED", oPRP);
        else
            dt = oDAL.GetAssetDetailsForSoldScrapped("SOLD", oPRP);
        if (dt.Rows.Count > 0)
        {
            gvAssetSoldScrapped.DataSource = dt;
            gvAssetSoldScrapped.DataBind();
            gvAssetSoldScrapped.Visible = true;
            lblAssetCount.Text = "Assets Count : " + dt.Rows.Count.ToString();
        }
        else
        {
            gvAssetSoldScrapped.DataSource = null;
            gvAssetSoldScrapped.DataBind();
            lblAssetCount.Text = "Assets Count : 0";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Either assets are in another location or filter criteria is incorrect.');", true);
            return;
        }
    }

    /// <summary>
    /// Get asset sold/scrapped details in the girdview to be viewed.
    /// </summary>
    private void GetSoldScrappedDetails()
    {
        gvSoldScrapped.DataSource = null;
        DataTable dt = new DataTable();
        dt = oDAL.GetSoldScrappedDetails(Session["COMPANY"].ToString());
        if (dt.Rows.Count > 0)
        {
            gvSoldScrapped.DataSource = Session["SOLD_SCRAPPED"] = dt;
            gvSoldScrapped.DataBind();
            btnExport.Visible = true;
        }
        else
        {
            gvSoldScrapped.DataSource = null;
            gvSoldScrapped.DataBind();
            btnExport.Visible = false;
        }
    }
    #endregion

    #region BUTTON EVENTS
    /// <summary>
    /// Refresh/reset category to be populated in the dropdownlist.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnRefreshCategory_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PopulateCategory(lblAssetType.Text);
            DataTable dt = new DataTable();
            ddlAssetMake.DataSource = dt;
            ddlAssetMake.DataBind();
            lstModelName.DataSource = dt;
            lstModelName.DataBind();
            dt = null;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Update asset status as sold/scrapped.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[1] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            bool bAssetSelected = false;
            bool bResp = false;
            oPRP.RefInvoiceNo = txtRefInvoiceNo.Text.Trim();
            oPRP.VendorCode = ddlVendor.SelectedValue.ToString();
            oPRP.CompCode = Session["COMPANY"].ToString();
            if (rdoSold.Checked)
            {
                if (ddlVendor.SelectedIndex == 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Vendor name is mandatory!');", true);
                    ddlVendor.Focus();
                    return;
                }
                if (txtContactName.Text.Trim() == "")
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Contact name is mandatory!');", true);
                    txtContactName.Focus();
                    return;
                }
                if (txtSoldDate.Text.Trim() == "")
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Sold date is mandatory!');", true);
                    txtSoldDate.Focus();
                    return;
                }
                if (txtCompanyAddress.Text.Trim() == "")
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Company address is mandatory!');", true);
                    txtCompanyAddress.Focus();
                    return;
                }
                for (int iCnt = 0; iCnt < gvAssetSoldScrapped.Rows.Count; iCnt++)
                {
                    if (((CheckBox)gvAssetSoldScrapped.Rows[iCnt].FindControl("chkSelect")).Checked == true)
                    {
                        bAssetSelected = true;
                        break;
                    }
                }
                if (!bAssetSelected)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Select at least one asset to be saved as sold.');", true);
                    return;
                }
                oPRP.ContactName = txtContactName.Text.Trim();
                oPRP.CompanyAddress = txtCompanyAddress.Text.Trim();
                oPRP.CompanyEmail = txtCompanyEmail.Text.Trim();
                oPRP.SoldDate = txtSoldDate.Text.Trim();
                oPRP.Remarks = txtRemarks.Text.Trim().Replace("'", "`");                
                foreach (GridViewRow gvRow in gvAssetSoldScrapped.Rows)
                {
                    if (((CheckBox)gvRow.FindControl("chkSelect")).Checked)
                    {
                        oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                        oPRP.AssetID = ((Label)gvRow.FindControl("lblAssetId")).Text.Trim();
                        oPRP.AssetSerialCode = ((Label)gvRow.FindControl("lblSerialCode")).Text.Trim();
                        bResp = oDAL.SaveAssetSoldScrapped(oPRP, "SOLD");
                    }
                }
            }
            else if (rdoScrapped.Checked)
            {
                if (txtScrapDate.Text.Trim() == "")
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Scrap Date cannot be blank.');", true);
                    txtScrapDate.Focus();
                    return;
                }
                for (int iCnt = 0; iCnt < gvAssetSoldScrapped.Rows.Count; iCnt++)
                {
                    if (((CheckBox)gvAssetSoldScrapped.Rows[iCnt].FindControl("chkSelect")).Checked == true)
                    {
                        bAssetSelected = true;
                        break;
                    }
                }
                if (!bAssetSelected)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Select at least one asset to be scrapped.');", true);
                    return;
                }
                oPRP.ScrapDate = txtScrapDate.Text.Trim();
                foreach (GridViewRow gvRow in gvAssetSoldScrapped.Rows)
                {
                    if (((CheckBox)gvRow.FindControl("chkSelect")).Checked)
                    {
                        oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                        oPRP.AssetID = ((Label)gvRow.FindControl("lblAssetId")).Text.Trim();
                        oPRP.AssetSerialCode = ((Label)gvRow.FindControl("lblSerialCode")).Text.Trim();
                        bResp = oDAL.SaveAssetSoldScrapped(oPRP, "SCRAPPED");
                    }
                }
            }
            if (bResp)
            {
                gvAssetSoldScrapped.DataSource = null;
                gvAssetSoldScrapped.DataBind();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ClearFields()", "ClearFields();", true);
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowErrMsg", "ShowErrMsg('Please Note : Asset scrapped/sold details saved successfully.');", true);
            }
            GetAssetDetailsForSoldScrapped();
            GetSoldScrappedDetails();
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Reset/clear page fields.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            gvAssetSoldScrapped.DataSource = null;
            gvAssetSoldScrapped.DataBind();
            lblAssetCount.Text = "Assets Count : 0";

            PopulateCategory(lblAssetType.Text);
            DataTable dt = new DataTable();
            ddlAssetMake.DataSource = dt;
            ddlAssetMake.DataBind();
            lstModelName.DataSource = dt;
            lstModelName.DataBind();
            dt = null;
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Search for assets having sold/scrapped status as NULL.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetAssetDetailsForSoldScrapped();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    //protected void btnGo_Click(object sender, ImageClickEventArgs e)
    //{
    //    try
    //    {
    //        if (txtAssetCode.Text.Trim() != "")
    //        {
    //            DataTable dt = new DataTable();
    //            dt = oDAL.GetAssetDetails(txtAssetCode.Text.Trim(), Session["COMPANY"].ToString());
    //            if (dt.Rows.Count > 0)
    //            {
    //                txtAssetID.Text = dt.Rows[0]["ASSET_ID"].ToString();
    //                txtSerialCode.Text = dt.Rows[0]["SERIAL_CODE"].ToString();
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        HandleExceptions(ex);
    //    }
    //}

    /// <summary>
    /// Export asset acquisition details from gridview to excel sheet.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnExport_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[4] == "0")
            {
                Response.Redirect("UnauthorizedUser.aspx");
            }
            if (gvSoldScrapped.Rows.Count > 0)
            {
                Response.Clear();
                DataTable dt = (DataTable)Session["SOLD_SCRAPPED"];
                DataSet dsExport = new DataSet();
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                DataGrid dgGrid = new DataGrid();
                dgGrid.DataSource = dt;
                dgGrid.HeaderStyle.Font.Bold = true;
                dgGrid.DataBind();
                dgGrid.RenderControl(hw);
                Response.ContentType = "application/vnd.ms-excel";
                this.EnableViewState = false;
                Response.Write(tw.ToString());
                Response.End();
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion

    #region SELECTEDINDEXCHANGED EVENTS
    /// <summary>
    /// Fetch list of categories based on asset type selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetType.SelectedIndex != 0)
            {
                DataTable dtNull = new DataTable();
                ddlAssetCategory.DataSource = dtNull;
                ddlAssetCategory.DataBind();
                ddlAssetMake.DataSource = dtNull;
                ddlAssetMake.DataBind();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                lblAssetType.Text = ddlAssetType.SelectedValue.ToString();
                PopulateCategory(lblAssetType.Text);
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get asset model names on the basis of asset make selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetMake_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetMake.SelectedIndex != 0)
                PopulateModelName(ddlAssetMake.SelectedValue.ToString(), lblCatCode.Text.Trim());
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get asset make and sub categories to be populated as per category name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAssetCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAssetCategory.SelectedIndex > 0)
            {
                DataTable dtNull = new DataTable();
                lstModelName.DataSource = dtNull;
                lstModelName.DataBind();
                dtNull = null;

                PopulateAssetMake(ddlAssetCategory.SelectedValue.ToString());
                int CatLevel = int.Parse(lblCatLevel.Text.Trim());
                lblCatLevel.Text = (CatLevel + 1).ToString();
                int iCatLevel = int.Parse(lblCatLevel.Text.Trim());
                string sCatCode = ddlAssetCategory.SelectedValue.ToString();
                lblCatCode.Text = sCatCode;

                ddlAssetCategory.DataSource = null;
                DataTable dt = oDAL.PopulateCategory(lblAssetType.Text, sCatCode, iCatLevel);
                if (dt.Rows.Count > 0)
                {
                    ddlAssetCategory.DataSource = dt;
                    ddlAssetCategory.DataValueField = "CATEGORY_CODE";
                    ddlAssetCategory.DataTextField = "CATEGORY_NAME";
                    ddlAssetCategory.DataBind();
                    ddlAssetCategory.Items.Insert(0, "-- Select Category --");
                    ddlAssetCategory.Focus();
                }
                else
                {
                    iCatLevel = iCatLevel - 1;
                    lblCatLevel.Text = iCatLevel.ToString();
                    ddlAssetMake.Focus();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }

    /// <summary>
    /// Get vendor details populated based on vendor name selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlVendor_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DataTable dt=new DataTable();
            if (ddlVendor.SelectedIndex > 0)
            {
                dt = oDAL.GetVendorDetails(ddlVendor.SelectedValue.ToString(), Session["COMPANY"].ToString());
                if (dt.Rows.Count > 0)
                {
                    txtContactName.Text = dt.Rows[0]["VENDOR_CONT_PERSON"].ToString();
                    txtCompanyEmail.Text = dt.Rows[0]["VENDOR_EMAIL"].ToString();
                    txtCompanyAddress.Text = dt.Rows[0]["VENDOR_ADDRESS"].ToString();
                }
            }
        }
        catch (Exception ex)
        { HandleExceptions(ex); }
    }
    #endregion

    #region CHECKED CHANGED EVENTS
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rdoScrapped_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rdoScrapped.Checked)
            {
                rdoSold.Checked = false;
                txtScrapDate.Text = "";
                txtScrapDate.Enabled = true;
                //****************************
                ddlVendor.SelectedIndex = 0;
                txtContactName.Text = "";
                txtSoldDate.Text = "";
                txtCompanyAddress.Text = "";
                txtRemarks.Text = "";
                txtSoldValue.Text = "";
                txtCompanyEmail.Text = "";
                ddlVendor.Enabled = false;
                txtContactName.Enabled = false;
                txtSoldDate.Enabled = false;
                txtCompanyAddress.Enabled = false;
                txtRemarks.Enabled = false;
                txtSoldValue.Enabled = false;
                txtCompanyEmail.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void rdoSold_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (rdoSold.Checked)
            {
                rdoScrapped.Checked = false;
                txtScrapDate.Text = "";
                txtScrapDate.Enabled = false;
                //****************************
                ddlVendor.Enabled = true;
                txtContactName.Enabled = true;
                txtSoldDate.Enabled = true;
                txtCompanyAddress.Enabled = true;
                txtRemarks.Enabled = true;
                txtSoldValue.Enabled = true;
                txtCompanyEmail.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion

    #region GRIDVIEW EVENTS
    /// <summary>
    /// Asset deletion from asset acquisition if not allocated.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSoldScrapped_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (clsGeneral._strRights[3] == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "ShowUnAuthorisedMsg", "ShowUnAuthorisedMsg();", true);
                return;
            }
            else
            {
                GridViewRow gvRow = (GridViewRow)gvSoldScrapped.Rows[e.RowIndex];
                oPRP.AssetCode = ((Label)gvRow.FindControl("lblAssetCode")).Text.Trim();
                oPRP.CompCode = Session["COMPANY"].ToString();
                oDAL.DeleteSoldScrappedDetails(oPRP);
                GetSoldScrappedDetails();
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssetSoldScrapped_RowCreated(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow &&
               (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                CheckBox chkSelect = (CheckBox)e.Row.Cells[0].FindControl("chkSelect");
                CheckBox chkHSelect = (CheckBox)this.gvAssetSoldScrapped.HeaderRow.FindControl("chkHSelect");
                chkSelect.Attributes["onclick"] = string.Format("javascript:ChildClick(this,'{0}');", chkHSelect.ClientID);
            }
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// Gridview page index changing event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAssetSoldScrapped_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAssetSoldScrapped.PageIndex = e.NewPageIndex;
            GetAssetDetailsForSoldScrapped();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvSoldScrapped_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvSoldScrapped.PageIndex = e.NewPageIndex;
            GetSoldScrappedDetails();
        }
        catch (Exception ex)
        {
            HandleExceptions(ex);
        }
    }
    #endregion
}