﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for CompanyMaster_DAL
    /// </summary>
    public class PlantMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public PlantMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~PlantMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        private bool CheckDuplicatePlant(string _PlantCode,string _CityCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_PlantMaster @TYPE='CHECKDUPLICATEPLANT', @CITY_CODE= '" + _CityCode.Trim() + "', @PLANT_CODE= '" + _PlantCode.Trim() + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool SavePlant(PlantMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                if (!CheckDuplicatePlant(oPRP.PlantCode,oPRP.CityCode))
                {                    
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_PlantMaster @TYPE='SAVEPLANT',@PLANT_CODE='" + oPRP.PlantCode.Trim().Replace("'", "''") + "',@CITY_CODE='" + oPRP.CityCode.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @PLANT_NAME='" + oPRP.PlantName.Trim().Replace("'", "''") + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");                    
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdatePlant(PlantMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;                
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_PlantMaster @TYPE='UPDATEPLANT', @PLANT_NAME= '" + oPRP.PlantName + "',@ACTIVE='" + oPRP.Active + "',@CITY_CODE='" + oPRP.CityCode.Trim() + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@PLANT_CODE='" + oPRP.PlantCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetPlantDetails()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_PlantMaster @TYPE='GETPLANTDETAILS'");                
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetCity()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_PlantMaster @TYPE='GETCITY'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }


        /// <summary>
        /// Delete entire details of the company from database based on company location master.
        /// </summary>       
        public bool DeletePlant(string _PlantCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_PlantMaster @TYPE='DELETEPLANT',@PLANT_CODE='" + _PlantCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}