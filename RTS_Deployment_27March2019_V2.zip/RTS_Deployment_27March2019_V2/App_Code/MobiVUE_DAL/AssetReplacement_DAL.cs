﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for Asset Replacement Data Access Layer
    /// </summary>
    public class AssetReplacement_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public AssetReplacement_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~AssetReplacement_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Save asset replacement details
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool SaveUpdateAssetReplacementDetails(AssetReplacement_PRP oPRP)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("INSERT INTO [ASSET_REPLACEMENT] ([ACTIVE_IN_ASSET_CODE],[SERIAL_CODE],[FAULTY_OUT_SERIAL_CODE],[FAULTY_SEC_GE_NO],[FAULTY_SEC_GE_DATE]");
                sbQuery.Append(",[ACTIVE_SEC_GE_NO],[ACTIVE_SEC_GE_DATE],[BONDED_TYPE],[CREATED_BY],[CREATED_ON],[REMARKS],[COMP_CODE])");
                sbQuery.Append(" VALUES ");
                sbQuery.Append("('" + oPRP.ActiveInAssetCode + "','" + oPRP.SerialCode + "','" + oPRP.FaultyOutSerialCode + "','" + oPRP.FaultySecurityGENo + "','" + oPRP.FaultySecurityGEDate + "'");
                sbQuery.Append(",'" + oPRP.ActiveSecurityGENo + "','" + oPRP.ActiveSecurityGEDate + "','" + oPRP.BondedType + "','" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.ReplaceRemarks + "','" + oPRP.CompCode + "')");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.Append("UPDATE [ASSET_ACQUISITION] SET [SERIAL_CODE]='" + oPRP.SerialCode + "',[ASSET_MAKE]='" + oPRP.AssetMake + "',[MODEL_NAME] = '" + oPRP.AssetModel + "'");
                sbQuery.Append(",[BONDED_TYPE] = '" + oPRP.BondedType + "',[SECURITY_GATE_ENTRY_NO] = '" + oPRP.ActiveSecurityGENo + "',[SECURITY_GATE_ENTRY_DATE] = '" + oPRP.ActiveSecurityGEDate + "'");
                sbQuery.Append(",[ASSET_APPROVED] = '0',REMARKS='" + oPRP.ReplaceRemarks + "' WHERE [ASSET_CODE] = '" + oPRP.ActiveInAssetCode + "' AND COMP_CODE='" + oPRP.CompCode + "'");
                int iRs = oDb.ExecuteQuery(sbQuery.ToString());

                if (iRes > 0 && iRs > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get Asset Replacement details.
        /// </summary>
        /// <returns></returns>
        public DataTable GetAssetReplacementDetails(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT AR.ACTIVE_IN_ASSET_CODE,AR.SERIAL_CODE,AR.FAULTY_OUT_SERIAL_CODE,AR.FAULTY_SEC_GE_NO,NULLIF(AR.FAULTY_SEC_GE_DATE,'') AS FAULTY_SEC_GE_DATE,");
            sbQuery.Append(" AR.ACTIVE_SEC_GE_NO,NULLIF(AR.ACTIVE_SEC_GE_DATE,'') AS ACTIVE_SEC_GE_DATE,AR.BONDED_TYPE,AR.CREATED_BY,AR.REMARKS");
            sbQuery.Append(" FROM ASSET_REPLACEMENT AR INNER JOIN ASSET_ACQUISITION AA ON AR.ACTIVE_IN_ASSET_CODE = AA.ASSET_CODE");
            sbQuery.Append(" WHERE AR.COMP_CODE='" + CompCode + "' AND AA.ASSET_APPROVED='1'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            return dt;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAssetCode()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ASSET_CODE FROM ASSET_ACQUISITION");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            return dt;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetAssetDetails(string _AssetCode, string _CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT SERIAL_CODE,ASSET_MAKE,MODEL_NAME FROM ASSET_ACQUISITION");
            sbQuery.Append(" WHERE ASSET_CODE='" + _AssetCode + "' AND COMP_CODE='" + _CompCode + "' AND ASSET_APPROVED='True'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public bool ChkFaultySerialNoExists(string FaultySerialNo,string CompCode)
        {
            bool bExists = false;
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT COUNT(*) AS CSN FROM ASSET_REPLACEMENT");
            sbQuery.Append(" WHERE FAULTY_OUT_SERIAL_CODE='" + FaultySerialNo + "' AND COMP_CODE='" + CompCode + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows[0]["CSN"].ToString() != "0")
                bExists = true;
            return bExists;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ActiveSerialNo"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public bool ChkActiveSerialNoExists(string ActiveSerialNo, string CompCode)
        {
            bool bExists = false;
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT COUNT(*) AS CSN FROM [ASSET_ACQUISITION]");
            sbQuery.Append(" WHERE SERIAL_CODE='" + ActiveSerialNo + "' AND COMP_CODE='" + CompCode + "'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows[0]["CSN"].ToString() != "0")
                bExists = true;
            return bExists;
        }
    }
}