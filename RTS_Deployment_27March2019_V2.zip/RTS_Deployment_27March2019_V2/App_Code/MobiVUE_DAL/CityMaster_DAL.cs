﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for CompanyMaster_DAL
    /// </summary>
    public class CityMaster_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public CityMaster_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~CityMaster_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        private bool CheckDuplicateCity(string _CityCode,string _CountryCode)
        {
            try
            {
                bool bDup = false;
                sbQuery = new StringBuilder();
                sbQuery.Append("EXEC sp_CityMaster @TYPE='CHECKDUPLICATECITY', @CITY_CODE= '" + _CityCode.Trim() + "', @COUNTRY_CODE= '" + _CountryCode.Trim() + "'");
                DataTable dt = oDb.GetDataTable(sbQuery.ToString());
                if (dt.Rows.Count > 0)
                    bDup = true;
                return bDup;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool SaveCity(CityMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;                
                if (!CheckDuplicateCity(oPRP.CityCode,oPRP.CountryCode))
                {                    
                    sbQuery = new StringBuilder();
                    sbQuery.Clear();
                    sbQuery.Append("EXEC sp_CityMaster @TYPE='SAVECITY',@CITY_CODE='" + oPRP.CityCode.Trim().Replace("'", "''") + "',@COUNTRY_CODE='" + oPRP.CountryCode.Trim().Replace("'", "''") + "',");
                    sbQuery.Append(" @CITY_NAME='" + oPRP.CityName.Trim().Replace("'", "''") + "', @REMARKS='" + oPRP.Remarks.Trim() + "',@ACTIVE='" + oPRP.Active + "',@CREATED_BY='" + oPRP.CreatedBy + "'");                    
                }

                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public bool UpdateCity(CityMaster_PRP oPRP)
        {
            try
            {
                bool bResult = false;                
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CityMaster @TYPE='UPDATECITY', @CITY_NAME= '" + oPRP.CityName + "',@ACTIVE='" + oPRP.Active + "',@COUNTRY_CODE='" + oPRP.CountryCode.Trim().Replace("'", "''") + "',");
                sbQuery.Append(" @REMARKS='" + oPRP.Remarks + "',@MODIFIED_BY='" + oPRP.ModifiedBy + "',@CITY_CODE='" + oPRP.CityCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetCityDetails()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CityMaster @TYPE='GETCITYDETAILS'");                
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        public DataTable GetCountry()
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CityMaster @TYPE='GETCOUNTRY'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }


        /// <summary>
        /// Delete entire details of the company from database based on company location master.
        /// </summary>       
        public bool DeleteCity(string _CityCode)
        {
            try
            {
                bool bResult = false;
                sbQuery = new StringBuilder();
                sbQuery.Clear();
                sbQuery.Append("EXEC sp_CityMaster @TYPE='DELETECITY',@CITY_CODE='" + _CityCode + "'");
                int iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
                return bResult;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}