﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using MobiVUE_ATS.PRP;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace MobiVUE_ATS.DAL
{
    /// <summary>
    /// Summary description for AssetAcquisition_DAL
    /// </summary>
    public class AssetAcquisition_DAL
    {
        clsDb oDb;
        StringBuilder sbQuery;
        public AssetAcquisition_DAL(string DatabaseType)
        {
            oDb = new clsDb();
            if (DatabaseType != "")
                oDb.Connect(DatabaseType);
        }
        ~AssetAcquisition_DAL()
        {
            oDb.Disconnect();
            oDb = null;
            sbQuery = null;
        }

        /// <summary>
        /// Fetch Locations details for mapping with user id
        /// </summary>
        /// <param name="_ParentLocCode"></param>
        /// <param name="_LocLevel"></param>
        /// <returns>DataTable</returns>OK
        public DataTable GetLocation(string _LocCode, string _ParentLocCode, int _LocLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETLOCATION',@PARENT_LOC_CODE='" + _ParentLocCode + "',");
            sbQuery.AppendLine(" @STORAGE_LOC_CODE='" + _LocCode + "',@LOC_LEVEL=" + _LocLevel + "");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch category code/name details to be populated into dropdownlist.
        /// </summary>
        /// <returns></returns>OK
        public DataTable PopulateCategory(string _AssetType, string _ParentCategory, int _CatLevel)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATECATEGORY',@ASSET_TYPE='" + _AssetType + "',");
            sbQuery.AppendLine(" @PARENT_CATEGORY='" + _ParentCategory + "',@CATEGORY_LEVEL=" + _CatLevel + "");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable PopulateCurrencyType()
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_CodetMaster @TYPE='GETCURRENCY'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable PopulateBondedType()
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_CodetMaster @TYPE='GETBONDEDTYPE'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable PopulatePlant()
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEPLANT'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable PopulateProject(string _LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEPROJECT',@STORAGE_LOC_CODE='" + _LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable PopulateSubProject(string _ProjectCode, string _LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATESUBPROJECT',@PROJECT_NAME='" + _ProjectCode + "',@STORAGE_LOC_CODE='" + _LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public DataTable GetProjectManager(string _SubProjectCode, string _LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETPROJECTMANAGER',@SUB_PROJECT_NAME='" + _SubProjectCode + "',@STORAGE_LOC_CODE='" + _LocCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get category cpde/name fr update operation.
        /// </summary>
        /// <returns></returns>OK
        public DataTable PopulateCategoryForUpdate()
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATECATEGORYFORUPDATE'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetch vendor code/name to be populated.
        /// </summary>
        /// <returns></returns>OK
        public DataTable PopulateVendor(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEVENDOR',@COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }


        /// <summary>
        /// Save new asset acquisition details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool SaveAssetAcquisitionDetails(AssetAcquisition_PRP oPRP)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='SAVEASSETACQUISITIONDETAILS',@ASSET_CODE='" + oPRP.AssetCode + "',@ASSET_ID='" + oPRP.AssetID + "',@SERIAL_CODE='" + oPRP.AssetSerialCode + "',");
            sbQuery.AppendLine(" @CUST_ORDR_NO='" + oPRP.CustomerOrderNo + "',@CATEGORY_CODE='" + oPRP.AssetCategoryCode + "',@ASSET_LOCATION='" + oPRP.AssetLocation + "',@AMC_WARRANTY='" + oPRP.AMC_Warranty + "',");
            sbQuery.AppendLine(" @AMC_WARRANTY_START_DATE='" + oPRP.AMC_Wrnty_Start_Date + "',@AMC_WARRANTY_END_DATE='" + oPRP.AMC_Wrnty_End_Date + "',@COMP_CODE='" + oPRP.CompCode + "',@VENDOR_CODE='" + oPRP.VendorCode + "',");
            sbQuery.AppendLine(" @ASSET_INSTALL_DATE='" + oPRP.AssetInstallDate + "',@PURCHASE_DATE='" + oPRP.PurchasedDate + "',@ASSET_PURCHASE_VAL=" + oPRP.AssetPurchaseValue + ",@CURRENCY='" + oPRP.Currency + "',");
            sbQuery.AppendLine(" @TRANSFER_PRICE=" + oPRP.Transfer_Price + ",@LOCAL_CURRENCY=" + oPRP.Local_Currency + ",@PO_NO='" + oPRP.PurchaseOrderNo + "',@PO_DATE='" + oPRP.PODate + "',@INVOICE_NO='" + oPRP.InvoiceNo + "',");
            sbQuery.AppendLine(" @SALE_DATE='" + oPRP.AssetSaleDate + "',@SALE_VAL=" + oPRP.AssetSaleValue + ",@CREATED_BY='" + oPRP.CreatedBy + "',@ASSET_MAKE='" + oPRP.AssetMakeName + "',@MAKE_MODEL='" + oPRP.AssetModelName + "',");
            sbQuery.AppendLine(" @ASSET_PROCESS='" + oPRP.AssetProcess + "',@SECURITYCLASSIFICATION='" + oPRP.SecurityClassification + "',@ASSET_SIZE='" + oPRP.AssetSize + "',@ASSET_VLAN='" + oPRP.AssetVlan + "',@ASSET_HDD='" + oPRP.AssetHDD + "',");
            sbQuery.AppendLine(" @ASSET_PROCESSOR='" + oPRP.AssetProcessor + "',@ASSET_RAM='" + oPRP.AssetRAM + "',@ASSET_IMEINO='" + oPRP.AssetIMEINo + "',@ASSET_PHONEMEMORY='" + oPRP.AssetPhoneMemory + "',@SERVICE_PROVIDER='" + oPRP.ServiceProvider + "',");
            sbQuery.AppendLine(" @ASSET_TYPE='" + oPRP.AssetType + "',@ASSET_BOE='" + oPRP.AssetBOE + "',@REGISTER_NO='" + oPRP.RegisterNo + "',@BONDED_TYPE='" + oPRP.BondedType + "',@BOND_NO='" + oPRP.Bond_No + "',@CAPITALISED_TYPE='" + oPRP.CapitalisedType + "',");
            sbQuery.AppendLine(" @VERIFIABLE_TYPE='" + oPRP.VerifiableType + "',@PORT_NO='" + oPRP.PortNo + "',@ASSET_ALLOCATED='False',@RUNNING_SERIAL_NO=" + oPRP.RunningSerialNo.ToString() + ",@SECURITYGENO='" + oPRP.SecurityGENo + "',@SECURITYGEDATE='" + oPRP.SecurityGEDate + "',");
            sbQuery.AppendLine(" @ASSET_REMARKS='" + oPRP.AssetRemarks.Replace("'", "`") + "',@ASSET_APPROVED='False',@WORKSTATIONNO='" + oPRP.WorkStationNo + "',@COSTCENTERNO='" + oPRP.CostCenterNo + "',@COMP_NAME='" + oPRP.CompanyName + "',@DEPARTMENT_CODE='" + oPRP.DeptCode + "',");
            sbQuery.AppendLine(" @PLANT_CODE='" + oPRP.Plant + "',@STORAGE_LOC_CODE='" + oPRP.Location + "',@ASSET_DESC='" + oPRP.Asset_Desc + "',@ASSET_MAIN_TEXT='" + oPRP.Asset_Main_Text + "',@ASSET_DESC_1='" + oPRP.Asset_Desc_1 + "',@ACCT_DE='" + oPRP.Acct_De + "',@ROOM='" + oPRP.Room + "',");
            sbQuery.AppendLine(" @BA='" + oPRP.BA + "',@INVENTORY_NOTE='" + oPRP.Inventory_Note + "',@PROJECT_NAME='" + oPRP.Project_Name + "',@SUB_PROJECT_NAME='" + oPRP.Sub_Project_Name + "',@PROJECT_MANAGER='" + oPRP.Project_Manager + "',@ASSIGN_PRO_TO_EMP='" + oPRP.Assign_Proj_To_Emp + "',");
            sbQuery.AppendLine(" @EXFLD1='" + oPRP.ExField1 + "',@EXFLD2='" + oPRP.ExField2 + "',@EXFLD3='" + oPRP.ExField3 + "',@EXFLD4='" + oPRP.ExField4 + "',@EXFLD5='" + oPRP.ExField5 + "'");
            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
                bResult = true;
            return bResult;
        }

        public bool SaveAssetAcquestion(DataTable TBL, string CATEGORY_CODE, string STORAGE_LOC_CODE)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("EXEC USP_UploadBulkAssetAcquisition @STORAGE_LOC_CODE='" + STORAGE_LOC_CODE + "',@CATEGORY_CODE='" + CATEGORY_CODE + "',@tblAsset='" + TBL + "'");
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText ="USP_UploadBulkAssetAcquisition";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter parameterTbl = new SqlParameter();
                parameterTbl.ParameterName = "@tblAsset";
                parameterTbl.SqlDbType = SqlDbType.Structured;
                parameterTbl.Value = TBL;
                cmd.Parameters.Add(parameterTbl);
                cmd.Parameters.AddWithValue("@STORAGE_LOC_CODE", STORAGE_LOC_CODE);
                cmd.Parameters.AddWithValue("@CATEGORY_CODE", CATEGORY_CODE);

                oDb.ExecuteCommand(cmd);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
        


        /// <summary>
        /// Save new asset acquisition details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        //public bool SaveAssetAcquisitionDetails(string OpType, AssetAcquisition_PRP oPRP)
        //{
        //    bool bResult = false;
        //    sbQuery = new StringBuilder();
        //    sbQuery.AppendLine("INSERT INTO [ASSET_ACQUISITION] ([ASSET_CODE],[ASSET_ID],[CUSTOMER_ORDER_NO],[SERIAL_CODE],[CATEGORY_CODE],[ASSET_LOCATION],[AMC_WARRANTY],[AMC_WARRANTY_START_DATE],[AMC_WARRANTY_END_DATE],[COMP_CODE]");
        //    sbQuery.AppendLine(" ,[VENDOR_CODE],[INSTALLED_DATE],[PURCHASED_DATE],[PURCHASED_AMT]");
        //    sbQuery.AppendLine(" ,[PO_NUMBER],[PO_DATE],[INVOICE_NO],[SALE_DATE],[SALE_AMT],[CREATED_BY],[CREATED_ON],[ASSET_MAKE]");
        //    sbQuery.AppendLine(" ,[MODEL_NAME],[ASSET_PROCESS],[SECURITY_CLASSIFICATION],[ASSET_SIZE],[ASSET_VLAN]");
        //    sbQuery.AppendLine(" ,[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO],[ASSET_PHONE_MEMORY],[ASSET_SERVICE_PROVIDER]");
        //    sbQuery.AppendLine(" ,[ASSET_TYPE],[ASSET_BOE],[ASSET_REGISTER_NO],[BONDED_TYPE],[CAPITALISED_STATUS],[VERIFIABLE_STATUS],[PORT_NO],[ASSET_ALLOCATED],[RUNNING_SERIAL_NO],[SECURITY_GATE_ENTRY_NO],[SECURITY_GATE_ENTRY_DATE],[REMARKS],[ASSET_APPROVED],[WORKSTATION_NO],[COST_CENTER_NO],[COMPANY_NAME],[DEPARTMENT])");
        //    sbQuery.AppendLine(" VALUES");
        //    sbQuery.AppendLine(" ('" + oPRP.AssetCode + "','" + oPRP.AssetID + "','" + oPRP.CustomerOrderNo + "','" + oPRP.AssetSerialCode + "','" + oPRP.AssetCategoryCode + "','" + oPRP.AssetLocation + "','" + oPRP.AMC_Warranty + "','" + oPRP.AMC_Wrnty_Start_Date + "','" + oPRP.AMC_Wrnty_End_Date + "','" + oPRP.CompCode + "'");
        //    sbQuery.AppendLine(" ,'" + oPRP.VendorCode + "','" + oPRP.AssetInstallDate + "','" + oPRP.PurchasedDate + "'," + oPRP.AssetPurchaseValue + "");
        //    sbQuery.AppendLine(" ,'" + oPRP.PurchaseOrderNo + "','" + oPRP.PODate + "','" + oPRP.InvoiceNo + "','" + oPRP.AssetSaleDate + "'," + oPRP.AssetSaleValue + ",'" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.AssetMakeName + "'");
        //    sbQuery.AppendLine(" ,'" + oPRP.AssetModelName + "','" + oPRP.AssetProcess + "','" + oPRP.SecurityClassification + "','" + oPRP.AssetSize + "','" + oPRP.AssetVlan + "'");
        //    sbQuery.AppendLine(" ,'" + oPRP.AssetHDD + "','" + oPRP.AssetProcessor + "','" + oPRP.AssetRAM + "','" + oPRP.AssetIMEINo + "','" + oPRP.AssetPhoneMemory + "','" + oPRP.ServiceProvider + "'");
        //    sbQuery.AppendLine(" ,'" + oPRP.AssetType + "','" + oPRP.AssetBOE + "','" + oPRP.RegisterNo + "','" + oPRP.BondedType + "','" + oPRP.CapitalisedType + "','" + oPRP.VerifiableType + "','" + oPRP.PortNo + "','False'," + oPRP.RunningSerialNo.ToString() + ",'" + oPRP.SecurityGENo + "','" + oPRP.SecurityGEDate + "','" + oPRP.AssetRemarks.Replace("'", "`") + "','False','" + oPRP.WorkStationNo + "','" + oPRP.CostCenterNo + "','" + oPRP.CompanyName + "','" + oPRP.DeptCode + "')");
        //    int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //    if (iRes > 0)
        //        bResult = true;
        //    return bResult;
        //}

        #region SQL TRANSACTION
        public void BeginTransaction()
        { oDb.BeginTrans(); }

        public void CommitTransaction()
        { oDb.CommitTrans(); }

        public void RollBackTransaction()
        { oDb.RollBack(); }
        #endregion

        /// <summary>
        /// Save asset acquisition details through excel file import.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        //public int SaveAssetAcquisitionDetails(AssetAcquisition_PRP oPRP)
        //{
        //    sbQuery = new StringBuilder();
        //    sbQuery.AppendLine("INSERT INTO [ASSET_ACQUISITION] ([ASSET_CODE],[ASSET_ID],[SERIAL_CODE],[CATEGORY_CODE],[ASSET_LOCATION],[AMC_WARRANTY],[AMC_WARRANTY_START_DATE],[AMC_WARRANTY_END_DATE],[COMP_CODE]");
        //    sbQuery.AppendLine(",[VENDOR_CODE],[INSTALLED_DATE],[PURCHASED_DATE],[PURCHASED_AMT]");
        //    sbQuery.AppendLine(",[PO_NUMBER],[PO_DATE],[INVOICE_NO],[SALE_DATE],[SALE_AMT],[CREATED_BY],[CREATED_ON],[ASSET_MAKE]");
        //    sbQuery.AppendLine(",[MODEL_NAME],[ASSET_PROCESS],[SECURITY_CLASSIFICATION],[ASSET_SIZE],[ASSET_VLAN]");
        //    sbQuery.AppendLine(",[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO],[ASSET_PHONE_MEMORY],[ASSET_SERVICE_PROVIDER]");
        //    sbQuery.AppendLine(",[ASSET_TYPE],[ASSET_BOE],[ASSET_REGISTER_NO],[BONDED_TYPE],[CAPITALISED_STATUS],[VERIFIABLE_STATUS],[PORT_NO],[ASSET_ALLOCATED],[RUNNING_SERIAL_NO],[SECURITY_GATE_ENTRY_NO],[SECURITY_GATE_ENTRY_DATE],[ASSET_APPROVED],[WORKSTATION_NO],[COST_CENTER_NO],[COMPANY_NAME],[CUSTOMER_ORDER_NO],[DEPARTMENT])");
        //    sbQuery.AppendLine(" VALUES");
        //    sbQuery.AppendLine(" ('" + oPRP.AssetCode + "','" + oPRP.AssetID + "','" + oPRP.AssetSerialCode + "','" + oPRP.AssetCategoryCode + "','" + oPRP.AssetLocation + "','" + oPRP.AMC_Warranty + "','" + oPRP.AMC_Wrnty_Start_Date + "','" + oPRP.AMC_Wrnty_End_Date + "','" + oPRP.CompCode + "'");
        //    sbQuery.AppendLine(",'" + oPRP.VendorCode + "','" + oPRP.AssetInstallDate + "','" + oPRP.PurchasedDate + "'," + oPRP.AssetPurchaseValue + "");
        //    sbQuery.AppendLine(",'" + oPRP.PurchaseOrderNo + "','" + oPRP.PODate + "','" + oPRP.InvoiceNo + "','" + oPRP.AssetSaleDate + "'," + oPRP.AssetSaleValue + ",'" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.AssetMakeName + "'");
        //    sbQuery.AppendLine(",'" + oPRP.AssetModelName + "','" + oPRP.AssetProcess + "','" + oPRP.SecurityClassification + "','" + oPRP.AssetSize + "','" + oPRP.AssetVlan + "'");
        //    sbQuery.AppendLine(",'" + oPRP.AssetHDD + "','" + oPRP.AssetProcessor + "','" + oPRP.AssetRAM + "','" + oPRP.AssetIMEINo + "','" + oPRP.AssetPhoneMemory + "','" + oPRP.ServiceProvider + "'");
        //    sbQuery.AppendLine(",'" + oPRP.AssetType + "','" + oPRP.AssetBOE + "','" + oPRP.RegisterNo + "','" + oPRP.BondedType + "','" + oPRP.CapitalisedType + "','" + oPRP.VerifiableType + "','" + oPRP.PortNo + "','False'," + oPRP.RunningSerialNo.ToString() + ",'" + oPRP.SecurityGENo + "','" + oPRP.SecurityGEDate + "','False','" + oPRP.WorkStationNo + "','" + oPRP.CostCenterNo + "','" + oPRP.CompanyName + "','" + oPRP.CustomerOrderNo + "','" + oPRP.DeptCode + "')");
        //    int iRslt = oDb.ExecuteQuery(sbQuery.ToString());
        //    return iRslt;
        //}

        //------------ addded by amit 23/07/0218 ---------------------------OK
        public int SaveAssetAcquisitionDetails1(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("INSERT INTO [ASSET_ACQUISITION] ([ASSET_CODE],[ASSET_ID],[SERIAL_CODE],[CATEGORY_CODE],[ASSET_LOCATION],[AMC_WARRANTY],[AMC_WARRANTY_START_DATE],[AMC_WARRANTY_END_DATE],[COMP_CODE]");
            sbQuery.AppendLine(",[VENDOR_CODE],[INSTALLED_DATE],[PURCHASED_DATE],[PURCHASED_AMT]");
            sbQuery.AppendLine(",[PO_NUMBER],[PO_DATE],[INVOICE_NO],[SALE_DATE],[SALE_AMT],[CREATED_BY],[CREATED_ON],[ASSET_MAKE]");
            sbQuery.AppendLine(",[MODEL_NAME],[ASSET_PROCESS],[SECURITY_CLASSIFICATION],[ASSET_SIZE],[ASSET_VLAN]");
            sbQuery.AppendLine(",[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO],[ASSET_PHONE_MEMORY],[ASSET_SERVICE_PROVIDER]");
            sbQuery.AppendLine(",[ASSET_TYPE],[ASSET_BOE],[ASSET_REGISTER_NO],[BONDED_TYPE],[CAPITALISED_STATUS],[VERIFIABLE_STATUS],[PORT_NO],[ASSET_ALLOCATED],[RUNNING_SERIAL_NO],[SECURITY_GATE_ENTRY_NO],[SECURITY_GATE_ENTRY_DATE],[ASSET_APPROVED],[WORKSTATION_NO],[COST_CENTER_NO],[COMPANY_NAME],[CUSTOMER_ORDER_NO],[DEPARTMENT]");
            sbQuery.AppendLine(",[PLANT],[LOCATION],[ASSET_DESCRIPTION],[ASSET_MAIN_TEXT],[ASSET_DESCRIPTION_1],[ACCT_DE],[ROOM],[BA],[CURRENCY],[BOND_NO],[INVENTORY_NOTE],[PROJECT_NAME])");
            sbQuery.AppendLine(" VALUES");
            sbQuery.AppendLine(" ('" + oPRP.AssetCode + "','" + oPRP.AssetID + "','" + oPRP.AssetSerialCode + "','" + oPRP.AssetCategoryCode + "','" + oPRP.AssetLocation + "','" + oPRP.AMC_Warranty + "','" + oPRP.AMC_Wrnty_Start_Date + "','" + oPRP.AMC_Wrnty_End_Date + "','" + oPRP.CompCode + "'");
            sbQuery.AppendLine(",'" + oPRP.VendorCode + "','" + oPRP.AssetInstallDate + "','" + oPRP.PurchasedDate + "'," + oPRP.AssetPurchaseValue + "");
            sbQuery.AppendLine(",'" + oPRP.PurchaseOrderNo + "','" + oPRP.PODate + "','" + oPRP.InvoiceNo + "','" + oPRP.AssetSaleDate + "'," + oPRP.AssetSaleValue + ",'" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.AssetMakeName + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetModelName + "','" + oPRP.AssetProcess + "','" + oPRP.SecurityClassification + "','" + oPRP.AssetSize + "','" + oPRP.AssetVlan + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetHDD + "','" + oPRP.AssetProcessor + "','" + oPRP.AssetRAM + "','" + oPRP.AssetIMEINo + "','" + oPRP.AssetPhoneMemory + "','" + oPRP.ServiceProvider + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetType + "','" + oPRP.AssetBOE + "','" + oPRP.RegisterNo + "','" + oPRP.BondedType + "','" + oPRP.CapitalisedType + "','" + oPRP.VerifiableType + "','" + oPRP.PortNo + "','False'," + oPRP.RunningSerialNo.ToString() + ",'" + oPRP.SecurityGENo + "','" + oPRP.SecurityGEDate + "','False','" + oPRP.WorkStationNo + "','" + oPRP.CostCenterNo + "','" + oPRP.CompanyName + "','" + oPRP.CustomerOrderNo + "','" + oPRP.DeptCode + "'");
            sbQuery.AppendLine(",'" + oPRP.Plant + "','" + oPRP.Location + "','" + oPRP.Asset_Desc + "','" + oPRP.Asset_Main_Text + "','" + oPRP.Asset_Desc_1 + "','" + oPRP.Acct_De + "','" + oPRP.Room + "','" + oPRP.BA + "','" + oPRP.Currency + "','" + oPRP.Bond_No + "','" + oPRP.Inventory_Note + "','" + oPRP.Project_Name + "')");
            int iRslt = oDb.ExecuteQuery(sbQuery.ToString());
            return iRslt;
        }

        ///// <summary>
        ///// Bulk update asset acquisition records.
        ///// </summary>
        ///// <param name="oPRP"></param>
        //public int UpdateAssetAcquisitionDetails(AssetAcquisition_PRP oPRP)
        //{
        //    sbQuery = new StringBuilder();
        //    sbQuery.AppendLine("UPDATE [ASSET_ACQUISITION] SET [ASSET_ID] = '" + oPRP.AssetID + "',[CUSTOMER_ORDER_NO] = '" + oPRP.CustomerOrderNo + "',[CATEGORY_CODE] = '" + oPRP.AssetCategoryCode + "',[ASSET_LOCATION] = '" + oPRP.AssetLocation + "',[VENDOR_CODE] = '" + oPRP.VendorCode + "',");
        //    sbQuery.AppendLine("[INSTALLED_DATE] = '" + oPRP.AssetInstallDate + "',[PURCHASED_DATE] = '" + oPRP.PurchasedDate + "',[PURCHASED_AMT] = " + oPRP.AssetPurchaseValue + ",[PO_NUMBER] = '" + oPRP.PurchaseOrderNo + "',[PO_DATE] = '" + oPRP.PODate + "',[INVOICE_NO] = '" + oPRP.InvoiceNo + "'");
        //    sbQuery.AppendLine(",[SALE_DATE] = '" + oPRP.AssetSaleDate + "',[SALE_AMT] = " + oPRP.AssetSaleValue + ",[ASSET_MAKE] = '" + oPRP.AssetMakeName + "',[MODEL_NAME] = '" + oPRP.AssetModelName + "',[ASSET_PROCESS] = '" + oPRP.AssetProcess + "'");
        //    sbQuery.AppendLine(",[SECURITY_CLASSIFICATION] = '" + oPRP.SecurityClassification + "',[ASSET_SIZE] = '" + oPRP.AssetSize + "',[ASSET_VLAN] = '" + oPRP.AssetVlan + "',[ASSET_HDD] = '" + oPRP.AssetHDD + "',[ASSET_PROCESSOR] = '" + oPRP.AssetProcessor + "'");
        //    sbQuery.AppendLine(",[ASSET_RAM] = '" + oPRP.AssetRAM + "',[ASSET_IMEI_NO] = '" + oPRP.AssetIMEINo + "',[ASSET_PHONE_MEMORY] = '" + oPRP.AssetPhoneMemory + "',[ASSET_SERVICE_PROVIDER] = '" + oPRP.ServiceProvider + "'");
        //    sbQuery.AppendLine(",[ASSET_TYPE] = '" + oPRP.AssetType + "',[ASSET_BOE] = '" + oPRP.AssetBOE + "',[ASSET_REGISTER_NO] = '" + oPRP.RegisterNo + "',[BONDED_TYPE] = '" + oPRP.BondedType + "',[CAPITALISED_STATUS] = '" + oPRP.CapitalisedType + "'");
        //    sbQuery.AppendLine(",[VERIFIABLE_STATUS] = '" + oPRP.VerifiableType + "',[PORT_NO] = '" + oPRP.PortNo + "',[SECURITY_GATE_ENTRY_NO] = '" + oPRP.SecurityGENo + "',[SECURITY_GATE_ENTRY_DATE] = '" + oPRP.SecurityGEDate + "',[CREATED_BY] = '" + oPRP.CreatedBy + "',[CREATED_ON] = GETDATE()");
        //    sbQuery.AppendLine(",[AMC_WARRANTY_START_DATE] = '" + oPRP.AMC_Wrnty_Start_Date + "',[AMC_WARRANTY_END_DATE] = '" + oPRP.AMC_Wrnty_End_Date + "',[AMC_WARRANTY] = '" + oPRP.AMC_Warranty + "',[WORKSTATION_NO] = '" + oPRP.WorkStationNo + "',[COST_CENTER_NO] = '" + oPRP.CostCenterNo + "',[COMPANY_NAME] = '" + oPRP.CompanyName + "',[DEPARTMENT] = '" + oPRP.DeptCode + "'");  //,[ASSET_ALLOCATED] = 'False'
        //    sbQuery.AppendLine(",[ASSET_APPROVED] = '0' WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
        //    int iRslt = oDb.ExecuteQuery(sbQuery.ToString());
        //    return iRslt;
        //}

        ///// <summary>
        ///// Update asset acquisition details.
        ///// </summary>
        ///// <param name="OpType"></param>
        ///// <param name="oPRP"></param>
        ///// <returns></returns>
        //public bool UpdateAssetAcquisitionDetails(string OpType, AssetAcquisition_PRP oPRP)
        //{
        //    bool bResult = false;
        //    sbQuery = new StringBuilder();
        //    sbQuery.AppendLine("UPDATE [ASSET_ACQUISITION] SET [SERIAL_CODE] = '" + oPRP.AssetSerialCode + "',[ASSET_ID] = '" + oPRP.AssetID + "',[CATEGORY_CODE] = '" + oPRP.AssetCategoryCode + "'");
        //    sbQuery.AppendLine(",[ASSET_LOCATION] = '" + oPRP.AssetLocation + "',[AMC_WARRANTY] = '" + oPRP.AMC_Warranty + "',[AMC_WARRANTY_START_DATE] = '" + oPRP.AMC_Wrnty_Start_Date + "',[AMC_WARRANTY_END_DATE] = '" + oPRP.AMC_Wrnty_End_Date + "',[VENDOR_CODE] = '" + oPRP.VendorCode + "',[INSTALLED_DATE] = '" + oPRP.AssetInstallDate + "',[PURCHASED_DATE] = '" + oPRP.PurchasedDate + "'");
        //    sbQuery.AppendLine(",[PURCHASED_AMT] = " + oPRP.AssetPurchaseValue + ",[PO_NUMBER] = '" + oPRP.PurchaseOrderNo + "',[PO_DATE] = '" + oPRP.PODate + "',[INVOICE_NO] = '" + oPRP.InvoiceNo + "',[SALE_DATE] = '" + oPRP.AssetSaleDate + "'");
        //    sbQuery.AppendLine(",[SALE_AMT] = " + oPRP.AssetSaleValue + ",[ASSET_MAKE] = '" + oPRP.AssetMakeName + "',[MODEL_NAME] = '" + oPRP.AssetModelName + "',[ASSET_PROCESS] = '" + oPRP.AssetProcess + "',[SECURITY_CLASSIFICATION] = '" + oPRP.SecurityClassification + "'");
        //    sbQuery.AppendLine(",[ASSET_SIZE] = '" + oPRP.AssetSize + "',[ASSET_VLAN] = '" + oPRP.AssetVlan + "',[ASSET_HDD] = '" + oPRP.AssetHDD + "',[ASSET_PROCESSOR] = '" + oPRP.AssetProcessor + "',[ASSET_RAM] = '" + oPRP.AssetRAM + "'");
        //    sbQuery.AppendLine(",[ASSET_IMEI_NO] = '" + oPRP.AssetIMEINo + "',[ASSET_PHONE_MEMORY] = '" + oPRP.AssetPhoneMemory + "',[ASSET_SERVICE_PROVIDER] = '" + oPRP.ServiceProvider + "',[ASSET_TYPE] = '" + oPRP.AssetType + "'");
        //    sbQuery.AppendLine(",[ASSET_BOE] = '" + oPRP.AssetBOE + "',[ASSET_REGISTER_NO] = '" + oPRP.RegisterNo + "',[BONDED_TYPE] = '" + oPRP.BondedType + "',[CAPITALISED_STATUS] = '" + oPRP.CapitalisedType + "',[VERIFIABLE_STATUS] = '" + oPRP.VerifiableType + "'");
        //    sbQuery.AppendLine(",[SECURITY_GATE_ENTRY_NO] = '" + oPRP.SecurityGENo + "',[SECURITY_GATE_ENTRY_DATE] = '" + oPRP.SecurityGEDate + "',[REMARKS] = '" + oPRP.AssetRemarks.Replace("'", "`") + "',[WORKSTATION_NO] = '" + oPRP.WorkStationNo + "',[COST_CENTER_NO] = '" + oPRP.CostCenterNo + "'");
        //    sbQuery.AppendLine(",[COMPANY_NAME] = '" + oPRP.CompanyName + "',[DEPARTMENT] = '" + oPRP.DeptCode + "',[CREATED_BY] = '" + oPRP.CreatedBy + "',[CREATED_ON] = GETDATE()");
        //    sbQuery.AppendLine(",[PORT_NO] = '" + oPRP.PortNo + "',[ASSET_APPROVED] = '0' WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
        //    int iRes = oDb.ExecuteQuery(sbQuery.ToString());
        //    if (iRes > 0)
        //        bResult = true;
        //    return bResult;
        //}

        /// <summary>
        /// Bulk update asset acquisition records.
        /// </summary>
        /// <param name="oPRP"></param>
        public int UpdateAssetAcquisitionDetails1(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE [ASSET_ACQUISITION] SET [ASSET_ID] = '" + RemoveNullToEmpty(oPRP.AssetID) + "',[CUSTOMER_ORDER_NO] = '" +RemoveNullToEmpty(oPRP.CustomerOrderNo) + "',[CATEGORY_CODE] = '" +RemoveNullToEmpty(oPRP.AssetCategoryCode) + "',[ASSET_LOCATION] = '" + RemoveNullToEmpty(oPRP.AssetLocation ) + "',[VENDOR_CODE] = '" + RemoveNullToEmpty(oPRP.VendorCode) + "',");
            sbQuery.AppendLine("[INSTALLED_DATE] = '" +RemoveNullToEmpty(oPRP.AssetInstallDate) + "',[PURCHASED_DATE] = '" + RemoveNullToEmpty(oPRP.PurchasedDate) + "',[PURCHASED_AMT] = " + RemoveNullToEmpty(oPRP.AssetPurchaseValue) + ",[PO_NUMBER] = '" + RemoveNullToEmpty(oPRP.PurchaseOrderNo) + "',[PO_DATE] = '" +RemoveNullToEmpty(oPRP.PODate) + "',[INVOICE_NO] = '" +RemoveNullToEmpty(oPRP.InvoiceNo) + "'");
            sbQuery.AppendLine(",[SALE_DATE] = '" + RemoveNullToEmpty(oPRP.AssetSaleDate) + "',[SALE_AMT] = " + oPRP.AssetSaleValue + ",[ASSET_MAKE] = '" + oPRP.AssetMakeName + "',[MODEL_NAME] = '" + oPRP.AssetModelName + "',[ASSET_PROCESS] = '" + oPRP.AssetProcess + "'");
            sbQuery.AppendLine(",[SECURITY_CLASSIFICATION] = '" +RemoveNullToEmpty(oPRP.SecurityClassification) + "',[ASSET_SIZE] = '" + RemoveNullToEmpty(oPRP.AssetSize) + "',[ASSET_VLAN] = '" + RemoveNullToEmpty(oPRP.AssetVlan) + "',[ASSET_HDD] = '" + RemoveNullToEmpty(oPRP.AssetHDD) + "',[ASSET_PROCESSOR] = '" + RemoveNullToEmpty(oPRP.AssetProcessor) + "'");
            sbQuery.AppendLine(",[ASSET_RAM] = '" + RemoveNullToEmpty(oPRP.AssetRAM) + "',[ASSET_IMEI_NO] = '" + RemoveNullToEmpty(oPRP.AssetIMEINo) + "',[ASSET_PHONE_MEMORY] = '" + RemoveNullToEmpty(oPRP.AssetPhoneMemory) + "',[ASSET_SERVICE_PROVIDER] = '" + RemoveNullToEmpty(oPRP.ServiceProvider) + "'");
            sbQuery.AppendLine(",[ASSET_TYPE] = '" + RemoveNullToEmpty(oPRP.AssetType) + "',[ASSET_BOE] = '" + RemoveNullToEmpty(oPRP.AssetBOE) + "',[ASSET_REGISTER_NO] = '" + RemoveNullToEmpty( oPRP.RegisterNo) + "',[BONDED_TYPE] = '" + RemoveNullToEmpty( oPRP.BondedType) + "',[CAPITALISED_STATUS] = '" + RemoveNullToEmpty(oPRP.CapitalisedType) + "'");
            sbQuery.AppendLine(",[VERIFIABLE_STATUS] = '" + RemoveNullToEmpty(oPRP.VerifiableType) + "',[PORT_NO] = '" +RemoveNullToEmpty(oPRP.PortNo) + "',[SECURITY_GATE_ENTRY_NO] = '" +RemoveNullToEmpty(oPRP.SecurityGENo) + "',[SECURITY_GATE_ENTRY_DATE] = '" + RemoveNullToEmpty(oPRP.SecurityGEDate) + "',[CREATED_BY] = '" + RemoveNullToEmpty(oPRP.CreatedBy) + "',[CREATED_ON] = GETDATE()");
            sbQuery.AppendLine(",[AMC_WARRANTY_START_DATE] = '" + RemoveNullToEmpty(oPRP.AMC_Wrnty_Start_Date) + "',[AMC_WARRANTY_END_DATE] = '" + RemoveNullToEmpty(oPRP.AMC_Wrnty_End_Date) + "',[AMC_WARRANTY] = '" + RemoveNullToEmpty(oPRP.AMC_Warranty) + "',[WORKSTATION_NO] = '" + RemoveNullToEmpty(oPRP.WorkStationNo) + "',[COST_CENTER_NO] = '" + RemoveNullToEmpty(oPRP.CostCenterNo) + "', [DEPARTMENT] = '" + oPRP.DeptCode + "'");  //,[ASSET_ALLOCATED] = 'False'  [COMPANY_NAME] = '" + oPRP.CompanyName + "',
            sbQuery.AppendLine(",[ASSET_APPROVED] = '0' WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
            int iRslt = oDb.ExecuteQuery(sbQuery.ToString());
            return iRslt;
        }

        /// <summary>
        /// Update asset acquisition details.
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>OK
        public bool UpdateAssetAcquisitionDetails(AssetAcquisition_PRP oPRP)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='UPDATEASSETACQUISITIONDETAILS', @SERIAL_CODE = '" + RemoveNullToEmpty(oPRP.AssetSerialCode) + "',@ASSET_ID = '" + RemoveNullToEmpty(oPRP.AssetID) + "',@CATEGORY_CODE = '" + RemoveNullToEmpty(oPRP.AssetCategoryCode) + "',@CUST_ORDR_NO='" + RemoveNullToEmpty(oPRP.CustomerOrderNo) + "',");
            sbQuery.AppendLine(" @ASSET_LOCATION = '" + RemoveNullToEmpty(oPRP.AssetLocation) + "',@AMC_WARRANTY = '" + RemoveNullToEmpty(oPRP.AMC_Warranty) + "',@AMC_WARRANTY_START_DATE = '" + RemoveNullToEmpty(oPRP.AMC_Wrnty_Start_Date) + "',@AMC_WARRANTY_END_DATE = '" + RemoveNullToEmpty(oPRP.AMC_Wrnty_End_Date) + "',");
            sbQuery.AppendLine(" @VENDOR_CODE = '" + RemoveNullToEmpty(oPRP.VendorCode) + "',@ASSET_INSTALL_DATE = '" + RemoveNullToEmpty(oPRP.AssetInstallDate) + "',@PURCHASE_DATE = '" + RemoveNullToEmpty(oPRP.PurchasedDate) + "',@ASSET_PURCHASE_VAL = " + RemoveNullToEmpty(oPRP.AssetPurchaseValue) + ",");


            sbQuery.AppendLine(" @PO_NO = '" + RemoveNullToEmpty(oPRP.PurchaseOrderNo) + "',@PO_DATE = '" + RemoveNullToEmpty(oPRP.PODate) + "',@INVOICE_NO = '" + RemoveNullToEmpty(oPRP.InvoiceNo) + "',@SALE_DATE = '" + RemoveNullToEmpty(oPRP.AssetSaleDate) + "',@SALE_VAL = " + RemoveNullToEmpty(oPRP.AssetSaleValue) + ",");

            sbQuery.AppendLine(" @ASSET_MAKE = '" + RemoveNullToEmpty(oPRP.AssetMakeName) + "',@MAKE_MODEL = '" + RemoveNullToEmpty(oPRP.AssetModelName) + "',@ASSET_PROCESS = '" + RemoveNullToEmpty(oPRP.AssetProcess) + "',@SECURITYCLASSIFICATION = '" + RemoveNullToEmpty(oPRP.SecurityClassification) + "',");

            sbQuery.AppendLine(" @ASSET_SIZE = '" + RemoveNullToEmpty(oPRP.AssetSize) + "',@ASSET_VLAN = '" + RemoveNullToEmpty(oPRP.AssetVlan) + "',@ASSET_HDD = '" + RemoveNullToEmpty(oPRP.AssetHDD) + "',@ASSET_PROCESSOR = '" + RemoveNullToEmpty(oPRP.AssetProcessor) + "',@ASSET_RAM = '" + RemoveNullToEmpty(oPRP.AssetRAM) + "',");


            sbQuery.AppendLine(" @ASSET_IMEINO = '" + RemoveNullToEmpty(oPRP.AssetIMEINo) + "',@ASSET_PHONEMEMORY = '" + RemoveNullToEmpty(oPRP.AssetPhoneMemory) + "',@SERVICE_PROVIDER = '" + RemoveNullToEmpty(oPRP.ServiceProvider) + "',@ASSET_TYPE = '" + RemoveNullToEmpty(oPRP.AssetType) + "',");

            sbQuery.AppendLine(" @ASSET_BOE = '" + RemoveNullToEmpty(oPRP.AssetBOE) + "',@REGISTER_NO = '" + RemoveNullToEmpty(oPRP.RegisterNo) + "',@BONDED_TYPE = '" + RemoveNullToEmpty(oPRP.BondedType) + "',@CAPITALISED_TYPE = '" + RemoveNullToEmpty(oPRP.CapitalisedType) + "',@VERIFIABLE_TYPE = '" + RemoveNullToEmpty(oPRP.VerifiableType) + "',");

            sbQuery.AppendLine(" @SECURITYGENO = '" + RemoveNullToEmpty(oPRP.SecurityGENo) + "',@SECURITYGEDATE = '" + RemoveNullToEmpty(oPRP.SecurityGEDate) + "',@ASSET_REMARKS = '" + (string.IsNullOrEmpty(oPRP.AssetRemarks) ? "" : oPRP.AssetRemarks.Replace("'", "`")) + "',@WORKSTATIONNO = '" + RemoveNullToEmpty(oPRP.WorkStationNo) + "',");

            sbQuery.AppendLine(" @COMP_NAME = '" + RemoveNullToEmpty(oPRP.CompanyName) + "',@DEPARTMENT_CODE = '" + RemoveNullToEmpty(oPRP.DeptCode) + "',@CREATED_BY = '" + RemoveNullToEmpty(oPRP.CreatedBy) + "',@COSTCENTERNO = '" + RemoveNullToEmpty(oPRP.CostCenterNo) + "',@CURRENCY='" + RemoveNullToEmpty(oPRP.Currency) + "',");

            sbQuery.AppendLine(" @PLANT_CODE = '" + RemoveNullToEmpty(oPRP.Plant) + "',@PROJECT_NAME = '" + RemoveNullToEmpty(oPRP.Project_Name) + "',@BOND_NO = '" + RemoveNullToEmpty(oPRP.Bond_No) + "',@INVENTORY_NOTE = '" + RemoveNullToEmpty(oPRP.Inventory_Note) + "', @TRANSFER_PRICE='" + (oPRP.Transfer_Price == null ? "0" : Convert.ToString(oPRP.Transfer_Price)) + "',");

            sbQuery.AppendLine(" @PROJECT_MANAGER = '" + RemoveNullToEmpty(oPRP.Project_Manager) + "',@SUB_PROJECT_NAME = '" + RemoveNullToEmpty(oPRP.Sub_Project_Name) + "',@ASSIGN_PRO_TO_EMP = '" + RemoveNullToEmpty(oPRP.Assign_Proj_To_Emp) + "',@LOCAL_CURRENCY = '" + (oPRP.Local_Currency == null ? "0" : Convert.ToString(oPRP.Local_Currency)) + "',");

            sbQuery.AppendLine(" @ASSET_DESC = '" + RemoveNullToEmpty(oPRP.Asset_Desc) + "',@ASSET_MAIN_TEXT = '" + RemoveNullToEmpty(oPRP.Asset_Main_Text) + "',@ACCT_DE = '" + RemoveNullToEmpty(oPRP.Acct_De) + "',@ROOM = '" + RemoveNullToEmpty(oPRP.Room) + "',@BA = '" + RemoveNullToEmpty(oPRP.BA) + "',");

            sbQuery.AppendLine(" @PORT_NO = '" + RemoveNullToEmpty(oPRP.PortNo) + "', @ASSET_CODE = '" + RemoveNullToEmpty(oPRP.AssetCode) + "',@COMP_CODE = '" + RemoveNullToEmpty(oPRP.CompCode) + "',@STORAGE_LOC_CODE='" + RemoveNullToEmpty(oPRP.Location) + "'");

            //SqlCommand cmd = new SqlCommand();
            //cmd.CommandText = "sp_AssetAcquisition";
            //cmd.CommandType = CommandType.StoredProcedure;
            //#region
            //cmd.Parameters.AddWithValue("@TYPE", "UPDATEASSETACQUISITIONDETAILS");
            //cmd.Parameters.AddWithValue("@SERIAL_CODE", oPRP.AssetSerialCode);
            //cmd.Parameters.AddWithValue("@ASSET_ID", oPRP.CustomerOrderNo);
            //cmd.Parameters.AddWithValue("@CATEGORY_CODE", oPRP.AssetCategoryCode);
            //cmd.Parameters.AddWithValue("@CUST_ORDR_NO", oPRP.CustomerOrderNo);
            //cmd.Parameters.AddWithValue("@ASSET_LOCATION", oPRP.AssetLocation);

            //cmd.Parameters.AddWithValue("@AMC_WARRANTY", oPRP.AMC_Warranty);
            //cmd.Parameters.AddWithValue("@AMC_WARRANTY_START_DATE", ToDateTime(oPRP.AMC_Wrnty_Start_Date));
            //cmd.Parameters.AddWithValue("@AMC_WARRANTY_END_DATE", ToDateTime(oPRP.AMC_Wrnty_End_Date));
            //cmd.Parameters.AddWithValue("@VENDOR_CODE", oPRP.VendorCode);
            //cmd.Parameters.AddWithValue("@ASSET_INSTALL_DATE", ToDateTime(oPRP.AssetInstallDate));
            //cmd.Parameters.AddWithValue("@PURCHASE_DATE", ToDateTime(oPRP.PurchasedDate));

            //cmd.Parameters.AddWithValue("@ASSET_PURCHASE_VAL", oPRP.AssetPurchaseValue);
            //cmd.Parameters.AddWithValue("@PO_NO", oPRP.PurchaseOrderNo);
            //cmd.Parameters.AddWithValue("@PO_DATE", oPRP.PODate);
            //cmd.Parameters.AddWithValue("@INVOICE_NO", oPRP.InvoiceNo);
            //cmd.Parameters.AddWithValue("@SALE_DATE", oPRP.AssetSaleValue);

            //cmd.Parameters.AddWithValue("@ASSET_MAKE", oPRP.AssetMakeName);

            //cmd.Parameters.AddWithValue("@MAKE_MODEL", oPRP.AssetModelName);
            //cmd.Parameters.AddWithValue("@ASSET_PROCESS", oPRP.AssetProcess);
            //cmd.Parameters.AddWithValue("@SECURITYCLASSIFICATION", oPRP.SecurityClassification);
            //cmd.Parameters.AddWithValue("@ASSET_SIZE", oPRP.AssetSize);
            //cmd.Parameters.AddWithValue("@ASSET_VLAN", oPRP.AssetVlan);
            //cmd.Parameters.AddWithValue("@ASSET_HDD", oPRP.AssetHDD);

            //cmd.Parameters.AddWithValue("@ASSET_PROCESSOR", oPRP.AssetProcessor);
      
            //cmd.Parameters.AddWithValue("@ASSET_RAM", oPRP.AssetRAM);

            //cmd.Parameters.AddWithValue("@ASSET_IMEINO", oPRP.AssetIMEINo);
             
            //cmd.Parameters.AddWithValue("@ASSET_PHONEMEMORY", oPRP.AssetPhoneMemory);
            //cmd.Parameters.AddWithValue("@SERVICE_PROVIDER", oPRP.ServiceProvider);
            //cmd.Parameters.AddWithValue("@ASSET_TYPE", oPRP.AssetType);
            //cmd.Parameters.AddWithValue("@ASSET_BOE", oPRP.AssetBOE);
            //cmd.Parameters.AddWithValue("@REGISTER_NO", oPRP.RegisterNo);
            //cmd.Parameters.AddWithValue("@BONDED_TYPE", oPRP.BondedType);
            //cmd.Parameters.AddWithValue("@CAPITALISED_TYPE", oPRP.CapitalisedType);
            //cmd.Parameters.AddWithValue("@VERIFIABLE_TYPE", oPRP.VerifiableType);
            //cmd.Parameters.AddWithValue("@SECURITYGENO", oPRP.SecurityGENo);
            //cmd.Parameters.AddWithValue("@SECURITYGEDATE", ToDateTime(oPRP.SecurityGEDate));
            //cmd.Parameters.AddWithValue("@ASSET_REMARKS", oPRP.AssetRemarks);
            //cmd.Parameters.AddWithValue("@WORKSTATIONNO", oPRP.WorkStationNo);
            //#endregion
           
            //cmd.Parameters.AddWithValue("@COMP_NAME", oPRP.CompanyName);
            //cmd.Parameters.AddWithValue("@DEPARTMENT_CODE", oPRP.DeptCode);
            //cmd.Parameters.AddWithValue("@CREATED_BY", oPRP.CreatedBy);
            //cmd.Parameters.AddWithValue("@COSTCENTERNO", oPRP.CostCenterNo);
            //cmd.Parameters.AddWithValue("@CURRENCY", oPRP.Currency);
            //cmd.Parameters.AddWithValue("@PLANT_CODE", oPRP.Plant);
            //cmd.Parameters.AddWithValue("@PROJECT_NAME", oPRP.Project_Name);
            //cmd.Parameters.AddWithValue("@BOND_NO", oPRP.Bond_No);
            //cmd.Parameters.AddWithValue("@INVENTORY_NOTE", oPRP.Inventory_Note);
            //cmd.Parameters.AddWithValue("@TRANSFER_PRICE", oPRP.Transfer_Price);

            //cmd.Parameters.AddWithValue("@PROJECT_MANAGER",oPRP.Project_Manager);
            //cmd.Parameters.AddWithValue("@SUB_PROJECT_NAME", oPRP.Sub_Project_Name);
            //cmd.Parameters.AddWithValue(",@ASSIGN_PRO_TO_EMP", oPRP.Assign_Proj_To_Emp);

            //cmd.Parameters.AddWithValue("@LOCAL_CURRENCY", oPRP.Local_Currency);


            //cmd.Parameters.AddWithValue("@ASSET_DESC", oPRP.Asset_Desc);
            //cmd.Parameters.AddWithValue("@ASSET_MAIN_TEXT", oPRP.Asset_Main_Text);

            //cmd.Parameters.AddWithValue("@ACCT_DE", oPRP.Acct_De);
            //cmd.Parameters.AddWithValue("@ROOM", oPRP.Room);
            //cmd.Parameters.AddWithValue("@BA", oPRP.BA);

            ////sbQuery.AppendLine(" @PORT_NO = '" +RemoveNullToEmpty(oPRP.PortNo) + "', @ASSET_CODE = '" + RemoveNullToEmpty(oPRP.AssetCode) 
            ////+ "',@COMP_CODE = '" + RemoveNullToEmpty(oPRP.CompCode) + "',@STORAGE_LOC_CODE='" +RemoveNullToEmpty(oPRP.Location) + "'");

            //cmd.Parameters.AddWithValue("@PORT_NO", oPRP.PortNo);

            //cmd.Parameters.AddWithValue("@ASSET_CODE", oPRP.AssetCode);
            //cmd.Parameters.AddWithValue("@COMP_CODE", oPRP.CompCode);
            //cmd.Parameters.AddWithValue("@STORAGE_LOC_CODE", oPRP.Location);


            int iRes = oDb.ExecuteQuery(sbQuery.ToString()); //oDb.ExecuteQueryWithTransation(cmd)  ; // oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
                bResult = true;
            return bResult;
        }



        private static  int GetMonth(string month)
        {
            Dictionary<string, int> dictmonth = new Dictionary<string, int>();
            dictmonth.Add("JAN", 1);
            dictmonth.Add("FEB", 2);
            dictmonth.Add("MAR", 3);
            dictmonth.Add("APR", 4);
            dictmonth.Add("MAY", 5);
            dictmonth.Add("JUN", 6);
            dictmonth.Add("JUL", 7);
            dictmonth.Add("AUG", 8);
            dictmonth.Add("SEP", 9);
            dictmonth.Add("OCT", 10);
            dictmonth.Add("NOV", 11);
            dictmonth.Add("DEC", 12);

            if (dictmonth.ContainsKey(month.ToUpper()))
            {
                return dictmonth.FirstOrDefault(p => p.Key == month.ToUpper()).Value;
            }
            return 0;

        }

        public static DateTime ToDateTime(string dt)
        {
            try
            {
                string [] d = dt.Split('/');
                DateTime ndt = new DateTime(Convert.ToInt32(d[2]), GetMonth(d[1]), Convert.ToInt32(d[0]));
                return ndt ;
            }
            catch (Exception)
            {
                return new DateTime(1900, 01, 01);
                //throw;
            }
            

        }

        public static string RemoveNullToEmpty(object obj)
        {
            if (string.IsNullOrEmpty(obj as string))
            {
                return string.Empty;
            }
            return  Convert.ToString(obj);
        }

        /// <summary>
        /// Save asset acquisition details through excel file import (save in asset acquisition table).
        /// </summary>
        /// <param name="OpType"></param>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public int ImportFreshAssetsAcquisition(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("INSERT INTO [ASSET_ACQUISITION] ([ASSET_CODE],[ASSET_ID],[SERIAL_CODE],[CATEGORY_CODE],[ASSET_LOCATION],[AMC_WARRANTY],[AMC_WARRANTY_START_DATE],[AMC_WARRANTY_END_DATE],[COMP_CODE]");
            sbQuery.AppendLine(",[VENDOR_CODE],[INSTALLED_DATE],[PURCHASED_DATE],[PURCHASED_AMT]");
            sbQuery.AppendLine(",[PO_NUMBER],[PO_DATE],[INVOICE_NO],[SALE_DATE],[SALE_AMT],[CREATED_BY],[CREATED_ON],[ASSET_MAKE]");
            sbQuery.AppendLine(",[MODEL_NAME],[ASSET_PROCESS],[SECURITY_CLASSIFICATION],[ASSET_SIZE],[ASSET_VLAN]");
            sbQuery.AppendLine(",[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO],[ASSET_PHONE_MEMORY],[ASSET_SERVICE_PROVIDER]");
            sbQuery.AppendLine(",[ASSET_TYPE],[ASSET_BOE],[ASSET_REGISTER_NO],[BONDED_TYPE],[CAPITALISED_STATUS],[VERIFIABLE_STATUS],[PORT_NO],[ASSET_ALLOCATED],[RUNNING_SERIAL_NO],[SECURITY_GATE_ENTRY_NO],[SECURITY_GATE_ENTRY_DATE],[ASSET_APPROVED],[WORKSTATION_NO],[COST_CENTER_NO],[COMPANY_NAME],[CUSTOMER_ORDER_NO],[DEPARTMENT])");
            sbQuery.AppendLine(" VALUES");
            sbQuery.AppendLine(" ('" + oPRP.AssetCode + "','" + oPRP.AssetID + "','" + oPRP.AssetSerialCode + "','" + oPRP.AssetCategoryCode + "','" + oPRP.AssetLocation + "','" + oPRP.AMC_Warranty + "','" + oPRP.AMC_Wrnty_Start_Date + "','" + oPRP.AMC_Wrnty_End_Date + "','" + oPRP.CompCode + "'");
            sbQuery.AppendLine(",'" + oPRP.VendorCode + "','" + oPRP.AssetInstallDate + "','" + oPRP.PurchasedDate + "'," + oPRP.AssetPurchaseValue + "");
            sbQuery.AppendLine(",'" + oPRP.PurchaseOrderNo + "','" + oPRP.PODate + "','" + oPRP.InvoiceNo + "','" + oPRP.AssetSaleDate + "'," + oPRP.AssetSaleValue + ",'" + oPRP.CreatedBy + "',GETDATE(),'" + oPRP.AssetMakeName + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetModelName + "','" + oPRP.AssetProcess + "','" + oPRP.SecurityClassification + "','" + oPRP.AssetSize + "','" + oPRP.AssetVlan + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetHDD + "','" + oPRP.AssetProcessor + "','" + oPRP.AssetRAM + "','" + oPRP.AssetIMEINo + "','" + oPRP.AssetPhoneMemory + "','" + oPRP.ServiceProvider + "'");
            sbQuery.AppendLine(",'" + oPRP.AssetType + "','" + oPRP.AssetBOE + "','" + oPRP.RegisterNo + "','" + oPRP.BondedType + "','" + oPRP.CapitalisedType + "','" + oPRP.VerifiableType + "','" + oPRP.PortNo + "','True'," + oPRP.RunningSerialNo.ToString() + ",'" + oPRP.SecurityGENo + "','" + oPRP.SecurityGEDate + "','True','" + oPRP.WorkStationNo + "','" + oPRP.CostCenterNo + "','" + oPRP.CompanyName + "','" + oPRP.CustomerOrderNo + "','" + oPRP.DeptCode + "')");
            int iRslt = oDb.ExecuteQueryTran(sbQuery.ToString());
            return iRslt;
        }

        /// <summary>
        /// Bulk allocate fresh assets (save in asset allocation table).
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public int AllocateFreshAssets(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("INSERT INTO [ASSET_ALLOCATION] ([ASSET_CODE],[ASSET_ALLOCATION_DATE],");
            sbQuery.AppendLine(" [ASSET_ALLOCATED_EMP],[ALLOCATED_EMP_ID],[ALLOCATED_DEPARTMENT],[ALLOCATED_PROCESS],");
            sbQuery.AppendLine(" [ASSET_LOCATION],[COMP_CODE],[PORT_NO],[VLAN],[WORKSTATION_NO],[CREATED_BY],[CREATED_ON])");
            sbQuery.AppendLine(" VALUES ");
            sbQuery.AppendLine("('" + oPRP.AssetCode + "','" + oPRP.AllocationDate + "',");
            sbQuery.AppendLine(" '" + oPRP.AllocatedTo + "','" + oPRP.AllocatedToId + "','" + oPRP.DeptCode + "','" + oPRP.AssetProcess + "',");
            sbQuery.AppendLine(" '" + oPRP.AssetLocation + "','" + oPRP.CompCode + "','" + oPRP.PortNo + "','" + oPRP.AssetVlan + "','" + oPRP.WorkStationNo + "','" + oPRP.CreatedBy + "',GETDATE())");
            int iRes = oDb.ExecuteQueryTran(sbQuery.ToString());
            return iRes;
        }

        /// <summary>
        /// Get new running serial no from asset acquisition data table.
        /// </summary>
        /// <returns></returns>OK
        public int GetMaxAcquisitionId(string CategoryCode, string LocCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETMAXACQUISITIONID',@CATEGORY_CODE='" + CategoryCode + "',@STORAGE_LOC_CODE='" + LocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            return int.Parse(dt.Rows[0]["RSN"].ToString());
        }

        /// <summary>
        /// Get asset details for being viewed/edited/deleted.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>OK1
        public DataTable GetViewAssetDetails(AssetAcquisition_PRP oPRP , string UserId)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME FROM ASSET_ACQUISITION AA INNER JOIN CATEGORY_MASTER CM");
            sbQuery.AppendLine(" ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
            sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
            sbQuery.AppendLine(" WHERE AA.ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND AA.ASSET_CODE LIKE '" + oPRP.AssetCode + "%'");
            sbQuery.AppendLine(" AND AA.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%' AND AA.ASSET_ID LIKE '" + oPRP.AssetID + "%' AND AA.PO_NUMBER LIKE '" + oPRP.PurchaseOrderNo + "%'");
            if (oPRP.AssetModelName != "")
                sbQuery.AppendLine(" AND AA.[MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
            else
                sbQuery.AppendLine(" AND AA.[MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
            sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%'");
            sbQuery.AppendLine(" AND AA.AMC_WARRANTY LIKE '" + oPRP.AMC_Warranty + "%' AND AA.VERIFIABLE_STATUS LIKE '" + oPRP.VerifiableType + "%'");
            sbQuery.AppendLine(" AND AA.ASSET_APPROVED = '" + oPRP.Asset_Approved + "' AND (  '" + oPRP.IsRFIDApproved + "' = '0' OR  ISNULL(AA.IsRFIDApproved,0) = '" + oPRP.IsRFIDApproved + "')   AND AA.COMP_CODE='" + oPRP.CompCode.Trim() + "' AND ( '"+UserId.ToUpper()+"' ='SYSADMIN' OR AA.Location='" + oPRP.Location + "')  ");
            if (oPRP.Sold_Scrapped == "")
                sbQuery.AppendLine(" AND AA.SOLD_SCRAPPED_STATUS IS NULL ORDER BY AA.PORT_NO");
            else
                sbQuery.AppendLine(" AND AA.SOLD_SCRAPPED_STATUS = '" + oPRP.Sold_Scrapped + "' ORDER BY AA.ASSET_CODE,AA.PORT_NO");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset list for being approved after being newly added/updated/swapped/replaced/transferred (internally).
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public DataTable GetAssetDetailsForApproval(AssetAcquisition_PRP oPRP)
        {
            if (oPRP.OperationType == "")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME FROM ASSET_ACQUISITION AA INNER JOIN CATEGORY_MASTER CM");
                sbQuery.AppendLine(" ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                sbQuery.AppendLine(" AND AA.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND AA.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%'");
                sbQuery.AppendLine(" AND AA.COMP_CODE='" + oPRP.CompCode + "' AND AA.ASSET_APPROVED = 'False' AND AA.SOLD_SCRAPPED_STATUS IS NULL ORDER BY AA.ASSET_CODE,AA.PORT_NO");
            }
            else if (oPRP.OperationType == "REPLACED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME");
                sbQuery.AppendLine(" FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" INNER JOIN ASSET_REPLACEMENT AR ON AA.ASSET_CODE = AR.ACTIVE_IN_ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%' AND AA.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND AA.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.COMP_CODE='" + oPRP.CompCode + "' AND");
                sbQuery.AppendLine(" AA.ASSET_APPROVED = 'False' AND AA.SOLD_SCRAPPED_STATUS IS NULL ORDER BY AA.ASSET_CODE,AA.PORT_NO");
            }
            else if (oPRP.OperationType == "TRANSFERRED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME");
                sbQuery.AppendLine(" FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" INNER JOIN ASSET_TRANSFER AT ON AA.ASSET_CODE = AT.ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%' AND AA.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND AA.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' -- AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.ASSET_APPROVED = 'False' AND AA.SOLD_SCRAPPED_STATUS IS NULL ORDER BY AA.ASSET_CODE,AA.PORT_NO");
            }
            else if (oPRP.OperationType == "SWAPPED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME");
                sbQuery.AppendLine(" FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH1 ON AA.ASSET_CODE = SH1.ASSET_CODE1 AND SH1.COMP_CODE='" + oPRP.CompCode + "' AND AA.ASSET_APPROVED='0'");
                sbQuery.AppendLine(" UNION");
                sbQuery.AppendLine(" SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME");
                sbQuery.AppendLine(" FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AA.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH2 ON AA.ASSET_CODE = SH2.ASSET_CODE2 AND SH2.COMP_CODE='" + oPRP.CompCode + "' AND AA.ASSET_APPROVED='0'");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%' AND AA.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND AA.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.[MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.SOLD_SCRAPPED_STATUS IS NULL ORDER BY AA.ASSET_CODE,AA.PORT_NO");
            }
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset details to be populated for being updated.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetAssetDetailsForUpdate(string _AssetCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT AA.*,CM.CATEGORY_NAME,LM.LOC_NAME FROM ASSET_ACQUISITION AA INNER JOIN CATEGORY_MASTER CM");
            sbQuery.AppendLine(" ON AA.CATEGORY_CODE = CM.CATEGORY_CODE");
            sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM");
            sbQuery.AppendLine(" ON AA.ASSET_LOCATION = LM.LOC_CODE");
            sbQuery.AppendLine(" WHERE AA.ASSET_CODE = '" + _AssetCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get process list under a department in a company/location.
        /// </summary>
        /// <returns></returns>
        public DataTable PopulateProcess(string DeptCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT PROCESS_CODE,PROCESS_NAME FROM PROCESS_MASTER WHERE");
            sbQuery.AppendLine(" DEPT_CODE = '" + DeptCode + "' AND COMP_CODE='" + CompCode + "' AND ACTIVE='1'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get process list in a company/location.
        /// </summary>
        /// <returns></returns>
        public DataTable PopulateProcess(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT PROCESS_CODE,PROCESS_NAME FROM PROCESS_MASTER WHERE");
            sbQuery.AppendLine(" COMP_CODE='" + CompCode + "' AND ACTIVE='1'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get process-wise owner name.
        /// </summary>
        /// <param name="ProcessCode"></param>
        /// <returns></returns>
        public DataTable GetProcessOwner(string ProcessCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT PROCESS_OWNER FROM PROCESS_MASTER WHERE PROCESS_CODE='" + ProcessCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset details for update sold/scrapped status.
        /// </summary>
        /// <param name="AssetType"></param>
        /// <param name="AssetCode"></param>
        /// <param name="AssetID"></param>
        /// <param name="SerialCode"></param>
        /// <returns></returns>
        public DataTable GetAssetDetailsForSoldScrapped(string StatusType, AssetAcquisition_PRP oPRP)
        {
            if (StatusType == "SCRAPPED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT ACQ.ASSET_CODE, ACQ.ASSET_ID, ACQ.SERIAL_CODE, ACQ.ASSET_MAKE, ACQ.MODEL_NAME, CM.CATEGORY_NAME, LM.LOC_NAME,");
                sbQuery.AppendLine(" ACQ.Project_Name FROM ASSET_ACQUISITION ACQ");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON ACQ.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON ACQ.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" WHERE ACQ.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND ACQ.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                sbQuery.AppendLine(" AND ACQ.ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND ACQ.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ACQ.ASSET_MAKE lIKE '" + oPRP.AssetMakeName + "%' ");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND ACQ.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND ACQ.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND ACQ.COMP_CODE='" + oPRP.CompCode + "' AND ACQ.Project_Name LIKE '" + oPRP.AssetProcess + "%' AND ACQ.SOLD_SCRAPPED_STATUS IS NULL AND ASSET_APPROVED = 'True'");
            }
            else if (StatusType == "SOLD")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT ACQ.ASSET_CODE, ACQ.ASSET_ID, ACQ.SERIAL_CODE, ACQ.ASSET_MAKE, ACQ.MODEL_NAME, CM.CATEGORY_NAME, LM.LOC_NAME,");
                sbQuery.AppendLine(" ACQ.Project_Name FROM ASSET_ACQUISITION ACQ");
                sbQuery.AppendLine(" INNER JOIN CATEGORY_MASTER CM ON ACQ.CATEGORY_CODE = CM.CATEGORY_CODE");
                sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON ACQ.ASSET_LOCATION = LM.LOC_CODE");
                sbQuery.AppendLine(" WHERE ACQ.ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND ACQ.ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND ACQ.SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
                sbQuery.AppendLine(" AND ACQ.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ACQ.ASSET_MAKE lIKE '" + oPRP.AssetMakeName + "%' ");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND ACQ.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND ACQ.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND ACQ.COMP_CODE='" + oPRP.CompCode + "' AND ACQ.Project_Name LIKE '" + oPRP.AssetProcess + "%' AND ACQ.SOLD_SCRAPPED_STATUS = 'SCRAPPED' AND ASSET_APPROVED = 'True'");
            }
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Save/update assets details as SCRAPPED/SOLD status.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <param name="OpType"></param>
        /// <returns></returns>
        public bool SaveAssetSoldScrapped(AssetAcquisition_PRP oPRP, string OpType)
        {
            int iRes = 0;
            bool bResult = false;
            if (OpType == "SOLD")
            {
                //sbQuery = new StringBuilder();
                //sbQuery.AppendLine("INSERT INTO [ASSET_SOLD_DETAILS] ([REFERENCE_INVOICE_NO],[VENDOR_CODE],[CONTACT_NAME],[COMPANY_EMAIL],[COMPANY_ADDRESS],[SOLD_DATE]");
                //sbQuery.AppendLine(",[ASSET_CODE],[ASSET_ID],[SERIAL_CODE],[REMARKS],[STATUS],[COMP_CODE])");
                //sbQuery.AppendLine(" VALUES ");
                //sbQuery.AppendLine("('" + oPRP.RefInvoiceNo + "','" + oPRP.VendorCode + "','" + oPRP.ContactName + "','" + oPRP.CompanyEmail + "','" + oPRP.CompanyAddress + "','" + oPRP.SoldDate + "'");
                //sbQuery.AppendLine(",'" + oPRP.AssetCode + "','" + oPRP.AssetID + "','" + oPRP.AssetSerialCode + "','" + oPRP.Remarks + "','SOLD','" + oPRP.CompCode + "')");

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("UPDATE [ASSET_SOLD_DETAILS] SET [REFERENCE_INVOICE_NO] = '" + oPRP.RefInvoiceNo + "',[VENDOR_CODE] = '" + oPRP.VendorCode + "',[CONTACT_NAME] = '" + oPRP.ContactName + "'");
                sbQuery.AppendLine(",[COMPANY_ADDRESS] = '" + oPRP.CompanyAddress + "',[SOLD_DATE] = '" + oPRP.SoldDate + "',[REMARKS] = '" + oPRP.Remarks + "',[SOLD_VALUE] = '" + oPRP.SoldValue + "',[STATUS] = 'SOLD',[COMPANY_EMAIL] = '" + oPRP.CompanyEmail + "'");
                sbQuery.AppendLine(" WHERE [ASSET_CODE] = '" + oPRP.AssetCode + "' AND [COMP_CODE] = '" + oPRP.CompCode + "'");
                iRes = oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("UPDATE ASSET_ACQUISITION SET SOLD_SCRAPPED_STATUS='SOLD'");
                sbQuery.AppendLine(" WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND ASSET_ID='" + oPRP.AssetID + "' AND SERIAL_CODE='" + oPRP.AssetSerialCode + "'");
                iRes = oDb.ExecuteQuery(sbQuery.ToString());

                if (iRes > 0)
                    bResult = true;
            }
            if (OpType == "SCRAPPED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("INSERT INTO [ASSET_SOLD_DETAILS] ([REFERENCE_INVOICE_NO],[ASSET_CODE],[ASSET_ID],");
                sbQuery.AppendLine("[SERIAL_CODE],[REMARKS],[SCRAP_DATE],[STATUS],[COMP_CODE])");
                sbQuery.AppendLine(" VALUES ");
                sbQuery.AppendLine("('" + oPRP.RefInvoiceNo + "','" + oPRP.AssetCode + "','" + oPRP.AssetID + "',");
                sbQuery.AppendLine("'" + oPRP.AssetSerialCode + "','" + oPRP.Remarks + "','" + oPRP.ScrapDate + "','SCRAPPED','" + oPRP.CompCode + "')");
                iRes = oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("UPDATE ASSET_ACQUISITION SET SOLD_SCRAPPED_STATUS='SCRAPPED'");
                sbQuery.AppendLine(" WHERE ASSET_CODE='" + oPRP.AssetCode + "' AND ASSET_ID='" + oPRP.AssetID + "' AND SERIAL_CODE='" + oPRP.AssetSerialCode + "'");
                iRes = oDb.ExecuteQuery(sbQuery.ToString());
                if (iRes > 0)
                    bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// Deleting asset sold/scrapped details and updating asset acquisition table.
        /// </summary>
        /// <param name="oPRP"></param>
        public void DeleteSoldScrappedDetails(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_SOLD_DETAILS] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE [ASSET_ACQUISITION] SET [SOLD_SCRAPPED_STATUS] = NULL");
            sbQuery.AppendLine(" WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());
        }

        /// <summary>
        /// Get PRN file for asset barcode printing.
        /// </summary>
        /// <returns></returns>OK
        public string GetPRNFile()
        {
            string strPRN = "";
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETPRNFILE'");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            strPRN = dt.Rows[0]["PRN_FILE_DATA"].ToString();
            return strPRN;
        }

        /// <summary>
        /// Get FAMS ID,Serial No., Model Name etc. as per asset code selected.
        /// </summary>
        /// <param name="_AssetCode"></param>
        /// <returns></returns>
        public DataTable GetAssetDetails(string _AssetCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT ASSET_ID,SERIAL_CODE,ASSET_ID,PO_NUMBER,MODEL_NAME,ASSET_TYPE FROM ASSET_ACQUISITION");
            sbQuery.AppendLine(" WHERE ASSET_CODE='" + _AssetCode + "' AND COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Delete asset details from asset acquisition table (if not allocated).
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public string DeleteAssetDetails(string _AssetCode, string _CompCode)
        {
            string DelRslt = "";
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM ASSET_ACQUISITION WHERE ASSET_CODE='" + _AssetCode + "' AND COMP_CODE='" + _CompCode + "' AND ASSET_ALLOCATED='0'");
            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [ASSET_TRANSFER] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [ASSET_SWAP_HISTORY] WHERE [ASSET_CODE1]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [ASSET_ALLOCATION] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [ASSET_SOLD_DETAILS] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [ASSET_REPLACEMENT] WHERE [ACTIVE_IN_ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [CALL_LOG_MGMT] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [GATEPASS_ASSETS] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());

                sbQuery = new StringBuilder();
                sbQuery.AppendLine("DELETE FROM [RECONCILED_ASSET_CODES] WHERE [ASSET_CODE]='" + _AssetCode + "' AND [COMP_CODE]='" + _CompCode + "'");
                oDb.ExecuteQuery(sbQuery.ToString());
            }
            if (iRes > 0)
                DelRslt = "SUCCESS";
            else
                DelRslt = "ALLOCATED";
            return DelRslt;
        }

        /// <summary>
        /// Approve asset details in order to use asset for further process.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool ApproveAssetDetails(AssetAcquisition_PRP oPRP)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE ASSET_ACQUISITION SET ASSET_APPROVED = 'True'");
            sbQuery.AppendLine(" WHERE ASSET_CODE = '" + oPRP.AssetCode + "' AND SERIAL_CODE = '" + oPRP.AssetSerialCode + "'");
            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
                bResult = true;
            return bResult;
        }

        /// <summary>
        /// Approve asset details in order to use asset for further process.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public bool ApproveAssetDetails(AssetAcquisition_PRP oPRP, string ApproveAll)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE ASSET_ACQUISITION SET ASSET_APPROVED = 'True'");
            sbQuery.AppendLine(" WHERE ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%'");
            sbQuery.AppendLine(" AND ASSET_TYPE = '" + oPRP.AssetType + "' AND ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
            if (oPRP.AssetModelName != "")
                sbQuery.AppendLine(" AND [MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
            else
                sbQuery.AppendLine(" AND [MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
            sbQuery.AppendLine(" AND CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%'");
            sbQuery.AppendLine(" AND COMP_CODE='" + oPRP.CompCode + "'");
            int iRes = oDb.ExecuteQuery(sbQuery.ToString());
            if (iRes > 0)
                bResult = true;
            return bResult;
        }

        /// <summary>
        /// Get asset count (unapproved/approved) based on search criteria.
        /// </summary>
        /// <returns></returns>
        public string GetAssetsCount(AssetAcquisition_PRP oPRP)
        {
            string AssetCount = "";
            if (oPRP.OperationType == "")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COUNT(*) UNAPPROVED FROM ASSET_ACQUISITION WHERE ASSET_TYPE='" + oPRP.AssetType + "'");
                sbQuery.AppendLine(" AND COMP_CODE='" + oPRP.CompCode + "' AND CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND ASSET_APPROVED='False'");
                sbQuery.AppendLine(" AND ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND MODEL_NAME IN (" + oPRP.AssetModelName + ");");
                else
                    sbQuery.AppendLine(" AND MODEL_NAME LIKE '" + oPRP.AssetModelName + "%';");

                sbQuery.AppendLine(" SELECT COUNT(*) APPROVED FROM ASSET_ACQUISITION WHERE ASSET_TYPE='" + oPRP.AssetType + "'");
                sbQuery.AppendLine(" AND COMP_CODE='" + oPRP.CompCode + "' AND CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND ASSET_APPROVED='True'");
                sbQuery.AppendLine(" AND ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
            }
            else if (oPRP.OperationType == "REPLACED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COUNT(*) UNAPPROVED FROM ASSET_ACQUISITION AA INNER JOIN ASSET_REPLACEMENT AR");
                sbQuery.AppendLine(" ON AA.ASSET_CODE = AR.ACTIVE_IN_ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE='" + oPRP.AssetType + "' AND AA.COMP_CODE='" + oPRP.CompCode + "' AND");
                sbQuery.AppendLine(" AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.ASSET_APPROVED='False' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%';");
                sbQuery.AppendLine(" SELECT COUNT(*) APPROVED FROM ASSET_ACQUISITION AA INNER JOIN ASSET_REPLACEMENT AR");
                sbQuery.AppendLine(" ON AA.ASSET_CODE = AR.ACTIVE_IN_ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE='" + oPRP.AssetType + "' AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%'  AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.ASSET_APPROVED='True' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
            }
            else if (oPRP.OperationType == "TRANSFERRED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COUNT(*) UNAPPROVED FROM ASSET_ACQUISITION AA INNER JOIN ASSET_TRANSFER AT");
                sbQuery.AppendLine(" ON AA.ASSET_CODE = AT.ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE='" + oPRP.AssetType + "' AND AA.COMP_CODE='" + oPRP.CompCode + "' AND");
                sbQuery.AppendLine(" AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.ASSET_APPROVED='False' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%';");
                sbQuery.AppendLine(" SELECT COUNT(*) APPROVED FROM ASSET_ACQUISITION AA INNER JOIN ASSET_TRANSFER AT");
                sbQuery.AppendLine(" ON AA.ASSET_CODE = AT.ASSET_CODE");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE='" + oPRP.AssetType + "' AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%'  AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.ASSET_APPROVED='True' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
            }
            else if (oPRP.OperationType == "SWAPPED")
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("SELECT COUNT(*) UNAPPROVED FROM");
                sbQuery.AppendLine("(SELECT AA.* FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH1 ON AA.ASSET_CODE = SH1.ASSET_CODE1 AND SH1.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.ASSET_APPROVED='0' UNION");
                sbQuery.AppendLine(" SELECT AA.* FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH2 ON AA.ASSET_CODE = SH2.ASSET_CODE2 AND SH2.COMP_CODE='" + oPRP.CompCode + "' AND AA.ASSET_APPROVED='0'");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.SOLD_SCRAPPED_STATUS IS NULL");
                sbQuery.AppendLine(" ) A;");
                sbQuery.AppendLine(" SELECT COUNT(*) APPROVED FROM");
                sbQuery.AppendLine(" (SELECT AA.* FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH1 ON AA.ASSET_CODE = SH1.ASSET_CODE1 AND SH1.COMP_CODE = '" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.ASSET_APPROVED='1' UNION");
                sbQuery.AppendLine(" SELECT AA.* FROM ASSET_ACQUISITION AA");
                sbQuery.AppendLine(" INNER JOIN ASSET_SWAP_HISTORY SH2 ON AA.ASSET_CODE = SH2.ASSET_CODE2 AND SH2.COMP_CODE = '" + oPRP.CompCode + "' AND AA.ASSET_APPROVED='1'");
                sbQuery.AppendLine(" WHERE AA.ASSET_TYPE = '" + oPRP.AssetType + "' AND AA.ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
                if (oPRP.AssetModelName != "")
                    sbQuery.AppendLine(" AND AA.MODEL_NAME IN (" + oPRP.AssetModelName + ")");
                else
                    sbQuery.AppendLine(" AND AA.MODEL_NAME LIKE '" + oPRP.AssetModelName + "%'");
                sbQuery.AppendLine(" AND AA.CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND AA.ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%' AND AA.COMP_CODE='" + oPRP.CompCode + "'");
                sbQuery.AppendLine(" AND AA.SOLD_SCRAPPED_STATUS IS NULL");
                sbQuery.AppendLine(" ) B");
            }
            DataSet ds = oDb.GetDataSet(sbQuery.ToString());
            AssetCount = ds.Tables[0].Rows[0]["UNAPPROVED"].ToString() + "^" + ds.Tables[1].Rows[0]["APPROVED"].ToString();
            return AssetCount;
        }

        /// <summary>
        /// Check if serial no. of the asset already exists in asset acquisition.
        /// </summary>
        /// <param name="SerialCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public bool CheckDuplicateSerialNo(string SerialCode, string LocCode)
        {
            bool bExists = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='CHECKDUPLICATESERIALNO',@SERIAL_CODE='" + SerialCode + "',@STORAGE_LOC_CODE='" + LocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows[0]["SC"].ToString() != "0")
                bExists = true;
            return bExists;
        }

        /// <summary>
        /// Check if IMEI no. of the asset already exists in asset acquisition.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>OK
        public bool CheckDuplicateIMEINo(string IMEINO, string LocCode)
        {
            bool bExists = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='CHECKDUPLICATEIMEINO',@ASSET_IMEINO='" + IMEINO + "',@STORAGE_LOC_CODE='" + LocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows[0]["IMEI"].ToString() != "0")
                bExists = true;
            return bExists;
        }

        /// <summary>
        /// Get assets list for being exported into excel sheet.
        /// </summary>
        /// <param name="AssetType"></param>
        /// <returns></returns>
        public DataTable GetAssetsForExport(string AssetType, string AssetCategoryCode, string AssetMakeName, string AssetModelName, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT [ASSET_CODE],[ASSET_ID] AS [FAMS_ID],[SERIAL_CODE],[CATEGORY_CODE],[ASSET_LOCATION],[AMC_WARRANTY],CONVERT(VARCHAR,NULLIF([AMC_WARRANTY_START_DATE],''),101) AS [AMC_WARRANTY_START_DATE],");
            sbQuery.AppendLine("CONVERT(VARCHAR,NULLIF([AMC_WARRANTY_END_DATE],''),101) AS [AMC_WARRANTY_END_DATE],[VENDOR_CODE],CONVERT(VARCHAR,NULLIF([INSTALLED_DATE],''),101) AS [INSTALLED_DATE],CONVERT(VARCHAR,NULLIF([PURCHASED_DATE],''),101) AS [PURCHASED_DATE],[PURCHASED_AMT],[PO_NUMBER],");
            sbQuery.AppendLine("CONVERT(VARCHAR,NULLIF([PO_DATE],''),101) AS [PO_DATE],[INVOICE_NO],CONVERT(VARCHAR,NULLIF([SALE_DATE],''),101) AS [SALE_DATE],[SALE_AMT],[ASSET_MAKE],[MODEL_NAME],[ASSET_PROCESS],[SECURITY_CLASSIFICATION],");
            sbQuery.AppendLine("[ASSET_SIZE],[ASSET_VLAN],[ASSET_HDD],[ASSET_PROCESSOR],[ASSET_RAM],[ASSET_IMEI_NO],[ASSET_PHONE_MEMORY],");
            sbQuery.AppendLine("[ASSET_SERVICE_PROVIDER],[ASSET_TYPE],[ASSET_BOE],[ASSET_REGISTER_NO],[BONDED_TYPE],[CAPITALISED_STATUS],");
            sbQuery.AppendLine("[VERIFIABLE_STATUS],[PORT_NO],[WORKSTATION_NO],[COST_CENTER_NO],[SECURITY_GATE_ENTRY_NO],");
            sbQuery.AppendLine("CONVERT(VARCHAR,NULLIF([SECURITY_GATE_ENTRY_DATE],''),101) AS [SECURITY_GATE_ENTRY_DATE],[COMP_CODE],[COMPANY_NAME],[CUSTOMER_ORDER_NO],[DEPARTMENT]");
            sbQuery.AppendLine(" FROM [ASSET_ACQUISITION] WHERE [ASSET_TYPE]='" + AssetType + "' AND [CATEGORY_CODE] LIKE '" + AssetCategoryCode + "%'");
            sbQuery.AppendLine(" AND [ASSET_MAKE] LIKE '" + AssetMakeName + "%'");
            if (AssetModelName != "")
                sbQuery.AppendLine(" AND [MODEL_NAME] IN (" + AssetModelName + ")");
            else
                sbQuery.AppendLine(" AND [MODEL_NAME] LIKE '" + AssetModelName + "%'");
            sbQuery.AppendLine(" AND [COMP_CODE]='" + CompCode + "' AND [ASSET_APPROVED]='1'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        public List<AssetDetails> GetAssetDetails(string AssetCode, string AssetCategory, string Make, string Model, string CompanyCode, string StoregLocation)
        {
            List<AssetDetails> lsts = new List<AssetDetails>();
            try
            {

                StringBuilder builder = new StringBuilder();
                builder.Append(@"  SELECT [ASSET_CODE] as[AssetCode], CATEGORY_CODE as[CategoryCode],[ASSET_ID] AS [FamsID],[ASSET_MAKE] as[AssetMake], [MODEL_NAME] as[AssetModel] , Count(*) as [Quantity]
            
			from ASSET_ACQUISITION
			where 
			 ( @CATEGORY_CODE ='' OR CATEGORY_CODE like @CATEGORY_CODE+'%')
			AND ( @ASSET_MAKE ='' OR ASSET_MAKE= @ASSET_MAKE)
		
           AND (@COMP_CODE ='' OR COMP_CODE =@COMP_CODE)
           AND (@Location ='' OR Location =@Location)
           AND isnull(Status,0) =0
           AND ISNULL(ASSET_APPROVED,0)  =1 
           AND ISNULL(IsRFIDApproved,0) =1
		
			Group by [ASSET_CODE],CATEGORY_CODE ,[ASSET_ID],[ASSET_MAKE], [MODEL_NAME]");//(@AssetCode ='' OR[ASSET_CODE]= @AssetCode)AND  	AND ( @MODEL_NAME ='' OR )

                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
                //cmd.Parameters.AddWithValue("@AssetCode", AssetCode);
                cmd.Parameters.AddWithValue("@CATEGORY_CODE", AssetCategory);
                cmd.Parameters.AddWithValue("@ASSET_MAKE", Make);
                cmd.Parameters.AddWithValue("@MODEL_NAME", Model);
                cmd.Parameters.AddWithValue("@COMP_CODE", CompanyCode);
                cmd.Parameters.AddWithValue("@Location", StoregLocation);
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = builder.ToString();
                System.Data.SqlClient.SqlDataReader reader = oDb.GetRecord(cmd);
                //if (reader.HasRows)
                //{
                while (reader.Read())
                {
                    AssetDetails obj = new AssetDetails();
                    obj.AssetCode = reader["AssetCode"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AssetCode"]);
                    obj.CategoryCode = reader["CategoryCode"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CategoryCode"]);
                    obj.AssetMake = reader["AssetMake"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AssetMake"]);
                    obj.AssetModel[0] = reader["AssetModel"] == DBNull.Value ? string.Empty : Convert.ToString(reader["AssetModel"]);
                    obj.Quantity = reader["Quantity"] == DBNull.Value ? default(Int32) : Convert.ToInt32(reader["Quantity"]);
                    obj.FamsID = reader["FamsID"] == DBNull.Value ? string.Empty : Convert.ToString(reader["FamsID"]);

                    lsts.Add(obj);
                }
                // }
                return lsts;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Get company/location based on login location.
        /// </summary>
        /// <returns></returns>
        //public DataTable PopulateCompany(string _CompCode)
        //{
        //    sbQuery = new StringBuilder();
        //    sbQuery.AppendLine("SELECT COMP_CODE,COMP_NAME FROM COMPANY_MASTER WHERE ACTIVE='1' AND COMP_CODE='" + _CompCode + "'");
        //    return oDb.GetDataTable(sbQuery.ToString());
        //}
        //OK
        public DataTable PopulateCompany(string _CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATECOMPANY',@COMP_CODE='" + _CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get department list based on login location.
        /// </summary>
        /// <returns></returns>OK
        public DataTable PopulateDepartment(string _CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEDEPARTMENT',@COMP_CODE='" + _CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset SCRAPPED/SOLD details for being viewed.
        /// </summary>
        /// <returns></returns>
        public DataTable GetSoldScrappedDetails(string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT [REFERENCE_INVOICE_NO],[VENDOR_CODE],[CONTACT_NAME],[COMPANY_ADDRESS],CONVERT(VARCHAR,NULLIF([SOLD_DATE],''),105) AS [SOLD_DATE]");
            sbQuery.AppendLine(",[ASSET_CODE],[ASSET_ID],[SERIAL_CODE],[SOLD_VALUE],CONVERT(VARCHAR,NULLIF([SCRAP_DATE],''),105) AS [SCRAP_DATE],[STATUS]");
            sbQuery.AppendLine(" FROM [ASSET_SOLD_DETAILS] WHERE [COMP_CODE]='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Update asset acquisition (AMC/Warranty) details when AMC details are updated.
        /// </summary>
        /// <param name="AMC_WARRANTY"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <param name="AssetCode"></param>
        /// <param name="SerialCode"></param>
        /// <param name="CompCode"></param>
        public void UpdateAssetAMCWarrantyDetails(string AMC_WARRANTY, DateTime StartDate, DateTime EndDate, string AssetCode, string SerialCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE [ASSET_ACQUISITION] SET [AMC_WARRANTY]='" + AMC_WARRANTY + "', [AMC_WARRANTY_START_DATE]='" + StartDate + "', [AMC_WARRANTY_END_DATE]='" + EndDate + "'");
            sbQuery.AppendLine(" WHERE [ASSET_CODE]='" + AssetCode + "' AND [SERIAL_CODE]='" + SerialCode + "' AND [COMP_CODE]='" + CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());
        }

        /// <summary>
        /// Check whether the asset is being transferred to another location.
        /// </summary>
        /// <param name="AssetCode"></param>
        /// <returns></returns>
        public bool ChkAssetTransferred(string AssetCode, string CompCode)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT COUNT(*) AS TRANS FROM [ASSET_TRANSFER] AT WHERE AT.[ASSET_CODE]='" + AssetCode + "'");
            sbQuery.AppendLine(" AND AT.[COMP_CODE]='" + CompCode + "' AND AT.[TO_LOCATION] IN ");
            sbQuery.AppendLine("(SELECT [LOC_CODE] FROM [LOCATION_MASTER] WHERE [COMP_CODE] <> '" + CompCode + "')");
            DataTable dt = oDb.GetDataTable(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["TRANS"].ToString() != "0")
                    bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// Check location code validity when asset is being saved/updated.
        /// </summary>
        /// <param name="LocationCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public bool ValidLocationCode(string LocationCode, string SLocCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDLOCATIONCODE',@LOC_CODE='" + LocationCode + "',@STORAGE_LOC_CODE='" + SLocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["LOC"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Check location code validity when asset is being saved/updated.
        /// </summary>
        /// <param name="LocationCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        /// added by amit chaubay 25/07/2018
        public bool ValidateCompLocation(string LocationCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDATECOMPLOCATION',@STORAGE_LOC_CODE='" + LocationCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["LOCATION"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Check process code validity when asset is being saved/updated.
        /// </summary>
        /// <param name="ProcessCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public bool ValidProcessCode(string ProcessCode, string CompCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.Append("SELECT COUNT(*) AS PRC FROM Project_Master   WHERE   PROJECT_CODE  ='" + ProcessCode + "' AND  ACTIVE='1' AND COMP_CODE='" + CompCode + "' ORDER BY PROJECT_NAME");
          //  sbQuery.AppendLine("SELECT COUNT(*) AS PRC FROM [PROCESS_MASTER] WHERE [PROCESS_CODE]='" + ProcessCode + "'");
         //   sbQuery.AppendLine(" AND [COMP_CODE]='" + CompCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["PRC"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        
        public bool ValidateSubProjectName(string ProjectName, string SubjectCode)
        {

            

                  bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT COUNT(*) AS PRC from SUB_Project_Master WHERE Project_Code ='" + ProjectName + "' AND SUB_Project_Code ='" + SubjectCode + "'");
           // sbQuery.Append("SELECT COUNT(*) AS PRC FROM Project_Master   WHERE   PROJECT_CODE  ='" + ProcessCode + "' AND  ACTIVE='1' AND COMP_CODE='" + CompCode + "' ORDER BY PROJECT_NAME");
          //  sbQuery.AppendLine("SELECT COUNT(*) AS PRC FROM [PROCESS_MASTER] WHERE [PROCESS_CODE]='" + ProcessCode + "'");
         //   sbQuery.AppendLine(" AND [COMP_CODE]='" + CompCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["PRC"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }


        /// <summary>
        /// Check department code validity when asset is being saved/updated.
        /// </summary>
        /// <param name="LocationCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public bool ValidDepartmentCode(string DeptCode, string CompCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDDEPARTMENTCODE',@DEPARTMENT_CODE='" + DeptCode + "',@COMP_CODE='" + CompCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["DPT"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Get a valid employee name based on employee code provided.
        /// </summary>
        /// <returns></returns>OK
        public string ValidEmployeeCode(string EmpCode, string SLocCode)
        {
            string EmpName = "";
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDEMPLOYEECODE',@EMP_CODE='" + EmpCode + "',@STORAGE_LOC_CODE='" + SLocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
                EmpName = dt.Rows[0]["EMPLOYEE_NAME"].ToString().Trim();
            else
                EmpName = "NOT_FOUND";
            return EmpName;
        }

        /// <summary>
        /// Get asset make based on category selected.
        /// </summary>
        /// <param name="CategoryCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public DataTable PopulateAssetMake(string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEASSETMAKE',@CATEGORY_CODE='" + CategoryCode + "',@COMP_CODE= '" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get asset model name based on category nad make selected.
        /// </summary>
        /// <param name="AssetMake"></param>
        /// <param name="CategoryCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public DataTable PopulateModelName(string AssetMake, string CategoryCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='POPULATEMODELNAME',@ASSET_MAKE='" + AssetMake + "',@CATEGORY_CODE='" + CategoryCode + "',@COMP_CODE= '" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Check whether serial code/no. exists in case of asset details updation.
        /// </summary>
        /// <param name="SerialCode"></param>
        /// <returns></returns>OK
        public bool ValidSerialNo(string SerialCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDSERIALNO',@SERIAL_CODE='" + SerialCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["SNO"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Check whether the category is valid while uploading asset through excel sheet.
        /// </summary>
        /// <param name="CategoryCode"></param>
        /// <returns></returns>OK
        public bool ValidCategoryCode(string CategoryCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDCATEGORYCODE',@CATEGORY_CODE='" + CategoryCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["CAT"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        public bool ValidDateFAMS_ID(string FAMS_ID)
        {
            bool bResult = false;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDFORMID', @ASSET_ID='" + FAMS_ID + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["FARMSIDCOUNT"].ToString() == "0")
                    bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// Category code cannot be changed when asset details are updated.
        /// </summary>
        /// <param name="AssetCode"></param>
        /// <param name="SerialCode"></param>
        /// <param name="CategoryCode"></param>
        /// <returns></returns>OK
        public bool CategoryCodeChanged(string AssetCode, string CategoryCode, string SLocCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='CATEGORYCODECHANGED',@ASSET_CODE='" + AssetCode + "',@STORAGE_LOC_CODE='" + SLocCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["CATEGORY_CODE"].ToString().Trim() == CategoryCode.Trim())
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Check whether the vendor exists on the location.
        /// </summary>
        /// <param name="VendorCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public bool ValidVendorCode(string VendorCode, string CompCode)
        {
            bool bResult = true;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='VALIDVENDORCODE',@VENDOR_CODE='" + VendorCode + "',@COMP_CODE='" + CompCode + "'");
            DataTable dt = oDb.GetDataTableInTransaction(sbQuery.ToString());
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["VENDOR"].ToString() == "0")
                    bResult = false;
            }
            return bResult;
        }

        /// <summary>
        /// Bulk deletion of assets from each database table as per criteria provided.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public int DeleteAssetsInBulk(AssetAcquisition_PRP oPRP)
        {
            int iResult = 0;
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_ACQUISITION] ");
            sbQuery.AppendLine(" WHERE ASSET_TYPE LIKE '" + oPRP.AssetType + "%' AND ASSET_CODE LIKE '" + oPRP.AssetCode + "%' AND SERIAL_CODE LIKE '" + oPRP.AssetSerialCode + "%' AND ASSET_MAKE LIKE '" + oPRP.AssetMakeName + "%'");
            if (oPRP.AssetModelName != "")
                sbQuery.AppendLine(" AND [MODEL_NAME] IN (" + oPRP.AssetModelName + ")");
            else
                sbQuery.AppendLine(" AND [MODEL_NAME] LIKE '" + oPRP.AssetModelName + "%'");
            sbQuery.AppendLine(" AND CATEGORY_CODE LIKE '" + oPRP.AssetCategoryCode + "%' AND ASSET_LOCATION LIKE '" + oPRP.AssetLocation + "%'");
            sbQuery.AppendLine(" AND AMC_WARRANTY LIKE '" + oPRP.AMC_Warranty + "%' AND VERIFIABLE_STATUS LIKE '" + oPRP.VerifiableType + "%'");
            sbQuery.AppendLine(" AND ASSET_APPROVED = '" + oPRP.Asset_Approved + "' AND COMP_CODE='" + oPRP.CompCode + "'");
            if (oPRP.Sold_Scrapped == "")
                sbQuery.AppendLine(" AND SOLD_SCRAPPED_STATUS IS NULL");
            else
                sbQuery.AppendLine(" AND SOLD_SCRAPPED_STATUS LIKE '" + oPRP.Sold_Scrapped + "%'");
            iResult = oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_TRANSFER] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_SWAP_HISTORY] WHERE [ASSET_CODE1]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_ALLOCATION] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_SOLD_DETAILS] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [ASSET_REPLACEMENT] WHERE [ACTIVE_IN_ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [CALL_LOG_MGMT] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [GATEPASS_ASSETS] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [RECONCILED_ASSET_CODES] WHERE [ASSET_CODE]='" + oPRP.AssetCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            sbQuery = new StringBuilder();
            sbQuery.AppendLine("DELETE FROM [RECONCILED_SERIAL_CODES] WHERE [SERIAL_CODES]='" + oPRP.AssetSerialCode + "' AND [COMP_CODE]='" + oPRP.CompCode + "'");
            oDb.ExecuteQuery(sbQuery.ToString());

            return iResult;
        }

        /// <summary>
        /// Get vendor master details
        /// </summary>
        /// <returns></returns>OK
        public DataTable GetVendor(string CompCode)
        {
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETVENDOR',@COMP_CODE='" + CompCode + "'");
                return oDb.GetDataTable(sbQuery.ToString());
            }
            catch (Exception ex)
            { throw ex; }
        }

        /// <summary>
        /// Get Vendor details based on vendor name selected in sold/scrapped assets.
        /// </summary>
        /// <param name="VendorCode"></param>
        /// <param name="CompCode"></param>
        /// <returns></returns>OK
        public DataTable GetVendorDetails(string VendorCode, string CompCode)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='GETVENDORDETAILS',@VENDOR_CODE='" + VendorCode + "',@COMP_CODE='" + CompCode + "'");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Fetches AMC details based on filter criteria (all/active/expired).
        /// </summary>
        /// <param name="_AMCType"></param>
        /// <returns></returns>
        public DataTable GetAMCDetails(AssetAcquisition_PRP oPRP, bool _VendorWiseAMC)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("SELECT CONVERT(VARCHAR,NULLIF(AACQ.AMC_WARRANTY_START_DATE,''),105) AS AMC_WARRANTY_START_DATE,");
            sbQuery.AppendLine(" CONVERT(VARCHAR,NULLIF(AACQ.AMC_WARRANTY_END_DATE,''),105) AS AMC_WARRANTY_END_DATE,AACQ.ASSET_CODE,");
            sbQuery.AppendLine(" AACQ.SERIAL_CODE,AACQ.PO_NUMBER,LM.LOC_NAME,AACQ.ASSET_MAKE,AACQ.MODEL_NAME,ISNULL(VM.VENDOR_NAME,'') AS VENDOR_NAME");
            sbQuery.AppendLine(" FROM ASSET_ACQUISITION AACQ LEFT OUTER JOIN VENDOR_MASTER VM");
            sbQuery.AppendLine(" ON AACQ.VENDOR_CODE = VM.VENDOR_CODE");
            sbQuery.AppendLine(" INNER JOIN LOCATION_MASTER LM ON AACQ.ASSET_LOCATION = LM.LOC_CODE");
            sbQuery.AppendLine(" WHERE AACQ.AMC_WARRANTY = 'AMC' AND AACQ.COMP_CODE='" + oPRP.CompCode + "' AND AACQ.COMP_CODE = LM.COMP_CODE");
            if (_VendorWiseAMC)
            {
                sbQuery.AppendLine(" AND AACQ.VENDOR_CODE='" + oPRP.AMCVendorCode + "'");
            }
            if (oPRP.ExpiredAMC == true)
            {
                sbQuery.AppendLine(" AND AACQ.AMC_WARRANTY_END_DATE < GETDATE()");
            }
            else if (oPRP.ActiveAMC == true)
            {
                sbQuery.AppendLine(" AND AACQ.AMC_WARRANTY_END_DATE >= GETDATE()");
            }
            sbQuery.AppendLine(" ORDER BY ASSET_CODE");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Get Process code/name details to be populated in dropdownlist.
        /// </summary>
        /// <param name="CompCode"></param>
        /// <returns></returns>
        public DataTable GetProcess(string CompCode)
        {
            sbQuery = new StringBuilder();
            //sbQuery.AppendLine("SELECT PROCESS_CODE,PROCESS_NAME FROM PROCESS_MASTER");
            //sbQuery.AppendLine(" WHERE COMP_CODE = '" + CompCode + "'");
            sbQuery.Append("SELECT PROJECT_CODE  , PROJECT_NAME FROM Project_Master WHERE ACTIVE='1' AND COMP_CODE='" + CompCode + "' ORDER BY PROJECT_NAME");
            return oDb.GetDataTable(sbQuery.ToString());
        }

        /// <summary>
        /// Update asset serial no. based on old serial code and asset code.
        /// </summary>
        /// <param name="oPRP"></param>OK
        public void UpdateAssetSerialNo(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("EXEC sp_AssetAcquisition @TYPE='UPDATEASSETSERIALNO',@NEW_SERIAL_CODE='" + oPRP.NewSerialNo + "',@COMP_CODE='" + oPRP.CompCode + "',");
            sbQuery.AppendLine(" @CREATED_BY = '" + oPRP.CreatedBy + "',@ASSET_CODE = '" + oPRP.AssetCode + "',@SERIAL_CODE = '" + oPRP.OldSerialNo + "'");
            oDb.ExecuteQuery(sbQuery.ToString());
        }

        /// <summary>
        ///  Allocate assets in bulk mode.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public int AllocateExistingAssets(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("INSERT INTO [ASSET_ALLOCATION] ([ASSET_CODE],[ASSET_ALLOCATION_DATE],");
            sbQuery.AppendLine(" [ASSET_ALLOCATED_EMP],[ALLOCATED_EMP_ID],[ALLOCATED_DEPARTMENT],[ALLOCATED_PROCESS],");
            sbQuery.AppendLine(" [ASSET_LOCATION],[COMP_CODE],[PORT_NO],[VLAN],");
            sbQuery.AppendLine(" [TICKET_NO],[GATEPASS_NO],[WORKSTATION_NO],[CREATED_BY],[CREATED_ON])");
            sbQuery.AppendLine(" VALUES ");
            sbQuery.AppendLine("('" + oPRP.AssetCode + "','" + oPRP.AllocationDate + "',");
            sbQuery.AppendLine(" '" + oPRP.AllocatedTo + "','" + oPRP.AllocatedToId + "','" + oPRP.DeptCode + "','" + oPRP.AssetProcess + "',");
            sbQuery.AppendLine(" '" + oPRP.AssetLocation + "','" + oPRP.CompCode + "','" + oPRP.PortNo + "','" + oPRP.AssetVlan + "',");
            sbQuery.AppendLine(" '" + oPRP.TicketNo + "','" + oPRP.GatePassNo + "','" + oPRP.WorkStationNo + "','" + oPRP.CreatedBy + "',GETDATE())");
            return oDb.ExecuteQueryTran(sbQuery.ToString());
        }

        /// <summary>
        /// update asset acquisition for bulk asset allocation.
        /// </summary>
        /// <param name="oPRP"></param>
        /// <returns></returns>
        public int UpdateAssetAcquisition(AssetAcquisition_PRP oPRP)
        {
            sbQuery = new StringBuilder();
            sbQuery.AppendLine("UPDATE ASSET_ACQUISITION SET ASSET_ALLOCATED='True',Project_Name='" + oPRP.AssetProcess + "',DEPARTMENT='" + oPRP.DeptCode + "',");
            sbQuery.AppendLine(" PORT_NO='" + oPRP.PortNo + "' WHERE ASSET_CODE='" + oPRP.AssetCode + "'");
            return oDb.ExecuteQueryTran(sbQuery.ToString());
        }
    }
}