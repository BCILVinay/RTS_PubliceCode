﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for AutoComplete
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class AutoComplete : System.Web.Services.WebService
{
    string strConnectionString = string.Empty;
    public AutoComplete()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod]
    public string[] GetAssetCode(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ASSET_CODE FROM ASSET_ACQUISITION WHERE ASSET_CODE LIKE '" + prefixText + "%'");
            sbQuery.Append(" AND SOLD_SCRAPPED_STATUS IS NULL");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;           
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;
            
            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string[] GetAssetSerialNo(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT SERIAL_CODE FROM ASSET_ACQUISITION WHERE SERIAL_CODE LIKE '" + prefixText + "%'");
            sbQuery.Append(" AND SOLD_SCRAPPED_STATUS IS NULL");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;

            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string[] GetAssetWorkStationNo(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT WORKSTATION_NO FROM ASSET_ACQUISITION WHERE WORKSTATION_NO LIKE '" + prefixText + "%'");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;

            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string[] GetAssetPortNo(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT PORT_NO FROM ASSET_ACQUISITION WHERE PORT_NO LIKE '" + prefixText + "%'");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;

            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string[] GetAssetFAMSId(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT ASSET_ID FROM ASSET_ACQUISITION WHERE ASSET_ID LIKE '" + prefixText + "%'");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;

            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public string[] GetAssetPONo(string prefixText)
    {
        try
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append("SELECT DISTINCT PO_NUMBER FROM ASSET_ACQUISITION WHERE PO_NUMBER LIKE '" + prefixText + "%'");
            if (clsGeneral.gStrAssetType == "IT")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrIT"].ToString();
            if (clsGeneral.gStrAssetType == "ADMIN")
                strConnectionString = ConfigurationManager.AppSettings["ConnStrAdmin"].ToString();
            SqlDataAdapter da = new SqlDataAdapter(sbQuery.ToString(), strConnectionString);
            DataTable dt = new DataTable();
            da.Fill(dt);
            int iCnt = 0;
            if (dt.Rows.Count > 100)
                iCnt = 100;
            else
                iCnt = dt.Rows.Count;
            string[] items = new string[iCnt];
            int i = 0;

            foreach (DataRow dr in dt.Rows)
            {
                items.SetValue(dr[0].ToString(), i);
                i++;
                if (i > iCnt - 1)
                    break;
            }
            return items;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}