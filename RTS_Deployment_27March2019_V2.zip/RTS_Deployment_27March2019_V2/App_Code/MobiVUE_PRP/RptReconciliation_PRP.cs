﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace MobiVUE_ATS.PRP
{
    /// <summary>
    /// Summary description for RptReconciliation_PRP
    /// </summary>
    public class RptReconciliation_PRP
    {
        #region ASSET REPLACEMENT PROPERTIES
        public string AssetCode
        { get; set; }
        #endregion
    }
}