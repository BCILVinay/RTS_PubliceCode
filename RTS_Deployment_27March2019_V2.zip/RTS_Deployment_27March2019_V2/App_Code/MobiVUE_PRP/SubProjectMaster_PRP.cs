﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace MobiVUE_ATS.PRP
{
    /// <summary>
    /// Summary description for Process Master Properties
    /// </summary>
    public class SubProjectMaster_PRP
    {
        #region SUB PROJECT MASTER PROPERTIES   
        public string SubProjectCode
        { get; set; }
        public string ProjectCode
        { get; set; }
        public string SubProjectName
        { get; set; }
        public string ProjectManager
        { get; set; }
        public string AssignEmployee
        { get; set; }
        public string CreatedBy
        { get; set; }
        public string LocCode
        { get; set; }
        public string Remarks
        { get; set; }
        public string ModifiedBy
        { get; set; }
        public bool Active
        { get; set; }
        #endregion
    }
}