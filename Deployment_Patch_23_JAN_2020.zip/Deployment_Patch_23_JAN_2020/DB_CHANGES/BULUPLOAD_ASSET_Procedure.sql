







CREATE PROC [dbo].[USP_AssetAquestionBulkUpload]
(
  @FAMS_ID numeric(18,0) =NULL 
, @RUNNING_SERIAL_NO numeric(18,0) =NULL 
, @ASSET_CODE nvarchar(50) =NULL 
, @TAG_ID nvarchar(50) =NULL 
, @ASSET_ID nvarchar(50) =NULL 
, @SERIAL_CODE nvarchar(50) =NULL 
, @CATEGORY_CODE nvarchar(50) =NULL 
, @ASSET_LOCATION nvarchar(50) =NULL 
, @PLANT nvarchar(50) =NULL 
, @LOCATION nvarchar(50) =NULL 
, @CUSTOMER_ORDER_NO nvarchar(50) =NULL 
, @PROJECT_NAME nvarchar(50) =NULL 
, @SUB_PROJECT nvarchar(50) =NULL 
, @PROJECT_MANAGER nvarchar(50) =NULL 
, @ASSIGN_EMPLOYEE nvarchar(50) =NULL 
, @COMP_CODE nchar(20) =NULL 
, @VENDOR_CODE nvarchar(50) =NULL 
, @INSTALLED_DATE datetime =NULL 
, @PURCHASED_DATE datetime =NULL 
, @PURCHASED_AMT decimal =NULL 
, @CURRENCY nvarchar(50) =NULL 
, @TRANSFER_PRICE decimal =NULL 
, @LOCAL_CURRENCY decimal =NULL 
, @PO_NUMBER nvarchar(50) =NULL 
, @PO_DATE datetime =NULL 
, @INVOICE_NO nvarchar(50) =NULL 
, @SALE_DATE datetime =NULL 
, @SALE_AMT decimal =NULL 
, @CREATED_BY nvarchar(50) =NULL 
, @CREATED_ON datetime =NULL 
, @ASSET_MAKE nvarchar(50) =NULL 
, @MODEL_NAME nvarchar(50) =NULL 
, @ASSET_PROCESS nvarchar(50) =NULL 
, @SECURITY_CLASSIFICATION nvarchar(50) =NULL 
, @ASSET_SIZE nvarchar(50) =NULL 
, @ASSET_VLAN nvarchar(50) =NULL 
, @ASSET_HDD nvarchar(50) =NULL 
, @ASSET_PROCESSOR nvarchar(50) =NULL 
, @ASSET_RAM nvarchar(50) =NULL 
, @ASSET_IMEI_NO nvarchar(50) =NULL 
, @ASSET_PHONE_MEMORY nvarchar(50) =NULL 
, @ASSET_SERVICE_PROVIDER nvarchar(50) =NULL 
, @ASSET_TYPE nvarchar(50) =NULL 
, @ASSET_BOE nvarchar(50) =NULL 
, @ASSET_REGISTER_NO nvarchar(50) =NULL 
, @BONDED_TYPE nvarchar(50) =NULL 
, @BOND_NO nvarchar(50) =NULL 
, @CAPITALISED_STATUS nvarchar(50) =NULL 
, @VERIFIABLE_STATUS nvarchar(50) =NULL 
, @PORT_NO nvarchar(50) =NULL 
, @ASSET_ALLOCATED bit =NULL 
, @SOLD_SCRAPPED_STATUS nvarchar(50) =NULL 
, @SECURITY_GATE_ENTRY_NO nvarchar(50) =NULL 
, @SECURITY_GATE_ENTRY_DATE datetime =NULL 
, @AMC_WARRANTY_START_DATE datetime =NULL 
, @AMC_WARRANTY_END_DATE datetime =NULL 
, @REMARKS nvarchar(50) =NULL 
, @ASSET_APPROVED bit =NULL 
, @AMC_WARRANTY nvarchar(50) =NULL 
, @WORKSTATION_NO nvarchar(50) =NULL 
, @COST_CENTER_NO nvarchar(50) =NULL 
, @COMPANY_NAME nvarchar(50) =NULL 
, @DEPARTMENT_CODE nvarchar(50) =NULL 
, @INVENTORY_NOTE nvarchar(50) =NULL 
, @ASSET_DESCRIPTION nvarchar(50) =NULL 
, @ASSET_MAIN_TEXT nvarchar(50) =NULL 
, @ASSET_DESCRIPTION_1 nvarchar(50) =NULL 
, @ACCT_DE_TYPE_OF_ASSET nvarchar(50) =NULL 
, @ROOM nvarchar(50) =NULL 
, @BA nvarchar(50) =NULL 
, @UPDATED_ON datetime =NULL 
, @UPDATED_BY nvarchar(50) =NULL 
, @EXTRA_FIELD1 nvarchar(50) =NULL 
, @EXTRA_FIELD2 nvarchar(50) =NULL 
, @EXTRA_FIELD3 nvarchar(50) =NULL 
, @EXTRA_FIELD4 nvarchar(50) =NULL 
, @EXTRA_FIELD5 nvarchar(50) =NULL 
, @Status bit =NULL 
, @IsRFIDApproved bit =NULL 
, @RFIDApprovedOn datetime =NULL 
, @ApprovedOn datetime =NULL 
, @ApprovedBy varchar(50) =NULL 
, @ISLabelPrinted bit =NULL 
, @LabelPrintedON datetime =NULL 
, @LabelPrintedBy varchar =NULL 
)
AS 
BEGIN 



INSERT INTO [dbo].[ASSET_ACQUISITION]
           (
			--ACQUISITION_ID
		   [RUNNING_SERIAL_NO]
           ,[ASSET_CODE]
           ,[TAG_ID]
           ,[ASSET_ID]
           ,[SERIAL_CODE]
           ,[CATEGORY_CODE]
           ,[ASSET_LOCATION]
           ,[PLANT]
           ,[LOCATION]
           ,[CUSTOMER_ORDER_NO]
           ,[PROJECT_NAME]
           ,[SUB_PROJECT_NAME]
           ,[PROJECT_MANAGER]
           ,[ASSIGN_PRO_TO_EMP]
           ,[COMP_CODE]
           ,[VENDOR_CODE]
           ,[INSTALLED_DATE]
           ,[PURCHASED_DATE]
           ,[PURCHASED_AMT]
           ,[CURRENCY]
           ,[TRANSFER_PRICE]
           ,[LOCAL_CURRENCY]
           ,[PO_NUMBER]
           ,[PO_DATE]
           ,[INVOICE_NO]
           ,[SALE_DATE]
           ,[SALE_AMT]
           ,[CREATED_BY]
     ,[CREATED_ON]
           ,[ASSET_MAKE]
           ,[MODEL_NAME]
           ,[ASSET_PROCESS]
           ,[SECURITY_CLASSIFICATION]
           ,[ASSET_SIZE]
           ,[ASSET_VLAN]
           ,[ASSET_HDD]
           ,[ASSET_PROCESSOR]
           ,[ASSET_RAM]
           ,[ASSET_IMEI_NO]
           ,[ASSET_PHONE_MEMORY]
           ,[ASSET_SERVICE_PROVIDER]
           ,[ASSET_TYPE]
           ,[ASSET_BOE]
           ,[ASSET_REGISTER_NO]
           ,[BONDED_TYPE]
           ,[BOND_NO]
           ,[CAPITALISED_STATUS]
           ,[VERIFIABLE_STATUS]
           ,[PORT_NO]
           ,[ASSET_ALLOCATED]
           ,[SOLD_SCRAPPED_STATUS]
           ,[SECURITY_GATE_ENTRY_NO]
           ,[SECURITY_GATE_ENTRY_DATE]
           ,[AMC_WARRANTY_START_DATE]
           ,[AMC_WARRANTY_END_DATE]
           ,[REMARKS]
           ,[ASSET_APPROVED]
           ,[AMC_WARRANTY]
           ,[WORKSTATION_NO]
           ,[COST_CENTER_NO]
           ,[COMPANY_NAME]
           ,[DEPARTMENT]
           ,[INVENTORY_NOTE]
           ,[ASSET_DESCRIPTION]
           ,[ASSET_MAIN_TEXT]
           ,[ASSET_DESCRIPTION_1]
           ,[ACCT_DE]
           ,[ROOM]
           ,[BA]
           ,[UPDATED_ON]
           ,[UPDATED_BY]
           ,[EX_FIELD1]
           ,[EX_FIELD2]
           ,[EX_FIELD3]
           ,[EX_FIELD4]
           ,[EX_FIELD5]
           ,[Status]
           ,[IsRFIDApproved]
           ,[RFIDApprovedOn]
           ,[ApprovedOn]
           ,[ApprovedBy]
           ,[ISLabelPrinted]
           ,[LabelPrintedON]
           ,[LabelPrintedBy])
VALUES
(
 -- @FAMS_ID
 @RUNNING_SERIAL_NO
, @ASSET_CODE
, @TAG_ID
, @FAMS_ID
, @SERIAL_CODE
, @CATEGORY_CODE
, @ASSET_LOCATION
, @PLANT
, @LOCATION
, @CUSTOMER_ORDER_NO
, @PROJECT_NAME
, @SUB_PROJECT
, @PROJECT_MANAGER
, @ASSIGN_EMPLOYEE
, @COMP_CODE
, @VENDOR_CODE
, @INSTALLED_DATE
, @PURCHASED_DATE
, @PURCHASED_AMT
, @CURRENCY
, @TRANSFER_PRICE
, @LOCAL_CURRENCY
, @PO_NUMBER
, @PO_DATE
, @INVOICE_NO
, @SALE_DATE
, @SALE_AMT
, @CREATED_BY
, @CREATED_ON
, @ASSET_MAKE
, @MODEL_NAME
, @ASSET_PROCESS
, @SECURITY_CLASSIFICATION
, @ASSET_SIZE
, @ASSET_VLAN
, @ASSET_HDD
, @ASSET_PROCESSOR
, @ASSET_RAM
, @ASSET_IMEI_NO
, @ASSET_PHONE_MEMORY
, @ASSET_SERVICE_PROVIDER
, @ASSET_TYPE
, @ASSET_BOE
, @ASSET_REGISTER_NO
, @BONDED_TYPE
, @BOND_NO
, @CAPITALISED_STATUS
, @VERIFIABLE_STATUS
, @PORT_NO
, @ASSET_ALLOCATED
, @SOLD_SCRAPPED_STATUS
, @SECURITY_GATE_ENTRY_NO
, @SECURITY_GATE_ENTRY_DATE
, @AMC_WARRANTY_START_DATE
, @AMC_WARRANTY_END_DATE
, @REMARKS
, @ASSET_APPROVED
, @AMC_WARRANTY
, @WORKSTATION_NO
, @COST_CENTER_NO
, @COMPANY_NAME
, @DEPARTMENT_CODE
, @INVENTORY_NOTE
, @ASSET_DESCRIPTION
, @ASSET_MAIN_TEXT
, @ASSET_DESCRIPTION_1
, @ACCT_DE_TYPE_OF_ASSET
, @ROOM
, @BA
, @UPDATED_ON
, @UPDATED_BY
, @EXTRA_FIELD1
, @EXTRA_FIELD2
, @EXTRA_FIELD3
, @EXTRA_FIELD4
, @EXTRA_FIELD5
, @Status
, @IsRFIDApproved
, @RFIDApprovedOn
, @ApprovedOn
, @ApprovedBy
, @ISLabelPrinted
, @LabelPrintedON
, @LabelPrintedBy
);


END 